# Lucy Frontend Web

Structured React + TypeScript frontend for Lucy backend APIs:

- Identity
- LMS
- Event
- Syllabus

## Run

1. Copy `.env.example` to `.env`
2. Set `VITE_API_BASE_URL` (default backend is `http://localhost:8080/api/v1`)
3. Install and start:

```bash
npm install
npm run dev
```

## Quality checks

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

## Architecture

- `src/core`: shared HTTP client, auth storage, router, query client, error helpers
- `src/modules/*`: domain modules with `api`, `hooks`, `pages`, `schemas`
- `src/shared`: reusable UI primitives and query state components
