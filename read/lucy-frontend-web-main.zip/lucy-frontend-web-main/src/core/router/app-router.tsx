import { Navigate, Route, Routes } from "react-router-dom";
import { AppLayout } from "../../shared/components/app-layout";
import { EventPage } from "../../modules/event/pages/event-page";
import { UsersPage } from "../../modules/identity/pages/users-page";
import { LoginPage } from "../../modules/identity/pages/login-page";
import { LmsPage } from "../../modules/lms/pages/lms-page";
import { SyllabusPage } from "../../modules/syllabus/pages/syllabus-page";
import { AuthGuard } from "./auth-guard";
import { HomePage } from "./home-page";

export function AppRouter() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<AuthGuard />}>
        <Route element={<AppLayout />}>
          <Route index element={<HomePage />} />
          <Route path="/syllabus" element={<SyllabusPage />} />
          <Route path="/lms" element={<LmsPage />} />
          <Route path="/events" element={<EventPage />} />
          <Route path="/identity/users" element={<UsersPage />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

