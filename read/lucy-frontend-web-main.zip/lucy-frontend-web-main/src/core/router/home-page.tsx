import { SectionCard } from "../../shared/components/section-card";

export function HomePage() {
  return (
    <SectionCard title="Lucy Frontend Platform">
      <p>
        This project provides a structured frontend for Identity, LMS, Event, and Syllabus APIs
        with reusable module-based architecture.
      </p>
    </SectionCard>
  );
}

