import { Navigate, Outlet, useLocation } from "react-router-dom";
import { tokenStorage } from "../auth/token-storage";

export function AuthGuard() {
  const location = useLocation();
  const token = tokenStorage.getAccessToken();
  if (!token) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }
  return <Outlet />;
}

