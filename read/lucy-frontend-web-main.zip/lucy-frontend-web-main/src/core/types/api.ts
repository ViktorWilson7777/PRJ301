export type ApiErrorMessage = {
  errorCode?: string;
  message?: string;
  params?: Record<string, unknown>;
};

export type ApiResponse<T> = {
  success: boolean;
  message?: string;
  errorMessage?: ApiErrorMessage;
  data?: T;
};

export type PagingResponse<T> = {
  currentPage: number;
  pageSize: number;
  totalPages: number;
  totalElement: number;
  data: T[];
};

