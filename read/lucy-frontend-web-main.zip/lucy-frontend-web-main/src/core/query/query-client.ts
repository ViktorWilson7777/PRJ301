import { QueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { toReadableError } from "../errors/api-error";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      staleTime: 30_000,
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
    },
    mutations: {
      onError: (error) => {
        toast.error(toReadableError(error));
      },
    },
  },
});

