import { describe, expect, it } from "vitest";
import { ApiError, toReadableError } from "./api-error";

describe("ApiError", () => {
  it("keeps status and code metadata", () => {
    const error = new ApiError("Forbidden", 403, "auth.unauthorized");
    expect(error.status).toBe(403);
    expect(error.code).toBe("auth.unauthorized");
  });

  it("converts unknown error to generic text", () => {
    expect(toReadableError({})).toBe("Unexpected error");
  });
});