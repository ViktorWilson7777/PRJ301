export class ApiError extends Error {
  public readonly status?: number;
  public readonly code?: string;

  constructor(message: string, status?: number, code?: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

export function toReadableError(error: unknown): string {
  if (error instanceof ApiError) {
    const detail = [error.message, error.status ? `(HTTP ${error.status})` : "", error.code || ""]
      .filter(Boolean)
      .join(" ");
    return detail || "Unexpected API error";
  }
  if (error instanceof Error) return error.message;
  return "Unexpected error";
}

