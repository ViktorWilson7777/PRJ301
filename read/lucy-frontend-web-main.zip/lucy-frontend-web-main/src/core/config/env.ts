const FALLBACK_API_URL = "http://34.128.106.111:8080/api/v1";

export const env = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL ?? FALLBACK_API_URL,
  googleClientId: import.meta.env.VITE_GOOGLE_CLIENT_ID ?? "",
};

