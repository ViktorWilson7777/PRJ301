const ACCESS_TOKEN_KEY = "lucy.accessToken";
const REFRESH_TOKEN_KEY = "lucy.refreshToken";
const USER_KEY = "lucy.user";

export type SessionUser = {
  id: string;
  email: string;
  displayName?: string;
  roles?: string[];
};

export type AuthSession = {
  accessToken: string;
  refreshToken?: string;
  user?: SessionUser;
};

export const tokenStorage = {
  getAccessToken() {
    return localStorage.getItem(ACCESS_TOKEN_KEY);
  },
  getRefreshToken() {
    return localStorage.getItem(REFRESH_TOKEN_KEY);
  },
  getUser(): SessionUser | null {
    const raw = localStorage.getItem(USER_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as SessionUser;
    } catch {
      return null;
    }
  },
  saveSession(session: AuthSession) {
    localStorage.setItem(ACCESS_TOKEN_KEY, session.accessToken);
    if (session.refreshToken) {
      localStorage.setItem(REFRESH_TOKEN_KEY, session.refreshToken);
    }
    if (session.user) {
      localStorage.setItem(USER_KEY, JSON.stringify(session.user));
    }
  },
  setAccessToken(accessToken: string) {
    localStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
  },
  setRefreshToken(refreshToken: string) {
    localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
  },
  clearSession() {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },
};

