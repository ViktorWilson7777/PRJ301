import axios from "axios";
import { env } from "../config/env";
import { tokenStorage } from "../auth/token-storage";
import type { ApiResponse } from "../types/api";
import { ApiError } from "../errors/api-error";

const client = axios.create({
  baseURL: env.apiBaseUrl,
  timeout: 15000,
});

const rootClient = axios.create({
  timeout: 15000,
});

let isRefreshing = false;
let pendingQueue: Array<(token: string | null) => void> = [];

const isDev = import.meta.env.DEV;

function debugHttp(message: string, payload?: unknown) {
  if (!isDev) return;
  if (typeof payload === "undefined") {
    console.debug(`[http] ${message}`);
    return;
  }
  console.debug(`[http] ${message}`, payload);
}

function redirectToLoginIfNeeded() {
  if (typeof window === "undefined") return;
  if (window.location.pathname !== "/login") {
    window.location.replace("/login");
  }
}

function attachRequestInterceptor(instance: typeof client) {
  instance.interceptors.request.use((config) => {
    debugHttp(`${String(config.method || "GET").toUpperCase()} ${String(config.url || "")}`, {
      params: config.params,
      data: config.data,
    });
    const skipAuth = config.headers?.["x-skip-auth"];
    if (skipAuth) {
      delete config.headers["x-skip-auth"];
      return config;
    }
    const token = tokenStorage.getAccessToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });
}

attachRequestInterceptor(client);
attachRequestInterceptor(rootClient);

function withRootBase(url: string): string {
  if (/^https?:\/\//i.test(url)) return url;
  const match = env.apiBaseUrl.match(/^(https?:\/\/[^/]+)/i);
  if (match) return `${match[1]}${url}`;
  return url;
}

function pickHttpClient(url: string) {
  if (url.startsWith("/api/")) return rootClient;
  return client;
}

client.interceptors.response.use(
  (response) => {
    debugHttp(`OK ${String(response.config.method || "GET").toUpperCase()} ${String(response.config.url || "")}`, {
      status: response.status,
      data: response.data,
    });
    return response;
  },
  async (error) => {
    debugHttp(`ERR ${String(error?.config?.method || "GET").toUpperCase()} ${String(error?.config?.url || "")}`, {
      status: error?.response?.status,
      data: error?.response?.data,
    });
    const status = error?.response?.status as number | undefined;
    const code = error?.response?.data?.errorMessage?.errorCode as string | undefined;
    const originalRequest = error?.config as { _retry?: boolean; headers: Record<string, string> };
    if (status === 401 && !originalRequest?._retry) {
      const refreshToken = tokenStorage.getRefreshToken();
      if (!refreshToken) {
        tokenStorage.clearSession();
        redirectToLoginIfNeeded();
      } else {
        if (isRefreshing) {
          return new Promise((resolve, reject) => {
            pendingQueue.push((newToken) => {
              if (!newToken) {
                reject(new ApiError("Session expired", 401, "auth.unauthenticated"));
                return;
              }
              originalRequest.headers.Authorization = `Bearer ${newToken}`;
              resolve(client(originalRequest));
            });
          });
        }
        isRefreshing = true;
        originalRequest._retry = true;
        try {
          const refreshRes = await client.post<ApiResponse<{ accessToken: string; refreshToken?: string }>>(
            "/auth/refresh",
            { refreshToken },
            { headers: { "x-skip-auth": "1" } },
          );
          const nextAccessToken = refreshRes.data.data?.accessToken;
          if (!nextAccessToken) {
            throw new ApiError("Invalid refresh response", 401, "auth.unauthenticated");
          }
          tokenStorage.setAccessToken(nextAccessToken);
          if (refreshRes.data.data?.refreshToken) {
            tokenStorage.setRefreshToken(refreshRes.data.data.refreshToken);
          }
          pendingQueue.forEach((resolvePending) => resolvePending(nextAccessToken));
          pendingQueue = [];
          originalRequest.headers.Authorization = `Bearer ${nextAccessToken}`;
          return client(originalRequest);
        } catch {
          tokenStorage.clearSession();
          pendingQueue.forEach((resolvePending) => resolvePending(null));
          pendingQueue = [];
          redirectToLoginIfNeeded();
        } finally {
          isRefreshing = false;
        }
      }
    }
    const message =
      error?.response?.data?.errorMessage?.message ||
      error?.response?.data?.message ||
      error?.message ||
      "Request failed";
    throw new ApiError(message, status, code);
  },
);

rootClient.interceptors.response.use(
  (response) => {
    debugHttp(`OK ${String(response.config.method || "GET").toUpperCase()} ${String(response.config.url || "")}`, {
      status: response.status,
      data: response.data,
    });
    return response;
  },
  async (error) => {
    debugHttp(`ERR ${String(error?.config?.method || "GET").toUpperCase()} ${String(error?.config?.url || "")}`, {
      status: error?.response?.status,
      data: error?.response?.data,
    });
    const status = error?.response?.status as number | undefined;
    const code = error?.response?.data?.errorMessage?.errorCode as string | undefined;
    const originalRequest = error?.config as { _retry?: boolean; headers: Record<string, string> };
    if (status === 401 && !originalRequest?._retry) {
      const refreshToken = tokenStorage.getRefreshToken();
      if (!refreshToken) {
        tokenStorage.clearSession();
        redirectToLoginIfNeeded();
      } else {
        if (isRefreshing) {
          return new Promise((resolve, reject) => {
            pendingQueue.push((newToken) => {
              if (!newToken) {
                reject(new ApiError("Session expired", 401, "auth.unauthenticated"));
                return;
              }
              originalRequest.headers.Authorization = `Bearer ${newToken}`;
              resolve(rootClient(originalRequest));
            });
          });
        }
        isRefreshing = true;
        originalRequest._retry = true;
        try {
          const refreshRes = await client.post<ApiResponse<{ accessToken: string; refreshToken?: string }>>(
            "/auth/refresh",
            { refreshToken },
            { headers: { "x-skip-auth": "1" } },
          );
          const nextAccessToken = refreshRes.data.data?.accessToken;
          if (!nextAccessToken) {
            throw new ApiError("Invalid refresh response", 401, "auth.unauthenticated");
          }
          tokenStorage.setAccessToken(nextAccessToken);
          if (refreshRes.data.data?.refreshToken) {
            tokenStorage.setRefreshToken(refreshRes.data.data.refreshToken);
          }
          pendingQueue.forEach((resolvePending) => resolvePending(nextAccessToken));
          pendingQueue = [];
          originalRequest.headers.Authorization = `Bearer ${nextAccessToken}`;
          return rootClient(originalRequest);
        } catch {
          tokenStorage.clearSession();
          pendingQueue.forEach((resolvePending) => resolvePending(null));
          pendingQueue = [];
          redirectToLoginIfNeeded();
        } finally {
          isRefreshing = false;
        }
      }
    }
    const message =
      error?.response?.data?.errorMessage?.message ||
      error?.response?.data?.message ||
      error?.message ||
      "Request failed";
    throw new ApiError(message, status, code);
  },
);

export async function apiGet<T>(url: string, params?: Record<string, unknown>) {
  const http = pickHttpClient(url);
  const finalUrl = http === rootClient ? withRootBase(url) : url;
  const { data } = await http.get<ApiResponse<T>>(finalUrl, { params });
  return unwrapApiResponse(data);
}

export async function apiPost<T, B>(url: string, body?: B) {
  const http = pickHttpClient(url);
  const finalUrl = http === rootClient ? withRootBase(url) : url;
  const { data } = await http.post<ApiResponse<T>>(finalUrl, body);
  return unwrapApiResponse(data);
}

export async function apiPut<T, B>(url: string, body?: B) {
  const http = pickHttpClient(url);
  const finalUrl = http === rootClient ? withRootBase(url) : url;
  const { data } = await http.put<ApiResponse<T>>(finalUrl, body);
  return unwrapApiResponse(data);
}

export async function apiDelete<T>(url: string) {
  const http = pickHttpClient(url);
  const finalUrl = http === rootClient ? withRootBase(url) : url;
  const { data } = await http.delete<ApiResponse<T>>(finalUrl);
  return unwrapApiResponse(data);
}

export async function apiMultipart<T>(url: string, formData: FormData) {
  const http = pickHttpClient(url);
  const finalUrl = http === rootClient ? withRootBase(url) : url;
  const { data } = await http.post<ApiResponse<T>>(finalUrl, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return unwrapApiResponse(data);
}

function unwrapApiResponse<T>(response: ApiResponse<T>): T {
  if (!response.success) {
    throw new ApiError(
      response.errorMessage?.message || response.message || "Operation failed",
      undefined,
      response.errorMessage?.errorCode,
    );
  }
  if (typeof response.data === "undefined") {
    throw new ApiError("Missing response data");
  }
  return response.data;
}