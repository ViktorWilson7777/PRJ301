import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { z } from "zod"
import { toast } from "sonner"
import { Loader2, Rocket } from "lucide-react"
import { eventApi } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Select } from "@/components/ui/select"

type FormErrors = Partial<
  Record<
    "title" | "description" | "topic" | "category" | "level" | "eventDatetime" | "meetingType" | "maxParticipants",
    string
  >
>

const schema = z.object({
  title: z.string().trim().min(3, "Title must be at least 3 characters."),
  description: z.string().trim().min(1, "Description is required."),
  topic: z.string().trim().min(1, "Topic is required."),
  category: z.string().trim().min(1, "Category is required."),
  level: z.string().trim().min(1, "Level is required."),
  eventDatetime: z.string().min(1, "Please select date & time."),
  meetingType: z.enum(["online", "offline"], { message: "Select meeting type." }),
  maxParticipants: z.coerce.number().min(2).max(20).optional(),
})

export default function CreateEventSheet() {
  const navigate = useNavigate()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [open, setOpen] = useState(true)

  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [topic, setTopic] = useState("")
  const [category, setCategory] = useState("")
  const [level, setLevel] = useState("")
  const [location, setLocation] = useState("")
  const [eventDatetime, setEventDatetime] = useState("")
  const [meetingType, setMeetingType] = useState<"online" | "offline">("online")
  const [maxParticipants, setMaxParticipants] = useState("6")

  const [formErrors, setFormErrors] = useState<FormErrors>({})

  const saveEvent = async () => {
    const validation = schema.safeParse({
      title,
      description,
      topic,
      category,
      level,
      eventDatetime,
      meetingType,
      maxParticipants: maxParticipants === "" ? undefined : Number(maxParticipants),
    })
    if (!validation.success) {
      const fe = validation.error.flatten().fieldErrors
      setFormErrors({
        title: fe.title?.[0],
        description: fe.description?.[0],
        topic: fe.topic?.[0],
        category: fe.category?.[0],
        level: fe.level?.[0],
        eventDatetime: fe.eventDatetime?.[0],
        meetingType: fe.meetingType?.[0],
        maxParticipants: fe.maxParticipants?.[0],
      })
      toast.error("Please resolve validation issues.")
      return
    }
    setFormErrors({})

    const dt = new Date(validation.data.eventDatetime)
    if (Number.isNaN(dt.getTime())) {
      toast.error("Invalid date.")
      return
    }

    setIsSubmitting(true)
    try {
      const res = await eventApi.create({
        title: validation.data.title,
        description: validation.data.description,
        topic: validation.data.topic,
        category: validation.data.category,
        level: validation.data.level,
        eventDatetime: dt.toISOString(),
        location: location.trim() || null,
        meetingType: validation.data.meetingType,
        maxParticipants: validation.data.maxParticipants,
      })
      toast.success(`Event created (${res.status}).`)
      navigate("/dashboard/events")
    } catch (err) {
      console.error(err)
      toast.error("Failed to create event.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Sheet
      open={open}
      onOpenChange={(next) => {
        setOpen(next)
        if (!next) navigate("/dashboard/events")
      }}
    >
      <SheetContent side="right" className="!w-full sm:!max-w-[800px] max-h-screen p-0 flex flex-col overflow-hidden">
        <SheetHeader className="px-6 py-4 border-b shrink-0">
          <SheetTitle>Create event</SheetTitle>
          <SheetDescription>Add a scheduled event (online or offline). Date must be in the future.</SheetDescription>
        </SheetHeader>

        <ScrollArea className="flex-1 min-h-0">
          <div className="p-6">
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="event-title">Title</Label>
                <Input
                  id="event-title"
                  value={title}
                  aria-invalid={Boolean(formErrors.title)}
                  onChange={(e) => {
                    setTitle(e.target.value)
                    if (formErrors.title) setFormErrors((p) => ({ ...p, title: undefined }))
                  }}
                  placeholder="Leadership workshop"
                />
                {formErrors.title ? <p className="text-xs text-destructive">{formErrors.title}</p> : null}
              </div>

              <div className="space-y-2">
                <Label htmlFor="event-description">Description</Label>
                <textarea
                  id="event-description"
                  className="flex min-h-[100px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                  value={description}
                  aria-invalid={Boolean(formErrors.description)}
                  onChange={(e) => {
                    setDescription(e.target.value)
                    if (formErrors.description) setFormErrors((p) => ({ ...p, description: undefined }))
                  }}
                  placeholder="Full description for attendees"
                />
                {formErrors.description ? <p className="text-xs text-destructive">{formErrors.description}</p> : null}
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="event-topic">Topic</Label>
                  <Input
                    id="event-topic"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    aria-invalid={Boolean(formErrors.topic)}
                  />
                  {formErrors.topic ? <p className="text-xs text-destructive">{formErrors.topic}</p> : null}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="event-category">Category</Label>
                  <Input
                    id="event-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    aria-invalid={Boolean(formErrors.category)}
                    placeholder="e.g. WORKSHOP"
                  />
                  {formErrors.category ? <p className="text-xs text-destructive">{formErrors.category}</p> : null}
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="event-level">Level</Label>
                  <Input
                    id="event-level"
                    value={level}
                    onChange={(e) => setLevel(e.target.value)}
                    aria-invalid={Boolean(formErrors.level)}
                    placeholder="e.g. Beginner"
                  />
                  {formErrors.level ? <p className="text-xs text-destructive">{formErrors.level}</p> : null}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="event-meeting">Meeting type</Label>
                  <Select
                    id="event-meeting"
                    value={meetingType}
                    onChange={(e) => setMeetingType(e.target.value as "online" | "offline")}
                    aria-invalid={Boolean(formErrors.meetingType)}
                  >
                    <option value="online">Online</option>
                    <option value="offline">Offline</option>
                  </Select>
                  {formErrors.meetingType ? <p className="text-xs text-destructive">{formErrors.meetingType}</p> : null}
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="event-start">Event date & time</Label>
                  <Input
                    id="event-start"
                    type="datetime-local"
                    value={eventDatetime}
                    onChange={(e) => setEventDatetime(e.target.value)}
                    aria-invalid={Boolean(formErrors.eventDatetime)}
                  />
                  {formErrors.eventDatetime ? <p className="text-xs text-destructive">{formErrors.eventDatetime}</p> : null}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="event-capacity">Max participants (2–20)</Label>
                  <Input
                    id="event-capacity"
                    type="number"
                    min={2}
                    max={20}
                    value={maxParticipants}
                    onChange={(e) => setMaxParticipants(e.target.value)}
                    aria-invalid={Boolean(formErrors.maxParticipants)}
                  />
                  {formErrors.maxParticipants ? <p className="text-xs text-destructive">{formErrors.maxParticipants}</p> : null}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="event-location">Location (optional)</Label>
                <Input
                  id="event-location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Venue or meeting link notes"
                />
              </div>
            </div>
          </div>
        </ScrollArea>

        <div className="px-6 py-4 border-t flex justify-end gap-3 bg-muted/20 shrink-0">
          <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="button" onClick={() => void saveEvent()} disabled={isSubmitting}>
            {isSubmitting ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Rocket className="mr-2 size-4" />}
            Create event
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
