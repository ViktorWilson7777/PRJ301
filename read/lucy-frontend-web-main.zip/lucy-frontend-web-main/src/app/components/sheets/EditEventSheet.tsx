import { useState, useEffect } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { toast } from "sonner"
import { CalendarDays } from "lucide-react"
import { eventApi } from "@/lib/api"
import type { EventDetail } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { PageLoading } from "@/components/common/PageLoading"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"

function formatDt(iso: string | null | undefined): string {
  if (!iso) return "—"
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return `${d.toLocaleString()}`
}

export default function EditEventSheet() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()

  const [isLoading, setIsLoading] = useState(true)
  const [open, setOpen] = useState(true)
  const [detail, setDetail] = useState<EventDetail | null>(null)

  useEffect(() => {
    if (!id) return
    const loadEvent = async () => {
      try {
        const ev = await eventApi.getById(id)
        setDetail(ev)
      } catch (err) {
        console.error(err)
        toast.error("Failed to load event details.")
        navigate("/dashboard/events")
      } finally {
        setIsLoading(false)
      }
    }
    void loadEvent()
  }, [id, navigate])

  if (isLoading) {
    return <PageLoading />
  }

  if (!detail) {
    return null
  }

  return (
    <Sheet
      open={open}
      onOpenChange={(next) => {
        setOpen(next)
        if (!next) navigate("/dashboard/events")
      }}
    >
      <SheetContent side="right" className="!w-full sm:!max-w-[800px] max-h-screen p-0 flex flex-col overflow-hidden">
        <SheetHeader className="px-6 py-4 border-b shrink-0">
          <SheetTitle>Event details</SheetTitle>
          <SheetDescription>
            View-only — editing events is not available on the API yet. Use the mobile or host tools to manage live sessions.
          </SheetDescription>
        </SheetHeader>

        <ScrollArea className="flex-1 min-h-0">
          <div className="p-6 space-y-6">
            <div className="flex items-start gap-3">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary border border-primary/20">
                <CalendarDays className="size-5" />
              </div>
              <div className="min-w-0">
                <h2 className="text-lg font-semibold leading-tight">{detail.title}</h2>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Badge variant="outline" className="text-[10px] uppercase">
                    {detail.status}
                  </Badge>
                  <Badge variant="secondary" className="text-[10px] uppercase">
                    {detail.meetingType}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label className="text-muted-foreground">Topic</Label>
                <p className="text-sm font-medium mt-1">{detail.topic || "—"}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Category</Label>
                <p className="text-sm font-medium mt-1">{detail.category || "—"}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Level</Label>
                <p className="text-sm font-medium mt-1">{detail.level || "—"}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Event time</Label>
                <p className="text-sm font-medium mt-1">{formatDt(detail.eventDatetime)}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Location</Label>
                <p className="text-sm font-medium mt-1">{detail.location?.trim() || "—"}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Max participants</Label>
                <p className="text-sm font-medium mt-1">{detail.maxParticipants ?? "—"}</p>
              </div>
            </div>

            <div>
              <Label className="text-muted-foreground">Description</Label>
              <p className="text-sm mt-1 whitespace-pre-wrap">{detail.description || "—"}</p>
            </div>

            <div className="grid gap-4 sm:grid-cols-3 rounded-lg border bg-muted/30 p-4">
              <div>
                <Label className="text-muted-foreground">Interested</Label>
                <p className="text-lg font-semibold">{detail.interestedCount ?? 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Likes</Label>
                <p className="text-lg font-semibold">{detail.likesCount ?? 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Comments</Label>
                <p className="text-lg font-semibold">{detail.commentsCount ?? 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Participants (joined)</Label>
                <p className="text-lg font-semibold">{detail.participantCount ?? 0}</p>
              </div>
              <div>
                <Label className="text-muted-foreground">Started at</Label>
                <p className="text-sm font-medium mt-1">{formatDt(detail.startedAt)}</p>
              </div>
            </div>
          </div>
        </ScrollArea>

        <div className="px-6 py-4 border-t flex justify-end gap-3 bg-muted/20 shrink-0">
          <Button type="button" variant="outline" onClick={() => setOpen(false)}>
            Close
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
