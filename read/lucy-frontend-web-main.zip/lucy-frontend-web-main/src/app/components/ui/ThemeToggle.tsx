import { useTheme } from "@/components/providers/ThemeProvider"
import { Button } from "./button"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const isDark = theme === "dark"

  return (
    <Button
      variant="ghost"
      size="icon"
      className="h-10 w-10 rounded-xl border border-border bg-background text-foreground hover:bg-muted"
      onClick={() => setTheme(isDark ? "light" : "dark")}
    >
      <span aria-hidden className="text-sm leading-none">
        {isDark ? "☀" : "☾"}
      </span>
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}
