import { useEffect, useState, type FormEvent } from "react"
import { z } from "zod"
import { toast } from "sonner"
import { User, Key, BadgeCheck, Mail, RefreshCw, Loader2 } from "lucide-react"

import { authApi, userApi, type UserResponse } from "@/lib/api"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PageLoading } from "@/components/common/PageLoading"
import { PageHeader } from "@/components/common/PageHeader"

type PasswordFormState = {
  currentPassword: string
  newPassword: string
  confirmPassword: string
}

type PasswordFormErrors = Partial<Record<keyof PasswordFormState, string>>

const passwordSchema = z
  .object({
    currentPassword: z.string().min(1, "Current password is required."),
    newPassword: z.string().min(6, "New password must be at least 6 characters."),
    confirmPassword: z.string().min(1, "Please confirm your new password."),
  })
  .refine((value) => value.newPassword === value.confirmPassword, {
    message: "Confirm password does not match.",
    path: ["confirmPassword"],
  })
  .refine((value) => value.currentPassword !== value.newPassword, {
    message: "New password must be different from current password.",
    path: ["newPassword"],
  })

function validatePasswordForm(form: PasswordFormState): PasswordFormErrors {
  const result = passwordSchema.safeParse(form)
  if (result.success) return {}
  const errors = result.error.flatten().fieldErrors
  return {
    currentPassword: errors.currentPassword?.[0],
    newPassword: errors.newPassword?.[0],
    confirmPassword: errors.confirmPassword?.[0],
  }
}

function initials(name: string): string {
  const trimmed = name.trim()
  if (!trimmed) return "ZU"
  return trimmed
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join("")
}

export default function ProfilePage() {
  const [user, setUser] = useState<UserResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [isChangingPassword, setIsChangingPassword] = useState(false)

  const [passwordForm, setPasswordForm] = useState<PasswordFormState>({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [passwordErrors, setPasswordErrors] = useState<PasswordFormErrors>({})

  useEffect(() => {
    const run = async () => {
      try {
        setLoading(true)
        const me = await userApi.getMe()
        setUser(me)
      } catch (error) {
        const message = error instanceof Error ? error.message : "Failed to load profile."
        toast.error(message)
      } finally {
        setLoading(false)
      }
    }

    void run()
  }, [])

  const accountStatusText = user?.isVerified ? "Verified" : "Unverified"

  if (loading) {
    return <PageLoading />
  }

  const handleChangePassword = async (event: FormEvent) => {
    event.preventDefault()
    const errors = validatePasswordForm(passwordForm)
    setPasswordErrors(errors)
    if (Object.values(errors).some(Boolean)) return

    try {
      setIsChangingPassword(true)
      await authApi.changePassword({
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
      })
      setPasswordForm({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      })
      setPasswordErrors({})
      toast.success("Password secured.")
    } catch (error) {
      const message = error instanceof Error ? error.message : "Update failed."
      toast.error(message)
    } finally {
      setIsChangingPassword(false)
    }
  }

  return (
    <div className="flex flex-col gap-8 max-w-5xl">
      <PageHeader
        title="Profile Settings"
        subtitle="Control your personal presence and security preferences."
        stats={[
          { label: "Status", value: accountStatusText },
          { label: "Privileges", value: user?.roles?.[0] || "User" },
        ]}
      />

      <Tabs defaultValue="details" className="w-full">
        <TabsList className="mb-6 h-12 justify-start gap-1 p-1 bg-muted/40">
          <TabsTrigger value="details" className="px-8 font-semibold data-[state=active]:bg-background">
            <User className="mr-2 size-4" />
            General Information
          </TabsTrigger>
          <TabsTrigger value="password" className="px-8 font-semibold data-[state=active]:bg-background">
            <Key className="mr-2 size-4" />
            Change Password
          </TabsTrigger>
        </TabsList>

        <div className="mt-4">
          <TabsContent value="details" className="focus-visible:outline-none">
            <Card className="overflow-hidden border shadow-sm">
              <CardHeader className="bg-muted/30 border-b p-8">
                <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-6">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src={user?.avatarUrl || undefined} className="object-cover" />
                      <AvatarFallback className="text-2xl font-bold bg-primary/10 text-primary">
                        {initials(user?.displayName ?? "")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="text-xl font-bold tracking-tight">{user?.displayName}</h2>
                      <div className="flex items-center gap-2 mt-1.5">
                        <Mail className="size-3.5 text-muted-foreground" />
                        <span className="text-sm font-medium text-muted-foreground">{user?.email}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={user?.isVerified ? "default" : "secondary"}
                      className="h-7 px-3 font-bold uppercase tracking-wide text-[10px]"
                    >
                      {user?.isVerified && <BadgeCheck className="mr-1.5 size-3.5" />}
                      {accountStatusText}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-8">
                <div className="space-y-6 max-w-2xl">
                  <p className="text-sm text-muted-foreground rounded-lg border bg-muted/20 p-4">
                    Profile editing (display name and avatar) is not available yet: the backend exposes{" "}
                    <span className="font-mono text-xs">GET /users/me</span> only, not{" "}
                    <span className="font-mono text-xs">PUT /users/me</span>. Use{" "}
                    <strong>Change Password</strong> below for credential updates.
                  </p>
                  <div className="grid gap-6">
                    <div className="space-y-2">
                      <Label className="ml-1 text-[11px] font-bold uppercase tracking-widest text-muted-foreground/80">
                        Display Name
                      </Label>
                      <Input
                        value={user?.displayName ?? ""}
                        disabled
                        className="h-11 rounded-xl bg-muted/60 border-transparent font-semibold opacity-80"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="ml-1 text-[11px] font-bold uppercase tracking-widest text-muted-foreground/80">
                        Email Address
                      </Label>
                      <Input
                        value={user?.email}
                        disabled
                        className="h-11 rounded-xl bg-muted/60 border-transparent font-medium opacity-70"
                      />
                      <p className="text-[10px] text-muted-foreground font-medium italic ml-1">
                        Contact administrators to modify primary security email.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="password" className="focus-visible:outline-none">
            <Card className="overflow-hidden border shadow-sm max-w-2xl">
              <CardHeader className="bg-muted/30 border-b p-8">
                <div className="flex items-center gap-4">
                  <div className="flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Key className="size-6" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Credentials Security</CardTitle>
                    <CardDescription>Update your login credentials to a unique, strong password.</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-8">
                <form onSubmit={handleChangePassword} className="space-y-6">
                  <div className="space-y-2">
                    <Label className="ml-1 text-[11px] font-bold uppercase tracking-widest text-muted-foreground/80">
                      Current Password
                    </Label>
                    <Input
                      type="password"
                      value={passwordForm.currentPassword}
                      onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                      className="h-11 rounded-xl font-medium"
                    />
                    {passwordErrors.currentPassword && (
                      <p className="text-xs font-bold text-destructive ml-1">{passwordErrors.currentPassword}</p>
                    )}
                  </div>

                  <Separator className="my-6" />

                  <div className="grid gap-6">
                    <div className="space-y-2">
                      <Label className="ml-1 text-[11px] font-bold uppercase tracking-widest text-muted-foreground/80">
                        New Password
                      </Label>
                      <Input
                        type="password"
                        value={passwordForm.newPassword}
                        onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                        className="h-11 rounded-xl font-medium"
                      />
                      {passwordErrors.newPassword && (
                        <p className="text-xs font-bold text-destructive ml-1">{passwordErrors.newPassword}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label className="ml-1 text-[11px] font-bold uppercase tracking-widest text-muted-foreground/80">
                        Confirm Selection
                      </Label>
                      <Input
                        type="password"
                        value={passwordForm.confirmPassword}
                        onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                        className="h-11 rounded-xl font-medium"
                      />
                      {passwordErrors.confirmPassword && (
                        <p className="text-xs font-bold text-destructive ml-1">{passwordErrors.confirmPassword}</p>
                      )}
                    </div>
                  </div>

                  <div className="pt-6">
                    <Button type="submit" size="lg" disabled={isChangingPassword} className="w-full font-bold">
                      {isChangingPassword ? (
                        <Loader2 className="mr-2 size-4 animate-spin" />
                      ) : (
                        <RefreshCw className="mr-2 size-4" />
                      )}
                      Establish New Password
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}
