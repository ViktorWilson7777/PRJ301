import { useEffect, useMemo, useState, useCallback } from "react"
import { useNavigate } from "react-router-dom"
import { toast } from "sonner"
import { Plus, Search, CalendarDays, MapPin } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Select } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { PageLoading } from "@/components/common/PageLoading"
import { eventApi, type EventFeedItem } from "../lib/api"
import { cn, formatNumber } from "@/lib/utils"
import { PageHeader } from "@/components/common/PageHeader"

export default function EventsPage() {
  const navigate = useNavigate()
  const [items, setItems] = useState<EventFeedItem[]>([])
  const [nextCursor, setNextCursor] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isLoadingMore, setIsLoadingMore] = useState(false)
  const [search, setSearch] = useState("")
  const [debouncedSearch, setDebouncedSearch] = useState("")
  const [selectedDate, setSelectedDate] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("ALL")
  const [selectedStatus, setSelectedStatus] = useState("ALL")

  useEffect(() => {
    const t = window.setTimeout(() => setDebouncedSearch(search.trim()), 300)
    return () => window.clearTimeout(t)
  }, [search])

  const fetchFirstPage = useCallback(async () => {
    setIsLoading(true)
    try {
      const data = await eventApi.getFeed({
        limit: 30,
        query: debouncedSearch || undefined,
        status: selectedStatus === "ALL" ? undefined : selectedStatus.toLowerCase(),
      })
      setItems(data.items)
      setNextCursor(data.nextCursor ?? null)
      setHasMore(Boolean(data.hasMore))
    } catch {
      toast.error("Failed to load events.")
      setItems([])
      setNextCursor(null)
      setHasMore(false)
    } finally {
      setIsLoading(false)
    }
  }, [debouncedSearch, selectedStatus])

  useEffect(() => {
    void fetchFirstPage()
  }, [fetchFirstPage])

  const loadMore = async () => {
    if (!nextCursor || !hasMore || isLoadingMore) return
    setIsLoadingMore(true)
    try {
      const data = await eventApi.getFeed({
        cursor: nextCursor,
        limit: 30,
        query: debouncedSearch || undefined,
        status: selectedStatus === "ALL" ? undefined : selectedStatus.toLowerCase(),
      })
      setItems((prev) => [...prev, ...data.items])
      setNextCursor(data.nextCursor ?? null)
      setHasMore(Boolean(data.hasMore))
    } catch {
      toast.error("Failed to load more events.")
    } finally {
      setIsLoadingMore(false)
    }
  }

  const filteredEvents = useMemo(() => {
    const query = search.trim().toLowerCase()
    return items.filter((event) => {
      if (query) {
        const haystack = [event.title, event.topic, event.category, event.description, event.location ?? ""]
          .join(" ")
          .toLowerCase()
        if (!haystack.includes(query)) return false
      }

      if (selectedDate) {
        const eventDay = new Date(event.eventDatetime).toISOString().slice(0, 10)
        if (eventDay !== selectedDate) return false
      }

      if (selectedCategory !== "ALL") {
        const category = (event.category || "").toUpperCase()
        if (category !== selectedCategory) return false
      }

      return true
    })
  }, [items, search, selectedDate, selectedCategory])

  function getCategory(event: EventFeedItem) {
    return (event.category || "OTHER").toUpperCase()
  }

  function getRegistration(event: EventFeedItem) {
    const registered = event.interestedCount ?? 0
    const capacity = event.maxParticipants ?? 20
    const cap = Math.max(capacity, 1)
    return { registered, capacity: cap, isFull: registered >= cap }
  }

  const activeCount = useMemo(
    () => items.filter((e) => e.status?.toLowerCase() === "live" || e.status?.toLowerCase() === "scheduled").length,
    [items],
  )

  if (isLoading && items.length === 0) {
    return <PageLoading />
  }

  return (
    <div className="flex flex-col gap-8">
      <PageHeader
        title="Event Management"
        subtitle="Track workshops and sessions from the event feed API."
        stats={[
          { label: "Loaded", value: formatNumber(items.length) },
          { label: "Scheduled / live", value: formatNumber(activeCount) },
        ]}
        actions={
          <Button onClick={() => navigate("/dashboard/events/create")} size="lg">
            <Plus className="mr-2 size-5" />
            Create Event
          </Button>
        }
      />

      <div className="space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative w-full sm:max-w-md">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search events (client + server query)..."
              className="pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:items-center">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full sm:w-auto"
            />
            <Select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} className="w-full sm:w-[180px]">
              <option value="ALL">All Categories</option>
              <option value="WORKSHOP">Workshop</option>
              <option value="SUMMIT">Summit</option>
              <option value="TALK">Talk</option>
              <option value="WEBINAR">Webinar</option>
            </Select>
            <Select value={selectedStatus} onChange={(e) => setSelectedStatus(e.target.value)} className="w-full sm:w-[180px]">
              <option value="ALL">All statuses</option>
              <option value="scheduled">Scheduled</option>
              <option value="live">Live</option>
              <option value="ended">Ended</option>
              <option value="cancelled">Cancelled</option>
            </Select>
          </div>
        </div>

        <div className="rounded-md bg-background border overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="px-6 h-12 w-16">STT</TableHead>
                <TableHead className="px-6 h-12">Event</TableHead>
                <TableHead className="px-6 h-12">Category</TableHead>
                <TableHead className="px-6 h-12">Status</TableHead>
                <TableHead className="px-6 h-12">Timeline</TableHead>
                <TableHead className="px-6 h-12">Location</TableHead>
                <TableHead className="px-6 h-12">Interest</TableHead>
                <TableHead className="px-6 h-12 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEvents.length > 0 ? (
                filteredEvents.map((event, idx) => {
                  const category = getCategory(event)
                  const registration = getRegistration(event)
                  const startTime = new Date(event.eventDatetime)
                  const location =
                    event.location?.trim() ||
                    (event.meetingType?.toLowerCase() === "online" ? "Online" : "—")

                  return (
                    <TableRow key={event.id} className="group border-none hover:bg-muted/40">
                      <TableCell className="px-6 py-4 text-muted-foreground">{idx + 1}</TableCell>
                      <TableCell className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary border border-primary/20">
                            <CalendarDays className="size-5" />
                          </div>
                          <div className="min-w-0">
                            <div
                              className="text-sm font-semibold text-foreground truncate max-w-[200px] cursor-pointer hover:text-primary transition-colors"
                              onClick={() => navigate(`/dashboard/events/edit/${event.id}`)}
                            >
                              {event.title}
                            </div>
                            <p className="text-[10px] text-muted-foreground truncate max-w-[220px]">{event.topic}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="px-6 py-4">
                        <Badge variant="outline" className="text-[10px] uppercase">
                          {category}
                        </Badge>
                      </TableCell>
                      <TableCell className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <span
                            className={cn(
                              "size-1.5 rounded-full",
                              event.status?.toLowerCase() === "live" ? "bg-green-500" : "bg-muted-foreground/50",
                            )}
                          />
                          <span className="text-xs font-medium uppercase">{event.status}</span>
                        </div>
                      </TableCell>
                      <TableCell className="px-6 py-4">
                        <div className="text-xs font-semibold text-foreground">
                          {Number.isNaN(startTime.getTime()) ? "—" : startTime.toLocaleDateString("en-US")}
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          {Number.isNaN(startTime.getTime())
                            ? ""
                            : startTime.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                        </div>
                      </TableCell>
                      <TableCell className="px-6 py-4">
                        <div className="flex items-center gap-1.5 text-xs font-medium text-foreground max-w-[120px] truncate">
                          <MapPin className="size-3.5 text-muted-foreground" />
                          {location}
                        </div>
                      </TableCell>
                      <TableCell className="px-6 py-4">
                        <div className="min-w-[100px] space-y-1.5">
                          <div className="flex justify-between text-[10px] font-bold uppercase tracking-tight">
                            <span className={registration.isFull ? "text-destructive" : "text-muted-foreground"}>
                              Interest
                            </span>
                            <span>
                              {registration.registered}/{registration.capacity}
                            </span>
                          </div>
                          <Progress
                            value={Math.min(100, (registration.registered / registration.capacity) * 100)}
                            className="h-1"
                          />
                        </div>
                      </TableCell>
                      <TableCell className="px-6 py-4 text-right">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => navigate(`/dashboard/events/edit/${event.id}`)}
                        >
                          <CalendarDays className="mr-2 size-4" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={8} className="h-32 text-center text-muted-foreground">
                    No events found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {hasMore && nextCursor ? (
          <div className="flex justify-center">
            <Button variant="secondary" onClick={() => void loadMore()} disabled={isLoadingMore}>
              {isLoadingMore ? "Loading…" : "Load more"}
            </Button>
          </div>
        ) : null}
      </div>
    </div>
  )
}
