import { useCallback, useEffect, useState } from "react"
import { toast } from "sonner"
import { Search } from "lucide-react"
import { PageHeader } from "@/components/common/PageHeader"
import { PageLoading } from "@/components/common/PageLoading"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { syllabusApi, type SyllabusItemResponse } from "../lib/api"
import { formatNumber } from "@/lib/utils"

type FilterFields = {
  levelNumber: string
  topicTitle: string
  category: string
}

export default function SyllabusPage() {
  const [rows, setRows] = useState<SyllabusItemResponse[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [levelNumber, setLevelNumber] = useState("")
  const [topicTitle, setTopicTitle] = useState("")
  const [category, setCategory] = useState("")

  const runQuery = useCallback(async (p: FilterFields) => {
    setIsLoading(true)
    try {
      const level = p.levelNumber.trim() === "" ? undefined : Number(p.levelNumber)
      const data = await syllabusApi.list({
        levelNumber: level !== undefined && !Number.isNaN(level) ? level : undefined,
        topicTitle: p.topicTitle.trim() || undefined,
        category: p.category.trim() || undefined,
      })
      setRows(data)
    } catch {
      toast.error("Failed to load syllabus.")
      setRows([])
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    void runQuery({ levelNumber: "", topicTitle: "", category: "" })
  }, [runQuery])

  if (isLoading && rows.length === 0) {
    return <PageLoading />
  }

  return (
    <div className="flex flex-col gap-8">
      <PageHeader
        title="Syllabus"
        subtitle="Reference curriculum levels and topics from the syllabus API."
        stats={[{ label: "Rows", value: formatNumber(rows.length) }]}
      />

      <div className="flex flex-col gap-4 lg:flex-row lg:items-end">
        <div className="grid flex-1 gap-3 sm:grid-cols-3">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Level number</label>
            <Input
              inputMode="numeric"
              placeholder="e.g. 1"
              value={levelNumber}
              onChange={(e) => setLevelNumber(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Topic title contains</label>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                className="pl-9"
                placeholder="Search topic..."
                value={topicTitle}
                onChange={(e) => setTopicTitle(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Category</label>
            <Input placeholder="Filter category" value={category} onChange={(e) => setCategory(e.target.value)} />
          </div>
        </div>
        <Button
          type="button"
          onClick={() => void runQuery({ levelNumber, topicTitle, category })}
          disabled={isLoading}
          className="shrink-0"
        >
          {isLoading ? "Loading…" : "Apply filters"}
        </Button>
      </div>

      <div className="rounded-md border bg-background overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="px-4 h-11">Level</TableHead>
              <TableHead className="px-4 h-11">Sub</TableHead>
              <TableHead className="px-4 h-11">Category</TableHead>
              <TableHead className="px-4 h-11">Topic</TableHead>
              <TableHead className="px-4 h-11 text-right">Has content</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length > 0 ? (
              rows.map((r) => {
                const hasBlocks = Boolean(r.warmupContent || r.coreContent || r.wrapupContent)
                return (
                  <TableRow key={r.id} className="hover:bg-muted/40">
                    <TableCell className="px-4 py-3 font-medium">{r.levelNumber}</TableCell>
                    <TableCell className="px-4 py-3 text-muted-foreground">{r.subLevelNumber}</TableCell>
                    <TableCell className="px-4 py-3">{r.category}</TableCell>
                    <TableCell className="px-4 py-3 max-w-[320px]">
                      <span className="line-clamp-2 text-sm">{r.topicTitle}</span>
                    </TableCell>
                    <TableCell className="px-4 py-3 text-right text-sm text-muted-foreground">
                      {hasBlocks ? "Yes" : "—"}
                    </TableCell>
                  </TableRow>
                )
              })
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="h-28 text-center text-muted-foreground">
                  No syllabus rows match the filters.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
