import { authStorage } from "./storage"

// ─── Base ─────────────────────────────────────────────────────────────────────
const BASE = import.meta.env.VITE_API_BASE_URL || "/api/v1"
const API_ROOT = import.meta.env.VITE_API_ROOT || BASE.replace(/\/api\/v1$/, "")

function resolveUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path
  if (path.startsWith("/api/")) return `${API_ROOT}${path}`
  return `${BASE}${path}`
}

interface ApiResponse<T> {
  success: boolean
  data: T
  message?: string
}

function buildHttpErrorMessage(res: Response): string {
  if (res.status === 413) {
    return "Uploaded file is too large for the server limit."
  }

  return `HTTP ${res.status}: ${res.statusText}`
}

function extractApiErrorMessage(body: unknown, fallback: string): string {
  if (!body || typeof body !== "object") return fallback
  const err = (body as { errorMessage?: { message?: string } }).errorMessage
  if (err?.message && typeof err.message === "string" && err.message.trim()) {
    return err.message.trim()
  }
  return fallback
}

async function parseJsonBody(res: Response): Promise<unknown> {
  const ct = res.headers.get("content-type") || ""
  if (!ct.includes("application/json")) return null
  try {
    return await res.json()
  } catch {
    return null
  }
}

export interface PagingResponse<T> {
  currentPage: number
  pageSize: number
  totalPages: number
  totalElement: number
  data: T[]
}

export interface SpringPage<T> {
  content: T[]
  pageable: unknown
  totalElements: number
  totalPages: number
  size: number
  number: number
}

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const token = authStorage.getToken()
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...init?.headers as Record<string, string>,
  }

  if (token) {
    headers["Authorization"] = `Bearer ${token}`
  }

  const res = await fetch(resolveUrl(path), {
    headers,
    ...init,
  })
  const body = await parseJsonBody(res)
  if (!res.ok) {
    throw new Error(extractApiErrorMessage(body, buildHttpErrorMessage(res)))
  }
  const json = body as ApiResponse<T>
  if (!json || typeof json !== "object") {
    throw new Error("Invalid response from server")
  }
  if (json.success === false) {
    throw new Error(extractApiErrorMessage(json, "Request failed"))
  }
  if (typeof json.data === "undefined") {
    throw new Error("Missing response data")
  }
  return json.data
}

// Public request — no Authorization header (for login, register, etc.)
async function reqPublic<T>(path: string, init?: RequestInit): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...init?.headers as Record<string, string>,
  }
  const res = await fetch(resolveUrl(path), { headers, ...init })
  const body = await parseJsonBody(res)
  if (!res.ok) {
    throw new Error(extractApiErrorMessage(body, buildHttpErrorMessage(res)))
  }
  const json = body as ApiResponse<T>
  if (!json || typeof json !== "object") {
    throw new Error("Invalid response from server")
  }
  if (json.success === false) {
    throw new Error(extractApiErrorMessage(json, "Request failed"))
  }
  if (typeof json.data === "undefined") {
    throw new Error("Missing response data")
  }
  return json.data
}

async function reqForm<T>(path: string, formData: FormData): Promise<T> {
  const token = authStorage.getToken()
  const headers: Record<string, string> = {}
  if (token) headers["Authorization"] = `Bearer ${token}`
  const res = await fetch(resolveUrl(path), { method: "POST", body: formData, headers })
  const body = await parseJsonBody(res)
  if (!res.ok) {
    throw new Error(extractApiErrorMessage(body, buildHttpErrorMessage(res)))
  }
  const json = body as ApiResponse<T>
  if (!json || typeof json !== "object") {
    throw new Error("Invalid response from server")
  }
  if (json.success === false) {
    throw new Error(extractApiErrorMessage(json, "Request failed"))
  }
  if (typeof json.data === "undefined") {
    throw new Error("Missing response data")
  }
  return json.data
}

async function uploadToPresignedUrl(uploadUrl: string, file: File, contentType: string): Promise<void> {
  const res = await fetch(uploadUrl, {
    method: "PUT",
    body: file,
    headers: {
      "Content-Type": contentType,
    },
  })

  if (!res.ok) {
    throw new Error(buildHttpErrorMessage(res))
  }
}

// ─── Response types (mirrors backend DTOs) ────────────────────────────────────

export interface AuthenticationResponse {
  authenticated: boolean
  accessToken: string
  refreshToken: string
}

export interface IntrospectResponse {
  isValid: boolean
}

export interface UserResponse {
  id: string
  email: string
  displayName: string
  avatarUrl: string | null
  backgroundUrl: string | null
  /** Backend: profile tier (e.g. SUPER). */
  profileRole: string | null
  isActive: boolean
  isVerified: boolean
  verifiedAt: string | null
  bannedUntil: string | null
  lastSignInAt: string | null
  isProfileCompleted: boolean
  appMetadata: Record<string, unknown>
  userMetadata: Record<string, unknown>
  roles: string[]
  createdAt: string
  updatedAt: string
}

/**
 * Wire JSON may use JavaBean names (`isActive`) or shorthand (`active`, `verified`, …)
 * and either `roles: string[]` or a single `role: string`.
 */
type RawUserResponse = Partial<UserResponse> & {
  role?: string
  active?: boolean
  verified?: boolean
  profileCompleted?: boolean
}

function firstDefinedBoolean(fallback: boolean, ...candidates: (boolean | undefined)[]): boolean {
  for (const v of candidates) {
    if (typeof v === "boolean") return v
  }
  return fallback
}

function firstDefinedString(...candidates: (string | null | undefined)[]): string | null {
  for (const v of candidates) {
    if (v === null || v === undefined) continue
    if (typeof v === "string") return v
  }
  return null
}

function rolesFromUserPayload(user: RawUserResponse): string[] {
  if (Array.isArray(user.roles) && user.roles.length > 0) {
    return user.roles.filter((r): r is string => typeof r === "string")
  }
  if (typeof user.role === "string" && user.role.trim()) {
    return [user.role.trim()]
  }
  return []
}

function normalizeUserResponse(user: RawUserResponse): UserResponse {
  const isActive = firstDefinedBoolean(true, user.isActive, user.active)
  const isVerified = firstDefinedBoolean(false, user.isVerified, user.verified)
  const isProfileCompleted = firstDefinedBoolean(false, user.isProfileCompleted, user.profileCompleted)

  return {
    id: user.id ?? "",
    email: user.email ?? "",
    displayName: user.displayName || user.email || "Unknown User",
    avatarUrl: firstDefinedString(user.avatarUrl),
    backgroundUrl: firstDefinedString(user.backgroundUrl),
    profileRole: firstDefinedString(user.profileRole),
    isActive,
    isVerified,
    verifiedAt: firstDefinedString(user.verifiedAt),
    bannedUntil: firstDefinedString(user.bannedUntil),
    lastSignInAt: firstDefinedString(user.lastSignInAt),
    isProfileCompleted,
    roles: rolesFromUserPayload(user),
    appMetadata: user.appMetadata ?? {},
    userMetadata: user.userMetadata ?? {},
    createdAt: user.createdAt ?? "",
    updatedAt: user.updatedAt ?? "",
  }
}

export interface LessonFileAttachmentResponse {
  provider: string
  fileName: string
  mimeType: string
  size: number
  url: string
  publicId: string
  resourceType: string
}

export interface LessonFileUploadResponse {
  lessonId: string
  attachment: LessonFileAttachmentResponse
}

export interface LessonResponse {
  id: string
  chapterId: string
  chapterTitle: string
  type: string
  title: string
  description: string | null
  orderIndex: number
  isHidden: boolean
  isOptional: boolean
  contentData: Record<string, unknown>
  createdAt: string
  updatedAt: string
}

export interface ChapterResponse {
  id: string
  courseRunId: string
  courseRunCode: string
  title: string
  description: string | null
  orderIndex: number
  lessons: LessonResponse[]
  createdAt: string
  updatedAt: string
}

export interface CourseRunResponse {
  id: string
  courseId: string
  code: string
  status: string
  startsAt: string | null
  endsAt: string | null
  timezone: string | null
  metadata: Record<string, unknown>
  enrollmentStartDate: string | null
  enrollmentEndDate: string | null
  capacity: number | null
  prerequisiteCourseRunId: string | null
  chapters: ChapterResponse[]
  createdAt: string
  updatedAt: string
}

export interface EnrollmentResponse {
  id: string
  userId: string
  userDisplayName: string | null
  userEmail: string | null
  userAvatarUrl: string | null
  courseRunId: string
  courseRunCode: string | null
  status: string
  role: string | null
  enrolmentMethod: string | null
  lastAccessedAt: string | null
  enrolledAt: string | null
  completedAt: string | null
  createdAt: string
  updatedAt: string
}

export interface EnrollmentImportFailureItem {
  rowNumber: number
  email: string | null
  orderNo: string | null
  amount: number | null
  reason: string
}

export interface EnrollmentImportResponse {
  totalRows: number
  successCount: number
  skippedCount: number
  failedCount: number
  failures: EnrollmentImportFailureItem[]
}

export interface CourseResponse {
  id: string
  code: string
  title: string
  description: string | null
  level: string | null
  thumbnailUrl: string | null
  category: string | null
  programId: string
  programCode: string | null
  orderIndex: number
  tags: string[]
  courseRuns: CourseRunResponse[]
  createdAt: string
  updatedAt: string
}

export interface ProgramResponse {
  id: string
  code: string
  title: string
  description: string | null
  thumbnailUrl: string | null
  isPublished: boolean
  publishedAt: string | null
  courses: CourseResponse[]
  createdAt: string
  updatedAt: string
}

export interface AssetResponse {
  url: string
  publicId: string
}

export interface PresignedUploadResponse {
  uploadUrl: string
  downloadUrl: string
  publicId: string
}

/** Event list item — mirrors backend EventFeedItemResponse */
export interface EventFeedItem {
  id: string
  title: string
  description: string
  topic: string
  category: string
  level: string
  status: string
  meetingType: string
  eventDatetime: string
  location: string | null
  maxParticipants: number | null
  interestedCount: number
  likesCount: number
  commentsCount: number
  monitorId: string | null
  monitorDisplayName: string | null
  monitorAvatarUrl: string | null
  isLiked: boolean | null
  isInterested: boolean | null
}

export interface EventFeed {
  items: EventFeedItem[]
  nextCursor: string | null
  hasMore: boolean
}

/** Event detail — mirrors backend EventDetailResponse */
export interface EventDetail {
  id: string
  title: string
  description: string
  topic: string
  category: string
  level: string
  status: string
  meetingType: string
  eventDatetime: string
  location: string | null
  maxParticipants: number | null
  interestedCount: number
  likesCount: number
  commentsCount: number
  monitorId: string | null
  startedAt: string | null
  participantCount: number | null
  isLiked: boolean | null
  isInterested: boolean | null
}

export interface CreateEventResponse {
  eventId: string
  status: string
}

// ─── Request types (mirrors backend DTOs) ─────────────────────────────────────

export interface AuthenticationRequest {
  email: string
  password: string
}

export interface IntrospectRequest {
  token: string
}

export interface RegisterRequest {
  displayName: string
  email: string
  password: string
}

export interface ForgotPasswordRequest {
  email: string
}

export interface VerifyOtpRequest {
  email: string
  otp: string
}

export interface ResetPasswordRequest {
  email: string
  otp: string
  newPassword: string
}

export interface ChangePasswordRequest {
  currentPassword: string
  newPassword: string
}

export interface ProgramUpsertRequest {
  code: string
  title: string
  description?: string | null
  thumbnailUrl?: string | null
  isPublished?: boolean
  publishedAt?: string | null
}

export interface CourseUpsertRequest {
  code: string
  title: string
  description?: string | null
  level?: string | null
  thumbnailUrl?: string | null
  category?: string | null
  programId: string
  orderIndex: number
  tags?: string[]
}

export interface CourseRunUpsertRequest {
  courseId: string
  code: string
  status: string
  startsAt: string   // ISO 8601 — backend: Instant (@NotNull)
  endsAt: string     // ISO 8601 — backend: Instant (@NotNull)
  timezone: string
  metadata?: Record<string, unknown>
}

export interface ManualEnrollmentRequest {
  userId: string
  courseRunId: string
}

export interface ChapterUpsertRequest {
  courseRunId: string
  title: string
  description?: string | null
  orderIndex: number
}

export interface LessonUpsertRequest {
  chapterId: string
  type: string
  title: string
  description?: string | null
  orderIndex: number
  isHidden?: boolean
  isOptional?: boolean
  contentData?: Record<string, unknown>
}

/** Mirrors backend CreateEventRequest */
export interface CreateEventRequest {
  title: string
  description: string
  topic: string
  category: string
  level: string
  eventDatetime: string
  location?: string | null
  meetingType: string
  maxParticipants?: number
}

function buildEventsQuery(params: Record<string, string | number | boolean | undefined | null>): string {
  const search = new URLSearchParams()
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === "") continue
    search.set(key, String(value))
  }
  const q = search.toString()
  return q ? `?${q}` : ""
}

// ─── Auth API ─────────────────────────────────────────────────────────────────
export const authApi = {
  login: (data: AuthenticationRequest) =>
    reqPublic<AuthenticationResponse>("/auth/token", { method: "POST", body: JSON.stringify(data) }),

  introspect: (data: IntrospectRequest) =>
    req<IntrospectResponse>("/auth/introspect", { method: "POST", body: JSON.stringify(data) }),

  register: (data: RegisterRequest) =>
    reqPublic<void>("/auth/register", { method: "POST", body: JSON.stringify(data) }),

  forgotPassword: (data: ForgotPasswordRequest) =>
    reqPublic<void>("/auth/forgot-password", { method: "POST", body: JSON.stringify(data) }),

  verifyOtp: (data: VerifyOtpRequest) =>
    reqPublic<void>("/auth/verify-otp", { method: "POST", body: JSON.stringify(data) }),

  resetPassword: (data: ResetPasswordRequest) =>
    reqPublic<void>("/auth/reset-password", { method: "POST", body: JSON.stringify(data) }),

  changePassword: (data: ChangePasswordRequest) =>
    req<void>("/auth/change-password", { method: "PUT", body: JSON.stringify(data) }),
}

// ─── User API ──────────────────────────────────────────────────────────────────
export const userApi = {
  getMe: async () => normalizeUserResponse(await req<RawUserResponse>("/users/me")),
  getAll: (page = 1, size = 10, field = "createdAt", direction = "DESC") =>
    req<PagingResponse<UserResponse>>(`/users?page=${page}&size=${size}&field=${field}&direction=${direction}`),
  getUsers: async (paging: {
    page: number
    pageSize?: number
    size?: number
    field?: string
    direction?: string
    keyword?: string
    enabled?: boolean
  }) => {
    const params = new URLSearchParams()
    params.set("page", String(paging.page))
    // Backend uses "size" instead of "pageSize".
    params.set("size", String(paging.size ?? paging.pageSize ?? 10))
    if (paging.field) params.set("field", paging.field)
    if (paging.direction) params.set("direction", paging.direction)
    if (paging.keyword) params.set("keyword", paging.keyword)
    if (typeof paging.enabled === "boolean") params.set("enabled", String(paging.enabled))
    const response = await req<PagingResponse<RawUserResponse> | SpringPage<RawUserResponse>>(`/users?${params.toString()}`)
    if ("content" in response) {
      return {
        currentPage: response.number + 1,
        pageSize: response.size,
        totalPages: response.totalPages,
        totalElement: response.totalElements,
        data: response.content.map(normalizeUserResponse),
      } satisfies PagingResponse<UserResponse>
    }
    return {
      ...response,
      data: response.data.map(normalizeUserResponse),
    }
  },
  getById: (id: string) => req<RawUserResponse>(`/users/${id}`).then(normalizeUserResponse),
}

// ─── Program API ───────────────────────────────────────────────────────────────
export const programApi = {
  getAll: () =>
    req<ProgramResponse[]>("/programs"),

  create: (data: ProgramUpsertRequest) =>
    req<ProgramResponse>("/programs", { method: "POST", body: JSON.stringify(data) }),

  update: (id: string, data: ProgramUpsertRequest) =>
    req<ProgramResponse>(`/programs/${id}`, { method: "PUT", body: JSON.stringify(data) }),

  getById: (id: string) =>
    req<ProgramResponse>(`/programs/${id}`),

  remove: (id: string) =>
    req<string>(`/programs/${id}`, { method: "DELETE" }),
}

// ─── Course API (Management) ──────────────────────────────────────────────────
export const courseApi = {
  getAll: (programId?: string) =>
    req<CourseResponse[]>(programId ? `/courses?programId=${encodeURIComponent(programId)}` : "/courses"),

  getById: (id: string) =>
    req<CourseResponse>(`/courses/${id}`),

  create: (data: CourseUpsertRequest) =>
    req<CourseResponse>("/courses", { method: "POST", body: JSON.stringify(data) }),

  update: (id: string, data: CourseUpsertRequest) =>
    req<CourseResponse>(`/courses/${id}`, { method: "PUT", body: JSON.stringify(data) }),

  remove: (id: string) =>
    req<string>(`/courses/${id}`, { method: "DELETE" }),
}

// ─── CourseRun API ─────────────────────────────────────────────────────────────
export const courseRunApi = {
  getById: (id: string) =>
    req<CourseRunResponse>(`/course-runs/${id}`),

  getAll: (courseId?: string) =>
    req<CourseRunResponse[]>(courseId ? `/course-runs?courseId=${encodeURIComponent(courseId)}` : "/course-runs"),

  create: (data: CourseRunUpsertRequest) =>
    req<CourseRunResponse>("/course-runs", { method: "POST", body: JSON.stringify(data) }),

  update: (id: string, data: CourseRunUpsertRequest) =>
    req<CourseRunResponse>(`/course-runs/${id}`, { method: "PUT", body: JSON.stringify(data) }),

  remove: (id: string) =>
    req<string>(`/course-runs/${id}`, { method: "DELETE" }),
}

export const enrollmentApi = {
  getByCourseRun: (courseRunId: string) =>
    req<EnrollmentResponse[]>(`/enrollments/by-course-run/${encodeURIComponent(courseRunId)}`),

  manualEnroll: (data: ManualEnrollmentRequest) =>
    req<EnrollmentResponse>("/enrollments/manual", { method: "POST", body: JSON.stringify(data) }),

  importByExcel: async (courseRunId: string, file: File, dryRun = false) => {
    const token = authStorage.getToken()
    const headers: Record<string, string> = {}
    if (token) headers["Authorization"] = `Bearer ${token}`

    const form = new FormData()
    form.append("courseRunId", courseRunId)
    form.append("file", file)
    form.append("dryRun", String(dryRun))

    const res = await fetch(`${BASE}/enrollments/import`, {
      method: "POST",
      headers,
      body: form,
    })
    const body = await parseJsonBody(res)
    if (!res.ok) {
      throw new Error(extractApiErrorMessage(body, buildHttpErrorMessage(res)))
    }
    const json = body as ApiResponse<EnrollmentImportResponse>
    if (!json || typeof json !== "object" || typeof json.data === "undefined") {
      throw new Error("Missing response data")
    }
    return json.data
  },

  downloadImportTemplate: async () => {
    const token = authStorage.getToken()
    const headers: Record<string, string> = {}
    if (token) headers["Authorization"] = `Bearer ${token}`
    const res = await fetch(`${BASE}/enrollments/import-template`, { headers })
    if (!res.ok) throw new Error(buildHttpErrorMessage(res))
    return res.blob()
  },
}

// ─── Chapter API ───────────────────────────────────────────────────────────────
export const chapterApi = {
  getAll: (courseRunId?: string) =>
    req<ChapterResponse[]>(courseRunId ? `/chapters?courseRunId=${encodeURIComponent(courseRunId)}` : "/chapters"),

  create: (data: ChapterUpsertRequest) =>
    req<ChapterResponse>("/chapters", { method: "POST", body: JSON.stringify(data) }),

  update: (id: string, data: ChapterUpsertRequest) =>
    req<ChapterResponse>(`/chapters/${id}`, { method: "PUT", body: JSON.stringify(data) }),

  getById: (id: string) =>
    req<ChapterResponse>(`/chapters/${id}`),

  remove: (id: string) =>
    req<string>(`/chapters/${id}`, { method: "DELETE" }),
}

// ─── Lesson API ────────────────────────────────────────────────────────────────
export const lessonApi = {
  getAll: (chapterId?: string) =>
    req<LessonResponse[]>(chapterId ? `/lessons?chapterId=${encodeURIComponent(chapterId)}` : "/lessons"),

  getById: (id: string) =>
    req<LessonResponse>(`/lessons/${id}`),

  create: (data: LessonUpsertRequest) =>
    req<LessonResponse>("/lessons", { method: "POST", body: JSON.stringify(data) }),

  update: (id: string, data: LessonUpsertRequest) =>
    req<LessonResponse>(`/lessons/${id}`, { method: "PUT", body: JSON.stringify(data) }),

  remove: (id: string) =>
    req<string>(`/lessons/${id}`, { method: "DELETE" }),

  uploadFile: (id: string, file: File) => {
    const form = new FormData()
    form.append("file", file)
    return reqForm<LessonFileUploadResponse>(`/lessons/${id}/files`, form)
  },
}

// ─── Syllabus API (root `/api/syllabus`) ─────────────────────────────────────
export interface SyllabusItemResponse {
  id: string
  levelNumber: number
  subLevelNumber: number
  category: string
  topicTitle: string
  warmupContent?: Record<string, unknown> | null
  coreContent?: Record<string, unknown> | null
  wrapupContent?: Record<string, unknown> | null
  createdAt?: string
}

export const syllabusApi = {
  list: (params: { levelNumber?: number; topicTitle?: string; category?: string }) =>
    req<SyllabusItemResponse[]>(`/api/syllabus${buildEventsQuery(params)}`),
}

// ─── Event API ────────────────────────────────────────────────────────────────
export const eventApi = {
  getFeed: (params: {
    cursor?: string
    limit?: number
    query?: string
    status?: string
    meetingType?: string
    mine?: boolean
    interested?: boolean
    from?: string
    to?: string
  }) =>
    req<EventFeed>(`/api/events${buildEventsQuery(params)}`),

  getById: (id: string) => req<EventDetail>(`/api/events/${id}`),

  create: (data: CreateEventRequest) =>
    req<CreateEventResponse>("/api/events", { method: "POST", body: JSON.stringify(data) }),
}

// ─── Asset API ────────────────────────────────────────────────────────────────
export const assetApi = {
  upload: (file: File) => {
    const form = new FormData()
    form.append("file", file)
    return reqForm<AssetResponse>("/assets/upload", form)
  },
  uploadLessonAsset: async (file: File) => {
    const fileName = encodeURIComponent(file.name)
    const contentType = encodeURIComponent(file.type || "application/octet-stream")
    const presigned = await req<PresignedUploadResponse>(`/assets/r2/presigned-upload?fileName=${fileName}&contentType=${contentType}`)

    await uploadToPresignedUrl(presigned.uploadUrl, file, file.type || "application/octet-stream")

    return {
      url: presigned.downloadUrl,
      publicId: presigned.publicId,
    } satisfies AssetResponse
  },
}
