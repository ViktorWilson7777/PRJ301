/** Lucy Admin requires backend UserRole.ADMIN (serialized as "ADMIN"). */
export function isLucyAdminRole(roles: string[] | undefined | null): boolean {
  if (!roles?.length) return false
  return roles.some((role) => {
    const u = role.toUpperCase()
    return u === "ADMIN" || u === "ROLE_ADMIN"
  })
}
