import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Navigate, useNavigate } from "react-router-dom";
import { tokenStorage } from "../../../core/auth/token-storage";
import { env } from "../../../core/config/env";
import { toReadableError } from "../../../core/errors/api-error";
import { loginSchema, type LoginInput } from "../identity.schemas";
import { useGoogleLogin, useLogin } from "../identity.hooks";
import "./login-page.css";

type GoogleCredentialResponse = {
  credential?: string;
};

type GoogleAccountsId = {
  initialize: (config: {
    client_id: string;
    callback: (response: GoogleCredentialResponse) => void;
  }) => void;
  renderButton: (
    parent: HTMLElement,
    options: {
      theme?: "outline" | "filled_blue" | "filled_black";
      size?: "large" | "medium" | "small";
      text?: "signin_with" | "signup_with" | "continue_with" | "signin";
      shape?: "rectangular" | "pill" | "circle" | "square";
      width?: number;
    },
  ) => void;
  prompt: () => void;
};

type GoogleNamespace = {
  accounts: {
    id: GoogleAccountsId;
  };
};

declare global {
  interface Window {
    google?: GoogleNamespace;
  }
}

export function LoginPage() {
  const navigate = useNavigate();
  const login = useLogin();
  const googleLogin = useGoogleLogin();
  const [isGoogleReady, setIsGoogleReady] = useState(false);
  const googleButtonRef = useRef<HTMLDivElement | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const { register, handleSubmit, formState } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
  });

  useEffect(() => {
    if (!env.googleClientId) {
      return;
    }

    const initializeGoogle = () => {
      if (!window.google?.accounts?.id) {
        return;
      }
      window.google.accounts.id.initialize({
        client_id: env.googleClientId,
        callback: async (response) => {
          if (!response.credential) return;
          setSubmitError(null);
          try {
            await googleLogin.mutateAsync({ idToken: response.credential });
            navigate("/", { replace: true });
          } catch (err) {
            setSubmitError(toReadableError(err));
          }
        },
      });
      if (googleButtonRef.current) {
        googleButtonRef.current.innerHTML = "";
        window.google.accounts.id.renderButton(googleButtonRef.current, {
          theme: "outline",
          size: "large",
          text: "continue_with",
          shape: "pill",
          width: 360,
        });
      }
      setIsGoogleReady(true);
    };

    if (window.google?.accounts?.id) {
      initializeGoogle();
      return;
    }

    const scriptId = "google-identity-service";
    const existing = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (existing) {
      existing.addEventListener("load", initializeGoogle);
      return () => existing.removeEventListener("load", initializeGoogle);
    }

    const script = document.createElement("script");
    script.id = scriptId;
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    script.addEventListener("load", initializeGoogle);
    document.head.appendChild(script);

    return () => script.removeEventListener("load", initializeGoogle);
  }, [googleLogin, navigate]);

  if (tokenStorage.getAccessToken()) {
    return <Navigate to="/" replace />;
  }

  return (
    <section className="login-page">
      <div className="login-card">
        <p className="login-badge">Lucy Frontend Platform</p>
        <h1 className="login-title">Welcome back</h1>
        <p className="login-subtitle">
          Sign in to continue working with Identity, LMS, Event and Syllabus modules.
        </p>
        <form
          onSubmit={handleSubmit(async (values) => {
            setSubmitError(null);
            try {
              await login.mutateAsync(values);
              navigate("/", { replace: true });
            } catch (err) {
              setSubmitError(toReadableError(err));
            }
          })}
          className="login-form"
        >
          <label className="login-field">
            <span>Email</span>
            <input {...register("email")} placeholder="admin@example.com" />
          </label>
          {formState.errors.email && <small className="login-error">{formState.errors.email.message}</small>}
          <label className="login-field">
            <span>Password</span>
            <input type="password" {...register("password")} placeholder="Enter your password" />
          </label>
          {formState.errors.password && (
            <small className="login-error">{formState.errors.password.message}</small>
          )}
          {submitError && (
            <p className="login-error" role="alert">
              {submitError}
            </p>
          )}
          <button className="login-submit" type="submit" disabled={login.isPending}>
            {login.isPending ? "Signing in..." : "Sign in"}
          </button>
          <div className="login-divider" aria-hidden="true">
            <span>or</span>
          </div>
          <div className="login-google-wrap" aria-label="Google sign-in container">
            <div ref={googleButtonRef} />
          </div>
          {env.googleClientId && !isGoogleReady && (
            <button type="button" className="login-google" disabled>
              Loading Google sign-in...
            </button>
          )}
          {!env.googleClientId && (
            <small className="login-hint">Missing `VITE_GOOGLE_CLIENT_ID` in frontend environment.</small>
          )}
        </form>
      </div>
    </section>
  );
}

