import { useState } from "react";
import { toReadableError } from "../../../core/errors/api-error";
import { QueryState } from "../../../shared/components/query-state";
import { SectionCard } from "../../../shared/components/section-card";
import { tokenStorage } from "../../../core/auth/token-storage";
import { useBanUser, useToggleUserStatus, useUpdateUserRoles, useUsers } from "../identity.hooks";
import "./users-page.css";

export function UsersPage() {
  const [keyword, setKeyword] = useState("");
  const currentUser = tokenStorage.getUser();
  const isAdmin = (currentUser?.roles || []).some((role) => role.toLowerCase() === "admin");
  const usersQuery = useUsers(keyword, isAdmin);
  const toggleStatus = useToggleUserStatus();
  const banUser = useBanUser();
  const updateRoles = useUpdateUserRoles();
  const users = usersQuery.data?.data ?? [];

  if (!isAdmin) {
    return (
      <SectionCard title="Identity Users">
        <p className="users-page__empty">Admin permission is required.</p>
      </SectionCard>
    );
  }

  return (
    <SectionCard title="Identity Users">
      <div className="users-page__toolbar">
        <input
          className="users-page__input"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          placeholder="Search by email or name"
        />
      </div>
      <QueryState
        isLoading={usersQuery.isLoading}
        error={usersQuery.error ? toReadableError(usersQuery.error) : null}
      />
      <table className="users-page__table">
        <thead>
          <tr>
            <th>Email</th>
            <th>Name</th>
            <th>Roles</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {users.length === 0 && (
            <tr>
              <td colSpan={4} className="users-page__empty-cell">
                No users found.
              </td>
            </tr>
          )}
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.email}</td>
              <td>{user.displayName || "-"}</td>
              <td>{(user.roles || []).join(", ") || "-"}</td>
              <td className="users-page__actions">
                <button
                  className="users-page__btn"
                  onClick={() =>
                    toggleStatus.mutate({
                      userId: user.id,
                      isActive: !user.isActive,
                    })
                  }
                  disabled={toggleStatus.isPending}
                >
                  {user.isActive ? "Deactivate" : "Activate"}
                </button>
                <button
                  className="users-page__btn"
                  onClick={() =>
                    banUser.mutate({
                      userId: user.id,
                      bannedUntil: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
                    })
                  }
                  disabled={banUser.isPending}
                >
                  Ban 24h
                </button>
                <button
                  className="users-page__btn"
                  onClick={() =>
                    updateRoles.mutate({
                      userId: user.id,
                      roles: ["student"],
                    })
                  }
                  disabled={updateRoles.isPending}
                >
                  Set Student Role
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </SectionCard>
  );
}

