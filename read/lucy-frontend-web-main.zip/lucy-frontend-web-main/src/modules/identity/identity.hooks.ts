import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { tokenStorage } from "../../core/auth/token-storage";
import { identityApi } from "./identity.api";
import type { LoginInput } from "./identity.schemas";

export function useLogin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: LoginInput) => identityApi.login(payload),
    onSuccess: (result) => {
      tokenStorage.saveSession({
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
        user: result.user,
      });
      queryClient.invalidateQueries({ queryKey: ["identity", "me"] });
    },
  });
}

export function useGoogleLogin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: { idToken: string }) => identityApi.loginWithGoogle(payload),
    onSuccess: (result) => {
      tokenStorage.saveSession({
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
        user: result.user,
      });
      queryClient.invalidateQueries({ queryKey: ["identity", "me"] });
    },
  });
}

export function useMe() {
  return useQuery({
    queryKey: ["identity", "me"],
    queryFn: identityApi.me,
    enabled: Boolean(tokenStorage.getAccessToken()),
  });
}

export function useUsers(keyword: string, enabled = true) {
  return useQuery({
    queryKey: ["identity", "users", keyword],
    queryFn: () =>
      identityApi.users({
        page: 1,
        size: 20,
        keyword: keyword || undefined,
        direction: "DESC",
        field: "createdAt",
      }),
    retry: false,
    enabled,
  });
}

export function useToggleUserStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ userId, isActive }: { userId: string; isActive: boolean }) =>
      identityApi.updateUserStatus(userId, isActive),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["identity", "users"] });
    },
  });
}

export function useBanUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ userId, bannedUntil }: { userId: string; bannedUntil: string | null }) =>
      identityApi.banUser(userId, bannedUntil),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["identity", "users"] }),
  });
}

export function useUpdateUserRoles() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ userId, roles }: { userId: string; roles: string[] }) =>
      identityApi.updateUserRoles(userId, roles),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["identity", "users"] }),
  });
}