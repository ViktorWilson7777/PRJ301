import { describe, expect, it } from "vitest";
import { loginSchema } from "./identity.schemas";

describe("loginSchema", () => {
  it("validates a correct payload", () => {
    const parsed = loginSchema.safeParse({
      email: "admin@example.com",
      password: "12345678",
    });
    expect(parsed.success).toBe(true);
  });

  it("rejects invalid email", () => {
    const parsed = loginSchema.safeParse({
      email: "invalid",
      password: "12345678",
    });
    expect(parsed.success).toBe(false);
  });
});

