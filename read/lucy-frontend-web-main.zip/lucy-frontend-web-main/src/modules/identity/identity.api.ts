import { apiGet, apiPost, apiPut } from "../../core/http/http-client";
import type { PagingResponse } from "../../core/types/api";

export type UserDto = {
  id: string;
  email: string;
  displayName?: string;
  roles?: string[];
  isActive?: boolean;
};

type AuthResponse = {
  authenticated: boolean;
  accessToken: string;
  refreshToken?: string;
  user: UserDto;
};

export const identityApi = {
  login(payload: { email: string; password: string }) {
    return apiPost<AuthResponse, typeof payload>("/auth/token", payload);
  },
  loginWithGoogle(payload: { idToken: string }) {
    return apiPost<AuthResponse, typeof payload>("/auth/google", payload);
  },
  refresh(refreshToken: string) {
    return apiPost<AuthResponse, { refreshToken: string }>("/auth/refresh", { refreshToken });
  },
  logout(refreshToken: string) {
    return apiPost<{ success: boolean }, { refreshToken: string }>("/auth/logout", { refreshToken });
  },
  me() {
    return apiGet<UserDto>("/users/me");
  },
  users(params: {
    page?: number;
    size?: number;
    keyword?: string;
    direction?: "ASC" | "DESC";
    field?: string;
  }) {
    return apiGet<PagingResponse<UserDto>>("/users", params);
  },
  updateUserStatus(userId: string, isActive: boolean) {
    return apiPut<UserDto, { isActive: boolean }>(`/admin/users/${userId}/status`, { isActive });
  },
  banUser(userId: string, bannedUntil: string | null) {
    return apiPut<UserDto, { bannedUntil: string | null }>(`/admin/users/${userId}/ban`, {
      bannedUntil,
    });
  },
  updateUserRoles(userId: string, roles: string[]) {
    return apiPut<UserDto, { roles: string[] }>(`/admin/users/${userId}/roles`, { roles });
  },
};

