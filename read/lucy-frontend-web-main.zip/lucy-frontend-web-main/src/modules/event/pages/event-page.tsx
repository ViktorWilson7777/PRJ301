import { useState } from "react";
import { toReadableError } from "../../../core/errors/api-error";
import { QueryState } from "../../../shared/components/query-state";
import { SectionCard } from "../../../shared/components/section-card";
import {
  useEventComments,
  useEventDetail,
  useEventFeed,
  useJoinEvent,
  useLeaveEvent,
  useToggleInterest,
  useToggleLike,
} from "../event.hooks";
import "./event-page.css";

export function EventPage() {
  const [selectedEventId, setSelectedEventId] = useState<string | undefined>();
  const feed = useEventFeed();
  const detail = useEventDetail(selectedEventId);
  const comments = useEventComments(selectedEventId);
  const joinEvent = useJoinEvent();
  const leaveEvent = useLeaveEvent();
  const toggleInterest = useToggleInterest();
  const toggleLike = useToggleLike();

  return (
    <SectionCard title="Event Hub">
      <QueryState
        isLoading={feed.isLoading}
        error={feed.error ? toReadableError(feed.error) : null}
      />
      <div className="event-page">
        <ul className="event-page__list">
          {(feed.data?.items || []).map((item, index) => (
            <li
              key={item.eventId || `${item.title}-${item.status}-${index}`}
              className={`event-page__item ${selectedEventId === item.eventId ? "active" : ""}`}
            >
              <button className="event-page__item-title" onClick={() => setSelectedEventId(item.eventId)}>
                {item.title}
              </button>
              <div className="event-page__meta-row">
                <span className={`event-page__badge event-page__badge--${item.status?.toLowerCase() || "default"}`}>
                  {item.status || "UNKNOWN"}
                </span>
                {item.topic && <span className="event-page__topic">{item.topic}</span>}
              </div>
              <div className="event-page__actions">
                <button
                  className="event-page__action-btn"
                  disabled={!item.eventId}
                  onClick={() =>
                    toggleInterest.mutate({ eventId: item.eventId, interested: !item.interested })
                  }
                >
                  {item.interested ? "Uninterest" : "Interest"}
                </button>
                <button
                  className="event-page__action-btn"
                  disabled={!item.eventId}
                  onClick={() => toggleLike.mutate({ eventId: item.eventId, liked: !item.liked })}
                >
                  {item.liked ? "Unlike" : "Like"}
                </button>
              </div>
            </li>
          ))}
        </ul>
        <div className="event-page__detail">
          <h4 className="event-page__detail-title">{detail.data?.title || "Select an event"}</h4>
          <p className="event-page__detail-status">Status: {detail.data?.status || "-"}</p>
          <div className="event-page__join-row">
            <button
              className="event-page__cta event-page__cta--primary"
              disabled={!selectedEventId || joinEvent.isPending}
              onClick={() => selectedEventId && joinEvent.mutate(selectedEventId)}
            >
              Join
            </button>
            <button
              className="event-page__cta"
              disabled={!selectedEventId || leaveEvent.isPending}
              onClick={() => selectedEventId && leaveEvent.mutate(selectedEventId)}
            >
              Leave
            </button>
          </div>
          <strong className="event-page__comment-title">Comments</strong>
          <ul className="event-page__comments">
            {(comments.data?.items || []).map((comment) => (
              <li key={comment.id} className="event-page__comment-item">
                <p>{comment.content}</p>
                <span>{comment.createdBy}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </SectionCard>
  );
}