import { apiDelete, apiGet, apiPost } from "../../core/http/http-client";

export type EventItem = {
  eventId: string;
  title: string;
  status: string;
  topic?: string;
  interested?: boolean;
  liked?: boolean;
};

export type EventFeed = {
  items: EventItem[];
  nextCursor?: string;
  hasMore: boolean;
};

function normalizeEventItem(raw: Record<string, unknown>): EventItem {
  const eventId = (raw.eventId ?? raw.id ?? "") as string;
  return {
    eventId,
    title: (raw.title ?? raw.name ?? "Untitled event") as string,
    status: (raw.status ?? "UNKNOWN") as string,
    topic: (raw.topic ?? raw.meetingType ?? undefined) as string | undefined,
    interested: (raw.interested ?? raw.isInterested ?? false) as boolean,
    liked: (raw.liked ?? raw.isLiked ?? false) as boolean,
  };
}

function normalizeEventFeed(raw: unknown): EventFeed {
  const payload = (raw ?? {}) as Record<string, unknown>;
  const rawItems = (payload.items ?? payload.events ?? payload.data ?? []) as Array<Record<string, unknown>>;
  return {
    items: rawItems.map(normalizeEventItem).filter((item) => Boolean(item.eventId)),
    nextCursor: (payload.nextCursor ?? undefined) as string | undefined,
    hasMore: Boolean(payload.hasMore ?? false),
  };
}

export const eventApi = {
  async feed(cursor?: string) {
    const raw = await apiGet<unknown>("/api/events", { cursor, limit: 20 });
    return normalizeEventFeed(raw);
  },
  detail(eventId: string) {
    return apiGet<EventItem>(`/api/events/${eventId}`);
  },
  setInterest(eventId: string, interested: boolean) {
    return apiPost<{ success: boolean }, { interested: boolean }>(`/api/events/${eventId}/interest`, {
      interested,
    });
  },
  setLike(eventId: string, liked: boolean) {
    if (liked) {
      return apiPost<{ success: boolean }, { liked: boolean }>(`/api/events/${eventId}/like`, { liked });
    }

    return apiDelete<{ success: boolean }>(`/api/events/${eventId}/like`);
  },
  comments(eventId: string) {
    return apiGet<{ items: Array<{ id: string; content: string; createdBy: string }> }>(
      `/api/events/${eventId}/comments`,
      { limit: 20 },
    );
  },
  join(eventId: string) {
    return apiPost<{ roomId: string; channelId: string; token: string }, Record<string, never>>(
      `/api/events/${eventId}/join`,
      {},
    );
  },
  leave(eventId: string) {
    return apiPost<{ success: boolean }, Record<string, never>>(`/api/events/${eventId}/leave`, {});
  },
  rtcToken(eventId: string) {
    return apiPost<{ token: string }, Record<string, never>>(`/api/events/${eventId}/rtc-token`, {});
  },
  participants(roomId: string) {
    return apiGet<Array<{ userId: string; micOn?: boolean; handRaised?: boolean }>>(
      `/api/events/rooms/${roomId}/participants`,
    );
  },
  roomState(eventId: string, roomId: string) {
    return apiGet<{ micStates: Record<string, boolean>; handQueue: string[] }>(
      `/api/events/${eventId}/rooms/${roomId}/participants/realtime-state`,
    );
  },
};

