import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { eventApi } from "./event.api";

export function useEventFeed(cursor?: string) {
  return useQuery({
    queryKey: ["event", "feed", cursor],
    queryFn: () => eventApi.feed(cursor),
  });
}

export function useEventDetail(eventId?: string) {
  return useQuery({
    queryKey: ["event", "detail", eventId],
    queryFn: () => eventApi.detail(eventId as string),
    enabled: Boolean(eventId),
  });
}

export function useEventComments(eventId?: string) {
  return useQuery({
    queryKey: ["event", "comments", eventId],
    queryFn: () => eventApi.comments(eventId as string),
    enabled: Boolean(eventId),
  });
}

export function useToggleInterest() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ eventId, interested }: { eventId: string; interested: boolean }) =>
      eventApi.setInterest(eventId, interested),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["event", "feed"] }),
  });
}

export function useToggleLike() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ eventId, liked }: { eventId: string; liked: boolean }) =>
      eventApi.setLike(eventId, liked),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["event", "feed"] }),
  });
}

export function useJoinEvent() {
  return useMutation({
    mutationFn: (eventId: string) => eventApi.join(eventId),
  });
}

export function useLeaveEvent() {
  return useMutation({
    mutationFn: (eventId: string) => eventApi.leave(eventId),
  });
}

