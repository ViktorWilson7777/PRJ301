import { useMutation, useQuery } from "@tanstack/react-query";
import { lmsApi } from "./lms.api";

export function usePrograms() {
  return useQuery({ queryKey: ["lms", "programs"], queryFn: lmsApi.programs });
}

export function useCourses(programId?: string) {
  return useQuery({
    queryKey: ["lms", "courses", programId],
    queryFn: () => lmsApi.courses(programId),
  });
}

export function useCourseRuns(courseId?: string) {
  return useQuery({
    queryKey: ["lms", "courseRuns", courseId],
    queryFn: () => lmsApi.courseRuns(courseId),
  });
}

export function useChapters(courseRunId?: string) {
  return useQuery({
    queryKey: ["lms", "chapters", courseRunId],
    queryFn: () => lmsApi.chapters(courseRunId),
    enabled: Boolean(courseRunId),
  });
}

export function useLessons(chapterId?: string) {
  return useQuery({
    queryKey: ["lms", "lessons", chapterId],
    queryFn: () => lmsApi.lessons(chapterId),
    enabled: Boolean(chapterId),
  });
}

export function useEnrollmentFilter(courseRunId?: string) {
  return useQuery({
    queryKey: ["lms", "enrollments", courseRunId],
    queryFn: () => lmsApi.filterEnrollments(courseRunId as string),
    enabled: Boolean(courseRunId),
  });
}

export function useImportEnrollments() {
  return useMutation({
    mutationFn: ({ file, courseRunId }: { file: File; courseRunId: string }) =>
      lmsApi.importEnrollment(file, courseRunId),
  });
}

export function useUploadLessonFile() {
  return useMutation({
    mutationFn: ({ lessonId, file }: { lessonId: string; file: File }) =>
      lmsApi.uploadLessonFile(lessonId, file),
  });
}

export function useProgressSummary(courseRunId?: string) {
  return useQuery({
    queryKey: ["lms", "progressSummary", courseRunId],
    queryFn: () => lmsApi.progressSummary(courseRunId as string),
    enabled: Boolean(courseRunId),
  });
}

