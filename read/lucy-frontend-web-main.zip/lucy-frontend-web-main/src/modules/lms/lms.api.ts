import { apiGet, apiMultipart, apiPost } from "../../core/http/http-client";
import type { PagingResponse } from "../../core/types/api";

export type Program = { id: string; code: string; title: string };
export type Course = { id: string; code: string; title: string; programId?: string };
export type CourseRun = { id: string; code: string; status: string; courseId: string };
export type Enrollment = { id: string; userId: string; courseRunId: string; status?: string };
export type LessonProgress = { lessonId: string; status: string; progressPercent?: number };
export type Chapter = { id: string; title: string; courseRunId: string; orderIndex: number };
export type Lesson = { id: string; title: string; chapterId: string; type: string; orderIndex: number };

export const lmsApi = {
  programs() {
    return apiGet<Program[]>("/programs");
  },
  courses(programId?: string) {
    return apiGet<Course[]>("/courses", { programId });
  },
  courseRuns(courseId?: string) {
    return apiGet<CourseRun[]>("/course-runs", { courseId });
  },
  chapters(courseRunId?: string) {
    return apiGet<Chapter[]>("/chapters", { courseRunId });
  },
  lessons(chapterId?: string) {
    return apiGet<Lesson[]>("/lessons", { chapterId });
  },
  courseRunRoadmap(courseRunId: string) {
    return apiGet<Record<string, unknown>>(`/course-runs/${courseRunId}/roadmap`);
  },
  filterEnrollments(courseRunId: string) {
    return apiPost<PagingResponse<Enrollment>, Record<string, unknown>>("/enrollments/filter", {
      courseRunId,
      conditions: [],
      page: 1,
      pageSize: 20,
    });
  },
  importEnrollment(file: File, courseRunId: string) {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("courseRunId", courseRunId);
    return apiMultipart<{ successCount: number; failedCount: number }>("/enrollments/import", formData);
  },
  uploadLessonFile(lessonId: string, file: File) {
    const formData = new FormData();
    formData.append("file", file);
    return apiMultipart<{ fileUrl?: string }>(`/lessons/${lessonId}/files`, formData);
  },
  progressSummary(courseRunId: string) {
    return apiGet<{ courseRunId: string; completedLessons: number; totalLessons: number }>(
      `/progress/me/course-runs/${courseRunId}/summary`,
    );
  },
  progressLessons(courseRunId: string) {
    return apiGet<LessonProgress[]>(`/progress/me/course-runs/${courseRunId}/lessons`);
  },
};

