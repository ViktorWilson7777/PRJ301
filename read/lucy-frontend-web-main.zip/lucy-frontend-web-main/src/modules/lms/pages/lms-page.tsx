import { useMemo, useState } from "react";
import { toReadableError } from "../../../core/errors/api-error";
import { QueryState } from "../../../shared/components/query-state";
import { SectionCard } from "../../../shared/components/section-card";
import {
  useChapters,
  useCourseRuns,
  useCourses,
  useEnrollmentFilter,
  useImportEnrollments,
  useLessons,
  usePrograms,
  useProgressSummary,
  useUploadLessonFile,
} from "../lms.hooks";
import "./lms-page.css";

export function LmsPage() {
  const [programId, setProgramId] = useState("");
  const [courseId, setCourseId] = useState("");
  const [courseRunId, setCourseRunId] = useState("");
  const [chapterId, setChapterId] = useState("");
  const [lessonId, setLessonId] = useState("");
  const programs = usePrograms();
  const courses = useCourses(programId || undefined);
  const courseRuns = useCourseRuns(courseId || undefined);
  const enrollments = useEnrollmentFilter(courseRunId || undefined);
  const chapters = useChapters(courseRunId || undefined);
  const lessons = useLessons(chapterId || undefined);
  const summary = useProgressSummary(courseRunId || undefined);
  const importer = useImportEnrollments();
  const lessonUploader = useUploadLessonFile();

  const statusError = useMemo(() => {
    return (
      programs.error ||
      courses.error ||
      courseRuns.error ||
      chapters.error ||
      lessons.error ||
      enrollments.error ||
      summary.error
    );
  }, [
    chapters.error,
    courseRuns.error,
    courses.error,
    enrollments.error,
    lessons.error,
    programs.error,
    summary.error,
  ]);

  return (
    <SectionCard title="LMS">
      <QueryState
        isLoading={programs.isLoading || courses.isLoading || courseRuns.isLoading}
        error={statusError ? toReadableError(statusError) : null}
      />
      <div className="lms-page__filters">
        <select className="lms-page__select" value={programId} onChange={(e) => setProgramId(e.target.value)}>
          <option value="">Select program</option>
          {(programs.data || []).map((item) => (
            <option key={item.id} value={item.id}>
              {item.title}
            </option>
          ))}
        </select>
        <select className="lms-page__select" value={courseId} onChange={(e) => setCourseId(e.target.value)}>
          <option value="">Select course</option>
          {(courses.data || []).map((item) => (
            <option key={item.id} value={item.id}>
              {item.title}
            </option>
          ))}
        </select>
        <select className="lms-page__select" value={courseRunId} onChange={(e) => setCourseRunId(e.target.value)}>
          <option value="">Select run</option>
          {(courseRuns.data || []).map((item) => (
            <option key={item.id} value={item.id}>
              {item.code} - {item.status}
            </option>
          ))}
        </select>
        <select className="lms-page__select" value={chapterId} onChange={(e) => setChapterId(e.target.value)}>
          <option value="">Select chapter</option>
          {(chapters.data || []).map((item) => (
            <option key={item.id} value={item.id}>
              {item.title}
            </option>
          ))}
        </select>
        <select className="lms-page__select" value={lessonId} onChange={(e) => setLessonId(e.target.value)}>
          <option value="">Select lesson</option>
          {(lessons.data || []).map((item) => (
            <option key={item.id} value={item.id}>
              {item.title}
            </option>
          ))}
        </select>
      </div>
      <p className="lms-page__summary">
        Enrollments: {enrollments.data?.data.length || 0} | Completed lessons:{" "}
        {summary.data?.completedLessons ?? 0}/{summary.data?.totalLessons ?? 0}
      </p>
      <label className="lms-page__upload">
        Import enrollments:
        <input
          type="file"
          accept=".xlsx,.xls,.csv"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file && courseRunId) {
              importer.mutate({ file, courseRunId });
            }
          }}
        />
      </label>
      <label className="lms-page__upload lms-page__upload--secondary">
        Upload lesson file:
        <input
          type="file"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file && lessonId) {
              lessonUploader.mutate({ lessonId, file });
            }
          }}
        />
      </label>
      {!statusError &&
        !programs.isLoading &&
        (programs.data || []).length === 0 && (
          <p className="lms-page__empty">No LMS data available from API.</p>
        )}
    </SectionCard>
  );
}

