import { useQuery } from "@tanstack/react-query";
import { syllabusApi, type SyllabusFilter } from "./syllabus.api";

export function useSyllabus(filter: SyllabusFilter) {
  return useQuery({
    queryKey: ["syllabus", filter],
    queryFn: () => syllabusApi.list(filter),
  });
}

