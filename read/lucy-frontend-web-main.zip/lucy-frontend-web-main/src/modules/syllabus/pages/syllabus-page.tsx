import { useMemo, useState } from "react";
import { toReadableError } from "../../../core/errors/api-error";
import { QueryState } from "../../../shared/components/query-state";
import { SectionCard } from "../../../shared/components/section-card";
import { useSyllabus } from "../syllabus.hooks";
import "./syllabus-page.css";

export function SyllabusPage() {
  const [level, setLevel] = useState("");
  const [topic, setTopic] = useState("");
  const [category, setCategory] = useState("");

  const filter = useMemo(
    () => ({
      levelNumber:
        level.trim() && Number.isFinite(Number(level.trim())) ? Number(level.trim()) : undefined,
      topicTitle: topic || undefined,
      category: category || undefined,
    }),
    [category, level, topic],
  );

  const query = useSyllabus(filter);

  return (
    <SectionCard title="Syllabus">
      <div className="syllabus-page__filters">
        <input className="syllabus-page__input" placeholder="Level" value={level} onChange={(e) => setLevel(e.target.value)} />
        <input className="syllabus-page__input" placeholder="Topic" value={topic} onChange={(e) => setTopic(e.target.value)} />
        <input
          className="syllabus-page__input"
          placeholder="Category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        />
      </div>
      <QueryState
        isLoading={query.isLoading}
        error={query.error ? toReadableError(query.error) : null}
      />
      <ul className="syllabus-page__list">
        {(query.data || []).map((item) => (
          <li key={item.id} className="syllabus-page__item">
            L{item.levelNumber}.{item.subLevelNumber} - {item.category} - {item.topicTitle}
          </li>
        ))}
        {!query.isLoading && (query.data || []).length === 0 && (
          <li className="syllabus-page__empty">No syllabus data available.</li>
        )}
      </ul>
    </SectionCard>
  );
}

