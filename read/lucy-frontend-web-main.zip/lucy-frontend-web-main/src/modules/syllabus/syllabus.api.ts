import { apiGet } from "../../core/http/http-client";

export type SyllabusItem = {
  id: string;
  levelNumber: number;
  subLevelNumber: number;
  category: string;
  topicTitle: string;
};

export type SyllabusFilter = {
  levelNumber?: number;
  topicTitle?: string;
  category?: string;
};

export const syllabusApi = {
  list(filter: SyllabusFilter) {
    return apiGet<SyllabusItem[]>("/api/syllabus", filter);
  },
};

