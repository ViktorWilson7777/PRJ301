type QueryStateProps = {
  isLoading: boolean;
  error: string | null;
};

export function QueryState({ isLoading, error }: QueryStateProps) {
  if (isLoading) return <p style={{ color: "#475569", fontWeight: 600 }}>Loading data...</p>;
  if (error) return <p style={{ color: "#b91c1c", fontWeight: 600 }}>{error}</p>;
  return null;
}

