import type { ReactNode } from "react";
import "./section-card.css";

type SectionCardProps = {
  title: string;
  children: ReactNode;
};

export function SectionCard({ title, children }: SectionCardProps) {
  return (
    <section className="section-card">
      <h3 className="section-card__title">{title}</h3>
      {children}
    </section>
  );
}

