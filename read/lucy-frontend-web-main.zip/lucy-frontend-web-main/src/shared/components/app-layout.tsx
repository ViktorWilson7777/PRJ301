import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { tokenStorage } from "../../core/auth/token-storage";
import "./app-layout.css";

const navItems = [
  { to: "/syllabus", label: "Syllabus" },
  { to: "/lms", label: "LMS" },
  { to: "/events", label: "Event" },
  { to: "/identity/users", label: "Identity" },
];

export function AppLayout() {
  const navigate = useNavigate();
  const user = tokenStorage.getUser();

  return (
    <div className="app-shell">
      <header className="app-shell__header">
        <Link to="/" className="app-shell__brand">
          <span className="app-shell__brand-dot" />
          Lucy Frontend
        </Link>
        <nav className="app-shell__nav">
          {navItems.map((item) => (
            <NavLink key={item.to} to={item.to} className="app-shell__nav-link">
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="app-shell__user-wrap">
          <span className="app-shell__user">{user?.displayName || user?.email || "Guest"}</span>
          <button
            type="button"
            className="app-shell__logout"
            onClick={() => {
              tokenStorage.clearSession();
              navigate("/login", { replace: true });
            }}
          >
            Logout
          </button>
        </div>
      </header>
      <main className="app-shell__content">
        <Outlet />
      </main>
    </div>
  );
}

