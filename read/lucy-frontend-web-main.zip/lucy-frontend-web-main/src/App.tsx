import LucyApp from "./app/App";

export default LucyApp;
