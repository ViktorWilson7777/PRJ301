import json
import uuid
import re

# Load parsed text for Japanese
with open('parsed_docx.json', 'r', encoding='utf-8') as f:
    docs = json.load(f)

# Load English JSON
with open('syllabus_english.json', 'r', encoding='utf-8') as f:
    english_data = json.load(f)

full_text = "\n".join(docs.values())
levels_data = {}

def get_default_sublevels(stage, level_title):
    if stage == 1:
        return [
            f"{level_title} - ウォームアップ",
            f"{level_title} - 基本表現",
            f"{level_title} - 質問と応答",
            f"{level_title} - ロールプレイ",
            f"{level_title} - 自分の意見",
            f"{level_title} - ミニストーリー"
        ]
    elif stage == 2:
        return [
            f"{level_title} - 導入と語彙",
            f"{level_title} - 経験を語る",
            f"{level_title} - 比較と視点",
            f"{level_title} - 問題と解決策",
            f"{level_title} - 意見交換",
            f"{level_title} - ストーリー化"
        ]
    else:
        return [
            "個人的経験",
            "説明・理由付け",
            "比較・視点",
            "問題・課題",
            "振り返り・意見",
            "拡張ストーリー"
        ]

current_level = 0
level_title = ""
sub_levels = []

for line in full_text.split('\n'):
    line = line.strip()
    if not line: continue
    
    m = re.search(r'レベル\s*(\d+)\s*[–\-]\s*(.+)', line)
    if m:
        if current_level > 0:
            levels_data[current_level] = {'title': level_title, 'sub': sub_levels}
        current_level = int(m.group(1))
        level_title = m.group(2).strip()
        sub_levels = []
    elif current_level > 0 and not line.startswith('🔹') and not line.startswith('🔵') and not line.startswith('🎯'):
        if len(sub_levels) < 6:
            sub_levels.append(line)

if current_level > 0:
    levels_data[current_level] = {'title': level_title, 'sub': sub_levels}

with open('seed_category_syllabus.sql', 'w', encoding='utf-8') as out:
    # Upgrade schema
    out.write('ALTER TABLE syllabus ADD COLUMN IF NOT EXISTS category VARCHAR(50);\n')
    out.write('TRUNCATE TABLE syllabus;\n')
    
    # 1. Insert English Syllabus (Level 1-30)
    for item in english_data['json_agg']:
        id_val = item['id']
        lvl = item['level_number']
        slvl = item['sub_level_number']
        title = item['topic_title'].replace("'", "''")
        warmup = json.dumps(item.get('warmup_content', {}), ensure_ascii=False).replace("'", "''")
        core = json.dumps(item.get('core_content', {}), ensure_ascii=False).replace("'", "''")
        wrapup = json.dumps(item.get('wrapup_content', {}), ensure_ascii=False).replace("'", "''")
        created_at = item.get('created_at', 'NOW()')
        if created_at != 'NOW()':
            created_at_val = f"'{created_at}'"
        else:
            created_at_val = "NOW()"
        
        # Insert with category = 'ENGLISH'
        out.write(f"INSERT INTO syllabus (id, category, level_number, sub_level_number, topic_title, warmup_content, core_content, wrapup_content, created_at) VALUES ('{id_val}', 'ENGLISH', {lvl}, {slvl}, '{title}', '{warmup}'::jsonb, '{core}'::jsonb, '{wrapup}'::jsonb, {created_at_val});\n")

    # 2. Insert Japanese Syllabus (Level 1-100)
    for lvl in range(1, 101):
        stage = 1 if lvl <= 30 else (2 if lvl <= 60 else 3)
        duration_warmup = 120 if stage == 1 else (120 if stage == 2 else 180)
        duration_core = 360 if stage == 1 else (660 if stage == 2 else 840)
        duration_wrapup = 120 if stage == 1 else (120 if stage == 2 else 180)
        
        if lvl not in levels_data:
            levels_data[lvl] = {'title': f"Level {lvl} Topic", 'sub': []}
        
        if len(levels_data[lvl]['sub']) < 6:
            defaults = get_default_sublevels(stage, levels_data[lvl]['title'])
            for i in range(len(levels_data[lvl]['sub']), 6):
                levels_data[lvl]['sub'].append(defaults[i])
        elif len(levels_data[lvl]['sub']) > 6:
            levels_data[lvl]['sub'] = levels_data[lvl]['sub'][:6]
            
        for sub_lvl in range(1, 7):
            id_val = str(uuid.uuid4())
            title = levels_data[lvl]['sub'][sub_lvl-1].replace("'", "''")
            
            warmup = {
                "text": f"トピック: {title}",
                "duration": duration_warmup
            }
            core = {
                "prompt": f"「{title}」について話してください。",
                "duration": duration_core,
                "keywords": ["例", "キーワード"]
            }
            wrapup = {
                "text": "よくできました！",
                "duration": duration_wrapup
            }
            
            warmup_str = json.dumps(warmup, ensure_ascii=False).replace("'", "''")
            core_str = json.dumps(core, ensure_ascii=False).replace("'", "''")
            wrapup_str = json.dumps(wrapup, ensure_ascii=False).replace("'", "''")
            
            # Insert with category = 'JAPANESE'
            out.write(f"INSERT INTO syllabus (id, category, level_number, sub_level_number, topic_title, warmup_content, core_content, wrapup_content, created_at) VALUES ('{id_val}', 'JAPANESE', {lvl}, {sub_lvl}, '{title}', '{warmup_str}'::jsonb, '{core_str}'::jsonb, '{wrapup_str}'::jsonb, NOW());\n")

print("Generated seed_category_syllabus.sql")
