import json

with open('syllabus_english.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

with open('seed_syllabus.sql', 'w', encoding='utf-8') as out:
    out.write('TRUNCATE TABLE syllabus;\n')
    for item in data['json_agg']:
        id_val = item['id']
        lvl = item['level_number']
        slvl = item['sub_level_number']
        title = item['topic_title'].replace("'", "''")
        warmup = json.dumps(item.get('warmup_content', {})).replace("'", "''")
        core = json.dumps(item.get('core_content', {})).replace("'", "''")
        wrapup = json.dumps(item.get('wrapup_content', {})).replace("'", "''")
        created_at = item.get('created_at', 'NOW()')
        
        if created_at != 'NOW()':
            created_at_val = f"'{created_at}'"
        else:
            created_at_val = "NOW()"

        out.write(f"INSERT INTO syllabus (id, level_number, sub_level_number, topic_title, warmup_content, core_content, wrapup_content, created_at) VALUES ('{id_val}', {lvl}, {slvl}, '{title}', '{warmup}'::jsonb, '{core}'::jsonb, '{wrapup}'::jsonb, {created_at_val});\n")
print('Generated seed_syllabus.sql')
