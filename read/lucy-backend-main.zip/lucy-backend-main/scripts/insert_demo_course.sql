
-- Insert Program
INSERT INTO programs (id, version, created_at, updated_at, code, title, description, thumbnail_url, is_published, published_at) 
VALUES ('a82eaac8-e70b-46a5-b222-b92b8fcb90de', 0, NOW(), NOW(), 'P-DEMO-01', 'Lucy Demo Program', 'A complete demo program for Lucy LMS', 'https://via.placeholder.com/150', true, NOW());

-- Insert Course
INSERT INTO courses (id, version, created_at, updated_at, code, title, description, level, thumbnail_url, category, program_id, order_index, tags)
VALUES ('0f1696b6-6f52-44a0-864d-022b2075dc26', 0, NOW(), NOW(), 'C-DEMO-01', 'Demo Course 1', 'Introduction to the demo course', 'Beginner', 'https://via.placeholder.com/150', 'General', 'a82eaac8-e70b-46a5-b222-b92b8fcb90de', 1, '{ "demo", "lucy" }');

-- Insert Course Run
INSERT INTO course_runs (id, version, created_at, updated_at, course_id, code, status, starts_at, ends_at, timezone, metadata, enrollment_start_date, enrollment_end_date, capacity)
VALUES ('ff0f72d5-6e8d-43be-908e-11cda7c8215b', 0, NOW(), NOW(), '0f1696b6-6f52-44a0-864d-022b2075dc26', 'CR-DEMO-01-2026', 'PUBLISHED', NOW() - INTERVAL '1 day', NOW() + INTERVAL '30 days', 'UTC', '{}'::jsonb, NOW() - INTERVAL '7 days', NOW() + INTERVAL '7 days', 100);

-- Insert Chapter
INSERT INTO chapters (id, version, created_at, updated_at, course_run_id, title, description, order_index)
VALUES ('0c83eb22-39d6-4f66-8724-8c7200337838', 0, NOW(), NOW(), 'ff0f72d5-6e8d-43be-908e-11cda7c8215b', 'Chapter 1: Getting Started', 'The first chapter of the demo course', 1);

-- Insert Video Lesson
INSERT INTO lessons (id, version, created_at, updated_at, chapter_id, type, title, description, order_index, is_hidden, is_optional, content_data)
VALUES ('84facd3f-1e71-4049-9afa-f31a1df88982', 0, NOW(), NOW(), '0c83eb22-39d6-4f66-8724-8c7200337838', 'VIDEO', 'Welcome Video', 'Introduction to the course concepts', 1, false, false, '{"videoUrl": "https://pub-f9fde820e02a4976b08ee6caab4a7c92.r2.dev/assets/2e303bd4-b83c-42fd-a9b8-697a2a687476-ZL1HEAL1%20Video_Day3%20pm_27-09-2025.mp4", "duration": 300, "provider": "cloudflare_r2"}'::jsonb);

-- Insert Text Lesson
INSERT INTO lessons (id, version, created_at, updated_at, chapter_id, type, title, description, order_index, is_hidden, is_optional, content_data)
VALUES ('9f5fd653-bae5-4f1a-98b6-01eb99ebdbcf', 0, NOW(), NOW(), '0c83eb22-39d6-4f66-8724-8c7200337838', 'TEXT', 'Reading Material', 'Please read these guidelines carefully.', 2, false, false, '{"content": "<p>Welcome to Lucy! Please review the syllabus before starting.</p>"}'::jsonb);
