#!/usr/bin/env python3
"""
Reads syllabus JSON ({ "json_agg": [...] } or [ { "json_agg": [...] } ]) and writes
Flyway migration SQL using batched INSERT ... VALUES with proper SQL escaping.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_JSON = ROOT / "src/main/resources/db/seed/syllabus_english.json"
OUT_SQL = ROOT / "src/main/resources/db/migration/V9__seed_syllabus_english.sql"
BATCH_SIZE = 40


def load_rows(raw: object) -> list[dict]:
    if isinstance(raw, list):
        if len(raw) == 1 and isinstance(raw[0], dict) and "json_agg" in raw[0]:
            return raw[0]["json_agg"]
        if raw and isinstance(raw[0], dict) and "id" in raw[0]:
            return raw
        raise ValueError("Unrecognized list shape for syllabus JSON")
    if isinstance(raw, dict) and "json_agg" in raw:
        return raw["json_agg"]
    raise ValueError("Expected object with json_agg or list of rows")


def sql_str(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


def sql_jsonb(obj: object | None) -> str:
    if obj is None:
        return "NULL"
    return sql_str(json.dumps(obj, ensure_ascii=False)) + "::jsonb"


def row_values(r: dict) -> str:
    uid = sql_str(r["id"])
    lvl = int(r["level_number"])
    sub = int(r["sub_level_number"])
    title = sql_str(r["topic_title"])
    w = sql_jsonb(r.get("warmup_content"))
    c = sql_jsonb(r.get("core_content"))
    u = sql_jsonb(r.get("wrapup_content"))
    ts = sql_str(r["created_at"])
    return f"({uid}::uuid, {lvl}, {sub}, {title}, {w}, {c}, {u}, {ts}::timestamptz)"


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] not in ("-",):
        path = Path(sys.argv[1])
        raw_text = path.read_text(encoding="utf-8")
    elif len(sys.argv) > 1 and sys.argv[1] == "-":
        raw_text = sys.stdin.read()
    else:
        raw_text = DEFAULT_JSON.read_text(encoding="utf-8")

    rows = load_rows(json.loads(raw_text))
    if not rows:
        raise SystemExit("No rows to insert")

    header = (
        "-- English syllabus (Stage 1) — seed for FE dropdowns / event creation\n"
        "-- Regenerate: python scripts/build_syllabus_seed_sql.py\n"
    )
    chunks: list[str] = []
    for i in range(0, len(rows), BATCH_SIZE):
        batch = rows[i : i + BATCH_SIZE]
        values_sql = ",\n".join(row_values(r) for r in batch)
        chunks.append(
            "INSERT INTO syllabus (id, level_number, sub_level_number, topic_title, warmup_content, core_content, wrapup_content, created_at)\n"
            f"VALUES\n{values_sql}\n"
            "ON CONFLICT (id) DO NOTHING;\n"
        )

    OUT_SQL.parent.mkdir(parents=True, exist_ok=True)
    OUT_SQL.write_text(header + "\n".join(chunks), encoding="utf-8")
    print(f"Wrote {OUT_SQL} ({len(rows)} rows in {len(chunks)} batch(es))")


if __name__ == "__main__":
    main()
