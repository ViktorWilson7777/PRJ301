-- Manual PostgreSQL upgrade script for existing Lucy LMS data
-- Use this when:
-- - your database already has LMS data
-- - you do NOT want to use Flyway
-- - you still run the app with JPA/Hibernate
--
-- Recommended runtime after executing this script:
-- 1. SPRING_FLYWAY_ENABLED=false
-- 2. Start app once with SPRING_JPA_HIBERNATE_DDL_AUTO=update
-- 3. After confirming schema is stable, consider switching to validate

BEGIN;

-- ---------------------------------------------------------------------------
-- 1. Identity compatibility
-- ---------------------------------------------------------------------------

ALTER TABLE IF EXISTS user_profiles
    ADD COLUMN IF NOT EXISTS profile_role varchar(20);

UPDATE user_profiles
SET profile_role = 'LUCY'
WHERE profile_role IS NULL;

ALTER TABLE IF EXISTS user_profiles
    ALTER COLUMN profile_role SET DEFAULT 'LUCY';

ALTER TABLE IF EXISTS user_profiles
    ALTER COLUMN profile_role SET NOT NULL;

-- ---------------------------------------------------------------------------
-- 2. Organization tables
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS organizations (
    id varchar(36) PRIMARY KEY,
    version bigint,
    code varchar(100) NOT NULL,
    name varchar(255) NOT NULL,
    description text,
    logo_url text,
    status varchar(20) NOT NULL DEFAULT 'ACTIVE',
    deleted_at timestamptz,
    created_at timestamptz,
    updated_at timestamptz
);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'organizations_code_key'
    ) THEN
        ALTER TABLE organizations
            ADD CONSTRAINT organizations_code_key UNIQUE (code);
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS organization_memberships (
    id varchar(36) PRIMARY KEY,
    version bigint,
    organization_id varchar(36) NOT NULL,
    user_id varchar(36) NOT NULL,
    role varchar(20) NOT NULL,
    status varchar(20) NOT NULL DEFAULT 'ACTIVE',
    joined_at timestamptz NOT NULL DEFAULT now(),
    created_at timestamptz,
    updated_at timestamptz
);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'organization_memberships_org_user_key'
    ) THEN
        ALTER TABLE organization_memberships
            ADD CONSTRAINT organization_memberships_org_user_key UNIQUE (organization_id, user_id);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_organization_memberships_organization'
    ) THEN
        ALTER TABLE organization_memberships
            ADD CONSTRAINT fk_organization_memberships_organization
            FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_organization_memberships_user'
    ) THEN
        ALTER TABLE organization_memberships
            ADD CONSTRAINT fk_organization_memberships_user
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
    END IF;
END $$;

-- ---------------------------------------------------------------------------
-- 3. Core LMS scope columns
-- ---------------------------------------------------------------------------

ALTER TABLE IF EXISTS programs
    ADD COLUMN IF NOT EXISTS access_scope varchar(20),
    ADD COLUMN IF NOT EXISTS organization_id varchar(36),
    ADD COLUMN IF NOT EXISTS owner_user_id varchar(36);

UPDATE programs
SET access_scope = 'PUBLIC'
WHERE access_scope IS NULL;

ALTER TABLE IF EXISTS programs
    ALTER COLUMN access_scope SET DEFAULT 'PUBLIC';

ALTER TABLE IF EXISTS programs
    ALTER COLUMN access_scope SET NOT NULL;

ALTER TABLE IF EXISTS courses
    ADD COLUMN IF NOT EXISTS access_scope varchar(20),
    ADD COLUMN IF NOT EXISTS organization_id varchar(36);

UPDATE courses
SET access_scope = 'PUBLIC'
WHERE access_scope IS NULL;

ALTER TABLE IF EXISTS courses
    ALTER COLUMN access_scope SET DEFAULT 'PUBLIC';

ALTER TABLE IF EXISTS courses
    ALTER COLUMN access_scope SET NOT NULL;

ALTER TABLE IF EXISTS course_runs
    ADD COLUMN IF NOT EXISTS access_scope varchar(20),
    ADD COLUMN IF NOT EXISTS organization_id varchar(36);

UPDATE course_runs
SET access_scope = 'PUBLIC'
WHERE access_scope IS NULL;

ALTER TABLE IF EXISTS course_runs
    ALTER COLUMN access_scope SET DEFAULT 'PUBLIC';

ALTER TABLE IF EXISTS course_runs
    ALTER COLUMN access_scope SET NOT NULL;

ALTER TABLE IF EXISTS enrollments
    ADD COLUMN IF NOT EXISTS access_scope varchar(20),
    ADD COLUMN IF NOT EXISTS organization_id varchar(36);

UPDATE enrollments
SET access_scope = 'PUBLIC'
WHERE access_scope IS NULL;

ALTER TABLE IF EXISTS enrollments
    ALTER COLUMN access_scope SET DEFAULT 'PUBLIC';

ALTER TABLE IF EXISTS enrollments
    ALTER COLUMN access_scope SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_programs_organization'
    ) THEN
        ALTER TABLE programs
            ADD CONSTRAINT fk_programs_organization
            FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE SET NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_courses_organization'
    ) THEN
        ALTER TABLE courses
            ADD CONSTRAINT fk_courses_organization
            FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE SET NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_course_runs_organization'
    ) THEN
        ALTER TABLE course_runs
            ADD CONSTRAINT fk_course_runs_organization
            FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE SET NULL;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_enrollments_organization'
    ) THEN
        ALTER TABLE enrollments
            ADD CONSTRAINT fk_enrollments_organization
            FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE SET NULL;
    END IF;
END $$;

-- ---------------------------------------------------------------------------
-- 4. Backfill owner for old public programs
-- ---------------------------------------------------------------------------
-- Old programs will otherwise be editable only by platform ADMIN or SUPER.
-- This assigns a default owner if a SUPER profile exists.

WITH default_super_owner AS (
    SELECT up.user_id
    FROM user_profiles up
    JOIN users u ON u.id = up.user_id
    WHERE up.profile_role = 'SUPER'
      AND u.deleted_at IS NULL
    ORDER BY u.created_at NULLS FIRST, u.id
    LIMIT 1
)
UPDATE programs p
SET owner_user_id = (SELECT user_id FROM default_super_owner)
WHERE p.access_scope = 'PUBLIC'
  AND p.owner_user_id IS NULL;

-- ---------------------------------------------------------------------------
-- 5. Remove old global code uniqueness
-- ---------------------------------------------------------------------------
-- This is required so different organizations can reuse the same code.

ALTER TABLE IF EXISTS programs
    DROP CONSTRAINT IF EXISTS programs_code_key;

ALTER TABLE IF EXISTS courses
    DROP CONSTRAINT IF EXISTS courses_code_key;

ALTER TABLE IF EXISTS course_runs
    DROP CONSTRAINT IF EXISTS course_runs_code_key;

DROP INDEX IF EXISTS programs_code_key;
DROP INDEX IF EXISTS courses_code_key;
DROP INDEX IF EXISTS course_runs_code_key;

-- ---------------------------------------------------------------------------
-- 6. Add new scope-aware uniqueness
-- ---------------------------------------------------------------------------

CREATE UNIQUE INDEX IF NOT EXISTS ux_programs_public_code
ON programs (lower(code))
WHERE organization_id IS NULL
  AND deleted_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ux_programs_org_code
ON programs (organization_id, lower(code))
WHERE organization_id IS NOT NULL
  AND deleted_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ux_courses_public_code
ON courses (lower(code))
WHERE organization_id IS NULL
  AND deleted_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ux_courses_org_code
ON courses (organization_id, lower(code))
WHERE organization_id IS NOT NULL
  AND deleted_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ux_course_runs_public_code
ON course_runs (lower(code))
WHERE organization_id IS NULL
  AND deleted_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS ux_course_runs_org_code
ON course_runs (organization_id, lower(code))
WHERE organization_id IS NOT NULL
  AND deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_programs_scope_org
ON programs (access_scope, organization_id);

CREATE INDEX IF NOT EXISTS idx_courses_scope_org
ON courses (access_scope, organization_id);

CREATE INDEX IF NOT EXISTS idx_course_runs_scope_org
ON course_runs (access_scope, organization_id);

CREATE INDEX IF NOT EXISTS idx_enrollments_scope_org
ON enrollments (access_scope, organization_id);

-- ---------------------------------------------------------------------------
-- 7. Public commerce tables
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public_course_products (
    id varchar(36) PRIMARY KEY,
    version bigint,
    course_run_id varchar(36) NOT NULL,
    price_amount numeric(19,2) NOT NULL,
    currency varchar(10) NOT NULL,
    is_active boolean NOT NULL DEFAULT true,
    purchase_type varchar(20) NOT NULL DEFAULT 'ONE_TIME',
    created_at timestamptz,
    updated_at timestamptz
);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'public_course_products_run_key'
    ) THEN
        ALTER TABLE public_course_products
            ADD CONSTRAINT public_course_products_run_key UNIQUE (course_run_id);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_public_course_products_course_run'
    ) THEN
        ALTER TABLE public_course_products
            ADD CONSTRAINT fk_public_course_products_course_run
            FOREIGN KEY (course_run_id) REFERENCES course_runs(id) ON DELETE CASCADE;
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS public_orders (
    id varchar(36) PRIMARY KEY,
    version bigint,
    buyer_user_id varchar(36) NOT NULL,
    status varchar(20) NOT NULL DEFAULT 'PENDING',
    total_amount numeric(19,2) NOT NULL,
    currency varchar(10) NOT NULL,
    provider varchar(50) NOT NULL,
    provider_transaction_id varchar(255),
    paid_at timestamptz,
    created_at timestamptz,
    updated_at timestamptz
);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_public_orders_buyer_user'
    ) THEN
        ALTER TABLE public_orders
            ADD CONSTRAINT fk_public_orders_buyer_user
            FOREIGN KEY (buyer_user_id) REFERENCES users(id) ON DELETE CASCADE;
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS public_order_items (
    id varchar(36) PRIMARY KEY,
    version bigint,
    order_id varchar(36) NOT NULL,
    course_run_id varchar(36) NOT NULL,
    unit_price numeric(19,2) NOT NULL,
    created_at timestamptz,
    updated_at timestamptz
);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_public_order_items_order'
    ) THEN
        ALTER TABLE public_order_items
            ADD CONSTRAINT fk_public_order_items_order
            FOREIGN KEY (order_id) REFERENCES public_orders(id) ON DELETE CASCADE;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_public_order_items_course_run'
    ) THEN
        ALTER TABLE public_order_items
            ADD CONSTRAINT fk_public_order_items_course_run
            FOREIGN KEY (course_run_id) REFERENCES course_runs(id) ON DELETE CASCADE;
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS learning_entitlements (
    id varchar(36) PRIMARY KEY,
    version bigint,
    user_id varchar(36) NOT NULL,
    course_run_id varchar(36) NOT NULL,
    source_type varchar(30) NOT NULL,
    source_ref_id varchar(36) NOT NULL,
    status varchar(20) NOT NULL DEFAULT 'ACTIVE',
    created_at timestamptz,
    updated_at timestamptz
);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'learning_entitlements_user_run_source_key'
    ) THEN
        ALTER TABLE learning_entitlements
            ADD CONSTRAINT learning_entitlements_user_run_source_key
            UNIQUE (user_id, course_run_id, source_type, source_ref_id);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_learning_entitlements_user'
    ) THEN
        ALTER TABLE learning_entitlements
            ADD CONSTRAINT fk_learning_entitlements_user
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_learning_entitlements_course_run'
    ) THEN
        ALTER TABLE learning_entitlements
            ADD CONSTRAINT fk_learning_entitlements_course_run
            FOREIGN KEY (course_run_id) REFERENCES course_runs(id) ON DELETE CASCADE;
    END IF;
END $$;

COMMIT;
