import json
import uuid
import re

# Load parsed text
with open('parsed_docx.json', 'r', encoding='utf-8') as f:
    docs = json.load(f)

# Load existing english JSON for Stage 1 to preserve high-quality content
with open('syllabus_english.json', 'r', encoding='utf-8') as f:
    english_data = json.load(f)

full_text = "\n".join(docs.values())
levels_data = {}

def get_default_sublevels(stage, level_title):
    if stage == 2:
        return [
            f"{level_title} - 導入と語彙",
            f"{level_title} - 経験を語る",
            f"{level_title} - 比較と視点",
            f"{level_title} - 問題と解決策",
            f"{level_title} - 意見交換",
            f"{level_title} - ストーリー化"
        ]
    else:
        return [
            "個人的経験",
            "説明・理由付け",
            "比較・視点",
            "問題・課題",
            "振り返り・意見",
            "拡張ストーリー"
        ]

current_level = 0
level_title = ""
sub_levels = []

for line in full_text.split('\n'):
    line = line.strip()
    if not line: continue
    
    m = re.search(r'レベル\s*(\d+)\s*[–\-]\s*(.+)', line)
    if m:
        if current_level > 0:
            levels_data[current_level] = {'title': level_title, 'sub': sub_levels}
        current_level = int(m.group(1))
        level_title = m.group(2).strip()
        sub_levels = []
    elif current_level > 0 and not line.startswith('🔹') and not line.startswith('🔵') and not line.startswith('🎯'):
        if len(sub_levels) < 6:
            sub_levels.append(line)

if current_level > 0:
    levels_data[current_level] = {'title': level_title, 'sub': sub_levels}

with open('seed_full_syllabus.sql', 'w', encoding='utf-8') as out:
    out.write('TRUNCATE TABLE syllabus;\n')
    
    # 1. Insert Stage 1 from the high-quality English JSON
    for item in english_data['json_agg']:
        id_val = item['id']
        lvl = item['level_number']
        slvl = item['sub_level_number']
        title = item['topic_title'].replace("'", "''")
        warmup = json.dumps(item.get('warmup_content', {}), ensure_ascii=False).replace("'", "''")
        core = json.dumps(item.get('core_content', {}), ensure_ascii=False).replace("'", "''")
        wrapup = json.dumps(item.get('wrapup_content', {}), ensure_ascii=False).replace("'", "''")
        created_at = item.get('created_at', 'NOW()')
        if created_at != 'NOW()':
            created_at_val = f"'{created_at}'"
        else:
            created_at_val = "NOW()"
        out.write(f"INSERT INTO syllabus (id, level_number, sub_level_number, topic_title, warmup_content, core_content, wrapup_content, created_at) VALUES ('{id_val}', {lvl}, {slvl}, '{title}', '{warmup}'::jsonb, '{core}'::jsonb, '{wrapup}'::jsonb, {created_at_val});\n")

    # 2. Generate Stage 2 & 3 (Levels 31 to 100)
    for lvl in range(31, 101):
        stage = 2 if lvl <= 60 else 3
        # Docx says Stage 3 is 20 min per sublevel (1200s). Let's use 180s warmup, 840s core, 180s wrapup
        # Stage 2 is same as Stage 1 (10 min per sublevel) or maybe 15 mins? The docx doesn't specify Stage 2 duration differently, 
        # but Stage 1 is 60m, Stage 2 is 90m (from text "90分連続スピーキング可能"). So 90m / 6 = 15m.
        # 15m = 900s. Let's do 120s warmup, 660s core, 120s wrapup.
        duration_warmup = 120 if stage == 2 else 180
        duration_core = 660 if stage == 2 else 840
        duration_wrapup = 120 if stage == 2 else 180
        
        if lvl not in levels_data:
            levels_data[lvl] = {'title': f"Level {lvl} Topic", 'sub': []}
        
        if len(levels_data[lvl]['sub']) < 6:
            defaults = get_default_sublevels(stage, levels_data[lvl]['title'])
            for i in range(len(levels_data[lvl]['sub']), 6):
                levels_data[lvl]['sub'].append(defaults[i])
        elif len(levels_data[lvl]['sub']) > 6:
            levels_data[lvl]['sub'] = levels_data[lvl]['sub'][:6]
            
        for sub_lvl in range(1, 7):
            id_val = str(uuid.uuid4())
            title = levels_data[lvl]['sub'][sub_lvl-1].replace("'", "''")
            
            warmup = {
                "text": f"Let's talk about: {title}",
                "duration": duration_warmup
            }
            core = {
                "prompt": f"Please share your thoughts on {title}.",
                "duration": duration_core,
                "keywords": ["example", "keyword"]
            }
            wrapup = {
                "text": "Great job today!",
                "duration": duration_wrapup
            }
            
            warmup_str = json.dumps(warmup, ensure_ascii=False).replace("'", "''")
            core_str = json.dumps(core, ensure_ascii=False).replace("'", "''")
            wrapup_str = json.dumps(wrapup, ensure_ascii=False).replace("'", "''")
            
            out.write(f"INSERT INTO syllabus (id, level_number, sub_level_number, topic_title, warmup_content, core_content, wrapup_content, created_at) VALUES ('{id_val}', {lvl}, {sub_lvl}, '{title}', '{warmup_str}'::jsonb, '{core_str}'::jsonb, '{wrapup_str}'::jsonb, NOW());\n")

print("Generated seed_full_syllabus.sql")
