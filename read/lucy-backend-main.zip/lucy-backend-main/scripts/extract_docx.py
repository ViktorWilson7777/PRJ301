import zipfile
import xml.etree.ElementTree as ET
import os
import json

def extract_text_from_docx(docx_path):
    try:
        with zipfile.ZipFile(docx_path, 'r') as docx:
            xml_content = docx.read('word/document.xml')
            tree = ET.fromstring(xml_content)
            namespace = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
            text = []
            for paragraph in tree.iterfind('.//w:p', namespace):
                texts = [node.text for node in paragraph.iterfind('.//w:t', namespace) if node.text]
                if texts:
                    text.append(''.join(texts))
            return '\n'.join(text)
    except Exception as e:
        return str(e)

files = [
    r"📘 LISA - ステージ1(レベル1-30).docx",
    r"📘 LISA - ステージ2(レベル31-60).docx",
    r"📘 LISA - ステージ3(レベル61-100).docx"
]

output = {}
for f in files:
    output[f] = extract_text_from_docx(f)

with open('parsed_docx.json', 'w', encoding='utf-8') as out_f:
    json.dump(output, out_f, ensure_ascii=False, indent=2)
