import uuid

def gen_uuid():
    return str(uuid.uuid4())

program_id = gen_uuid()
course_id = gen_uuid()
course_run_id = gen_uuid()

video_url = "https://pub-f9fde820e02a4976b08ee6caab4a7c92.r2.dev/assets/2e303bd4-b83c-42fd-a9b8-697a2a687476-ZL1HEAL1%20Video_Day3%20pm_27-09-2025.mp4"

sql = []

sql.append("-- ==========================================")
sql.append("-- MOCK DATA FOR LMS COURSE (10 Chapters x 4 Lessons)")
sql.append("-- ==========================================")
sql.append("")

# Insert Program
sql.append("-- 1. Insert Program")
sql.append(f"INSERT INTO programs (id, version, created_at, updated_at, code, title, description, thumbnail_url, is_published, published_at) ")
sql.append(f"VALUES ('{program_id}', 0, NOW(), NOW(), 'P-DEMO-MASTER', 'Lucy Masterclass Program', 'Complete demo program with full chapters and lessons for UI mock', 'https://via.placeholder.com/600x400?text=Lucy+Masterclass', true, NOW());")
sql.append("")

# Insert Course
sql.append("-- 2. Insert Course")
sql.append(f"INSERT INTO courses (id, version, created_at, updated_at, code, title, description, level, thumbnail_url, category, program_id, order_index, tags)")
sql.append(f"VALUES ('{course_id}', 0, NOW(), NOW(), 'C-DEMO-MASTER', 'Ultimate Flutter & Backend Course', 'Mastering the entire stack with Lucy LMS clone', 'Advanced', 'https://via.placeholder.com/600x400?text=Ultimate+Course', 'Technology', '{program_id}', 1, '{{ \"flutter\", \"backend\", \"masterclass\" }}');")
sql.append("")

# Insert Course Run
sql.append("-- 3. Insert Course Run")
sql.append(f"INSERT INTO course_runs (id, version, created_at, updated_at, course_id, code, status, starts_at, ends_at, timezone, metadata, enrollment_start_date, enrollment_end_date, capacity)")
sql.append(f"VALUES ('{course_run_id}', 0, NOW(), NOW(), '{course_id}', 'CR-DEMO-MASTER-2026', 'PUBLISHED', NOW() - INTERVAL '1 day', NOW() + INTERVAL '180 days', 'UTC', '{{}}'::jsonb, NOW() - INTERVAL '14 days', NOW() + INTERVAL '14 days', 500);")
sql.append("")

sql.append("-- 4. Insert Chapters and Lessons")
for c in range(1, 11):
    chapter_id = gen_uuid()
    sql.append(f"-- ================= CHAPTER {c} =================")
    sql.append(f"INSERT INTO chapters (id, version, created_at, updated_at, course_run_id, title, description, order_index)")
    sql.append(f"VALUES ('{chapter_id}', 0, NOW(), NOW(), '{course_run_id}', 'Chapter {c}: Masterclass Module {c}', 'In-depth concepts and practical exercises for module {c}.', {c});")
    
    for l in range(1, 5):
        lesson_id = gen_uuid()
        order_index = l
        
        # We will make 3 videos and 1 text lesson per chapter to make UI look diverse
        if l <= 3:
            lesson_type = 'VIDEO'
            title = f"Lesson {c}.{l}: Video Tutorial"
            desc = "Watch this video to understand the core principles."
            content_data = f'{{"videoUrl": "{video_url}", "duration": {300 + c*10 + l*5}, "provider": "cloudflare_r2"}}'
        else:
            lesson_type = 'TEXT'
            title = f"Lesson {c}.{l}: Reading & Resources"
            desc = "Review these materials carefully before proceeding."
            content_data = f'{{"content": "<p>Please review the documentation for Chapter {c}. This is crucial for your understanding.</p>"}}'
            
        sql.append(f"INSERT INTO lessons (id, version, created_at, updated_at, chapter_id, type, title, description, order_index, is_hidden, is_optional, content_data)")
        sql.append(f"VALUES ('{lesson_id}', 0, NOW(), NOW(), '{chapter_id}', '{lesson_type}', '{title}', '{desc}', {order_index}, false, false, '{content_data}'::jsonb);")
    sql.append("")

with open("e:/Ky8/PRM392/lucy-backend/insert_demo_course_full.sql", "w") as f:
    f.write("\n".join(sql))

print("SQL script generated at e:/Ky8/PRM392/lucy-backend/insert_demo_course_full.sql")
