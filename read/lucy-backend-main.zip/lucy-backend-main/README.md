# lucy-backend

Production backend for Lucy mobile app (`com.lucy.api`) with:

- Identity and RBAC
- Event/room realtime (STOMP)
- Messaging realtime (custom Netty WebSocket + Redis fan-out)
- LMS, profile/story, relationship, notifications, streak

## Runtime ports

- `8080`: HTTP REST + STOMP handshake (`/ws-room`, `/ws-messaging`)
- `8081`: Netty WebSocket (`/ws-netty`) for messenger realtime frames

## Local run (Docker)

1. Copy `.env.example` to `.env`.
2. Start services:
   - `docker compose up -d --build`
3. Verify health:
   - `http://localhost:8080/actuator/health`
4. Open Swagger:
   - `http://localhost:8080/swagger-ui`

## Realtime boundary

- Room realtime chat/presence:
  - STOMP endpoint: `/ws-room`
  - Inbound: `/app/room/*`
  - Outbound: `/topic/room/*`
- Messaging realtime:
  - Netty endpoint: `ws://<host>:8081/ws-netty`
  - Frame types: `AUTH`, `JOIN_CONVERSATION`, `MESSAGE`

## Deploy notes

- Keep `SPRING_FLYWAY_ENABLED=true` in deploy environment.
- Do not run with `ddl-auto=update` in production.
- Ensure reverse proxy/LB exposes both `8080` and `8081`.
- Set strong `JWT_SIGNER_KEY` and non-default `ADMIN_PASSWORD`.
