# Multi-tenant LMS Feature Status

Tài liệu này ghi lại trạng thái thực tế của backend `lucy-backend` sau đợt triển khai `dual catalog LMS`:

- `Public LMS`: catalog công khai, creator là `PRO` hoặc `SUPER`, học qua purchase + entitlement.
- `Organization LMS`: catalog theo từng tổ chức, học qua membership + enrollment theo quyền.

Mục tiêu của file này là trả lời 3 câu hỏi:

- Phần nào đã có trong repo
- Phần nào còn thiếu nhưng bắt buộc nếu muốn hệ thống đủ chuẩn `Multi-tenant LMS`
- Phần nào có thể để sau

## 1. Đã có

### Tenant và phân quyền

- Có `Organization` với CRUD cơ bản.
- Có `OrganizationMembership` với role:
  - `OWNER`
  - `ADMIN`
  - `INSTRUCTOR`
  - `LEARNER`
- User có thể thuộc nhiều tổ chức.
- Có `OrganizationAccessService` để kiểm tra membership và role theo organization.
- Dữ liệu LMS đã có `accessScope = PUBLIC | ORGANIZATION`.

### Catalog và nội dung học

- Có 2 nhánh API riêng:
  - `/api/v1/public/*`
  - `/api/v1/organizations/{organizationId}/*`
- Có đủ cấu trúc:
  - `Program`
  - `Course`
  - `CourseRun`
  - `Chapter`
  - `Lesson`
- Public catalog và organization catalog tách biệt ở backend.
- Public catalog có ownership ở `Program.ownerUserId`.
- Creator public được kiểm tra qua `PublicCreatorAccessService`.
- Legacy LMS controllers đã bị khóa về `ROLE_ADMIN` để tránh bypass scope mới.

### Enrollment và learning progress

- Có `self-enroll` cho learner.
- Có `manual enroll`.
- Có `import enrollments` cho organization course run.
- Public course run yêu cầu `entitlement` trước khi self-enroll.
- Organization course run yêu cầu membership hợp lệ và policy cho phép.
- Có `LessonProgress` và summary progress theo course run.
- Completion của enrollment được cập nhật khi hoàn thành đủ lesson.

### Public commerce

- Có `PublicCourseProduct`.
- Có `PublicOrder`.
- Có `PublicOrderItem`.
- Có `LearningEntitlement`.
- Có flow:
  - tạo order
  - confirm payment
  - cấp entitlement
  - learner dùng entitlement để enroll/học
- `confirm-payment` đã được giới hạn theo buyer hoặc `ADMIN`.

### Runtime và migration

- Đã thêm Flyway dependency.
- Đã bật `spring.flyway.enabled`.
- Đã có migration versioned:
  - `V1__sync_user_identity_profile_session.sql`
  - `V2__identity_profile_compat.sql`
  - `V3__multi_tenant_public_lms.sql`

### Test hiện có

- Có test service-level cho các blocker chính:
  - ownership check của public creator
  - buyer-only payment confirmation
  - entitlement gate cho public self-enroll

## 2. Thiếu nhưng bắt buộc

Đây là các phần nên triển khai tiếp nếu muốn nói backend này đã đủ chuẩn `Multi-tenant LMS` để vận hành nghiêm túc, không chỉ là v1 usable.

### Invitation và onboarding tổ chức

- Chưa có mời user vào organization qua email/token/link.
- Chưa có flow `invite -> accept -> activate membership`.
- Hiện chỉ có add member trực tiếp bằng `userId`, chưa phù hợp cho tổ chức dùng thật.

Lý do bắt buộc:
- Hệ thống multi-tenant thực tế cần onboarding member mà không phụ thuộc admin biết trước `userId`.

### Enrollment policy đầy đủ cho organization

- Hiện mới có `allowSelfEnrollment` ở mức metadata đơn giản.
- Chưa có policy rõ ràng cho:
  - invite-only
  - approval required
  - waitlist
  - close/open enrollment theo rule của tenant

Lý do bắt buộc:
- Mỗi tenant thường có chính sách vào lớp khác nhau, đây là một use case cốt lõi của LMS tổ chức.

### Reporting cơ bản theo tenant

- Chưa có API báo cáo cho organization:
  - learner list theo course run
  - completion rate
  - progress summary
  - enrollment stats

Lý do bắt buộc:
- Một LMS cho tổ chức mà không xem được tiến độ học tập theo tenant thì chưa đáp ứng use case quản trị đào tạo.

### Entitlement lifecycle đầy đủ

- Chưa có revoke entitlement.
- Chưa có refund flow.
- Chưa có logic đồng bộ giữa refund và revoke access.
- Chưa có expiration policy nếu sau này cần access theo thời hạn.

Lý do bắt buộc:
- Public LMS có commerce thì phải có vòng đời quyền truy cập, không thể chỉ có cấp mà không có thu hồi.

### Payment integration thực tế

- Hiện `provider` mới ở mức `MOCK/MANUAL`.
- Chưa có webhook/payment provider thật như Stripe hoặc cổng thanh toán tương đương.
- Chưa có xác thực chữ ký webhook hay reconciliation payment.

Lý do bắt buộc:
- Nếu public LMS bán course thật thì payment flow thật là bắt buộc.

### Integration test đủ rộng cho isolation

- Hiện test mới là service-level, chưa có integration test toàn luồng.
- Chưa có test cho:
  - user org A không truy cập org B
  - PRO không sửa public content của PRO khác qua API thật
  - payment -> entitlement -> enroll -> progress end-to-end
  - import enrollment org theo quyền

Lý do bắt buộc:
- Multi-tenant system mà không có test isolation thì rủi ro regression rất cao.

### Production schema policy hoàn chỉnh

- Hiện vẫn còn `spring.jpa.hibernate.ddl-auto=update`.
- Dù đã bật Flyway, runtime production đúng chuẩn nên chuyển sang:
  - `validate`
  - hoặc `none`

Lý do bắt buộc:
- Tránh drift schema, đặc biệt khi hệ thống bắt đầu có nhiều tenant và dữ liệu commerce.

## 3. Thiếu nhưng để sau

Đây là các phần hữu ích nhưng chưa cần để gọi là MVP hoặc v1 usable.

### Học liệu và đánh giá nâng cao

- Quiz bank nâng cao
- Attempt history đầy đủ
- Assignment/submission
- Grading rubric
- Certificate
- Completion rule phức tạp

### Marketplace nâng cao

- Coupon
- Tax
- Multi-currency logic nâng cao
- Subscription
- Bundle/course package
- Refund admin console

### Tenant content operations nâng cao

- Clone public course vào organization
- Clone course giữa các organization
- Versioning course content
- Archive/restore tenant content

### Analytics và vận hành

- Dashboard analytics
- Export report Excel/CSV
- Audit search/filter nâng cao
- Alerting / monitoring theo tenant

### Enterprise integrations

- Cohort sync từ HRIS/CRM
- SSO tenant-specific
- SCORM/xAPI
- External content provider sync

## 4. Đề xuất thứ tự triển khai tiếp

Nếu tiếp tục phát triển hệ thống này, thứ tự nên là:

1. `Invitation + membership activation`
2. `Enrollment policy` đầy đủ cho organization
3. `Tenant reporting` cơ bản
4. `Refund/revoke entitlement`
5. `Payment provider` thật
6. `Integration tests` cho isolation và commerce
7. Chuyển production sang `Flyway-first`, bỏ `ddl-auto=update`

## 5. Kết luận ngắn

Trạng thái hiện tại:

- Backend đã có nền tảng tốt cho `Multi-tenant LMS v1`
- Chưa đủ để gọi là đã bao phủ hết use case cần thiết của một hệ thống LMS tổ chức vận hành thực tế

Kết luận thực dụng:

- `Đã có`: phần lõi kiến trúc và permission
- `Thiếu nhưng bắt buộc`: onboarding tenant, reporting, payment thật, entitlement lifecycle, integration tests, production migration policy
- `Thiếu nhưng để sau`: analytics, certificate, assignment, clone/import nâng cao, enterprise integration
