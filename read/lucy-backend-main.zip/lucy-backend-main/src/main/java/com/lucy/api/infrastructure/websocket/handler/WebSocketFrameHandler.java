package com.lucy.api.infrastructure.websocket.handler;

import com.lucy.api.infrastructure.websocket.config.WebSocketNettyAttributeKeys;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketErrorCodeConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketFrameTypeConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketMessageKeys;
import com.lucy.api.infrastructure.websocket.dto.response.WebSocketErrorResponse;
import com.lucy.api.infrastructure.websocket.enums.WebSocketMessageType;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketMessageService;
import com.lucy.api.infrastructure.websocket.utils.SessionIdGenerator;
import com.lucy.api.infrastructure.websocket.utils.WebSocketPayloadCodec;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PongWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WebSocketFrameHandler extends SimpleChannelInboundHandler<WebSocketFrame> {

    WebSocketAuthHandler authHandler;
    WebSocketMessageService messageService;
    WebSocketPayloadCodec payloadCodec;
    MessageSource messageSource;
    Map<String, WebSocketCommandHandler> handlerMap;

    public WebSocketFrameHandler(
            WebSocketAuthHandler authHandler,
            WebSocketMessageService messageService,
            WebSocketPayloadCodec payloadCodec,
            MessageSource messageSource,
            List<WebSocketCommandHandler> handlers
    ) {
        this.authHandler = authHandler;
        this.messageService = messageService;
        this.payloadCodec = payloadCodec;
        this.messageSource = messageSource;
        this.handlerMap = handlers.stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toUnmodifiableMap(
                        WebSocketCommandHandler::getType,
                        Function.identity()
                ));
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, WebSocketFrame frame) {
        switch (frame) {
            case TextWebSocketFrame textFrame -> handleTextFrame(ctx, textFrame);
            case PingWebSocketFrame ignored ->
                    ctx.channel().writeAndFlush(new PongWebSocketFrame(frame.content().retain()));
            case CloseWebSocketFrame ignored -> handleClose(ctx);
            default -> log.warn("Unsupported WebSocket frame type: {}", frame.getClass().getName());
        }
    }

    private void handleTextFrame(ChannelHandlerContext ctx, TextWebSocketFrame frame) {
        String text = frame.text();
        String sessionId = getSessionId(ctx.channel());

        try {
            WebSocketMessageType messageType = payloadCodec.getMessageType(text);

            if (messageType == null) {
                sendError(ctx, WebSocketErrorCodeConstants.INVALID_MESSAGE, WebSocketMessageKeys.INVALID_MESSAGE);
                return;
            }

            if (messageType == WebSocketMessageType.AUTH) {
                authHandler.handleAuth(ctx, text, sessionId);
                return;
            }

            if (messageType == WebSocketMessageType.PING) {
                String pong = payloadCodec.toJson(Map.of(WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.PONG));
                if (pong != null) {
                    ctx.channel().writeAndFlush(new TextWebSocketFrame(pong));
                }
                return;
            }

            String typeKey = messageType.name();
            WebSocketCommandHandler handler = handlerMap.get(typeKey);

            if (handler == null) {
                log.warn("No WebSocketCommandHandler found for type: {}", typeKey);
                sendError(ctx, WebSocketErrorCodeConstants.INVALID_MESSAGE, WebSocketMessageKeys.UNSUPPORTED_TYPE);
                return;
            }

            if (sessionId == null) {
                sendError(ctx, WebSocketErrorCodeConstants.UNAUTHENTICATED, WebSocketMessageKeys.UNAUTHENTICATED);
                return;
            }

            handler.handle(ctx, text, sessionId);
        } catch (Exception e) {
            log.error("Error handling WebSocket message", e);
            sendError(ctx, WebSocketErrorCodeConstants.INVALID_MESSAGE, WebSocketMessageKeys.PROCESS_FAILED);
        }
    }

    private void handleClose(ChannelHandlerContext ctx) {
        String sessionId = getSessionId(ctx.channel());
        if (sessionId != null) {
            messageService.unregisterChannel(sessionId);
            authHandler.handleDisconnect(sessionId);
        }
        ctx.close();
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) {
        String sessionId = SessionIdGenerator.generate();
        ctx.channel().attr(WebSocketNettyAttributeKeys.SESSION_ID).set(sessionId);
        log.debug("New WebSocket connection: {}", sessionId);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        handleClose(ctx);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        log.error("WebSocket exception", cause);
        ctx.close();
    }

    private String getSessionId(Channel channel) {
        return channel.attr(WebSocketNettyAttributeKeys.SESSION_ID).get();
    }

    private void sendError(ChannelHandlerContext ctx, String errorCode, String messageKey) {
        String resolved = messageSource.getMessage(messageKey, null, Locale.ENGLISH);
        WebSocketErrorResponse error = WebSocketErrorResponse.builder()
                .errorCode(errorCode)
                .message(resolved)
                .messageKey(messageKey)
                .build();

        String errorJson = payloadCodec.toJson(Map.of(
                WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.ERROR,
                WebSocketConstants.FIELD_ERROR_CODE, error.getErrorCode(),
                WebSocketConstants.FIELD_MESSAGE, error.getMessage(),
                WebSocketConstants.FIELD_MESSAGE_KEY, error.getMessageKey()
        ));

        if (errorJson != null) {
            ctx.channel().writeAndFlush(new TextWebSocketFrame(errorJson));
        }
    }
}
