package com.lucy.api.modules.lms.repository;

import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CourseRunRepository extends JpaRepository<CourseRun, String> {
    List<CourseRun> findAllByCourseId(String courseId);
    List<CourseRun> findAllByDeletedAtIsNull();
    List<CourseRun> findAllByAccessScopeAndDeletedAtIsNull(LmsAccessScope accessScope);
    List<CourseRun> findAllByOrganization_IdAndDeletedAtIsNull(String organizationId);
    Optional<CourseRun> findByIdAndDeletedAtIsNull(String id);
}
