package com.lucy.api.infrastructure.websocket.config;

import io.netty.util.AttributeKey;

public final class WebSocketNettyAttributeKeys {

    private WebSocketNettyAttributeKeys() {
    }

    public static final AttributeKey<String> SESSION_ID = AttributeKey.valueOf("websocketSessionId");
}
