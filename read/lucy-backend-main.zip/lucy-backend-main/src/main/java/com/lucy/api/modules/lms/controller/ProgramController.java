package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.audit.annotation.AuditAction;
import com.lucy.api.modules.audit.constants.AuditActionType;
import com.lucy.api.modules.audit.constants.AuditEntityType;
import com.lucy.api.modules.lms.dto.request.ProgramUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ProgramResponse;
import com.lucy.api.modules.lms.service.api.ProgramService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/programs")
@Tag(name = "LMS Programs", description = "CRUD APIs for LMS programs")
public class ProgramController {
    private final ProgramService programService;

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Create a new program")
    @AuditAction(action = AuditActionType.PROGRAM_CREATE, entityType = AuditEntityType.PROGRAM)
    public ResponseEntity<ApiResponse<ProgramResponse>> create(@Valid @RequestBody ProgramUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<ProgramResponse>builder().success(true).data(programService.create(request)).build());
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get all programs")
    public ResponseEntity<ApiResponse<List<ProgramResponse>>> findAll() {
        return ResponseEntity.ok(ApiResponse.<List<ProgramResponse>>builder().success(true).data(programService.findAll()).build());
    }

    @GetMapping("/{programId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get a program by id")
    public ResponseEntity<ApiResponse<ProgramResponse>> findById(@PathVariable String programId) {
        return ResponseEntity.ok(ApiResponse.<ProgramResponse>builder().success(true).data(programService.findById(programId)).build());
    }

    @PutMapping("/{programId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Update a program")
    @AuditAction(action = AuditActionType.PROGRAM_UPDATE, entityType = AuditEntityType.PROGRAM)
    public ResponseEntity<ApiResponse<ProgramResponse>> update(@PathVariable String programId, @Valid @RequestBody ProgramUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<ProgramResponse>builder().success(true).data(programService.update(programId, request)).build());
    }

    @DeleteMapping("/{programId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Delete a program")
    @AuditAction(action = AuditActionType.PROGRAM_DELETE, entityType = AuditEntityType.PROGRAM)
    public ResponseEntity<ApiResponse<String>> delete(@PathVariable String programId) {
        programService.delete(programId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Program deleted successfully").build());
    }
}
