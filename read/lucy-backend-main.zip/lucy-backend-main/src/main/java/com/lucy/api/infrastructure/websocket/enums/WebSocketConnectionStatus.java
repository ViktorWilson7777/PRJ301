package com.lucy.api.infrastructure.websocket.enums;

public enum WebSocketConnectionStatus {
    CONNECTED,
    AUTHENTICATED,
    JOINED,
    DISCONNECTED
}
