package com.lucy.api.infrastructure.websocket.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.infrastructure.websocket.config.WebSocketNettyProperties;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.entity.WebSocketSession;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketSessionService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WebSocketSessionServiceImpl implements WebSocketSessionService {

    StringRedisTemplate stringRedisTemplate;
    ObjectMapper objectMapper;
    WebSocketNettyProperties webSocketNettyProperties;

    @Override
    public void createSession(WebSocketSession session) {
        try {
            String sessionKey = WebSocketConstants.REDIS_KEY_PREFIX_SESSION + session.getSessionId();
            String sessionJson = objectMapper.writeValueAsString(session);

            Duration ttl = Duration.ofMillis(webSocketNettyProperties.getSessionTimeout());
            stringRedisTemplate.opsForValue().set(sessionKey, sessionJson, ttl);

            String userSessionsKey = WebSocketConstants.REDIS_KEY_PREFIX_USER_SESSIONS
                    + session.getUserId() + WebSocketConstants.REDIS_KEY_SUFFIX_SESSIONS;
            stringRedisTemplate.opsForSet().add(userSessionsKey, session.getSessionId());
            stringRedisTemplate.expire(userSessionsKey, ttl);

            log.debug("Created WebSocket session: {}", session.getSessionId());
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize session: {}", session.getSessionId(), e);
            throw new IllegalStateException("Failed to create session", e);
        }
    }

    @Override
    public Optional<WebSocketSession> getSession(String sessionId) {
        try {
            String sessionKey = WebSocketConstants.REDIS_KEY_PREFIX_SESSION + sessionId;
            String sessionJson;
            try {
                sessionJson = stringRedisTemplate.opsForValue().get(sessionKey);
            } catch (RuntimeException ex) {
                log.debug("Redis unavailable when fetching WebSocket session {}. Skipping cleanup.", sessionId, ex);
                return Optional.empty();
            }

            if (sessionJson == null) {
                return Optional.empty();
            }

            WebSocketSession session = objectMapper.readValue(sessionJson, WebSocketSession.class);
            return Optional.of(session);
        } catch (JsonProcessingException e) {
            log.error("Failed to deserialize session: {}", sessionId, e);
            return Optional.empty();
        }
    }

    @Override
    public void updateSession(String sessionId, WebSocketSession session) {
        try {
            String sessionKey = WebSocketConstants.REDIS_KEY_PREFIX_SESSION + sessionId;
            String sessionJson = objectMapper.writeValueAsString(session);

            stringRedisTemplate.opsForValue()
                    .set(sessionKey, sessionJson, Duration.ofMillis(webSocketNettyProperties.getSessionTimeout()));

            log.debug("Updated WebSocket session: {}", sessionId);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize session for update: {}", sessionId, e);
            throw new IllegalStateException("Failed to update session", e);
        }
    }

    @Override
    public void removeSession(String sessionId) {
        Optional<WebSocketSession> sessionOpt = getSession(sessionId);
        if (sessionOpt.isEmpty()) {
            return;
        }

        WebSocketSession session = sessionOpt.get();

        String sessionKey = WebSocketConstants.REDIS_KEY_PREFIX_SESSION + sessionId;
        stringRedisTemplate.delete(sessionKey);

        String userSessionsKey = WebSocketConstants.REDIS_KEY_PREFIX_USER_SESSIONS
                + session.getUserId() + WebSocketConstants.REDIS_KEY_SUFFIX_SESSIONS;
        stringRedisTemplate.opsForSet().remove(userSessionsKey, sessionId);

        if (session.getConversationId() != null) {
            removeSessionFromConversation(sessionId, session.getConversationId());
        }

        log.debug("Removed WebSocket session: {}", sessionId);
    }

    @Override
    public List<String> getUserSessions(String userId) {
        String userSessionsKey = WebSocketConstants.REDIS_KEY_PREFIX_USER_SESSIONS
                + userId + WebSocketConstants.REDIS_KEY_SUFFIX_SESSIONS;
        Set<String> sessionIds = stringRedisTemplate.opsForSet().members(userSessionsKey);
        return sessionIds != null ? sessionIds.stream().collect(Collectors.toList()) : List.of();
    }

    @Override
    public List<String> getConversationSessions(String conversationId) {
        String conversationSessionsKey = WebSocketConstants.REDIS_KEY_PREFIX_CONVERSATION_SESSIONS
                + conversationId + WebSocketConstants.REDIS_KEY_SUFFIX_CONVERSATION_SESSIONS;
        Set<String> sessionIds = stringRedisTemplate.opsForSet().members(conversationSessionsKey);
        return sessionIds != null ? sessionIds.stream().collect(Collectors.toList()) : List.of();
    }

    @Override
    public void addSessionToConversation(String sessionId, String conversationId) {
        String conversationSessionsKey = WebSocketConstants.REDIS_KEY_PREFIX_CONVERSATION_SESSIONS
                + conversationId + WebSocketConstants.REDIS_KEY_SUFFIX_CONVERSATION_SESSIONS;
        stringRedisTemplate.opsForSet().add(conversationSessionsKey, sessionId);
        stringRedisTemplate.expire(
                conversationSessionsKey,
                Duration.ofMillis(webSocketNettyProperties.getSessionTimeout())
        );

        Optional<WebSocketSession> sessionOpt = getSession(sessionId);
        if (sessionOpt.isPresent()) {
            WebSocketSession session = sessionOpt.get();
            session.setConversationId(conversationId);
            updateSession(sessionId, session);
        }

        log.debug("Added session {} to conversation {}", sessionId, conversationId);
    }

    @Override
    public void removeSessionFromConversation(String sessionId, String conversationId) {
        String conversationSessionsKey = WebSocketConstants.REDIS_KEY_PREFIX_CONVERSATION_SESSIONS
                + conversationId + WebSocketConstants.REDIS_KEY_SUFFIX_CONVERSATION_SESSIONS;
        stringRedisTemplate.opsForSet().remove(conversationSessionsKey, sessionId);

        Optional<WebSocketSession> sessionOpt = getSession(sessionId);
        if (sessionOpt.isPresent()) {
            WebSocketSession session = sessionOpt.get();
            session.setConversationId(null);
            updateSession(sessionId, session);
        }

        log.debug("Removed session {} from conversation {}", sessionId, conversationId);
    }
}
