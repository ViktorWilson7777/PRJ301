package com.lucy.api.modules.messaging.constant;

public final class ConversationParticipantConstants {

    public static final String TABLE = "conversation_participants";

    public static final String COL_CONVERSATION_ID = "conversation_id";
    public static final String COL_USER_ID = "user_id";
    public static final String COL_STATUS = "status";
    public static final String COL_JOINED_AT = "joined_at";
    public static final String COL_LEFT_AT = "left_at";

    private ConversationParticipantConstants() {
    }
}
