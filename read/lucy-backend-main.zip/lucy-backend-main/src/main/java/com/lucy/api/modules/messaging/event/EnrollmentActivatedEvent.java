package com.lucy.api.modules.messaging.event;

public record EnrollmentActivatedEvent(String userId, String courseRunId) {
}
