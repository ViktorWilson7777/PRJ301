package com.lucy.api.modules.event.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.UUID;

/**
 * Response DTO broadcasted when a user leaves a room
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserLeftResponse {
    private UUID roomId;
    private UUID userId;
    private String displayName;
    private String reason;
    private Instant leftAt;
    private int totalParticipants;
}
