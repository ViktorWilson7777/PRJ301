package com.lucy.api.common.constants;

public class PaginationConstant {
    public static final int MIN_PAGE_SIZE =  1;
    public static final int MIN_PAGE_NUMBER =  0;
    public static final int DEFAULT_PAGE_SIZE = 10;

    public static final String DESC =  "desc";
    public static final String ASC =  "asc";

    private PaginationConstant() {}
}
