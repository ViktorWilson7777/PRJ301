package com.lucy.api.modules.agora.token;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;

public class ByteBuf {
    private final ByteBuffer buffer;

    public ByteBuf() {
        this.buffer = ByteBuffer.allocate(1024).order(ByteOrder.LITTLE_ENDIAN);
    }

    public byte[] asBytes() {
        byte[] out = new byte[buffer.position()];
        buffer.rewind();
        buffer.get(out, 0, out.length);
        return out;
    }

    public ByteBuf put(short value) {
        buffer.putShort(value);
        return this;
    }

    public ByteBuf put(byte[] value) {
        put((short) value.length);
        buffer.put(value);
        return this;
    }

    public ByteBuf put(int value) {
        buffer.putInt(value);
        return this;
    }

    public ByteBuf put(String value) {
        return put(value.getBytes(StandardCharsets.UTF_8));
    }

    public ByteBuf putIntMap(TreeMap<Short, Integer> map) {
        put((short) map.size());
        for (Map.Entry<Short, Integer> pair : map.entrySet()) {
            put(pair.getKey());
            put(pair.getValue());
        }
        return this;
    }
}
