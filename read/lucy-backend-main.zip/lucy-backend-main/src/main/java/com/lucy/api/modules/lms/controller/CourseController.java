package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.audit.annotation.AuditAction;
import com.lucy.api.modules.audit.constants.AuditActionType;
import com.lucy.api.modules.audit.constants.AuditEntityType;
import com.lucy.api.modules.lms.dto.request.CourseUpsertRequest;
import com.lucy.api.modules.lms.dto.response.CourseResponse;
import com.lucy.api.modules.lms.service.api.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/courses")
@Tag(name = "LMS Courses", description = "CRUD APIs for LMS courses")
public class CourseController {
    private final CourseService courseService;

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Create a new course")
    @AuditAction(action = AuditActionType.COURSE_CREATE, entityType = AuditEntityType.COURSE)
    public ResponseEntity<ApiResponse<CourseResponse>> create(@Valid @RequestBody CourseUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<CourseResponse>builder().success(true).data(courseService.create(request)).build());
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get all courses, optionally filtered by program id")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> findAll(@RequestParam(required = false) String programId) {
        return ResponseEntity.ok(ApiResponse.<List<CourseResponse>>builder().success(true).data(courseService.findAll(programId)).build());
    }

    @GetMapping("/{courseId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get a course by id")
    public ResponseEntity<ApiResponse<CourseResponse>> findById(@PathVariable String courseId) {
        return ResponseEntity.ok(ApiResponse.<CourseResponse>builder().success(true).data(courseService.findById(courseId)).build());
    }

    @PutMapping("/{courseId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Update a course")
    @AuditAction(action = AuditActionType.COURSE_UPDATE, entityType = AuditEntityType.COURSE)
    public ResponseEntity<ApiResponse<CourseResponse>> update(@PathVariable String courseId, @Valid @RequestBody CourseUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<CourseResponse>builder().success(true).data(courseService.update(courseId, request)).build());
    }

    @DeleteMapping("/{courseId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Delete a course")
    @AuditAction(action = AuditActionType.COURSE_DELETE, entityType = AuditEntityType.COURSE)
    public ResponseEntity<ApiResponse<String>> delete(@PathVariable String courseId) {
        courseService.delete(courseId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Course deleted successfully").build());
    }
}
