package com.lucy.api.modules.messaging.constant;

public final class MessagingWebSocketFrameConstants {

    private MessagingWebSocketFrameConstants() {
    }

    public static final String JOIN_CONVERSATION = "JOIN_CONVERSATION";
    public static final String MESSAGE_ACK = "MESSAGE_ACK";

    public static final String FIELD_SUCCESS = "success";
    public static final String FIELD_CONVERSATION_ID = "conversationId";
    public static final String FIELD_MESSAGE_ID = "messageId";
}
