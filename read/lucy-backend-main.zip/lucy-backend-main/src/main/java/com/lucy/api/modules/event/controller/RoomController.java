package com.lucy.api.modules.event.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.event.dto.request.CreateEventRequest;
import com.lucy.api.modules.event.dto.request.EventFeedRequest;
import com.lucy.api.modules.event.dto.response.CreateEventResponse;
import com.lucy.api.modules.event.dto.response.EventDetailResponse;
import com.lucy.api.modules.event.dto.response.EventFeedResponse;
import com.lucy.api.modules.event.dto.response.ChatMessageListResponse;
import com.lucy.api.modules.event.service.EventAuthContextService;
import com.lucy.api.modules.event.service.EventService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {
    private final EventService eventService;
    private final EventAuthContextService eventAuthContextService;

    @PostMapping
    public ResponseEntity<ApiResponse<CreateEventResponse>> createRoom(@Valid @RequestBody CreateEventRequest request,
                                                                       @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<CreateEventResponse>builder()
                .success(true)
                .data(eventService.createEvent(request, currentUserId))
                .build());
    }

    @GetMapping
    public ResponseEntity<ApiResponse<EventFeedResponse>> listRooms(@RequestParam(required = false) String status,
                                                                    @RequestParam(required = false) Boolean mine,
                                                                    @RequestParam(required = false) Boolean interested,
                                                                    @RequestParam(required = false) String from,
                                                                    @RequestParam(required = false) String to,
                                                                    @RequestParam(required = false) String cursor,
                                                                    @RequestParam(required = false) String query,
                                                                    @RequestParam(required = false) Integer limit,
                                                                    @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        EventFeedRequest request = new EventFeedRequest(status, mine, interested, from, to, cursor, query, limit);
        return ResponseEntity.ok(ApiResponse.<EventFeedResponse>builder()
                .success(true)
                .data(eventService.listEvents(request, currentUserId))
                .build());
    }

    @GetMapping("/{roomId}")
    public ResponseEntity<ApiResponse<EventDetailResponse>> getRoomDetail(
            @PathVariable UUID roomId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        UUID currentUserId = eventAuthContextService.getUserId(jwt).orElse(null);
        return ResponseEntity.ok(ApiResponse.<EventDetailResponse>builder()
                .success(true)
                .data(eventService.getEventDetail(roomId, currentUserId))
                .build());
    }

    @GetMapping("/{roomId}/chat/messages")
    public ResponseEntity<ApiResponse<ChatMessageListResponse>> getRoomChatMessages(
            @PathVariable UUID roomId,
            @RequestParam(required = false) String cursor,
            @RequestParam(required = false) Integer limit) {
        return ResponseEntity.ok(ApiResponse.<ChatMessageListResponse>builder()
                .success(true)
                .data(eventService.listRoomChatMessages(roomId, cursor, limit))
                .build());
    }
}
