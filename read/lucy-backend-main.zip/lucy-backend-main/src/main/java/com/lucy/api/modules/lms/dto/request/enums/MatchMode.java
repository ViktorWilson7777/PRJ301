package com.lucy.api.modules.lms.dto.request.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum MatchMode {
    NONE("None"),
    ANY("Any"),
    ALL("All");

    private final String value;

    MatchMode(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    @JsonCreator
    public static MatchMode fromValue(String value) {
        for (MatchMode mode : values()) {
            if (mode.value.equalsIgnoreCase(value)) {
                return mode;
            }
        }
        throw new IllegalArgumentException("Unknown match mode: " + value);
    }
}
