package com.lucy.api.modules.story.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.event.service.EventAuthContextService;
import com.lucy.api.modules.story.dto.request.CreateAvatarStoryRequest;
import com.lucy.api.modules.story.dto.response.AvatarStoryListResponse;
import com.lucy.api.modules.story.dto.response.StoryItemResponse;
import com.lucy.api.modules.story.service.AvatarStoryQueryService;
import com.lucy.api.modules.story.service.AvatarStoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AvatarStoryController {

    private final EventAuthContextService eventAuthContextService;
    private final AvatarStoryService avatarStoryService;
    private final AvatarStoryQueryService avatarStoryQueryService;

    @PostMapping("/me/avatar-stories")
    public ResponseEntity<ApiResponse<StoryItemResponse>> createAvatarStory(@Valid @RequestBody CreateAvatarStoryRequest request,
                                                                            @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<StoryItemResponse>builder()
                .success(true)
                .data(avatarStoryService.createAvatarStory(currentUserId, request))
                .build());
    }

    @GetMapping("/avatar-stories/feed")
    public ResponseEntity<ApiResponse<AvatarStoryListResponse>> getAvatarStoryFeed(@AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<AvatarStoryListResponse>builder()
                .success(true)
                .data(avatarStoryQueryService.getFeed(currentUserId))
                .build());
    }

    @GetMapping("/users/{userId}/avatar-stories")
    public ResponseEntity<ApiResponse<AvatarStoryListResponse>> getUserAvatarStories(@PathVariable UUID userId,
                                                                                      @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<AvatarStoryListResponse>builder()
                .success(true)
                .data(avatarStoryQueryService.getUserStories(userId, currentUserId))
                .build());
    }

    @PostMapping("/avatar-stories/{storyId}/view")
    public ResponseEntity<ApiResponse<Object>> markStoryViewed(@PathVariable UUID storyId, @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        avatarStoryService.markViewed(storyId, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @DeleteMapping("/avatar-stories/{storyId}")
    public ResponseEntity<ApiResponse<Object>> deleteStory(@PathVariable UUID storyId, @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        avatarStoryService.deleteStory(storyId, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }
}
