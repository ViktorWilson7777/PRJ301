package com.lucy.api.modules.event.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ParticipantResponse {
    UUID userId;
    String displayName;
    boolean monitor;
    String role;
    boolean micEnabled;
    boolean raiseHand;
    Instant joinedAt;
    Integer rtcUid;
}
