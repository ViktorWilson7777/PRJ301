package com.lucy.api.modules.lms.dto.response;

import com.lucy.api.modules.lms.dto.response.LessonResponse;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ChapterResponse {
    String id;
    String courseRunId;
    String courseRunCode;
    String title;
    String description;
    Integer orderIndex;
    List<LessonResponse> lessons;
    Instant createdAt;
    Instant updatedAt;
}
