package com.lucy.api.infrastructure.websocket.constants;

public final class WebSocketErrorCodeConstants {

    private WebSocketErrorCodeConstants() {
    }

    public static final String INVALID_TOKEN = "WEBSOCKET_INVALID_TOKEN";
    public static final String UNAUTHENTICATED = "WEBSOCKET_UNAUTHENTICATED";
    public static final String INVALID_MESSAGE = "WEBSOCKET_INVALID_MESSAGE";
    public static final String SESSION_NOT_FOUND = "WEBSOCKET_SESSION_NOT_FOUND";
    public static final String MESSAGING_FORBIDDEN = "WEBSOCKET_MESSAGING_FORBIDDEN";
    public static final String MESSAGE_SEND_FAILED = "WEBSOCKET_MESSAGE_SEND_FAILED";
}
