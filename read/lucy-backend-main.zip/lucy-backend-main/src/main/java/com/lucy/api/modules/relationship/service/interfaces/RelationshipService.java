package com.lucy.api.modules.relationship.service.interfaces;

import com.lucy.api.modules.relationship.dtos.request.FriendRequestCreateRequest;
import com.lucy.api.modules.relationship.dtos.response.RelationshipResponse;
import com.lucy.api.modules.relationship.dtos.response.RelationshipStatusResponse;

import java.util.List;

public interface RelationshipService {

    RelationshipResponse sendFriendRequest(FriendRequestCreateRequest request);

    RelationshipResponse acceptRequest(String relationshipId);

    void rejectRequest(String relationshipId);

    void cancelSentRequest(String relationshipId);

    void unfriend(String relationshipId);

    List<RelationshipResponse> getMyFriends();

    List<RelationshipResponse> getPendingReceivedRequests();

    List<RelationshipResponse> getPendingSentRequests();

    RelationshipStatusResponse getRelationshipStatus(String otherUserId);

    boolean canMessage(String currentUserId, String otherUserId);

    boolean canCurrentUserMessage(String otherUserId);
}
