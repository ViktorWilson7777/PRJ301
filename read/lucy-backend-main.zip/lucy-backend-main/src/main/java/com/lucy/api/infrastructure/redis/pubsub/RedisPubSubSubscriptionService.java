package com.lucy.api.infrastructure.redis.pubsub;

import com.lucy.api.infrastructure.redis.constants.RedisChannelPrefixes;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class RedisPubSubSubscriptionService {

    RedisMessageListenerContainer redisMessageListenerContainer;
    RedisPubSubDispatcher redisPubSubDispatcher;

    public void subscribeToConversation(String conversationId) {
        String channel = RedisChannelPrefixes.WS_MESSAGE + conversationId;
        redisMessageListenerContainer.addMessageListener(redisPubSubDispatcher, new ChannelTopic(channel));
        log.debug("Subscribed to new conversation channel: {}", channel);
    }

    public void subscribeToUserNotifications(String userId) {
        String channel = RedisChannelPrefixes.WS_NOTIFICATION + userId;
        redisMessageListenerContainer.addMessageListener(redisPubSubDispatcher, new ChannelTopic(channel));
        log.debug("Subscribed to new user notification channel: {}", channel);
    }
}
