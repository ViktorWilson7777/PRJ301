package com.lucy.api.modules.event.repository;

import com.lucy.api.modules.event.entity.RoomParticipantEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RoomParticipantRepository extends JpaRepository<RoomParticipantEntity, UUID> {
    long countByRoomId(UUID roomId);
    long countByRoomIdAndUserId(UUID roomId, UUID userId);
    Optional<RoomParticipantEntity> findByRoomIdAndUserId(UUID roomId, UUID userId);
    List<RoomParticipantEntity> findByRoomIdOrderByJoinedAtAsc(UUID roomId);
    void deleteAllByUserIdIn(List<UUID> userIds);
    void deleteAllByRoomIdIn(List<UUID> roomIds);
}
