package com.lucy.api.modules.identity.controller;

import com.lucy.api.common.constants.PaginationConstant;
import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.request.SortRequest;
import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.identity.dtos.response.user.UserResponse;
import com.lucy.api.modules.identity.service.interfaces.UserService;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class UserController {
    private final UserService userService;

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserResponse>> getMe() {
        return ResponseEntity.ok(ApiResponse.<UserResponse>builder().success(true).data(userService.getMe()).build());
    }

    @DeleteMapping("/me")
    public ResponseEntity<ApiResponse<Void>> deleteMe() {
        userService.deleteMe();
        return ResponseEntity.ok(ApiResponse.<Void>builder().success(true).build());
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PagingResponse<UserResponse>>> getUsers(
            @RequestParam(required = false) String keyword,
            @RequestParam(value = "page", required = false, defaultValue = "1") int page,
            @RequestParam(value = "size", required = false, defaultValue = "10") int size,
            @RequestParam(required = false, defaultValue = PaginationConstant.DESC) String direction,
            @RequestParam(required = false, defaultValue = "createdAt") String field
    ) {
        return ResponseEntity.ok(ApiResponse.<PagingResponse<UserResponse>>builder()
                .success(true)
                .data(userService.getUsers(keyword, buildPagingRequest(page, size, direction, field)))
                .build());
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse<UserResponse>> getById(@PathVariable String userId) {
        return ResponseEntity.ok(ApiResponse.<UserResponse>builder().success(true).data(userService.getById(userId)).build());
    }

    private PagingRequest buildPagingRequest(int page, int size, String direction, String field) {
        return PagingRequest.builder()
                .page(page)
                .pageSize(size)
                .sortRequest(SortRequest.builder().direction(direction).field(field).build())
                .build();
    }
}
