package com.lucy.api.modules.messaging.enums;

public enum ConversationMode {
    GROUP,
    DIRECT
}
