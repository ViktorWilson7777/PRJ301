package com.lucy.api.modules.lms.service.api;

import com.lucy.api.modules.lms.dto.request.CourseRunUpsertRequest;
import com.lucy.api.modules.lms.dto.response.CourseRunResponse;
import com.lucy.api.modules.lms.entity.CourseRun;

import java.util.List;

public interface CourseRunService {
    CourseRunResponse create(CourseRunUpsertRequest request);
    CourseRunResponse createPublic(CourseRunUpsertRequest request);
    CourseRunResponse createForOrganization(String organizationId, CourseRunUpsertRequest request);
    List<CourseRunResponse> findAll(String courseId);
    List<CourseRunResponse> findAllPublic(String courseId);
    List<CourseRunResponse> findAllByOrganization(String organizationId, String courseId);
    CourseRunResponse findById(String courseRunId);
    CourseRunResponse findPublicById(String courseRunId);
    CourseRunResponse findByOrganizationAndId(String organizationId, String courseRunId);
    CourseRunResponse update(String courseRunId, CourseRunUpsertRequest request);
    CourseRunResponse updatePublic(String courseRunId, CourseRunUpsertRequest request);
    CourseRunResponse updateForOrganization(String organizationId, String courseRunId, CourseRunUpsertRequest request);
    void delete(String courseRunId);
    void deletePublic(String courseRunId);
    void deleteForOrganization(String organizationId, String courseRunId);
    CourseRun getEntityById(String courseRunId);
}
