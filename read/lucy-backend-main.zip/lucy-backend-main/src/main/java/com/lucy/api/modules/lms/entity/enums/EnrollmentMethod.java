package com.lucy.api.modules.lms.entity.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum EnrollmentMethod {
    COHORT_SYNC("Cohort sync"),
    MANUAL_ENROLMENTS("Manual enrolments");

    private final String value;

    EnrollmentMethod(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    @JsonCreator
    public static EnrollmentMethod fromValue(String value) {
        for (EnrollmentMethod method : values()) {
            if (method.value.equalsIgnoreCase(value)) {
                return method;
            }
        }
        throw new IllegalArgumentException("Unknown enrollment method: " + value);
    }
}
