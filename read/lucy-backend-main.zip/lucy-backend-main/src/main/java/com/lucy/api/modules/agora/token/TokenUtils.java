package com.lucy.api.modules.agora.token;

import java.io.ByteArrayOutputStream;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.zip.Deflater;

public final class TokenUtils {
    private TokenUtils() {
    }

    public static String base64Encode(byte[] data) {
        return Base64.getEncoder().encodeToString(data);
    }

    public static int getTimestamp() {
        return (int) Instant.now().getEpochSecond();
    }

    public static int randomInt() {
        return new SecureRandom().nextInt();
    }

    public static boolean isUUID(String uuid) {
        return uuid != null && uuid.length() == 32 && uuid.matches("\\p{XDigit}+");
    }

    public static byte[] compress(byte[] data) {
        Deflater deflater = new Deflater();
        ByteArrayOutputStream output = new ByteArrayOutputStream(data.length);

        try {
            deflater.reset();
            deflater.setInput(data);
            deflater.finish();

            byte[] buffer = new byte[data.length];
            while (!deflater.finished()) {
                int count = deflater.deflate(buffer);
                output.write(buffer, 0, count);
            }
            return output.toByteArray();
        } finally {
            deflater.end();
        }
    }
}
