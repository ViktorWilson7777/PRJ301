package com.lucy.api.modules.agora.token;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.Map;
import java.util.TreeMap;

public class AccessToken2 {
    public enum PrivilegeRtc {
        PRIVILEGE_JOIN_CHANNEL(1),
        PRIVILEGE_PUBLISH_AUDIO_STREAM(2),
        PRIVILEGE_PUBLISH_VIDEO_STREAM(3),
        PRIVILEGE_PUBLISH_DATA_STREAM(4);

        public final short intValue;

        PrivilegeRtc(int value) {
            this.intValue = (short) value;
        }
    }

    private static final String VERSION = "007";
    private static final short SERVICE_TYPE_RTC = 1;

    private final String appCert;
    private final String appId;
    private final int expire;
    private final int issueTs;
    private final int salt;
    private final Map<Short, Service> services = new TreeMap<>();

    public AccessToken2(String appId, String appCert, int expire) {
        this.appCert = appCert;
        this.appId = appId;
        this.expire = expire;
        this.issueTs = TokenUtils.getTimestamp();
        this.salt = TokenUtils.randomInt();
    }

    public void addService(Service service) {
        this.services.put(service.getServiceType(), service);
    }

    public String build() throws Exception {
        if (!TokenUtils.isUUID(this.appId) || !TokenUtils.isUUID(this.appCert)) {
            return "";
        }

        ByteBuf payload = new ByteBuf()
                .put(this.appId)
                .put(this.issueTs)
                .put(this.expire)
                .put(this.salt)
                .put((short) this.services.size());

        byte[] signing = getSign();
        this.services.forEach((k, v) -> v.pack(payload));

        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(signing, "HmacSHA256"));
        byte[] signature = mac.doFinal(payload.asBytes());

        ByteBuf content = new ByteBuf().put(signature);
        content.put(payload.asBytes());

        return VERSION + TokenUtils.base64Encode(TokenUtils.compress(content.asBytes()));
    }

    private byte[] getSign() throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(new ByteBuf().put(this.issueTs).asBytes(), "HmacSHA256"));
        byte[] signing = mac.doFinal(this.appCert.getBytes());
        mac.init(new SecretKeySpec(new ByteBuf().put(this.salt).asBytes(), "HmacSHA256"));
        return mac.doFinal(signing);
    }

    public static String getUidStr(int uid) {
        if (uid == 0) {
            return "";
        }
        return String.valueOf(uid & 0xFFFFFFFFL);
    }

    public static class Service {
        private final short type;
        private final TreeMap<Short, Integer> privileges = new TreeMap<>();

        protected Service(short serviceType) {
            this.type = serviceType;
        }

        public void addPrivilegeRtc(PrivilegeRtc privilege, int expire) {
            this.privileges.put(privilege.intValue, expire);
        }

        public short getServiceType() {
            return this.type;
        }

        public ByteBuf pack(ByteBuf buf) {
            return buf.put(this.type).putIntMap(this.privileges);
        }
    }

    public static class ServiceRtc extends Service {
        private final String channelName;
        private final String uid;

        public ServiceRtc(String channelName, String uid) {
            super(SERVICE_TYPE_RTC);
            this.channelName = channelName;
            this.uid = uid;
        }

        @Override
        public ByteBuf pack(ByteBuf buf) {
            return super.pack(buf).put(this.channelName).put(this.uid);
        }
    }
}
