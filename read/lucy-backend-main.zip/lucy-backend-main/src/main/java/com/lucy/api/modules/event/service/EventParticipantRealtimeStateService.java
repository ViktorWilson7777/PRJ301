package com.lucy.api.modules.event.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class EventParticipantRealtimeStateService {
    private static final Duration STATE_TTL = Duration.ofHours(24);

    private final StringRedisTemplate redisTemplate;

    public void setMicState(UUID eventId, UUID roomId, UUID userId, boolean enabled) {
        String micKey = micKey(eventId, roomId);
        try {
            redisTemplate.opsForHash().put(micKey, userId.toString(), enabled ? "1" : "0");
            refreshTtl(eventId, roomId);
        } catch (DataAccessException ex) {
            log.warn("Failed to set mic state in redis roomId={} userId={}", roomId, userId, ex);
        }
    }

    public Map<UUID, Boolean> getMicStates(UUID eventId, UUID roomId) {
        Map<UUID, Boolean> result = new HashMap<>();
        try {
            Map<Object, Object> values = redisTemplate.opsForHash().entries(micKey(eventId, roomId));
            values.forEach((key, value) -> parseUuid(key).ifPresent(userId ->
                    result.put(userId, "1".equals(String.valueOf(value)))));
        } catch (DataAccessException ex) {
            log.warn("Failed to read mic states from redis roomId={}", roomId, ex);
        }
        return result;
    }

    public int setRaisedState(UUID eventId, UUID roomId, UUID userId, boolean raised) {
        String activeKey = handActiveKey(eventId, roomId);
        String queueKey = handQueueKey(eventId, roomId);
        try {
            if (raised) {
                redisTemplate.opsForSet().add(activeKey, userId.toString());
                redisTemplate.opsForZSet().add(queueKey, userId.toString(), Instant.now().toEpochMilli());
            } else {
                redisTemplate.opsForSet().remove(activeKey, userId.toString());
                redisTemplate.opsForZSet().remove(queueKey, userId.toString());
            }
            refreshTtl(eventId, roomId);
            Long handCount = redisTemplate.opsForSet().size(activeKey);
            return handCount == null ? 0 : handCount.intValue();
        } catch (DataAccessException ex) {
            log.warn("Failed to set raised state in redis roomId={} userId={}", roomId, userId, ex);
            return 0;
        }
    }

    public List<UUID> getHandQueue(UUID eventId, UUID roomId) {
        List<UUID> queue = new ArrayList<>();
        try {
            Set<String> values = redisTemplate.opsForZSet().range(handQueueKey(eventId, roomId), 0, -1);
            if (values == null) {
                return queue;
            }
            values.forEach(value -> parseUuid(value).ifPresent(queue::add));
        } catch (DataAccessException ex) {
            log.warn("Failed to read hand queue from redis roomId={}", roomId, ex);
        }
        return queue;
    }

    public void removeParticipantState(UUID eventId, UUID roomId, UUID userId) {
        try {
            redisTemplate.opsForHash().delete(micKey(eventId, roomId), userId.toString());
            redisTemplate.opsForSet().remove(handActiveKey(eventId, roomId), userId.toString());
            redisTemplate.opsForZSet().remove(handQueueKey(eventId, roomId), userId.toString());
        } catch (DataAccessException ex) {
            log.warn("Failed to cleanup participant state in redis roomId={} userId={}", roomId, userId, ex);
        }
    }

    public boolean isRaised(UUID eventId, UUID roomId, UUID userId) {
        try {
            Boolean member = redisTemplate.opsForSet().isMember(handActiveKey(eventId, roomId), userId.toString());
            return Boolean.TRUE.equals(member);
        } catch (DataAccessException ex) {
            log.warn("Failed to read raised state in redis roomId={} userId={}", roomId, ex);
            return false;
        }
    }

    private void refreshTtl(UUID eventId, UUID roomId) {
        redisTemplate.expire(micKey(eventId, roomId), STATE_TTL);
        redisTemplate.expire(handActiveKey(eventId, roomId), STATE_TTL);
        redisTemplate.expire(handQueueKey(eventId, roomId), STATE_TTL);
    }

    private java.util.Optional<UUID> parseUuid(Object value) {
        try {
            return java.util.Optional.of(UUID.fromString(String.valueOf(value)));
        } catch (IllegalArgumentException ex) {
            return java.util.Optional.empty();
        }
    }

    private String micKey(UUID eventId, UUID roomId) {
        return "rt:event:" + eventId + ":room:" + roomId + ":mic";
    }

    private String handActiveKey(UUID eventId, UUID roomId) {
        return "rt:event:" + eventId + ":room:" + roomId + ":hand:active";
    }

    private String handQueueKey(UUID eventId, UUID roomId) {
        return "rt:event:" + eventId + ":room:" + roomId + ":hand:queue";
    }
}
