package com.lucy.api.modules.event.dto.realtime;

public record HandStatusChangedData(
        boolean raised,
        int handCount
) {
}
