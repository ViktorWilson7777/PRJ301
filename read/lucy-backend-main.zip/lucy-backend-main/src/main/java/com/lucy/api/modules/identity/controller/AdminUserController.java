package com.lucy.api.modules.identity.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.identity.dtos.request.admin.AdminBanUserRequest;
import com.lucy.api.modules.identity.dtos.request.admin.AdminUpdateUserRolesRequest;
import com.lucy.api.modules.identity.dtos.request.admin.AdminUpdateUserStatusRequest;
import com.lucy.api.modules.identity.dtos.response.user.UserResponse;
import com.lucy.api.modules.identity.service.interfaces.AdminUserService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/admin/users")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class AdminUserController {

    AdminUserService adminUserService;

    @PutMapping("/{userId}/status")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<UserResponse>> updateStatus(
            @PathVariable String userId,
            @RequestBody AdminUpdateUserStatusRequest request
    ) {
        return ResponseEntity.ok(ApiResponse.<UserResponse>builder()
                .success(true)
                .data(adminUserService.updateStatus(userId, request))
                .build());
    }

    @PutMapping("/{userId}/ban")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<UserResponse>> ban(
            @PathVariable String userId,
            @RequestBody AdminBanUserRequest request
    ) {
        return ResponseEntity.ok(ApiResponse.<UserResponse>builder()
                .success(true)
                .data(adminUserService.ban(userId, request))
                .build());
    }

    @PutMapping("/{userId}/roles")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse<UserResponse>> updateRoles(
            @PathVariable String userId,
            @RequestBody AdminUpdateUserRolesRequest request
    ) {
        return ResponseEntity.ok(ApiResponse.<UserResponse>builder()
                .success(true)
                .data(adminUserService.updateRoles(userId, request))
                .build());
    }
}

