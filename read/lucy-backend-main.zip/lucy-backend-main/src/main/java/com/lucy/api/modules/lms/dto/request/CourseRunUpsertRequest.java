package com.lucy.api.modules.lms.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.Map;

@Getter
@Setter
public class CourseRunUpsertRequest {
    @NotNull(message = "common.field_required")
    private String courseId;

    @NotBlank(message = "common.field_required")
    @Size(max = 120, message = "common.validation")
    private String code;

    @NotBlank(message = "common.field_required")
    @Size(max = 20, message = "common.validation")
    private String status;

    @NotNull(message = "common.field_required")
    private Instant startsAt;

    @NotNull(message = "common.field_required")
    private Instant endsAt;

    @NotBlank(message = "common.field_required")
    @Size(max = 64, message = "common.validation")
    private String timezone;

    private Instant enrollmentStartDate;
    private Instant enrollmentEndDate;
    private Integer capacity;
    private String prerequisiteCourseRunId;

    private Map<String, Object> metadata;
}
