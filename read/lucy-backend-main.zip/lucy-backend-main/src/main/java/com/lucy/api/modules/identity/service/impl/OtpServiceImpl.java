package com.lucy.api.modules.identity.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.constants.auth.OtpConstants;
import com.lucy.api.modules.identity.constants.user.UserErrorCodeConstants;
import com.lucy.api.modules.identity.service.interfaces.OtpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Duration;

@Service
@RequiredArgsConstructor
@Slf4j
public class OtpServiceImpl implements OtpService {

    private final StringRedisTemplate redisTemplate;

    private static final String OTP_KEY_PREFIX = OtpConstants.OTP_KEY_PREFIX;
    private static final String COOLDOWN_KEY_PREFIX = OtpConstants.COOLDOWN_KEY_PREFIX;
    private static final String OTP_REGISTER_PREFIX = OtpConstants.OTP_REGISTER_KEY_PREFIX;
    private static final String COOLDOWN_REGISTER_PREFIX = OtpConstants.COOLDOWN_REGISTER_KEY_PREFIX;
    private static final Duration OTP_TTL = OtpConstants.OTP_TTL;
    private static final Duration COOLDOWN_TTL = OtpConstants.COOLDOWN_TTL;
    private static final int OTP_LENGTH = OtpConstants.OTP_LENGTH;

    private final SecureRandom secureRandom = new SecureRandom();

    @Override
    public String generateAndStoreOtp(String email) {
        // Check cooldown
        String cooldownKey = COOLDOWN_KEY_PREFIX + email;
        if (Boolean.TRUE.equals(redisTemplate.hasKey(cooldownKey))) {
            throw new AppException(UserErrorCodeConstants.AUTH_OTP_COOLDOWN, HttpStatus.TOO_MANY_REQUESTS);
        }

        // Generate 6-digit OTP
        int otpNumber = secureRandom.nextInt((int) Math.pow(10, OTP_LENGTH));
        String otp = String.format("%0" + OTP_LENGTH + "d", otpNumber);

        // Store OTP in Redis with TTL
        String otpKey = OTP_KEY_PREFIX + email;
        redisTemplate.opsForValue().set(otpKey, otp, OTP_TTL);

        // Set cooldown
        redisTemplate.opsForValue().set(cooldownKey, "1", COOLDOWN_TTL);

        log.info("OTP generated and stored for email: {}", email);
        return otp;
    }

    @Override
    public boolean verifyOtp(String email, String otp) {
        String otpKey = OTP_KEY_PREFIX + email;
        String storedOtp = redisTemplate.opsForValue().get(otpKey);

        if (storedOtp == null || !storedOtp.equals(otp)) {
            return false;
        }
        return true;
    }

    @Override
    public void deleteOtp(String email) {
        String otpKey = OTP_KEY_PREFIX + email;
        redisTemplate.delete(otpKey);

        // Also clean up cooldown
        String cooldownKey = COOLDOWN_KEY_PREFIX + email;
        redisTemplate.delete(cooldownKey);

        log.info("OTP deleted for email: {}", email);
    }

    @Override
    public String generateAndStoreRegistrationOtp(String email) {
        String cooldownKey = COOLDOWN_REGISTER_PREFIX + email;
        if (Boolean.TRUE.equals(redisTemplate.hasKey(cooldownKey))) {
            throw new AppException(UserErrorCodeConstants.AUTH_OTP_COOLDOWN, HttpStatus.TOO_MANY_REQUESTS);
        }

        int otpNumber = secureRandom.nextInt((int) Math.pow(10, OTP_LENGTH));
        String otp = String.format("%0" + OTP_LENGTH + "d", otpNumber);

        String otpKey = OTP_REGISTER_PREFIX + email;
        redisTemplate.opsForValue().set(otpKey, otp, OTP_TTL);
        redisTemplate.opsForValue().set(cooldownKey, "1", COOLDOWN_TTL);

        log.info("Registration OTP generated for email: {}", email);
        return otp;
    }

    @Override
    public boolean verifyRegistrationOtp(String email, String otp) {
        String otpKey = OTP_REGISTER_PREFIX + email;
        String storedOtp = redisTemplate.opsForValue().get(otpKey);
        return storedOtp != null && storedOtp.equals(otp);
    }

    @Override
    public void deleteRegistrationOtp(String email) {
        redisTemplate.delete(OTP_REGISTER_PREFIX + email);
        redisTemplate.delete(COOLDOWN_REGISTER_PREFIX + email);
        log.info("Registration OTP deleted for email: {}", email);
    }
}
