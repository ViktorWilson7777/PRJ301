package com.lucy.api.modules.commerce.repository;

import com.lucy.api.modules.commerce.entity.PublicCourseProduct;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PublicCourseProductRepository extends JpaRepository<PublicCourseProduct, String> {
    Optional<PublicCourseProduct> findByCourseRun_IdAndIsActiveTrue(String courseRunId);
}
