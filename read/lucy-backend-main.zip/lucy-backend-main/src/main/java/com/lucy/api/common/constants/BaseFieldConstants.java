package com.lucy.api.common.constants;

public class BaseFieldConstants {
    public static final String ID = "id";
}
