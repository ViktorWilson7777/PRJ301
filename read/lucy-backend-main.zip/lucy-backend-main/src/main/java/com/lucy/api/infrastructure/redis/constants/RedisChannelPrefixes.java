package com.lucy.api.infrastructure.redis.constants;

/**
 * Prefix kênh Redis pub/sub — một nguồn cho publish, subscribe và {@code supports(channel)}.
 */
public final class RedisChannelPrefixes {

    private RedisChannelPrefixes() {
    }

    public static final String WS_MESSAGE = "ws:message:";
    public static final String WS_NOTIFICATION = "ws:notification:";
}
