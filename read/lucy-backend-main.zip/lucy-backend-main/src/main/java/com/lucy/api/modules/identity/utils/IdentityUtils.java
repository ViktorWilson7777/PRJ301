package com.lucy.api.modules.identity.utils;

import com.lucy.api.common.constants.JwtClaimSetConstant;
import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.constants.user.UserErrorCodeConstants;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class IdentityUtils {

    public static String getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication instanceof JwtAuthenticationToken jwtAuth) {
            Jwt jwt = jwtAuth.getToken();
            Object claim = jwt.getClaims().get(JwtClaimSetConstant.CLAIM_USER_ID);
            if (claim == null) {
                throw new AppException(UserErrorCodeConstants.AUTH_UNAUTHENTICATED, HttpStatus.UNAUTHORIZED);
            }
            String userIdString = claim.toString();
            if (userIdString.isBlank()) {
                throw new AppException(UserErrorCodeConstants.AUTH_UNAUTHENTICATED, HttpStatus.UNAUTHORIZED);
            }
            return userIdString;
        }

        throw new AppException(UserErrorCodeConstants.AUTH_UNAUTHENTICATED, HttpStatus.UNAUTHORIZED);
    }
}

