package com.lucy.api.modules.messaging.listener;

import com.lucy.api.modules.messaging.event.EnrollmentActivatedEvent;
import com.lucy.api.modules.messaging.event.EnrollmentRemovedEvent;
import com.lucy.api.modules.messaging.service.facade.CourseRunGroupChatFacade;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Slf4j
@Component
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MessagingEnrollmentListener {

    CourseRunGroupChatFacade courseRunGroupChatFacade;

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onEnrollmentActivated(EnrollmentActivatedEvent event) {
        try {
            courseRunGroupChatFacade.syncAfterEnrollmentActivated(event.userId(), event.courseRunId());
        } catch (Exception e) {
            log.error("Messaging sync after enrollment failed userId={} courseRunId={}",
                    event.userId(), event.courseRunId(), e);
        }
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onEnrollmentRemoved(EnrollmentRemovedEvent event) {
        try {
            courseRunGroupChatFacade.syncAfterEnrollmentRemoved(event.userId(), event.courseRunId());
        } catch (Exception e) {
            log.error("Messaging sync after enrollment removal failed userId={} courseRunId={}",
                    event.userId(), event.courseRunId(), e);
        }
    }
}
