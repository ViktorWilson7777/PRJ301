package com.lucy.api.modules.messaging.service.impl;

import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.messaging.dto.request.EditMessageRequest;
import com.lucy.api.modules.messaging.dto.request.SendMessageRequest;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;
import com.lucy.api.modules.messaging.service.MessagingService;
import com.lucy.api.modules.messaging.service.facade.MessagingFacade;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MessagingServiceImpl implements MessagingService {
    MessagingFacade messagingFacade;

    @Override
    @Transactional
    public ChatMessageResponse sendMessage(SendMessageRequest request, String currentUserId, boolean emitRealtime) {
        return messagingFacade.sendMessage(
                request.getConversationId(),
                request.getPeerUserId(),
                currentUserId,
                request.getText(),
                request.getAttachments(),
                request.getReplyToMessageId()
        );
    }

    @Override
    @Transactional
    public ChatMessageResponse editMessage(String messageId, EditMessageRequest request, String currentUserId, boolean emitRealtime) {
        return messagingFacade.editMessage(messageId, currentUserId, request);
    }

    @Override
    @Transactional(readOnly = true)
    public PagingResponse<ChatMessageResponse> getMessages(String conversationId, PagingRequest pagingRequest, String currentUserId) {
        return messagingFacade.getMessages(conversationId, currentUserId, pagingRequest);
    }
}
