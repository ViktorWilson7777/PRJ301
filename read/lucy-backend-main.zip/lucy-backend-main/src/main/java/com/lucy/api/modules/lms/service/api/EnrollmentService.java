package com.lucy.api.modules.lms.service.api;

import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.lms.dto.request.EnrollMeRequest;
import com.lucy.api.modules.lms.dto.request.EnrollmentFilterRequest;
import com.lucy.api.modules.lms.dto.request.ManualEnrollmentRequest;
import com.lucy.api.modules.lms.dto.request.EnrollmentUpdateRequest;
import com.lucy.api.modules.lms.dto.response.EnrollmentImportResponse;
import com.lucy.api.modules.lms.dto.response.EnrollmentResponse;
import com.lucy.api.modules.lms.entity.Enrollment;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface EnrollmentService {

    /**
     * Create an enrollment for a user in a course run.
     * Intended for internal service-layer use only (not exposed via REST).
     */
    EnrollmentResponse enroll(String userId, String courseRunId);

    /**
     * Self-enrollment for authenticated user.
     * Validates that the course run is open for enrollment before delegating to enroll().
     */
    EnrollmentResponse enrollMe(EnrollMeRequest request);

    EnrollmentResponse manualEnroll(ManualEnrollmentRequest request);

    EnrollmentImportResponse importFromExcel(MultipartFile file, String courseRunId, boolean dryRun);

    byte[] generateImportTemplate();

    boolean hasActiveEnrollment(String userId, String courseRunId);

    /**
     * Paginated, compound-filtered list of enrollments.
     */
    PagingResponse<EnrollmentResponse> getList(EnrollmentFilterRequest request);

    /**
     * Get a single enrollment by its id.
     */
    EnrollmentResponse getById(String enrollmentId);

    /**
     * Update mutable fields of an enrollment (status, role, method, timestamps).
     */
    EnrollmentResponse update(String enrollmentId, EnrollmentUpdateRequest request);

    /**
     * Load raw entity — used internally by other services.
     */
    Enrollment getEntityById(String enrollmentId);

    /**
     * Get all enrollments for a specific course run (flat list, no pagination).
     */
    List<EnrollmentResponse> getByCourseRunId(String courseRunId);

    /**
     * Get all enrollments for a specific user (flat list, no pagination).
     */
    List<EnrollmentResponse> getByUserId(String userId);

    /**
     * Soft-delete (or hard-delete) an enrollment.
     */
    void delete(String enrollmentId);
}
