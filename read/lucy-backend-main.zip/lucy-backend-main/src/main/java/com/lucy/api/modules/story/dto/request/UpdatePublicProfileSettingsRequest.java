package com.lucy.api.modules.story.dto.request;

import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UpdatePublicProfileSettingsRequest {
    @Size(max = 20)
    List<@Size(max = 40) String> sections;
}
