package com.lucy.api.modules.messaging.entity;

import com.lucy.api.modules.messaging.enums.ConversationMode;
import com.lucy.api.modules.messaging.enums.ConversationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "conversations")
public class ConversationEntity {
    @Id
    @Column(updatable = false, length = 36)
    String id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    ConversationMode mode;

    @Column(name = "room_id", length = 36)
    String roomId;

    @Column(name = "direct_key", length = 120)
    String directKey;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    ConversationStatus status;

    @Column(name = "created_at", nullable = false)
    Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    Instant updatedAt;

    @PrePersist
    void prePersist() {
        Instant now = Instant.now();
        if (id == null) {
            id = UUID.randomUUID().toString();
        }
        if (status == null) {
            status = ConversationStatus.OPEN;
        }
        if (createdAt == null) {
            createdAt = now;
        }
        updatedAt = now;
    }

    @PreUpdate
    void preUpdate() {
        updatedAt = Instant.now();
    }
}
