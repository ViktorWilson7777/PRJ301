package com.lucy.api.modules.event.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.modules.event.dto.response.ParticipantResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Redis Cache Service for Room Participants
 * Manages real-time participant list in Redis for fast access
 * 
 * Redis Key Patterns:
 * - room:{roomId}:participants - Hash map of participants (userId -> JSON)
 * - room:{roomId}:participant:count - Participant count
 * - room:{roomId}:participants:ttl - TTL marker for cleanup
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class RoomCacheService {

    private final RedisTemplate<String, Object> redisTemplate;
    private final ObjectMapper objectMapper;

    private static final String PARTICIPANTS_KEY_PREFIX = "room:";
    private static final String PARTICIPANTS_KEY_SUFFIX = ":participants";
    private static final String COUNT_KEY_SUFFIX = ":participant:count";
    
    // TTL: 24 hours for active rooms (will be refreshed on activity)
    private static final long ROOM_TTL_HOURS = 24;

    /**
     * Add participant to room cache
     */
    public void addParticipant(UUID roomId, ParticipantResponse participant) {
        try {
            String participantsKey = getParticipantsKey(roomId);
            String participantJson = objectMapper.writeValueAsString(participant);

            redisTemplate.opsForHash().put(participantsKey, participant.getUserId().toString(), participantJson);

            syncParticipantCount(roomId);
            refreshRoomTTL(roomId);

            log.info("Added participant {} to room {} cache", participant.getUserId(), roomId);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize participant data", e);
            throw new RuntimeException("Failed to cache participant", e);
        }
    }

    /**
     * Remove participant from room cache
     */
    public void removeParticipant(UUID roomId, UUID userId) {
        try {
            String participantsKey = getParticipantsKey(roomId);
            Long removed = redisTemplate.opsForHash().delete(participantsKey, userId.toString());

            if (removed != null && removed > 0) {
                syncParticipantCount(roomId);
                refreshRoomTTL(roomId);
                log.info("Removed participant {} from room {} cache", userId, roomId);
            }
        } catch (Exception e) {
            log.error("Failed to remove participant from cache", e);
            throw new RuntimeException("Failed to remove participant from cache", e);
        }
    }

    /**
     * Get all participants in a room
     */
    public List<ParticipantResponse> getParticipants(UUID roomId) {
        try {
            String participantsKey = getParticipantsKey(roomId);
            
            // Get all participants from hash map
            Map<Object, Object> entries = redisTemplate.opsForHash().entries(participantsKey);
            
            if (entries.isEmpty()) {
                return Collections.emptyList();
            }
            
            // Deserialize all participants
            return entries.values().stream()
                    .map(obj -> {
                        try {
                            return objectMapper.readValue(obj.toString(), ParticipantResponse.class);
                        } catch (JsonProcessingException e) {
                            log.error("Failed to deserialize participant", e);
                            return null;
                        }
                    })
                    .filter(Objects::nonNull)
                    .sorted((p1, p2) -> {
                        if (p1.getJoinedAt() == null) return 1;
                        if (p2.getJoinedAt() == null) return -1;
                        return p1.getJoinedAt().compareTo(p2.getJoinedAt());
                    })
                    .collect(Collectors.toList());
            
        } catch (Exception e) {
            log.error("Failed to get participants from cache", e);
            return Collections.emptyList();
        }
    }

    /**
     * Get participant count for a room
     */
    public int getParticipantCount(UUID roomId) {
        try {
            String countKey = getCountKey(roomId);
            Object count = redisTemplate.opsForValue().get(countKey);
            if (count == null) {
                return 0;
            }
            if (count instanceof Number number) {
                return number.intValue();
            }
            return Integer.parseInt(count.toString());
        } catch (Exception e) {
            log.error("Failed to get participant count from cache", e);
            return 0;
        }
    }

    /**
     * Get specific participant from room
     */
    public Optional<ParticipantResponse> getParticipant(UUID roomId, UUID userId) {
        try {
            String participantsKey = getParticipantsKey(roomId);
            
            Object participantJson = redisTemplate.opsForHash().get(participantsKey, userId.toString());
            
            if (participantJson == null) {
                return Optional.empty();
            }
            
            ParticipantResponse participant = objectMapper.readValue(
                    participantJson.toString(), 
                    ParticipantResponse.class
            );
            
            return Optional.of(participant);
            
        } catch (Exception e) {
            log.error("Failed to get participant from cache", e);
            return Optional.empty();
        }
    }

    /**
     * Check if user is in room cache
     */
    public boolean isParticipantInCache(UUID roomId, UUID userId) {
        try {
            String participantsKey = getParticipantsKey(roomId);
            return redisTemplate.opsForHash().hasKey(participantsKey, userId.toString());
        } catch (Exception e) {
            log.error("Failed to check participant in cache", e);
            return false;
        }
    }

    /**
     * Update participant info (e.g., mic status, hand raise)
     */
    public void updateParticipant(UUID roomId, ParticipantResponse participant) {
        addParticipant(roomId, participant);
    }

    /**
     * Get participant snapshot (list + count)
     */
    public Map<String, Object> getParticipantSnapshot(UUID roomId) {
        List<ParticipantResponse> participants = getParticipants(roomId);
        int count = participants.size(); // Use actual list size for accuracy
        
        Map<String, Object> snapshot = new HashMap<>();
        snapshot.put("roomId", roomId);
        snapshot.put("totalParticipants", count);
        snapshot.put("participants", participants);
        snapshot.put("generatedAt", Instant.now());
        
        return snapshot;
    }

    /**
     * Check whether room participant cache has been initialized,
     * including the case where the room currently has zero participants.
     */
    public boolean hasParticipantCache(UUID roomId) {
        try {
            String participantsKey = getParticipantsKey(roomId);
            String countKey = getCountKey(roomId);
            Boolean hasParticipantsKey = redisTemplate.hasKey(participantsKey);
            Boolean hasCountKey = redisTemplate.hasKey(countKey);
            return Boolean.TRUE.equals(hasParticipantsKey) || Boolean.TRUE.equals(hasCountKey);
        } catch (Exception e) {
            log.error("Failed to check participant cache existence", e);
            return false;
        }
    }

    /**
     * Clear all cache for a room (when room ends)
     */
    public void clearRoomCache(UUID roomId) {
        try {
            String participantsKey = getParticipantsKey(roomId);
            String countKey = getCountKey(roomId);
            
            redisTemplate.delete(participantsKey);
            redisTemplate.delete(countKey);
            
            log.info("Cleared cache for room {}", roomId);
            
        } catch (Exception e) {
            log.error("Failed to clear room cache", e);
        }
    }

    /**
     * Refresh TTL for room cache
     * Called on every activity to keep cache alive
     */
    public void refreshRoomTTL(UUID roomId) {
        try {
            String participantsKey = getParticipantsKey(roomId);
            String countKey = getCountKey(roomId);
            
            redisTemplate.expire(participantsKey, ROOM_TTL_HOURS, TimeUnit.HOURS);
            redisTemplate.expire(countKey, ROOM_TTL_HOURS, TimeUnit.HOURS);
            
        } catch (Exception e) {
            log.error("Failed to refresh room TTL", e);
        }
    }

    /**
     * Sync cache with database (fallback mechanism)
     * Use this when cache is empty but DB has data
     */
    public void syncCacheWithDatabase(UUID roomId, List<ParticipantResponse> participants) {
        try {
            clearRoomCache(roomId);

            if (participants.isEmpty()) {
                String countKey = getCountKey(roomId);
                redisTemplate.opsForValue().set(countKey, "0", ROOM_TTL_HOURS, TimeUnit.HOURS);
                log.info("Initialized empty participant cache for room {}", roomId);
                return;
            }

            for (ParticipantResponse participant : participants) {
                addParticipant(roomId, participant);
            }
            
            log.info("Synced {} participants to cache for room {}", participants.size(), roomId);
            
        } catch (Exception e) {
            log.error("Failed to sync cache with database", e);
        }
    }

    /**
     * Get all active room IDs (for monitoring/debugging)
     */
    public Set<String> getActiveRoomIds() {
        try {
            Set<String> keys = redisTemplate.keys(PARTICIPANTS_KEY_PREFIX + "*" + PARTICIPANTS_KEY_SUFFIX);
            return keys != null ? keys : Collections.emptySet();
        } catch (Exception e) {
            log.error("Failed to get active room IDs", e);
            return Collections.emptySet();
        }
    }

    // Helper methods
    private String getParticipantsKey(UUID roomId) {
        return PARTICIPANTS_KEY_PREFIX + roomId + PARTICIPANTS_KEY_SUFFIX;
    }

    private String getCountKey(UUID roomId) {
        return PARTICIPANTS_KEY_PREFIX + roomId + COUNT_KEY_SUFFIX;
    }

    private void syncParticipantCount(UUID roomId) {
        String participantsKey = getParticipantsKey(roomId);
        String countKey = getCountKey(roomId);
        Long size = redisTemplate.opsForHash().size(participantsKey);
        redisTemplate.opsForValue().set(countKey, String.valueOf(size != null ? size : 0L));
    }
}
