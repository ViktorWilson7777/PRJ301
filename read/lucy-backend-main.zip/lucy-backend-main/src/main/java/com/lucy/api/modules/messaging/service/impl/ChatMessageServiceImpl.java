package com.lucy.api.modules.messaging.service.impl;

import com.lucy.api.common.constants.GlobalVariableConstant;
import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.common.utils.PagingUtil;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketMessageService;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.messaging.constant.MessagingErrorKeys;
import com.lucy.api.modules.messaging.dto.request.AttachmentRequest;
import com.lucy.api.modules.messaging.dto.request.EditMessageRequest;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;
import com.lucy.api.modules.messaging.dto.response.ChatSenderInfoResponse;
import com.lucy.api.modules.messaging.dto.websocket.MessagingAttachmentPayload;
import com.lucy.api.modules.messaging.dto.websocket.MessagingRealtimeMessagePayload;
import com.lucy.api.modules.messaging.entity.ChatMessage;
import com.lucy.api.modules.messaging.mapper.ChatMessageMapper;
import com.lucy.api.modules.messaging.repository.ChatMessageRepository;
import com.lucy.api.modules.messaging.repository.ConversationParticipantRepository;
import com.lucy.api.modules.messaging.repository.ConversationRepository;
import com.lucy.api.modules.messaging.service.interfaces.ChatMessageService;
import com.lucy.api.modules.messaging.service.domain.ChatMessageDomainService;
import com.lucy.api.modules.messaging.service.domain.ConversationParticipantDomainService;
import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import com.lucy.api.modules.notifications.entity.UserDevice;
import com.lucy.api.modules.notifications.repository.UserDeviceRepository;
import com.lucy.api.modules.notifications.service.FirebasePushService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ChatMessageServiceImpl implements ChatMessageService {

    ChatMessageRepository chatMessageRepository;
    ConversationRepository conversationRepository;
    ConversationParticipantDomainService conversationParticipantDomainService;
    ChatMessageDomainService chatMessageDomainService;
    UserRepository userRepository;
    WebSocketMessageService webSocketMessageService;
    ChatMessageMapper chatMessageMapper;
    ConversationParticipantRepository conversationParticipantRepository;
    UserDeviceRepository userDeviceRepository;
    FirebasePushService firebasePushService;
    MessageSource messageSource;
    StringRedisTemplate stringRedisTemplate;

    @Override
    @Transactional
    public ChatMessageResponse sendMessage(
            String conversationId,
            String senderUserId,
            String text,
            List<AttachmentRequest> attachments,
            String replyToMessageId
    ) {
        ChatMessage saved = chatMessageDomainService.createAndSaveMessage(
                conversationId, senderUserId, text, attachments, replyToMessageId);
        ChatMessageResponse response = chatMessageMapper.toResponse(saved);
        response.setAttachments(chatMessageMapper.toAttachmentList(saved.getAttachments()));
        response.setIsEcho(Boolean.TRUE);
        enrichSenderInfo(List.of(response));
        broadcastRealtime(response);
        notifyParticipants(saved, response, senderUserId);
        return response;
    }

    @Override
    @Transactional
    public ChatMessageResponse editMessage(String messageId, String editorUserId, EditMessageRequest request) {
        ChatMessage saved = chatMessageDomainService.updateMessageText(messageId, editorUserId, request.getText());
        ChatMessageResponse response = chatMessageMapper.toResponse(saved);
        response.setAttachments(chatMessageMapper.toAttachmentList(saved.getAttachments()));
        response.setIsEcho(Boolean.TRUE);
        enrichSenderInfo(List.of(response));
        broadcastRealtime(response);
        return response;
    }

    private void notifyParticipants(ChatMessage saved, ChatMessageResponse response, String senderUserId) {
        final List<User> recipients = conversationParticipantRepository
                .findByConversationIdAndStatus(saved.getConversation().getId(), ParticipantStatus.ACTIVE)
                .stream()
                .map(cp -> cp.getUser())
                .filter(user -> user != null && user.getId() != null && !user.getId().equals(senderUserId))
                .distinct()
                .toList();

        final String senderName = response.getSenderInfo() != null
                ? response.getSenderInfo().getFullName()
                : response.getSenderUsername();
        final List<String> recipientIds = recipients.stream()
                .map(User::getId)
                .filter(id -> id != null && !id.isBlank())
                .toList();
        final Map<String, List<String>> tokensByUserId = userDeviceRepository.findByUserIdIn(recipientIds)
                .stream()
                .filter(device -> device.getUserId() != null && device.getDeviceToken() != null && !device.getDeviceToken().isBlank())
                .collect(Collectors.groupingBy(
                        UserDevice::getUserId,
                        Collectors.mapping(UserDevice::getDeviceToken, Collectors.toList())
                ));
        recipients.forEach(user -> {
            final Locale locale = resolveUserLocale(user);
            final String baseTitle = (senderName == null || senderName.isBlank())
                    ? messageSource.getMessage("notification.chat.new_message.title", null, locale)
                    : messageSource.getMessage("notification.chat.new_message.with_sender.title", new Object[]{senderName}, locale);
            final String latestMessagePreview = (response.getText() == null || response.getText().isBlank())
                    ? messageSource.getMessage("notification.chat.attachment.body", null, locale)
                    : response.getText();
            final long unreadCount = incrementChatPushCount(user.getId(), saved.getConversation().getId());
            final String title = unreadCount > 1 && senderName != null && !senderName.isBlank()
                    ? messageSource.getMessage(
                    "notification.chat.new_message.summary.with_sender.title",
                    new Object[]{senderName, unreadCount},
                    locale
            )
                    : baseTitle;

            final List<String> tokens = tokensByUserId.getOrDefault(user.getId(), List.of())
                    .stream()
                    .filter(token -> token != null && !token.isBlank())
                    .distinct()
                    .toList();

            if (!tokens.isEmpty()) {
                final Map<String, String> data = new HashMap<>();
                data.put("conversationId", saved.getConversation().getId());
                data.put("type", "CHAT");
                data.put("unreadCount", String.valueOf(unreadCount));
                firebasePushService.sendMulticastPushWithDataAndTag(
                        tokens,
                        title,
                        latestMessagePreview,
                        data,
                        saved.getConversation().getId()
                );
            }
        });
    }

    private long incrementChatPushCount(String userId, String conversationId) {
        final String key = "push:chat:count:" + userId + ":" + conversationId;
        Long count = stringRedisTemplate.opsForValue().increment(key);
        stringRedisTemplate.expire(key, 1, TimeUnit.DAYS);
        return count == null ? 1L : count;
    }

    private void clearChatPushCount(String userId, String conversationId) {
        final String key = "push:chat:count:" + userId + ":" + conversationId;
        stringRedisTemplate.delete(key);
    }

    private Locale resolveUserLocale(User user) {
        if (user == null || user.getUserMetadata() == null) {
            return Locale.ENGLISH;
        }
        final Object locale = user.getUserMetadata().get("locale");
        if (locale == null) {
            return Locale.ENGLISH;
        }
        final String tag = locale.toString().trim();
        if (tag.isEmpty()) {
            return Locale.ENGLISH;
        }
        return Locale.forLanguageTag(tag);
    }

    @Override
    @Transactional(readOnly = true)
    public PagingResponse<ChatMessageResponse> getMessages(
            String conversationId,
            String readerUserId,
            PagingRequest pagingRequest
    ) {
        conversationRepository.findById(conversationId)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));

        conversationParticipantDomainService.requireActiveParticipant(conversationId, readerUserId);
        clearChatPushCount(readerUserId, conversationId);

        if (pagingRequest == null) {
            pagingRequest = PagingRequest.builder()
                    .page(1)
                    .pageSize(100)
                    .build();
        }

        Pageable pageable = PageRequest.of(
                pagingRequest.getPage() - GlobalVariableConstant.PAGE_SIZE_INDEX,
                pagingRequest.getPageSize(),
                PagingUtil.createSort(pagingRequest)
        );

        Page<ChatMessage> page = chatMessageRepository.findByConversationIdOrderByCreatedAtDesc(conversationId, pageable);

        List<ChatMessageResponse> data = CollectionUtils.isEmpty(page.getContent())
                ? List.of()
                : page.getContent().stream()
                .map(msg -> {
                    ChatMessageResponse r = chatMessageMapper.toResponse(msg);
                    r.setAttachments(chatMessageMapper.toAttachmentList(msg.getAttachments()));
                    boolean isEcho = msg.getSender() != null && readerUserId.equals(msg.getSender().getId());
                    r.setIsEcho(isEcho);
                    return r;
                })
                .toList();

        enrichSenderInfo(data);

        return PagingResponse.<ChatMessageResponse>builder()
                .currentPage(pagingRequest.getPage())
                .pageSize(page.getSize())
                .totalPages(page.getTotalPages())
                .totalElement(page.getTotalElements())
                .data(data)
                .build();
    }

    private void broadcastRealtime(ChatMessageResponse message) {
        try {
            List<MessagingAttachmentPayload> att = null;
            if (message.getAttachments() != null) {
                att = message.getAttachments().stream()
                        .map(a -> MessagingAttachmentPayload.builder()
                                .type(a.getType())
                                .url(a.getUrl())
                                .title(a.getTitle())
                                .build())
                        .toList();
            }
            MessagingRealtimeMessagePayload payload = MessagingRealtimeMessagePayload.builder()
                    .conversationId(message.getConversationId())
                    .messageId(message.getId())
                    .text(message.getText())
                    .senderId(message.getSenderId())
                    .senderUsername(message.getSenderUsername())
                    .timestamp(message.getCreatedAt())
                    .attachments(att)
                    .isEdited(message.getIsEdited())
                    .editCount(message.getEditCount())
                    .senderFullName(message.getSenderInfo() != null ? message.getSenderInfo().getFullName() : null)
                    .senderAvatarUrl(message.getSenderInfo() != null ? message.getSenderInfo().getAvatarUrl() : null)
                    .build();

            webSocketMessageService.sendToTopic(
                    message.getConversationId(),
                    payload,
                    WebSocketConstants.OUTBOUND_FRAME_TYPE_MESSAGE
            );
        } catch (Exception e) {
            log.error("Failed to broadcast chat message {} to WebSocket", message.getId(), e);
        }
    }

    private void enrichSenderInfo(List<ChatMessageResponse> messages) {
        if (CollectionUtils.isEmpty(messages)) {
            return;
        }
        Set<String> senderIds = new HashSet<>();
        for (ChatMessageResponse message : messages) {
            if (message != null && message.getSenderId() != null) {
                senderIds.add(message.getSenderId());
            }
        }
        if (senderIds.isEmpty()) {
            return;
        }
        List<User> users = userRepository.findAllById(senderIds);
        Map<String, ChatSenderInfoResponse> infoByUserId = new HashMap<>();
        for (User user : users) {
            if (user == null || user.getId() == null) {
                continue;
            }
            ChatSenderInfoResponse info = ChatSenderInfoResponse.builder()
                    .userId(user.getId())
                    .username(user.getProfile() != null ? user.getProfile().getDisplayName() : user.getEmail())
                    .fullName(user.getProfile() != null ? user.getProfile().getDisplayName() : user.getEmail())
                    .avatarUrl(user.getProfile() != null ? user.getProfile().getAvatarUrl() : null)
                    .build();
            infoByUserId.put(user.getId(), info);
        }
        for (ChatMessageResponse message : messages) {
            if (message == null || message.getSenderId() == null) {
                continue;
            }
            ChatSenderInfoResponse info = infoByUserId.get(message.getSenderId());
            if (info != null) {
                message.setSenderInfo(info);
            }
        }
    }
}
