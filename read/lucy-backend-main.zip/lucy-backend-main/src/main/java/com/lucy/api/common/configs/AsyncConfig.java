package com.lucy.api.common.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@EnableAsync
@Configuration
public class AsyncConfig {

    @Bean(name = "taskExecutor", destroyMethod = "close")
    public ExecutorService taskExecutor() {
        return Executors.newVirtualThreadPerTaskExecutor();
    }

    @Bean(name = "fileUploadExecutor", destroyMethod = "close")
    public ExecutorService fileUploadExecutor() {
        return Executors.newVirtualThreadPerTaskExecutor();
    }

    @Bean(name = "backgroundTaskExecutor", destroyMethod = "close")
    public ExecutorService backgroundTaskExecutor() {
        return Executors.newVirtualThreadPerTaskExecutor();
    }

    @Bean(name = "messagingWebSocketExecutor", destroyMethod = "close")
    public ExecutorService messagingWebSocketExecutor() {
        return Executors.newVirtualThreadPerTaskExecutor();
    }
}
