package com.lucy.api.infrastructure.websocket.handler;

import io.netty.channel.ChannelHandlerContext;

/**
 * Xử lý từng loại message WebSocket (theo {@code WebSocketMessageType}).
 * Đăng ký làm Spring bean; module nghiệp vụ thêm bean mới để mở rộng (vd. chat, events).
 */
public interface WebSocketCommandHandler {

    String getType();

    void handle(ChannelHandlerContext ctx, String payloadJson, String sessionId);
}
