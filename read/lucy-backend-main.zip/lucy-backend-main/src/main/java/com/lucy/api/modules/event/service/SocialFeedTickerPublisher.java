package com.lucy.api.modules.event.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.modules.event.dto.realtime.SocialFeedTickerMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class SocialFeedTickerPublisher {
    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;

    public void publish(String type,
                        String entityType,
                        UUID entityId,
                        UUID actorUserId,
                        Map<String, Object> data) {
        SocialFeedTickerMessage message = new SocialFeedTickerMessage(
                type,
                entityType,
                entityId,
                actorUserId,
                Instant.now(),
                data
        );
        try {
            String payload = objectMapper.writeValueAsString(message);
            redisTemplate.convertAndSend(SocialFeedTickerChannels.REDIS_CHANNEL, payload);
        } catch (JsonProcessingException ex) {
            log.warn("Failed to serialize social feed ticker payload type={} entityType={} entityId={}",
                    type, entityType, entityId, ex);
        } catch (Exception ex) {
            log.warn("Failed to publish social feed ticker type={} entityType={} entityId={}",
                    type, entityType, entityId, ex);
        }
    }
}
