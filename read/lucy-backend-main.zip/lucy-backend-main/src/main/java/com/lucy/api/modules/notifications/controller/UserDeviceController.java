package com.lucy.api.modules.notifications.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.notifications.dto.request.UserDeviceRequest;
import com.lucy.api.modules.notifications.service.UserDeviceService;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping({"/api/v1/notifications/devices", "/api/me/device-tokens"})
@RequiredArgsConstructor
public class UserDeviceController {

    private final UserDeviceService userDeviceService;

    @PostMapping({"/token", ""})
    public ResponseEntity<ApiResponse<Map<String, String>>> registerDevice(
            @Valid @RequestBody UserDeviceRequest request) {

        String currentUserId = IdentityUtils.getCurrentUserId();
        userDeviceService.registerDevice(currentUserId, request);
        return ResponseEntity.ok(ApiResponse.<Map<String, String>>builder()
                .success(true)
                .data(Map.of("message", "Device token registered successfully"))
                .build());
    }

    @DeleteMapping({"/token", ""})
    public ResponseEntity<ApiResponse<Map<String, String>>> unregisterDevice(
            @Valid @RequestBody UserDeviceRequest request) {

        userDeviceService.unregisterDevice(request.getToken());
        return ResponseEntity.ok(ApiResponse.<Map<String, String>>builder()
                .success(true)
                .data(Map.of("message", "Device token unregistered successfully"))
                .build());
    }
}
