package com.lucy.api.modules.messaging.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class InviteMembersRequest {
    @NotNull
    private List<String> memberUserIds;
}

