package com.lucy.api.modules.event.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CreateEventRequest {
    @NotBlank(message = "event.title_required")
    @Size(max = 200, message = "event.title_too_long")
    String title;

    @NotBlank(message = "event.description_required")
    @Size(max = 4000, message = "event.description_too_long")
    String description;

    @NotBlank(message = "event.topic_required")
    @Size(max = 120, message = "event.topic_too_long")
    String topic;

    @NotBlank(message = "event.category_required")
    @Size(max = 120, message = "event.category_too_long")
    String category;

    @NotBlank(message = "event.level_required")
    @Size(max = 40, message = "event.level_too_long")
    String level;

    @NotNull(message = "event.datetime_required")
    Instant eventDatetime;

    @Size(max = 255, message = "event.location_too_long")
    String location;

    @Min(value = 2, message = "event.max_participants_invalid")
    @Max(value = 20, message = "event.max_participants_invalid")
    Integer maxParticipants;

}
