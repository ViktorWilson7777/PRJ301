package com.lucy.api.modules.identity.dtos.request.auth;

import jakarta.validation.constraints.NotBlank;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AppleAuthRequest {

    @NotBlank(message = "{validation.auth.apple.identityToken.not_blank}")
    String identityToken;

    @NotBlank(message = "{validation.auth.apple.authorizationCode.not_blank}")
    String authorizationCode;

    String userIdentifier;
    String givenName;
    String familyName;
}
