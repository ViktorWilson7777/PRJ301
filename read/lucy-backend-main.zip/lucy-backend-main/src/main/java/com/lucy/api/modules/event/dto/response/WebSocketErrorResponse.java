package com.lucy.api.modules.event.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Generic error response for WebSocket operations
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WebSocketErrorResponse {
    private String errorCode;
    private String errorMessage;
    private UUID roomId;
    private String timestamp;
}
