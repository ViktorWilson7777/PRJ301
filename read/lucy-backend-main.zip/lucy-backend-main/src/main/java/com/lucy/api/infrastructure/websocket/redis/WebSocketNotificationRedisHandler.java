package com.lucy.api.infrastructure.websocket.redis;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.infrastructure.redis.constants.RedisChannelPrefixes;
import com.lucy.api.infrastructure.redis.pubsub.RedisEventHandler;
import com.lucy.api.infrastructure.websocket.constants.WebSocketRedisInboundLogConstants;
import com.lucy.api.infrastructure.websocket.dto.response.WebSocketNotificationResponse;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketNotificationService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Order(1)
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WebSocketNotificationRedisHandler implements RedisEventHandler {

    ObjectMapper objectMapper;
    WebSocketNotificationService notificationService;

    @Override
    public boolean supports(String channel) {
        return channel != null && channel.startsWith(RedisChannelPrefixes.WS_NOTIFICATION);
    }

    @Override
    public void handle(String channel, String payload) {
        try {
            String userId = channel.substring(RedisChannelPrefixes.WS_NOTIFICATION.length());
            WebSocketNotificationResponse notification =
                    objectMapper.readValue(payload, WebSocketNotificationResponse.class);
            notificationService.broadcastToLocalSessions(userId, notification);
            log.debug("Broadcasted notification to local sessions for user: {}", userId);
        } catch (JsonProcessingException e) {
            log.error(WebSocketRedisInboundLogConstants.PARSE_NOTIFICATION_FAILED, e);
        }
    }
}
