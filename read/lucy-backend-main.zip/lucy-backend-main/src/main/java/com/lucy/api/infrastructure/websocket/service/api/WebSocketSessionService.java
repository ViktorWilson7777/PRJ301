package com.lucy.api.infrastructure.websocket.service.api;

import com.lucy.api.infrastructure.websocket.entity.WebSocketSession;

import java.util.List;
import java.util.Optional;

public interface WebSocketSessionService {

    void createSession(WebSocketSession session);

    Optional<WebSocketSession> getSession(String sessionId);

    void updateSession(String sessionId, WebSocketSession session);

    void removeSession(String sessionId);

    List<String> getUserSessions(String userId);

    List<String> getConversationSessions(String conversationId);

    void addSessionToConversation(String sessionId, String conversationId);

    void removeSessionFromConversation(String sessionId, String conversationId);
}
