package com.lucy.api.modules.story.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "ask_profiles")
public class AskProfileEntity {
    @Id
    @Column(name = "user_id", columnDefinition = "uuid")
    UUID userId;

    @Column(name = "attitude_score")
    Integer attitudeScore;

    @Column(name = "skills_score")
    Integer skillsScore;

    @Column(name = "knowledge_score")
    Integer knowledgeScore;

    String bio;

    @Column(name = "updated_at")
    Instant updatedAt;

    @PrePersist
    void prePersist() {
        this.updatedAt = Instant.now();
    }

    @PreUpdate
    void preUpdate() {
        this.updatedAt = Instant.now();
    }
}
