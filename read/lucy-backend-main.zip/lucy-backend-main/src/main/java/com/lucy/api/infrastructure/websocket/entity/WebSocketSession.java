package com.lucy.api.infrastructure.websocket.entity;

import com.lucy.api.infrastructure.websocket.enums.WebSocketConnectionStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WebSocketSession {
    String sessionId;
    String userId;
    String channelId;
    WebSocketConnectionStatus status;
    String conversationId;
    Instant connectedAt;
    Instant lastActivityAt;
    @Builder.Default
    Set<String> authorities = new HashSet<>();
}
