package com.lucy.api.modules.identity.entity.enums;

public enum ProfileRole {
    LUCY,
    PRO,
    SUPER
}
