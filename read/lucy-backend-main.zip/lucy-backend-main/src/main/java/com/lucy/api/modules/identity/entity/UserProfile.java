package com.lucy.api.modules.identity.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.constants.user.UserConstants;
import com.lucy.api.modules.identity.entity.enums.ProfileRole;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = UserConstants.TABLE_USER_PROFILES)
public class UserProfile extends BaseEntity {

    @Id
    @Column(name = UserConstants.COL_USER_ID, nullable = false, length = 36)
    String id;

    public String getUserId() {
        return id;
    }

    public void setUserId(String userId) {
        setId(userId);
    }

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId
    @JoinColumn(name = UserConstants.COL_USER_ID, nullable = false)
    User user;

    @Column(name = UserConstants.COL_DISPLAY_NAME, nullable = false)
    String displayName;

    @Enumerated(EnumType.STRING)
    @Column(name = "profile_role", nullable = false, length = 20, columnDefinition = "varchar(20) default 'LUCY'")
    ProfileRole profileRole;

    @Column(name = UserConstants.COL_AVATAR_URL)
    String avatarUrl;

    @Column(name = UserConstants.COL_AVATAR_KEY)
    String avatarKey;

    @Column(name = UserConstants.COL_BACKGROUND_URL)
    String backgroundUrl;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = UserConstants.COL_BACKGROUND_METADATA, columnDefinition = UserConstants.JSONB_DEFINITION)
    @Builder.Default
    Map<String, Object> backgroundMetadata = new HashMap<>();

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = UserConstants.COL_PUBLIC_PROFILE_SETTINGS, columnDefinition = UserConstants.JSONB_DEFINITION)
    @Builder.Default
    Map<String, Object> publicProfileSettings = new HashMap<>();

    @Column(name = UserConstants.COL_LEVEL, nullable = false)
    @Builder.Default
    Integer level = 1;

    @Column(name = UserConstants.COL_SPEAKING_MINUTES_TOTAL, nullable = false)
    @Builder.Default
    Integer speakingMinutesTotal = 0;

    @Column(name = UserConstants.COL_SPEAKING_MINUTES_CURRENT, nullable = false)
    @Builder.Default
    Integer speakingMinutesCurrent = 0;

    @Column(name = UserConstants.COL_INTEREST)
    String interest;

    @Column(name = UserConstants.COL_SPECIALTY)
    String specialty;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = UserConstants.COL_INTERESTS, nullable = false, columnDefinition = "jsonb DEFAULT '[]'::jsonb")
    @Builder.Default
    List<String> interests = new ArrayList<>();

    @Column(name = UserConstants.COL_IS_PRO_CERTIFIED, nullable = false)
    @Builder.Default
    boolean isProCertified = false;

    @Column(name = UserConstants.COL_EVOLUTION_STAGE, nullable = false)
    @Builder.Default
    Integer evolutionStage = 1;

}
