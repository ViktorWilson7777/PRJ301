package com.lucy.api.modules.lms.progress.service.api;

import com.lucy.api.modules.lms.progress.dto.request.SubmitQuizAttemptRequest;
import com.lucy.api.modules.lms.progress.dto.request.UpsertLessonProgressRequest;
import com.lucy.api.modules.lms.progress.dto.response.CourseRunProgressSummaryResponse;
import com.lucy.api.modules.lms.progress.dto.response.LessonProgressResponse;
import com.lucy.api.modules.lms.progress.dto.response.QuizAttemptResultResponse;

import java.util.List;

public interface LearningProgressService {

    CourseRunProgressSummaryResponse getMyCourseRunSummary(String userId, String courseRunId);

    List<LessonProgressResponse> getMyLessonProgresses(String userId, String courseRunId);

    LessonProgressResponse upsertMyLessonProgress(String userId, String courseRunId, String lessonId, UpsertLessonProgressRequest request);

    QuizAttemptResultResponse submitMyQuizAttempt(String userId, String courseRunId, String lessonId, SubmitQuizAttemptRequest request);
}

