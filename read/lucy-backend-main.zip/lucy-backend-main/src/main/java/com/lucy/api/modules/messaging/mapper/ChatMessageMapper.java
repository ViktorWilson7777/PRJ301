package com.lucy.api.modules.messaging.mapper;

import com.lucy.api.modules.messaging.dto.response.ChatAttachmentResponse;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;
import com.lucy.api.modules.messaging.entity.ChatAttachment;
import com.lucy.api.modules.messaging.entity.ChatMessage;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ChatMessageMapper {

    @Mapping(target = "conversationId", source = "conversation.id")
    @Mapping(target = "senderId", source = "sender.id")
    @Mapping(target = "senderUsername", source = "sender.profile.displayName")
    @Mapping(target = "senderInfo", ignore = true)
    @Mapping(target = "isEcho", ignore = true)
    @Mapping(target = "attachments", ignore = true)
    ChatMessageResponse toResponse(ChatMessage message);

    ChatAttachmentResponse toAttachment(ChatAttachment attachment);

    List<ChatAttachmentResponse> toAttachmentList(List<ChatAttachment> attachments);
}
