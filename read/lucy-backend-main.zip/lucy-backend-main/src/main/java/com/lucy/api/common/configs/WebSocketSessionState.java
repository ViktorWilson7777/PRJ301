package com.lucy.api.common.configs;

import java.security.Principal;
import java.util.Set;
import java.util.UUID;

public record WebSocketSessionState(Principal principal, Set<UUID> roomIds) {
}
