package com.lucy.api.common.dtos.request;

import com.lucy.api.common.constants.PaginationConstant;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PagingRequest {
    @Builder.Default
    @Min(value = PaginationConstant.MIN_PAGE_NUMBER, message = "common.page_invalid")
    int page = PaginationConstant.MIN_PAGE_NUMBER;

    @Builder.Default
    @Min(value = PaginationConstant.MIN_PAGE_SIZE, message = "common.page_size_invalid")
    int pageSize = PaginationConstant.DEFAULT_PAGE_SIZE;

    @Valid
    SortRequest sortRequest;
}
