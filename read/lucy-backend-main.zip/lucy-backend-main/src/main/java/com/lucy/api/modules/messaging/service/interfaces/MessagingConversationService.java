package com.lucy.api.modules.messaging.service.interfaces;

import com.lucy.api.modules.messaging.dto.response.ConversationParticipantResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationListItemResponse;

import java.util.List;

public interface MessagingConversationService {

    ConversationResponse getGroupConversationForEnrolledUser(String courseRunId, String currentUserId);
    ConversationResponse getGroupConversationForRoomParticipant(String roomId, String currentUserId);

    List<ConversationParticipantResponse> listParticipants(String conversationId, String currentUserId);

    List<ConversationListItemResponse> listMyConversations(String currentUserId);

    ConversationResponse getOrCreateDirectConversation(String currentUserId, String peerUserId);

    ConversationResponse createAdhocGroupConversation(String currentUserId, String groupName, List<String> memberUserIds);

    void inviteMembers(String conversationId, String inviterUserId, List<String> memberUserIds);

    ConversationResponse renameGroupConversation(String conversationId, String ownerUserId, String groupName);

    String getMyParticipantStatus(String conversationId, String currentUserId);

    void acceptInvite(String conversationId, String currentUserId);

    void rejectInvite(String conversationId, String currentUserId);
}
