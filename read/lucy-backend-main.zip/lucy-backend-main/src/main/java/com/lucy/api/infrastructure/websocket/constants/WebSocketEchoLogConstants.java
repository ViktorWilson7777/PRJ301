package com.lucy.api.infrastructure.websocket.constants;

public final class WebSocketEchoLogConstants {

    private WebSocketEchoLogConstants() {
    }

    public static final String ECHO_FAILED = "Echo command failed";
}
