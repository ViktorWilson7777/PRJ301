package com.lucy.api.modules.lms.service.api;

import com.lucy.api.modules.lms.dto.request.ProgramUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ProgramResponse;
import com.lucy.api.modules.lms.entity.Program;

import java.util.List;

public interface ProgramService {
    ProgramResponse create(ProgramUpsertRequest request);

    ProgramResponse createPublic(ProgramUpsertRequest request);

    ProgramResponse createForOrganization(String organizationId, ProgramUpsertRequest request);

    List<ProgramResponse> findAll();

    List<ProgramResponse> findAllPublic();

    List<ProgramResponse> findAllByOrganization(String organizationId);

    ProgramResponse findById(String programId);

    ProgramResponse findPublicById(String programId);

    ProgramResponse findByOrganizationAndId(String organizationId, String programId);

    ProgramResponse update(String programId, ProgramUpsertRequest request);

    ProgramResponse updatePublic(String programId, ProgramUpsertRequest request);

    ProgramResponse updateForOrganization(String organizationId, String programId, ProgramUpsertRequest request);

    void delete(String programId);

    void deletePublic(String programId);

    void deleteForOrganization(String organizationId, String programId);

    Program getEntityById(String programId);
}
