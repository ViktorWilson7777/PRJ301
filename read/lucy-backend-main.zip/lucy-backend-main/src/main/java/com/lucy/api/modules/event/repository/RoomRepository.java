package com.lucy.api.modules.event.repository;

import com.lucy.api.modules.event.entity.RoomEntity;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RoomRepository extends JpaRepository<RoomEntity, UUID> {
    @Query("""
            select r.id as id, r.title as title, r.description as description, r.topic as topic, r.category as category,
                   r.level as level, r.status as status, r.eventDatetime as eventDatetime,
                   r.location as location, r.maxParticipants as maxParticipants, r.interestedCount as interestedCount,
                   r.likesCount as likesCount, r.commentsCount as commentsCount, r.monitorId as monitorId
            from RoomEntity r
            where r.roomType = 'event'
              and (cast(:status as text) is null or r.status = :status)
              and (cast(:monitorId as uuid) is null or r.monitorId = :monitorId)
              and (cast(:interestedUserId as uuid) is null or exists (
                    select 1
                    from RoomInterestEntity ri
                    where ri.roomId = r.id and ri.userId = :interestedUserId
              ))
              and (cast(:fromTs as timestamp) is null or r.eventDatetime >= :fromTs)
              and (cast(:toTs as timestamp) is null or r.eventDatetime <= :toTs)
              and (cast(:keyword as text) is null or (
                    lower(r.title) like concat('%', cast(:keyword as text), '%')
                    or lower(r.topic) like concat('%', cast(:keyword as text), '%')
                    or lower(r.description) like concat('%', cast(:keyword as text), '%')
              ))
              and ((cast(:cursorDatetime as timestamp) is null and cast(:cursorId as uuid) is null)
                or (r.eventDatetime < :cursorDatetime)
                or (r.eventDatetime = :cursorDatetime and r.id < :cursorId))
            order by r.eventDatetime desc, r.id desc
            """)
    List<EventFeedProjection> findEventFeed(
            @Param("status") String status,
            @Param("monitorId") UUID monitorId,
            @Param("interestedUserId") UUID interestedUserId,
            @Param("fromTs") Instant fromTs,
            @Param("toTs") Instant toTs,
            @Param("keyword") String keyword,
            @Param("cursorDatetime") Instant cursorDatetime,
            @Param("cursorId") UUID cursorId,
            Pageable pageable
    );

    @Query("select r from RoomEntity r where r.id = :id and r.roomType = 'event'")
    Optional<RoomEntity> findEventById(@Param("id") UUID id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from RoomEntity r where r.id = :id and r.roomType = 'event'")
    Optional<RoomEntity> findEventByIdForUpdate(@Param("id") UUID id);

    @Modifying
    @Query("update RoomEntity r set r.interestedCount = r.interestedCount + :delta where r.id = :roomId")
    int incrementInterestedCount(@Param("roomId") UUID roomId, @Param("delta") int delta);

    @Modifying
    @Query("update RoomEntity r set r.commentsCount = r.commentsCount + :delta where r.id = :roomId")
    int incrementCommentsCount(@Param("roomId") UUID roomId, @Param("delta") int delta);

    @Modifying
    @Query("update RoomEntity r set r.likesCount = r.likesCount + :delta where r.id = :roomId")
    int incrementLikesCount(@Param("roomId") UUID roomId, @Param("delta") int delta);

    long countEventsByMonitorIdAndRoomType(UUID monitorId, String roomType);

    default long countEventsByMonitorId(UUID monitorId) {
        return countEventsByMonitorIdAndRoomType(monitorId, "event");
    }

    @Query("""
            select r.id
            from RoomEntity r
            where r.roomType = 'event'
              and r.monitorId in :monitorIds
            """)
    List<UUID> findIdsByMonitorIdIn(@Param("monitorIds") List<UUID> monitorIds);
}
