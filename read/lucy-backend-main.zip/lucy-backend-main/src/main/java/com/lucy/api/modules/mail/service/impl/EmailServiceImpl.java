package com.lucy.api.modules.mail.service.impl;

import com.lucy.api.modules.identity.constants.auth.OtpConstants;
import com.lucy.api.modules.mail.MailProperties;
import com.lucy.api.modules.mail.service.interfaces.EmailService;
import com.lucy.api.modules.mail.template.MailTemplates;
import com.lucy.api.modules.mail.utils.MailTemplateUtils;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender mailSender;
    private final MailProperties mailProperties;

    @Async
    @Override
    public void sendOtpEmail(String toEmail, String otp) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            if (mailProperties.getFrom() != null && !mailProperties.getFrom().isBlank()) {
                helper.setFrom(mailProperties.getFrom());
            }
            helper.setTo(toEmail);
            helper.setSubject(MailTemplates.OTP_RESET_PASSWORD_SUBJECT);

            Map<String, String> variables = Map.of(
                    "otp", otp,
                    "expireMinutes", String.valueOf(OtpConstants.OTP_TTL.toMinutes())
            );
            String htmlContent = MailTemplateUtils.buildEmailFromTemplate(MailTemplates.OTP_RESET_PASSWORD, variables);

            helper.setText(htmlContent, true);

            mailSender.send(mimeMessage);
            log.info("OTP email sent successfully to {}", toEmail);
        } catch (Exception e) {
            log.error("Failed to send OTP email to {}: {}", toEmail, e.getMessage(), e);
        }
    }

    @Async
    @Override
    public void sendRegistrationOtpEmail(String toEmail, String otp) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            if (mailProperties.getFrom() != null && !mailProperties.getFrom().isBlank()) {
                helper.setFrom(mailProperties.getFrom());
            }
            helper.setTo(toEmail);
            helper.setSubject(MailTemplates.OTP_VERIFY_EMAIL_SUBJECT);

            Map<String, String> variables = Map.of(
                    "otp", otp,
                    "expireMinutes", String.valueOf(OtpConstants.OTP_TTL.toMinutes())
            );
            String htmlContent = MailTemplateUtils.buildEmailFromTemplate(MailTemplates.OTP_VERIFY_EMAIL, variables);

            helper.setText(htmlContent, true);

            mailSender.send(mimeMessage);
            log.info("Registration OTP email sent successfully to {}", toEmail);
        } catch (Exception e) {
            log.error("Failed to send registration OTP email to {}: {}", toEmail, e.getMessage(), e);
        }
    }
}
