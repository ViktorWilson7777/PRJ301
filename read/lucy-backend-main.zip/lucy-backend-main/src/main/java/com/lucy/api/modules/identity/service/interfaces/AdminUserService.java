package com.lucy.api.modules.identity.service.interfaces;

import com.lucy.api.modules.identity.dtos.request.admin.AdminBanUserRequest;
import com.lucy.api.modules.identity.dtos.request.admin.AdminUpdateUserRolesRequest;
import com.lucy.api.modules.identity.dtos.request.admin.AdminUpdateUserStatusRequest;
import com.lucy.api.modules.identity.dtos.response.user.UserResponse;

public interface AdminUserService {
    UserResponse updateStatus(String userId, AdminUpdateUserStatusRequest request);

    UserResponse ban(String userId, AdminBanUserRequest request);

    UserResponse updateRoles(String userId, AdminUpdateUserRolesRequest request);
}

