package com.lucy.api.modules.identity.dtos.request.admin;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AdminUpdateUserRolesRequest {
    private List<String> roles;
}

