package com.lucy.api.common.configs;

import com.lucy.api.modules.event.service.SocialFeedTickerChannels;
import com.lucy.api.modules.event.service.SocialFeedTickerSubscriber;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class RedisPubSubConfig {
    @Bean
    public ChannelTopic socialFeedTickerTopic() {
        return new ChannelTopic(SocialFeedTickerChannels.REDIS_CHANNEL);
    }

    @Bean
    public MessageListenerAdapter socialFeedTickerListenerAdapter(SocialFeedTickerSubscriber subscriber) {
        MessageListenerAdapter adapter = new MessageListenerAdapter(subscriber, "onMessage");
        adapter.setSerializer(StringRedisSerializer.UTF_8);
        return adapter;
    }

    @Bean
    public InitializingBean redisPubSubListenerRegistrar(
            RedisMessageListenerContainer redisMessageListenerContainer,
            MessageListenerAdapter socialFeedTickerListenerAdapter,
            ChannelTopic socialFeedTickerTopic) {
        return () -> {
            redisMessageListenerContainer.addMessageListener(socialFeedTickerListenerAdapter, socialFeedTickerTopic);
        };
    }
}
