package com.lucy.api.modules.r2.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.cloudinary.dto.StoredFileInfo;
import com.lucy.api.modules.cloudinary.service.api.FileStorageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedPutObjectRequest;
import software.amazon.awssdk.services.s3.presigner.model.PutObjectPresignRequest;

import java.time.Duration;
import java.util.UUID;

@Service("r2FileStorageServiceImpl")
@RequiredArgsConstructor
@Slf4j
public class R2FileStorageServiceImpl implements FileStorageService {

    private final S3Client s3Client;
    private final S3Presigner s3Presigner;

    @Value("${r2.bucket-name:local-bucket}")
    private String bucketName;

    @Value("${r2.public-url:}")
    private String publicUrl;

    @Override
    public StoredFileInfo upload(MultipartFile file, String folder) {
        try {
            String originalFilename = extractOriginalFilename(file);
            String extension = extractExtension(originalFilename);
            String fileName = UUID.randomUUID() + extension;
            String key = (folder != null && !folder.isBlank()) ? folder + "/" + fileName : fileName;

            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .contentType(file.getContentType())
                    .build();

            s3Client.putObject(putObjectRequest, RequestBody.fromBytes(file.getBytes()));

            // Determine the final URL to return (prefer permanent public URL if configured)
            String finalUrl = getFileUrl(key);

            return StoredFileInfo.builder()
                    .provider("r2")
                    .fileName(fileName)
                    .mimeType(file.getContentType())
                    .size(file.getSize())
                    .url(finalUrl)
                    .publicId(key)
                    .resourceType(file.getContentType().startsWith("image") ? "image" : "raw")
                    .build();
        } catch (Exception exception) {
            log.error("Failed to upload file to R2: {}", exception.getMessage(), exception);
            throw new AppException("storage.upload_failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public String getPresignedUploadUrl(String key, String contentType) {
        try {
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .contentType(contentType)
                    .build();

            PutObjectPresignRequest putObjectPresignRequest = PutObjectPresignRequest.builder()
                    .signatureDuration(Duration.ofMinutes(15))
                    .putObjectRequest(putObjectRequest)
                    .build();

            PresignedPutObjectRequest presignedPutObjectRequest = s3Presigner.presignPutObject(putObjectPresignRequest);
            return presignedPutObjectRequest.url().toString();
        } catch (Exception exception) {
            log.error("Failed to generate presigned upload URL: {}", exception.getMessage());
            throw new AppException("storage.presign_failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public String getPresignedDownloadUrl(String key) {
        try {
            GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .build();

            GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder()
                    .signatureDuration(Duration.ofDays(7))
                    .getObjectRequest(getObjectRequest)
                    .build();

            PresignedGetObjectRequest presignedGetObjectRequest = s3Presigner.presignGetObject(getObjectPresignRequest);
            return presignedGetObjectRequest.url().toString();
        } catch (Exception exception) {
            log.error("Failed to generate presigned download URL: {}", exception.getMessage());
            throw new AppException("storage.presign_failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public void delete(String key) {
        try {
            DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .build();
            s3Client.deleteObject(deleteObjectRequest);
        } catch (Exception exception) {
            log.error("Failed to delete file from R2: {}", exception.getMessage());
            throw new AppException("storage.delete_failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public String getFileUrl(String key) {
        if (publicUrl != null && !publicUrl.isBlank()) {
            return publicUrl.endsWith("/") ? publicUrl + key : publicUrl + "/" + key;
        }
        return getPresignedDownloadUrl(key);
    }

    private String extractOriginalFilename(MultipartFile file) {
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.isBlank()) {
            return "uploaded-file";
        }
        return originalFilename;
    }

    private String extractExtension(String filename) {
        int lastDotIndex = filename.lastIndexOf('.');
        return lastDotIndex >= 0 ? filename.substring(lastDotIndex) : "";
    }
}
