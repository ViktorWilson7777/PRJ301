package com.lucy.api.modules.organization.entity.enums;

public enum OrganizationMembershipRole {
    OWNER,
    ADMIN,
    INSTRUCTOR,
    LEARNER
}
