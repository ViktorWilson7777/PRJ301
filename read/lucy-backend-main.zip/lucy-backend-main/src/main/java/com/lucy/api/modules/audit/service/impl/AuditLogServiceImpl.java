package com.lucy.api.modules.audit.service.impl;

import com.lucy.api.modules.audit.constants.AuditLogConstants;
import com.lucy.api.modules.audit.dto.request.AuditLogMessage;
import com.lucy.api.modules.audit.dto.request.AuditLogSearchRequest;
import com.lucy.api.modules.audit.dto.response.AuditLogResponse;
import com.lucy.api.modules.audit.entity.AuditLog;
import com.lucy.api.modules.audit.repository.AuditLogRepository;
import com.lucy.api.modules.audit.service.api.AuditLogService;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class AuditLogServiceImpl implements AuditLogService {

    AuditLogRepository auditLogRepository;
    com.lucy.api.modules.identity.repository.UserRepository userRepository;

    @Override
    @Async("auditLogExecutor")
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(AuditLogMessage message) {
        try {
            String finalActorDisplay = message.getActorDisplay();
            if (finalActorDisplay == null && message.getActorUserId() != null) {
                finalActorDisplay = userRepository.findById(message.getActorUserId().toString())
                        .map(u -> (u.getProfile() != null ? u.getProfile().getDisplayName() : "Unknown") + " (" + u.getEmail() + ")")
                        .orElse(null);
            }

            AuditLog entry = AuditLog.builder()
                    .actorUserId(message.getActorUserId())
                    .actorType(message.getActorType())
                    .actorDisplay(finalActorDisplay)
                    .action(message.getAction())
                    .entityType(message.getEntityType())
                    .entityId(message.getEntityId())
                    .requestId(message.getRequestId())
                    .ipAddress(message.getIpAddress())
                    .userAgent(message.getUserAgent())
                    .metadata(message.getMetadata() != null ? message.getMetadata() : Map.of())
                    .build();

            auditLogRepository.saveAndFlush(entry);

        } catch (Exception ex) {
            log.error("[AuditLog] Failed to persist entry — action='{}' actorUserId='{}': {}",
                    message.getAction(), message.getActorUserId(), ex.getMessage(), ex);
        }
    }

    @Override
    public Page<AuditLogResponse> getAuditLogs(AuditLogSearchRequest searchRequest) {
        PageRequest pageRequest = PageRequest.of(
                searchRequest.getPage() - 1,
                searchRequest.getSize(),
                Sort.by(Sort.Direction.DESC, AuditLogConstants.FIELD_CREATED_AT)
        );

        Specification<AuditLog> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (searchRequest.getAction() != null && !searchRequest.getAction().isBlank()) {
                predicates.add(cb.equal(root.get(AuditLogConstants.FIELD_ACTION), searchRequest.getAction()));
            }
            if (searchRequest.getEntityType() != null && !searchRequest.getEntityType().isBlank()) {
                predicates.add(cb.equal(root.get(AuditLogConstants.FIELD_ENTITY_TYPE), searchRequest.getEntityType()));
            }
            if (searchRequest.getActorUserId() != null && !searchRequest.getActorUserId().isBlank()) {
                try {
                    predicates.add(cb.equal(root.get(AuditLogConstants.FIELD_ACTOR_USER_ID), UUID.fromString(searchRequest.getActorUserId())));
                } catch (IllegalArgumentException ignored) {
                }
            }
            return cb.and(predicates.toArray(new Predicate[0]));
        };

        return auditLogRepository.findAll(spec, pageRequest).map(this::mapToResponse);
    }

    private AuditLogResponse mapToResponse(AuditLog entry) {
        return AuditLogResponse.builder()
                .id(entry.getId())
                .actorUserId(entry.getActorUserId())
                .actorType(entry.getActorType())
                .actorDisplay(entry.getActorDisplay())
                .action(entry.getAction())
                .entityType(entry.getEntityType())
                .entityId(entry.getEntityId())
                .requestId(entry.getRequestId())
                .ipAddress(entry.getIpAddress())
                .userAgent(entry.getUserAgent())
                .metadata(entry.getMetadata())
                .createdAt(entry.getCreatedAt())
                .build();
    }
}
