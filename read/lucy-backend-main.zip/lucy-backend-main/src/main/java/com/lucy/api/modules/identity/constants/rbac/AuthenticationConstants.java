package com.lucy.api.modules.identity.constants.rbac;

public class AuthenticationConstants {
    private AuthenticationConstants() {
    };

    public static final String JWT_GENERATION_FAIL = "jwt.generation_fail";

    // Providers
    public static final String PROVIDER_LOCAL = "local";
    public static final String PROVIDER_GOOGLE = "google";
    public static final String PROVIDER_APPLE = "apple";

    public static final String NOTIFICATION_SENDER_SYSTEM = "SYSTEM";
}
