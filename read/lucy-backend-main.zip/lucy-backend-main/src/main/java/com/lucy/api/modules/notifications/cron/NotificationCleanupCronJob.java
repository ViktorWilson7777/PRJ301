package com.lucy.api.modules.notifications.cron;

import com.lucy.api.modules.notifications.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Slf4j
@Component
@RequiredArgsConstructor
public class NotificationCleanupCronJob {

    private final NotificationRepository notificationRepository;

    /**
     * Daily cleanup for old in-app notifications.
     * Keeps the table bounded and avoids unbounded growth.
     */
    @Scheduled(cron = "0 0 3 * * *")
    @Transactional
    public void cleanupOldNotifications() {
        Instant cutoff = Instant.now().minus(30, ChronoUnit.DAYS);
        int deleted = notificationRepository.deleteAllCreatedBefore(cutoff);
        if (deleted > 0) {
            log.info("[NotificationCleanup] Deleted {} notification(s) created before {}", deleted, cutoff);
        }
    }
}

