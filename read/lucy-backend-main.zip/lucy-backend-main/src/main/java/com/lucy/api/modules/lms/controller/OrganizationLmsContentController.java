package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.lms.dto.request.ChapterUpsertRequest;
import com.lucy.api.modules.lms.dto.request.LessonFileUploadRequest;
import com.lucy.api.modules.lms.dto.request.LessonUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.dto.response.LessonFileUploadResponse;
import com.lucy.api.modules.lms.dto.response.LessonResponse;
import com.lucy.api.modules.lms.entity.Chapter;
import com.lucy.api.modules.lms.entity.Lesson;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.lms.service.api.ChapterService;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import com.lucy.api.modules.lms.service.api.LessonService;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole;
import com.lucy.api.modules.organization.service.OrganizationAccessService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/organizations/{organizationId}")
public class OrganizationLmsContentController {
    private final ChapterService chapterService;
    private final LessonService lessonService;
    private final CourseRunService courseRunService;
    private final OrganizationAccessService organizationAccessService;

    @PostMapping("/chapters")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ChapterResponse>> createChapter(@PathVariable String organizationId, @Valid @RequestBody ChapterUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN, OrganizationMembershipRole.INSTRUCTOR);
        courseRunService.findByOrganizationAndId(organizationId, request.getCourseRunId());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.create(request)).build());
    }

    @GetMapping("/chapters")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<ChapterResponse>>> getChapters(@PathVariable String organizationId, @RequestParam String courseRunId) {
        courseRunService.findByOrganizationAndId(organizationId, courseRunId);
        return ResponseEntity.ok(ApiResponse.<List<ChapterResponse>>builder().success(true).data(chapterService.findAll(courseRunId)).build());
    }

    @GetMapping("/chapters/{chapterId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ChapterResponse>> getChapter(@PathVariable String organizationId, @PathVariable String chapterId) {
        Chapter chapter = chapterService.getEntityById(chapterId);
        assertOrganizationChapter(organizationId, chapter);
        return ResponseEntity.ok(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.findById(chapterId)).build());
    }

    @PutMapping("/chapters/{chapterId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ChapterResponse>> updateChapter(@PathVariable String organizationId, @PathVariable String chapterId, @Valid @RequestBody ChapterUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN, OrganizationMembershipRole.INSTRUCTOR);
        assertOrganizationChapter(organizationId, chapterService.getEntityById(chapterId));
        courseRunService.findByOrganizationAndId(organizationId, request.getCourseRunId());
        return ResponseEntity.ok(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.update(chapterId, request)).build());
    }

    @DeleteMapping("/chapters/{chapterId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteChapter(@PathVariable String organizationId, @PathVariable String chapterId) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN, OrganizationMembershipRole.INSTRUCTOR);
        assertOrganizationChapter(organizationId, chapterService.getEntityById(chapterId));
        chapterService.delete(chapterId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Organization chapter deleted successfully").build());
    }

    @PostMapping("/lessons")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LessonResponse>> createLesson(@PathVariable String organizationId, @Valid @RequestBody LessonUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN, OrganizationMembershipRole.INSTRUCTOR);
        assertOrganizationChapter(organizationId, chapterService.getEntityById(request.getChapterId()));
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.create(request)).build());
    }

    @GetMapping("/lessons")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<LessonResponse>>> getLessons(@PathVariable String organizationId, @RequestParam String chapterId) {
        assertOrganizationChapter(organizationId, chapterService.getEntityById(chapterId));
        return ResponseEntity.ok(ApiResponse.<List<LessonResponse>>builder().success(true).data(lessonService.findAll(chapterId)).build());
    }

    @GetMapping("/lessons/{lessonId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LessonResponse>> getLesson(@PathVariable String organizationId, @PathVariable String lessonId) {
        Lesson lesson = lessonService.getEntityById(lessonId);
        assertOrganizationLesson(organizationId, lesson);
        return ResponseEntity.ok(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.findById(lessonId)).build());
    }

    @PutMapping("/lessons/{lessonId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LessonResponse>> updateLesson(@PathVariable String organizationId, @PathVariable String lessonId, @Valid @RequestBody LessonUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN, OrganizationMembershipRole.INSTRUCTOR);
        assertOrganizationLesson(organizationId, lessonService.getEntityById(lessonId));
        assertOrganizationChapter(organizationId, chapterService.getEntityById(request.getChapterId()));
        return ResponseEntity.ok(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.update(lessonId, request)).build());
    }

    @DeleteMapping("/lessons/{lessonId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteLesson(@PathVariable String organizationId, @PathVariable String lessonId) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN, OrganizationMembershipRole.INSTRUCTOR);
        assertOrganizationLesson(organizationId, lessonService.getEntityById(lessonId));
        lessonService.delete(lessonId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Organization lesson deleted successfully").build());
    }

    @PostMapping("/lessons/{lessonId}/files")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LessonFileUploadResponse>> uploadLessonFile(
            @PathVariable String organizationId,
            @PathVariable String lessonId,
            @Valid @ModelAttribute LessonFileUploadRequest request) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN, OrganizationMembershipRole.INSTRUCTOR);
        assertOrganizationLesson(organizationId, lessonService.getEntityById(lessonId));
        return ResponseEntity.ok(ApiResponse.<LessonFileUploadResponse>builder().success(true).data(lessonService.attachFileToLesson(lessonId, request.getFile())).build());
    }

    private void assertOrganizationChapter(String organizationId, Chapter chapter) {
        if (chapter.getCourseRun().getAccessScope() != LmsAccessScope.ORGANIZATION
                || chapter.getCourseRun().getOrganization() == null
                || !organizationId.equals(chapter.getCourseRun().getOrganization().getId())) {
            throw new AppException("lms.organization_chapter_not_found", HttpStatus.NOT_FOUND);
        }
    }

    private void assertOrganizationLesson(String organizationId, Lesson lesson) {
        assertOrganizationChapter(organizationId, lesson.getChapter());
    }
}
