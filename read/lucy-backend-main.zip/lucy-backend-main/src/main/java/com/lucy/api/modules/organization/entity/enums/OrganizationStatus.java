package com.lucy.api.modules.organization.entity.enums;

public enum OrganizationStatus {
    ACTIVE,
    INACTIVE
}
