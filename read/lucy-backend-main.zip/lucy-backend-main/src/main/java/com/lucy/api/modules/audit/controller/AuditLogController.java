package com.lucy.api.modules.audit.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.audit.dto.response.AuditLogResponse;
import com.lucy.api.modules.audit.service.api.AuditLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.lucy.api.modules.audit.dto.request.AuditLogSearchRequest;
import org.springdoc.core.annotations.ParameterObject;

@RestController
@RequestMapping("/api/v1/audit-logs")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Tag(name = "Audit Logs", description = "Admin API for viewing and searching system audit logs")
public class AuditLogController {

    AuditLogService auditLogService;

    @GetMapping
    @Operation(summary = "Get paginated audit logs (Admin only)")
    // @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Page<AuditLogResponse>>> getAuditLogs(
            @ParameterObject AuditLogSearchRequest searchRequest) {

        Page<AuditLogResponse> logsPage = auditLogService.getAuditLogs(searchRequest);
        return ResponseEntity.ok(ApiResponse.<Page<AuditLogResponse>>builder()
                .success(true)
                .data(logsPage)
                .build());
    }
}
