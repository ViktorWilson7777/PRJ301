package com.lucy.api.modules.event.service;

import com.lucy.api.modules.event.exception.EventApiException;
import org.springframework.http.HttpStatus;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.UUID;

public final class CommentCursorUtil {
    private CommentCursorUtil() {
    }

    public record CursorData(Instant createdAt, UUID id) {
    }

    public static String encode(Instant createdAt, UUID id) {
        String payload = createdAt.toEpochMilli() + "|" + id;
        return Base64.getUrlEncoder().withoutPadding().encodeToString(payload.getBytes(StandardCharsets.UTF_8));
    }

    public static CursorData decode(String cursor) {
        try {
            String payload = new String(Base64.getUrlDecoder().decode(cursor), StandardCharsets.UTF_8);
            String[] parts = payload.split("\\|");
            if (parts.length != 2) {
                throw new IllegalArgumentException("Invalid cursor");
            }
            return new CursorData(Instant.ofEpochMilli(Long.parseLong(parts[0])), UUID.fromString(parts[1]));
        } catch (Exception e) {
            throw new EventApiException("BAD_REQUEST", "Invalid cursor", HttpStatus.BAD_REQUEST);
        }
    }
}
