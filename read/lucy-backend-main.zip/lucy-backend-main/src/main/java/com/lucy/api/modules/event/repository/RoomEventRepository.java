package com.lucy.api.modules.event.repository;

import com.lucy.api.modules.event.entity.RoomEventEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface RoomEventRepository extends JpaRepository<RoomEventEntity, UUID> {
    long countByRoomIdAndType(UUID roomId, String type);
    void deleteAllByUserIdIn(List<UUID> userIds);
    void deleteAllByRoomIdIn(List<UUID> roomIds);
}
