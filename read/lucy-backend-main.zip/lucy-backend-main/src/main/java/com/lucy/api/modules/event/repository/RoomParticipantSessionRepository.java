package com.lucy.api.modules.event.repository;

import com.lucy.api.modules.event.entity.RoomParticipantSessionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RoomParticipantSessionRepository extends JpaRepository<RoomParticipantSessionEntity, UUID> {
    Optional<RoomParticipantSessionEntity> findByRoomIdAndUserIdAndLeftAtIsNull(UUID roomId, UUID userId);
    List<RoomParticipantSessionEntity> findByRoomIdAndLeftAtIsNull(UUID roomId);
    void deleteAllByUserIdIn(List<UUID> userIds);
    void deleteAllByRoomIdIn(List<UUID> roomIds);
}
