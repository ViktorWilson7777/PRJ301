package com.lucy.api.modules.messaging.event;

public record EnrollmentRemovedEvent(String userId, String courseRunId) {
}
