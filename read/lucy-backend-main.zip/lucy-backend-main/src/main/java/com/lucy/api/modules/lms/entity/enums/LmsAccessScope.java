package com.lucy.api.modules.lms.entity.enums;

public enum LmsAccessScope {
    PUBLIC,
    ORGANIZATION
}
