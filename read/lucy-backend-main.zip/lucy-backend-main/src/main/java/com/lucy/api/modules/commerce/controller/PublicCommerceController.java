package com.lucy.api.modules.commerce.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.commerce.dto.request.ConfirmPublicOrderPaymentRequest;
import com.lucy.api.modules.commerce.dto.request.CreatePublicOrderRequest;
import com.lucy.api.modules.commerce.dto.response.LearningEntitlementResponse;
import com.lucy.api.modules.commerce.dto.response.PublicOrderResponse;
import com.lucy.api.modules.commerce.dto.response.PublicPurchaseOfferResponse;
import com.lucy.api.modules.commerce.service.PublicCommerceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/public")
public class PublicCommerceController {
    private final PublicCommerceService publicCommerceService;

    @GetMapping("/course-runs/{courseRunId}/purchase-offer")
    public ResponseEntity<ApiResponse<PublicPurchaseOfferResponse>> getPurchaseOffer(@PathVariable String courseRunId) {
        return ResponseEntity.ok(ApiResponse.<PublicPurchaseOfferResponse>builder().success(true).data(publicCommerceService.getPurchaseOffer(courseRunId)).build());
    }

    @PostMapping("/orders")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<PublicOrderResponse>> createOrder(@Valid @RequestBody CreatePublicOrderRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<PublicOrderResponse>builder().success(true).data(publicCommerceService.createOrder(request)).build());
    }

    @GetMapping("/orders/me")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<PublicOrderResponse>>> getMyOrders() {
        return ResponseEntity.ok(ApiResponse.<List<PublicOrderResponse>>builder().success(true).data(publicCommerceService.getMyOrders()).build());
    }

    @GetMapping("/orders/{orderId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<PublicOrderResponse>> getOrder(@PathVariable String orderId) {
        return ResponseEntity.ok(ApiResponse.<PublicOrderResponse>builder().success(true).data(publicCommerceService.getMyOrder(orderId)).build());
    }

    @PostMapping("/orders/{orderId}/confirm-payment")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<PublicOrderResponse>> confirmPayment(
            @PathVariable String orderId,
            @Valid @RequestBody ConfirmPublicOrderPaymentRequest request) {
        return ResponseEntity.ok(ApiResponse.<PublicOrderResponse>builder().success(true).data(publicCommerceService.confirmPayment(orderId, request)).build());
    }

    @GetMapping("/entitlements/me")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<LearningEntitlementResponse>>> getMyEntitlements() {
        return ResponseEntity.ok(ApiResponse.<List<LearningEntitlementResponse>>builder().success(true).data(publicCommerceService.getMyEntitlements()).build());
    }
}
