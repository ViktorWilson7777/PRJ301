package com.lucy.api.modules.lms.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.lms.dto.request.CourseUpsertRequest;
import com.lucy.api.modules.lms.dto.response.CourseResponse;
import com.lucy.api.modules.lms.entity.Course;
import com.lucy.api.modules.lms.entity.Program;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.lms.mapper.CourseMapper;
import com.lucy.api.modules.lms.repository.CourseRepository;
import com.lucy.api.modules.lms.service.PublicCreatorAccessService;
import com.lucy.api.modules.lms.service.api.CourseService;
import com.lucy.api.modules.lms.service.api.ProgramService;
import com.lucy.api.modules.organization.service.OrganizationAccessService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {
    private final CourseRepository courseRepository;
    private final CourseMapper courseMapper;
    private final ProgramService programService;
    private final OrganizationAccessService organizationAccessService;
    private final PublicCreatorAccessService publicCreatorAccessService;

    @Override
    @Transactional
    public CourseResponse create(CourseUpsertRequest request) {
        return createPublic(request);
    }

    @Override
    @Transactional
    public CourseResponse createPublic(CourseUpsertRequest request) {
        Program program = programService.getEntityById(request.getProgramId());
        assertPublicProgram(program);
        publicCreatorAccessService.assertCanManagePublicProgram(program);
        validateCode(request.getCode(), null, LmsAccessScope.PUBLIC, null);
        Course course = courseMapper.toEntity(request);
        course.setProgram(program);
        course.setAccessScope(LmsAccessScope.PUBLIC);
        course.setOrganization(null);
        return courseMapper.toResponse(courseRepository.save(course));
    }

    @Override
    @Transactional
    public CourseResponse createForOrganization(String organizationId, CourseUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        Program program = programService.getEntityById(request.getProgramId());
        assertOrganizationProgram(program, organizationId);
        validateCode(request.getCode(), null, LmsAccessScope.ORGANIZATION, organizationId);
        Course course = courseMapper.toEntity(request);
        course.setProgram(program);
        course.setAccessScope(LmsAccessScope.ORGANIZATION);
        course.setOrganization(program.getOrganization());
        return courseMapper.toResponse(courseRepository.save(course));
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> findAll(String programId) {
        return findAllPublic(programId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> findAllPublic(String programId) {
        if (programId != null) {
            Program program = programService.getEntityById(programId);
            assertPublicProgram(program);
            return courseRepository.findAllByProgram_IdAndDeletedAtIsNullOrderByOrderIndexAscCreatedAtAsc(programId).stream()
                    .filter(course -> course.getAccessScope() == LmsAccessScope.PUBLIC)
                    .map(courseMapper::toResponse)
                    .toList();
        }
        return courseRepository.findAllByAccessScopeAndDeletedAtIsNullOrderByCreatedAtDesc(LmsAccessScope.PUBLIC).stream()
                .map(courseMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> findAllByOrganization(String organizationId, String programId) {
        organizationAccessService.assertActiveMembership(organizationId);
        if (programId != null) {
            Program program = programService.getEntityById(programId);
            assertOrganizationProgram(program, organizationId);
            return courseRepository.findAllByProgram_IdAndDeletedAtIsNullOrderByOrderIndexAscCreatedAtAsc(programId).stream()
                    .filter(course -> course.getAccessScope() == LmsAccessScope.ORGANIZATION)
                    .map(courseMapper::toResponse)
                    .toList();
        }
        return courseRepository.findAllByOrganization_IdAndDeletedAtIsNullOrderByCreatedAtDesc(organizationId).stream()
                .filter(course -> course.getAccessScope() == LmsAccessScope.ORGANIZATION)
                .map(courseMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public CourseResponse findById(String courseId) {
        return findPublicById(courseId);
    }

    @Override
    @Transactional(readOnly = true)
    public CourseResponse findPublicById(String courseId) {
        Course course = getEntityById(courseId);
        if (course.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_course_not_found", HttpStatus.NOT_FOUND);
        }
        return courseMapper.toResponse(course);
    }

    @Override
    @Transactional(readOnly = true)
    public CourseResponse findByOrganizationAndId(String organizationId, String courseId) {
        organizationAccessService.assertActiveMembership(organizationId);
        Course course = getEntityById(courseId);
        assertOrganizationCourse(course, organizationId);
        return courseMapper.toResponse(course);
    }

    @Override
    @Transactional
    public CourseResponse update(String courseId, CourseUpsertRequest request) {
        return updatePublic(courseId, request);
    }

    @Override
    @Transactional
    public CourseResponse updatePublic(String courseId, CourseUpsertRequest request) {
        Course course = getEntityById(courseId);
        if (course.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_course_not_found", HttpStatus.NOT_FOUND);
        }
        publicCreatorAccessService.assertCanManagePublicProgram(course.getProgram());
        Program program = programService.getEntityById(request.getProgramId());
        assertPublicProgram(program);
        publicCreatorAccessService.assertCanManagePublicProgram(program);
        validateCode(request.getCode(), courseId, LmsAccessScope.PUBLIC, null);
        courseMapper.updateEntity(course, request);
        course.setProgram(program);
        course.setAccessScope(LmsAccessScope.PUBLIC);
        course.setOrganization(null);
        return courseMapper.toResponse(courseRepository.save(course));
    }

    @Override
    @Transactional
    public CourseResponse updateForOrganization(String organizationId, String courseId, CourseUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        Course course = getEntityById(courseId);
        assertOrganizationCourse(course, organizationId);
        Program program = programService.getEntityById(request.getProgramId());
        assertOrganizationProgram(program, organizationId);
        validateCode(request.getCode(), courseId, LmsAccessScope.ORGANIZATION, organizationId);
        courseMapper.updateEntity(course, request);
        course.setProgram(program);
        course.setAccessScope(LmsAccessScope.ORGANIZATION);
        course.setOrganization(program.getOrganization());
        return courseMapper.toResponse(courseRepository.save(course));
    }

    @Override
    @Transactional
    public void delete(String courseId) {
        deletePublic(courseId);
    }

    @Override
    @Transactional
    public void deletePublic(String courseId) {
        Course course = getEntityById(courseId);
        if (course.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_course_not_found", HttpStatus.NOT_FOUND);
        }
        publicCreatorAccessService.assertCanManagePublicProgram(course.getProgram());
        course.setDeletedAt(Instant.now());
        courseRepository.save(course);
    }

    @Override
    @Transactional
    public void deleteForOrganization(String organizationId, String courseId) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        Course course = getEntityById(courseId);
        assertOrganizationCourse(course, organizationId);
        course.setDeletedAt(Instant.now());
        courseRepository.save(course);
    }

    @Override
    @Transactional(readOnly = true)
    public Course getEntityById(String courseId) {
        return courseRepository.findByIdAndDeletedAtIsNull(courseId)
                .orElseThrow(() -> new AppException("lms.course_not_found", HttpStatus.NOT_FOUND));
    }

    private void validateCode(String code, String currentCourseId, LmsAccessScope scope, String organizationId) {
        String normalizedCode = code.trim();
        boolean existed;
        if (scope == LmsAccessScope.PUBLIC) {
            existed = currentCourseId == null
                    ? courseRepository.existsByCodeIgnoreCaseAndAccessScopeAndOrganizationIsNull(normalizedCode, scope)
                    : courseRepository.existsByCodeIgnoreCaseAndAccessScopeAndOrganizationIsNullAndIdNot(normalizedCode, scope, currentCourseId);
        } else {
            existed = currentCourseId == null
                    ? courseRepository.existsByCodeIgnoreCaseAndOrganization_Id(normalizedCode, organizationId)
                    : courseRepository.existsByCodeIgnoreCaseAndOrganization_IdAndIdNot(normalizedCode, organizationId, currentCourseId);
        }
        if (existed) {
            throw new AppException("lms.course_code_exists", HttpStatus.CONFLICT);
        }
    }

    private void assertPublicProgram(Program program) {
        if (program.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_program_not_found", HttpStatus.NOT_FOUND);
        }
    }

    private void assertOrganizationProgram(Program program, String organizationId) {
        if (program.getAccessScope() != LmsAccessScope.ORGANIZATION
                || program.getOrganization() == null
                || !organizationId.equals(program.getOrganization().getId())) {
            throw new AppException("lms.organization_program_not_found", HttpStatus.NOT_FOUND);
        }
    }

    private void assertOrganizationCourse(Course course, String organizationId) {
        if (course.getAccessScope() != LmsAccessScope.ORGANIZATION
                || course.getOrganization() == null
                || !organizationId.equals(course.getOrganization().getId())) {
            throw new AppException("lms.organization_course_not_found", HttpStatus.NOT_FOUND);
        }
    }
}
