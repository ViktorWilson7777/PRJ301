package com.lucy.api.modules.story.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.story.dto.request.CompleteOnboardingSurveyRequest;
import com.lucy.api.modules.event.service.EventAuthContextService;
import com.lucy.api.modules.story.dto.request.UpdateMyProfileRequest;
import com.lucy.api.modules.story.dto.request.UpdatePublicProfileSettingsRequest;
import com.lucy.api.modules.story.dto.request.UpdateProfileBackgroundRequest;
import com.lucy.api.modules.story.dto.response.ProfileResponse;
import com.lucy.api.modules.story.service.ProfileService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/me/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final EventAuthContextService eventAuthContextService;
    private final ProfileService profileService;

    @GetMapping
    public ResponseEntity<ApiResponse<ProfileResponse>> getProfile(@AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<ProfileResponse>builder()
                .success(true)
                .data(profileService.getCurrentProfile(currentUserId))
                .build());
    }

    @PatchMapping("/background")
    public ResponseEntity<ApiResponse<ProfileResponse>> updateBackground(@RequestBody UpdateProfileBackgroundRequest request,
                                                                         @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<ProfileResponse>builder()
                .success(true)
                .data(profileService.updateBackground(currentUserId, request))
                .build());
    }

    @PatchMapping
    public ResponseEntity<ApiResponse<ProfileResponse>> updateMyProfile(@Valid @RequestBody UpdateMyProfileRequest request,
                                                                         @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<ProfileResponse>builder()
                .success(true)
                .data(profileService.updateMyProfile(currentUserId, request))
                .build());
    }

    @PatchMapping("/onboarding-survey")
    public ResponseEntity<ApiResponse<ProfileResponse>> completeOnboardingSurvey(@Valid @RequestBody CompleteOnboardingSurveyRequest request,
                                                                                 @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<ProfileResponse>builder()
                .success(true)
                .data(profileService.completeOnboardingSurvey(currentUserId, request))
                .build());
    }

    @PatchMapping("/public-settings")
    public ResponseEntity<ApiResponse<ProfileResponse>> updatePublicProfileSettings(@Valid @RequestBody UpdatePublicProfileSettingsRequest request,
                                                                                     @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<ProfileResponse>builder()
                .success(true)
                .data(profileService.updatePublicProfileSettings(currentUserId, request))
                .build());
    }

}
