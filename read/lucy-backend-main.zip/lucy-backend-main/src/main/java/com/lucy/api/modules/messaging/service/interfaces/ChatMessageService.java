package com.lucy.api.modules.messaging.service.interfaces;

import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.messaging.dto.request.AttachmentRequest;
import com.lucy.api.modules.messaging.dto.request.EditMessageRequest;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;

import java.util.List;

public interface ChatMessageService {

    ChatMessageResponse sendMessage(
            String conversationId,
            String senderUserId,
            String text,
            List<AttachmentRequest> attachments,
            String replyToMessageId
    );

    ChatMessageResponse editMessage(String messageId, String editorUserId, EditMessageRequest request);

    PagingResponse<ChatMessageResponse> getMessages(String conversationId, String readerUserId, PagingRequest pagingRequest);
}
