package com.lucy.api.modules.messaging.service;

import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.messaging.dto.request.EditMessageRequest;
import com.lucy.api.modules.messaging.dto.request.SendMessageRequest;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;

public interface MessagingService {
    ChatMessageResponse sendMessage(SendMessageRequest request, String currentUserId, boolean emitRealtime);

    ChatMessageResponse editMessage(String messageId, EditMessageRequest request, String currentUserId, boolean emitRealtime);

    PagingResponse<ChatMessageResponse> getMessages(String conversationId, PagingRequest pagingRequest, String currentUserId);
}
