package com.lucy.api.common.configs;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

import java.util.Arrays;

@Configuration
@EnableWebSocketMessageBroker
@RequiredArgsConstructor
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {
    private final WebSocketJwtChannelInterceptor webSocketJwtChannelInterceptor;
    @Value("${app.websocket.stomp.room-endpoint:/ws-room}")
    private String roomStompEndpoint;
    @Value("${app.websocket.stomp.messaging-endpoint:/ws-messaging}")
    private String messagingStompEndpoint;
    @Value("${app.websocket.stomp.allowed-origin-patterns:*}")
    private String allowedOriginPatterns;

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        String[] originPatterns = Arrays.stream(allowedOriginPatterns.split(","))
                .map(String::trim)
                .filter(value -> !value.isEmpty())
                .toArray(String[]::new);
        registry.addEndpoint(roomStompEndpoint)
                .setAllowedOriginPatterns(originPatterns)
                .withSockJS();

        if (!messagingStompEndpoint.equals(roomStompEndpoint)) {
            registry.addEndpoint(messagingStompEndpoint)
                    .setAllowedOriginPatterns(originPatterns)
                    .withSockJS();
        }
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.setApplicationDestinationPrefixes("/app");
        registry.enableSimpleBroker("/topic", "/queue");
    }

    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(webSocketJwtChannelInterceptor);
    }
}
