package com.lucy.api.modules.assets.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PresignedUploadResponse {
    String uploadUrl;
    String downloadUrl;
    String publicId;
}
