package com.lucy.api.modules.event.repository;

import com.lucy.api.modules.event.entity.RoomChatMessageEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public interface RoomChatMessageRepository extends JpaRepository<RoomChatMessageEntity, UUID> {
    @Query("""
    select m.id as id, m.senderId as senderId, m.content as content, m.createdAt as createdAt
    from RoomChatMessageEntity m
    where m.roomId = :roomId
      and m.deletedAt is null
      and (
            (cast(:cursorCreatedAt as Instant) is null and cast(:cursorId as uuid) is null)
            or (m.createdAt < :cursorCreatedAt)
            or (m.createdAt = :cursorCreatedAt and m.id < :cursorId)
          )
    order by m.createdAt desc, m.id desc
    """)
    List<RoomChatMessageProjection> findByRoomId(
            @Param("roomId") UUID roomId,
            @Param("cursorCreatedAt") Instant cursorCreatedAt,
            @Param("cursorId") UUID cursorId,
            Pageable pageable
    );

    void deleteAllBySenderIdIn(List<UUID> userIds);

    void deleteAllByRoomIdIn(List<UUID> roomIds);
}
