package com.lucy.api.modules.event.repository;

import java.time.Instant;
import java.util.UUID;

public interface RoomCommentProjection {
    UUID getId();
    UUID getUserId();
    UUID getParentId();
    String getContent();
    Integer getLevel();
    Integer getLikesCount();
    Integer getRepliesCount();
    Instant getCreatedAt();
    Instant getDeletedAt();
    String getUserDisplayName();
    String getUserAvatarUrl();
}
