package com.lucy.api.modules.event.controller;

import com.lucy.api.common.configs.WebSocketSessionStore;
import com.lucy.api.modules.event.dto.request.ChatMessageRequest;
import com.lucy.api.modules.event.dto.response.ChatMessageResponse;
import com.lucy.api.modules.event.dto.response.ParticipantResponse;
import com.lucy.api.modules.event.dto.response.ParticipantSnapshotResponse;
import com.lucy.api.modules.event.service.EventService;
import com.lucy.api.modules.event.service.RoomRealtimePublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;

import java.security.Principal;
import java.time.Instant;
import java.util.UUID;

/**
 * Dedicated room chat websocket controller.
 * Keeps room lifecycle actions isolated from chat publishing.
 */
@Controller
@RequiredArgsConstructor
@Slf4j
public class RoomChatWebSocketController {

    private final RoomRealtimePublisher realtimePublisher;
    private final EventService eventService;
    private final WebSocketSessionStore webSocketSessionStore;

    @MessageMapping("/room/{roomId}/chat")
    public void handleChatMessage(
            @DestinationVariable UUID roomId,
            @Payload ChatMessageRequest request,
            Principal principal,
            SimpMessageHeaderAccessor headerAccessor) {
        try {
            UUID userId = requireUserId(principal, headerAccessor);
            ensureMatchingRoom(roomId, request != null ? request.getRoomId() : null);
            trackSessionRoom(headerAccessor, roomId);
            ParticipantResponse participant = eventService.requireParticipantState(roomId, userId);
            String content = request != null ? request.getContent() : null;
            if (!StringUtils.hasText(content)) {
                throw new IllegalArgumentException("content is required");
            }

            log.info("Chat message from user {} ({}) in room {}", participant.getDisplayName(), userId, roomId);
            final var saved = eventService.saveChatMessage(roomId, userId, content);

            ChatMessageResponse response = ChatMessageResponse.builder()
                    .id(saved.getId())
                    .roomId(roomId)
                    .userId(userId)
                    .displayName(participant.getDisplayName())
                    .content(saved.getContent())
                    .timestamp(saved.getCreatedAt())
                    .build();

            realtimePublisher.publishChat(roomId, response);
        } catch (Exception e) {
            log.error("Error handling chat message", e);
            sendError(roomId, "CHAT_ERROR", e.getMessage(), principal, headerAccessor);
        }
    }

    @SubscribeMapping({"/room/{roomId}/participants.snapshot", "/rooms/{roomId}/participants.snapshot"})
    public ParticipantSnapshotResponse subscribeToParticipants(@DestinationVariable UUID roomId) {
        log.info("Client requested participant snapshot for room {}", roomId);
        return eventService.getParticipantSnapshot(roomId);
    }

    private void sendError(
            UUID roomId,
            String errorCode,
            String errorMessage,
            Principal principal,
            SimpMessageHeaderAccessor headerAccessor) {
        com.lucy.api.modules.event.dto.response.WebSocketErrorResponse error = com.lucy.api.modules.event.dto.response.WebSocketErrorResponse.builder()
                .errorCode(errorCode)
                .errorMessage(errorMessage)
                .roomId(roomId)
                .timestamp(Instant.now().toString())
                .build();

        String userId = resolvePrincipalName(principal, headerAccessor);
        String sessionId = sessionId(headerAccessor);
        if (StringUtils.hasText(userId) && StringUtils.hasText(sessionId)) {
            realtimePublisher.publishErrorToUserSession(userId, sessionId, error);
        }
    }

    private void ensureMatchingRoom(UUID destinationRoomId, UUID payloadRoomId) {
        if (payloadRoomId != null && !destinationRoomId.equals(payloadRoomId)) {
            throw new IllegalArgumentException("roomId in payload does not match destination");
        }
    }

    private void trackSessionRoom(SimpMessageHeaderAccessor headerAccessor, UUID roomId) {
        String sessionId = sessionId(headerAccessor);
        if (sessionId != null) {
            webSocketSessionStore.trackRoom(sessionId, roomId);
        }
    }

    private UUID requireUserId(Principal principal, SimpMessageHeaderAccessor headerAccessor) {
        String userId = resolvePrincipalName(principal, headerAccessor);
        if (!StringUtils.hasText(userId)) {
            throw new IllegalArgumentException("Authentication required");
        }

        return UUID.fromString(userId);
    }

    private String sessionId(SimpMessageHeaderAccessor headerAccessor) {
        return headerAccessor != null ? headerAccessor.getSessionId() : null;
    }

    private String resolvePrincipalName(Principal principal, SimpMessageHeaderAccessor headerAccessor) {
        Principal effectivePrincipal = principal;
        if ((effectivePrincipal == null || !StringUtils.hasText(effectivePrincipal.getName()))
                && headerAccessor != null) {
            effectivePrincipal = headerAccessor.getUser();
        }
        if ((effectivePrincipal == null || !StringUtils.hasText(effectivePrincipal.getName()))
                && headerAccessor != null) {
            effectivePrincipal = webSocketSessionStore.get(headerAccessor.getSessionId()).orElse(null);
        }

        return effectivePrincipal != null ? effectivePrincipal.getName() : null;
    }
}
