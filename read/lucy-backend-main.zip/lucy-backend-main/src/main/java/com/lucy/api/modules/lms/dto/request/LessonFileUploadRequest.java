package com.lucy.api.modules.lms.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
public class LessonFileUploadRequest {
    @NotNull(message = "common.field_required")
    private MultipartFile file;
}
