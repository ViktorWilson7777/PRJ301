package com.lucy.api.modules.event.dto.realtime;

public record InterestUpdatedData(boolean interested, long interestedCount) {
}
