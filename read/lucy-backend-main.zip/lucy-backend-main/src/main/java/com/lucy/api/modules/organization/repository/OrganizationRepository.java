package com.lucy.api.modules.organization.repository;

import com.lucy.api.modules.organization.entity.Organization;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OrganizationRepository extends JpaRepository<Organization, String> {
    boolean existsByCodeIgnoreCase(String code);

    boolean existsByCodeIgnoreCaseAndIdNot(String code, String id);

    Optional<Organization> findByIdAndDeletedAtIsNull(String id);
}
