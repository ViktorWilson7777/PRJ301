package com.lucy.api.modules.lms.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChapterUpsertRequest {
    @NotNull(message = "common.field_required")
    private String courseRunId;

    @NotBlank(message = "common.field_required")
    @Size(max = 255, message = "common.validation")
    private String title;

    private String description;

    @NotNull(message = "common.field_required")
    @PositiveOrZero(message = "common.validation")
    private Integer orderIndex;
}
