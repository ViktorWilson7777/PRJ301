package com.lucy.api.modules.lms.repository;

import com.lucy.api.modules.lms.entity.Enrollment;
import com.lucy.api.modules.lms.entity.enums.EnrollmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, String>,
        JpaSpecificationExecutor<Enrollment> {

    boolean existsByUserIdAndCourseRunId(String userId, String courseRunId);

    boolean existsByUser_IdAndCourseRun_IdAndStatus(String userId, String courseRunId, EnrollmentStatus status);

    Optional<Enrollment> findByUser_IdAndCourseRun_Id(String userId, String courseRunId);

    Optional<Enrollment> findByIdAndUser_Id(String enrollmentId, String userId);

    List<Enrollment> findAllByCourseRunId(String courseRunId);

    List<Enrollment> findAllByUserId(String userId);

    List<Enrollment> findAllByUser_IdIn(List<String> userIds);

    long countByCourseRunId(String courseRunId);

    boolean existsByUserIdAndCourseRunIdAndCompletedAtIsNotNull(String userId, String courseRunId);

    @Modifying
    @Transactional
    void deleteAllByUser_IdIn(List<String> userIds);
}
