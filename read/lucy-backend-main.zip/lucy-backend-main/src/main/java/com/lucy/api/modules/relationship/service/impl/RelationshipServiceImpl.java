package com.lucy.api.modules.relationship.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import com.lucy.api.modules.notifications.service.interfaces.NotificationService;
import com.lucy.api.modules.relationship.constants.RelationshipConstants;
import com.lucy.api.modules.relationship.constants.RelationshipErrorCodeConstants;
import com.lucy.api.modules.relationship.dtos.request.FriendRequestCreateRequest;
import com.lucy.api.modules.relationship.dtos.response.RelationshipResponse;
import com.lucy.api.modules.relationship.dtos.response.RelationshipStatusResponse;
import com.lucy.api.modules.relationship.entity.Relationship;
import com.lucy.api.modules.relationship.enums.RelationshipStatus;
import com.lucy.api.modules.relationship.mapper.RelationshipMapper;
import com.lucy.api.modules.relationship.repository.RelationshipRepository;
import com.lucy.api.modules.relationship.service.interfaces.RelationshipService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class RelationshipServiceImpl implements RelationshipService {

    RelationshipRepository relationshipRepository;
    RelationshipMapper relationshipMapper;
    UserRepository userRepository;
    NotificationService notificationService;
    MessageSource messageSource;

    @Override
    @Transactional
    public RelationshipResponse sendFriendRequest(FriendRequestCreateRequest request) {
        String currentUserId = IdentityUtils.getCurrentUserId();
        String targetUserId = request.getTargetUserId().trim();

        if (currentUserId.equals(targetUserId)) {
            throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_SELF_REQUEST_NOT_ALLOWED, HttpStatus.BAD_REQUEST);
        }

        User requester = getExistingUser(currentUserId, true);
        User addressee = getExistingUser(targetUserId, false);

        relationshipRepository.findBetweenUsers(currentUserId, targetUserId).ifPresent(relationship -> {
            if (relationship.getStatus() == RelationshipStatus.ACCEPTED) {
                throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_ALREADY_FRIENDS, HttpStatus.CONFLICT);
            }

            if (relationship.getRequester().getId().equals(currentUserId)) {
                throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_REQUEST_ALREADY_SENT, HttpStatus.CONFLICT);
            }

            throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_REQUEST_ALREADY_RECEIVED, HttpStatus.CONFLICT);
        });

        Relationship relationship = new Relationship();
        relationship.setRequester(requester);
        relationship.setAddressee(addressee);
        relationship.setStatus(RelationshipStatus.PENDING);
        relationship.setRequestedAt(Instant.now());
        relationship.setRespondedAt(null);

        Relationship savedRelationship = relationshipRepository.save(relationship);

        notificationService.createNotification(
                addressee,
                messageSource.getMessage("notification.relationship.request.title", null, LocaleContextHolder.getLocale()),
                messageSource.getMessage("notification.relationship.request.body", new Object[]{requester.getProfile() != null ? requester.getProfile().getDisplayName() : requester.getEmail()}, LocaleContextHolder.getLocale()),
                RelationshipConstants.NOTIFICATION_TYPE
        );

        return relationshipMapper.toResponse(savedRelationship);
    }

    @Override
    @Transactional
    public RelationshipResponse acceptRequest(String relationshipId) {
        String currentUserId = IdentityUtils.getCurrentUserId();
        Relationship relationship = getExistingRelationship(relationshipId);

        if (relationship.getStatus() != RelationshipStatus.PENDING
                || !relationship.getAddressee().getId().equals(currentUserId)) {
            throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_INVALID_ACCEPT, HttpStatus.CONFLICT);
        }

        relationship.setStatus(RelationshipStatus.ACCEPTED);
        relationship.setRespondedAt(Instant.now());

        Relationship savedRelationship = relationshipRepository.save(relationship);

        notificationService.createNotification(
                relationship.getRequester(),
                messageSource.getMessage("notification.relationship.accept.title", null, LocaleContextHolder.getLocale()),
                messageSource.getMessage("notification.relationship.accept.body", new Object[]{relationship.getAddressee().getProfile() != null ? relationship.getAddressee().getProfile().getDisplayName() : relationship.getAddressee().getEmail()}, LocaleContextHolder.getLocale()),
                RelationshipConstants.NOTIFICATION_TYPE
        );

        return relationshipMapper.toResponse(savedRelationship);
    }

    @Override
    @Transactional
    public void rejectRequest(String relationshipId) {
        String currentUserId = IdentityUtils.getCurrentUserId();
        Relationship relationship = getExistingRelationship(relationshipId);

        if (relationship.getStatus() != RelationshipStatus.PENDING
                || !relationship.getAddressee().getId().equals(currentUserId)) {
            throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_INVALID_REJECT, HttpStatus.CONFLICT);
        }

        relationshipRepository.delete(relationship);
    }

    @Override
    @Transactional
    public void cancelSentRequest(String relationshipId) {
        String currentUserId = IdentityUtils.getCurrentUserId();
        Relationship relationship = getExistingRelationship(relationshipId);

        if (relationship.getStatus() != RelationshipStatus.PENDING
                || !relationship.getRequester().getId().equals(currentUserId)) {
            throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_INVALID_CANCEL, HttpStatus.CONFLICT);
        }

        relationshipRepository.delete(relationship);
    }

    @Override
    @Transactional
    public void unfriend(String relationshipId) {
        String currentUserId = IdentityUtils.getCurrentUserId();
        Relationship relationship = getExistingRelationship(relationshipId);

        boolean isParticipant = relationship.getRequester().getId().equals(currentUserId)
                || relationship.getAddressee().getId().equals(currentUserId);

        if (relationship.getStatus() != RelationshipStatus.ACCEPTED || !isParticipant) {
            throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_INVALID_UNFRIEND, HttpStatus.CONFLICT);
        }

        relationshipRepository.delete(relationship);
    }

    @Override
    @Transactional(readOnly = true)
    public List<RelationshipResponse> getMyFriends() {
        String currentUserId = IdentityUtils.getCurrentUserId();
        return relationshipRepository.findAllByUserIdAndStatus(currentUserId, RelationshipStatus.ACCEPTED).stream()
                .map(relationshipMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<RelationshipResponse> getPendingReceivedRequests() {
        String currentUserId = IdentityUtils.getCurrentUserId();
        return relationshipRepository.findAllByAddressee_IdAndStatusOrderByRequestedAtDesc(currentUserId, RelationshipStatus.PENDING)
                .stream()
                .map(relationshipMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<RelationshipResponse> getPendingSentRequests() {
        String currentUserId = IdentityUtils.getCurrentUserId();
        return relationshipRepository.findAllByRequester_IdAndStatusOrderByRequestedAtDesc(currentUserId, RelationshipStatus.PENDING)
                .stream()
                .map(relationshipMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public RelationshipStatusResponse getRelationshipStatus(String otherUserId) {
        String currentUserId = IdentityUtils.getCurrentUserId();

        if (currentUserId.equals(otherUserId)) {
            throw new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_SELF_REQUEST_NOT_ALLOWED, HttpStatus.BAD_REQUEST);
        }

        User otherUser = getExistingUser(otherUserId, false);

        return relationshipRepository.findBetweenUsers(currentUserId, otherUserId)
                .map(relationship -> buildStatusResponse(currentUserId, otherUser, relationship))
                .orElseGet(() -> RelationshipStatusResponse.builder()
                        .otherUser(relationshipMapper.toUserSummary(otherUser))
                        .status(null)
                        .isRequester(false)
                        .isAddressee(false)
                        .canMessage(false)
                        .build());
    }

    @Override
    @Transactional(readOnly = true)
    public boolean canMessage(String currentUserId, String otherUserId) {
        return relationshipRepository.findBetweenUsers(currentUserId, otherUserId)
                .map(relationship -> relationship.getStatus() == RelationshipStatus.ACCEPTED)
                .orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean canCurrentUserMessage(String otherUserId) {
        return canMessage(IdentityUtils.getCurrentUserId(), otherUserId);
    }

    private RelationshipStatusResponse buildStatusResponse(String currentUserId, User otherUser, Relationship relationship) {
        return RelationshipStatusResponse.builder()
                .otherUser(relationshipMapper.toUserSummary(otherUser))
                .status(relationship.getStatus())
                .isRequester(relationship.getRequester().getId().equals(currentUserId))
                .isAddressee(relationship.getAddressee().getId().equals(currentUserId))
                .canMessage(relationship.getStatus() == RelationshipStatus.ACCEPTED)
                .build();
    }

    private Relationship getExistingRelationship(String relationshipId) {
        return relationshipRepository.findById(relationshipId)
                .orElseThrow(() -> new AppException(RelationshipErrorCodeConstants.RELATIONSHIP_NOT_FOUND, HttpStatus.NOT_FOUND));
    }

    private User getExistingUser(String userId, boolean currentUser) {
        return userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException(
                        currentUser ? "auth.user_not_existed" : RelationshipErrorCodeConstants.RELATIONSHIP_USER_NOT_FOUND,
                        HttpStatus.NOT_FOUND
                ));
    }
}
