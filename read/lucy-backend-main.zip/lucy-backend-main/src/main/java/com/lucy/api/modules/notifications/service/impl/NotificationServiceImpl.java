package com.lucy.api.modules.notifications.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.infrastructure.websocket.dto.response.WebSocketNotificationResponse;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketNotificationService;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.notifications.dtos.response.NotificationResponse;
import com.lucy.api.modules.notifications.entity.Notification;
import com.lucy.api.modules.notifications.repository.NotificationRepository;
import com.lucy.api.modules.notifications.service.interfaces.NotificationService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.time.Instant;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class NotificationServiceImpl implements NotificationService {
    NotificationRepository notificationRepository;
    WebSocketNotificationService webSocketNotificationService;

    @Override
    @Transactional
    public void createNotification(User user, String title, String message, String type) {
        createNotification(user, title, message, type, null, null);
    }

    @Override
    @Transactional
    public void createNotification(User user, String title, String message, String type, String conversationId, String payload) {
        Notification notification = Notification.builder()
                .user(user)
                .title(title)
                .message(message)
                .type(type)
                .conversationId(conversationId)
                .payload(payload)
                .isRead(false)
                .build();
        Notification saved = notificationRepository.save(notification);

        webSocketNotificationService.sendNotificationToUser(
                user.getId(),
                WebSocketNotificationResponse.builder()
                        .type(type)
                        .title(title)
                        .message(message)
                        .conversationId(conversationId)
                        .notificationId(saved.getId())
                        .payload(payload != null ? payload : "")
                        .timestamp(Instant.now())
                        .build()
        );
    }

    @Override
    public List<NotificationResponse> getMyNotifications(String userId) {
        return notificationRepository.findAllByUserIdOrderByCreatedAtDesc(userId)
                .stream()
                .map(n -> NotificationResponse.builder()
                        .id(n.getId())
                        .title(n.getTitle())
                        .message(n.getMessage())
                        .isRead(n.isRead())
                        .type(n.getType())
                        .conversationId(n.getConversationId())
                        .payload(n.getPayload())
                        .createdAt(n.getCreatedAt())
                        .build())
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void markAsRead(String notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new AppException("NOT_FOUND", HttpStatus.NOT_FOUND));
        notification.setRead(true);
        notificationRepository.save(notification);
    }

    @Override
    @Transactional
    public void markAllAsRead(String userId) {
        notificationRepository.markAllAsReadByUserId(userId);
    }

    @Override
    public long countUnreadNotifications(String userId) {
        return notificationRepository.countByUserIdAndIsReadFalse(userId);
    }
}
