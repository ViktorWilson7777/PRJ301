package com.lucy.api.modules.commerce.dto.response;

import com.lucy.api.modules.commerce.entity.enums.PublicCoursePurchaseType;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PublicCourseProductResponse {
    String id;
    String courseRunId;
    BigDecimal priceAmount;
    String currency;
    boolean active;
    PublicCoursePurchaseType purchaseType;
}
