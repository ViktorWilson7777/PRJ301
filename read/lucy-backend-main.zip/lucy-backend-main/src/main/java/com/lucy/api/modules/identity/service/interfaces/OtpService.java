package com.lucy.api.modules.identity.service.interfaces;

public interface OtpService {

    /**
     * Generate a 6-digit OTP and store it in Redis with TTL
     * @param email the user's email address (used as Redis key)
     * @return the generated OTP string
     */
    String generateAndStoreOtp(String email);

    /**
     * Verify the OTP for a given email (does NOT consume it)
     * @param email the user's email address
     * @param otp the OTP to verify
     * @return true if the OTP matches
     */
    boolean verifyOtp(String email, String otp);

    /**
     * Delete the OTP from Redis (call after successful password reset)
     * @param email the user's email address
     */
    void deleteOtp(String email);

    String generateAndStoreRegistrationOtp(String email);

    boolean verifyRegistrationOtp(String email, String otp);

    void deleteRegistrationOtp(String email);
}
