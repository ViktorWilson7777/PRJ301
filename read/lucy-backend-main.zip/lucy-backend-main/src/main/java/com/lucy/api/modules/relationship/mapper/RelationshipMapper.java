package com.lucy.api.modules.relationship.mapper;

import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.relationship.dtos.response.RelationshipResponse;
import com.lucy.api.modules.relationship.dtos.response.RelationshipUserSummaryResponse;
import com.lucy.api.modules.relationship.entity.Relationship;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface RelationshipMapper {

    @Mapping(target = "userId",      source = "id")
    @Mapping(target = "displayName", source = "profile.displayName")
    @Mapping(target = "avatarUrl",   source = "profile.avatarUrl")
    RelationshipUserSummaryResponse toUserSummary(User user);

    @Mapping(target = "requester", source = "requester")
    @Mapping(target = "addressee", source = "addressee")
    RelationshipResponse toResponse(Relationship relationship);
}
