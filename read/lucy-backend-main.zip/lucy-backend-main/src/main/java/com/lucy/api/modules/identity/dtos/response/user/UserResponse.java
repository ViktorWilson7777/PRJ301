package com.lucy.api.modules.identity.dtos.response.user;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserResponse {
    String id;

    String email;
    String displayName;
    String avatarUrl;
    String profileRole;
    boolean isActive;
    boolean isVerified;
    Instant verifiedAt;
    Instant bannedUntil;
    Instant lastSignInAt;
    boolean isProfileCompleted;

    String role;

    Instant createdAt;
    Instant updatedAt;
}

