package com.lucy.api.modules.identity.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.UserProfile;
import com.lucy.api.modules.identity.entity.enums.ProfileRole;
import com.lucy.api.modules.identity.repository.UserProfileRepository;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class CurrentUserService {
    UserRepository userRepository;
    UserProfileRepository userProfileRepository;

    public String getCurrentUserId() {
        return IdentityUtils.getCurrentUserId();
    }

    @Transactional(readOnly = true)
    public User getCurrentUser() {
        return userRepository.findByIdAndDeletedAtIsNull(getCurrentUserId())
                .orElseThrow(() -> new AppException("auth.user_not_existed", HttpStatus.NOT_FOUND));
    }

    @Transactional(readOnly = true)
    public ProfileRole getCurrentProfileRole() {
        UserProfile profile = userProfileRepository.findByUserId(getCurrentUserId())
                .orElseThrow(() -> new AppException("auth.profile_not_found", HttpStatus.NOT_FOUND));
        return profile.getProfileRole();
    }
}
