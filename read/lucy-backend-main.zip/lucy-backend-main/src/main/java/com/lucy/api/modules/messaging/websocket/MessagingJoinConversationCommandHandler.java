package com.lucy.api.modules.messaging.websocket;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.infrastructure.redis.pubsub.RedisPubSubSubscriptionService;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketErrorCodeConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketFrameTypeConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketMessageKeys;
import com.lucy.api.infrastructure.websocket.entity.WebSocketSession;
import com.lucy.api.infrastructure.websocket.enums.WebSocketConnectionStatus;
import com.lucy.api.infrastructure.websocket.enums.WebSocketMessageType;
import com.lucy.api.infrastructure.websocket.handler.WebSocketCommandHandler;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketSessionService;
import com.lucy.api.infrastructure.websocket.utils.WebSocketPayloadCodec;
import com.lucy.api.modules.messaging.constant.MessagingErrorKeys;
import com.lucy.api.modules.messaging.constant.MessagingWebSocketFrameConstants;
import com.lucy.api.modules.messaging.dto.websocket.WebSocketJoinConversationRequest;
import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import com.lucy.api.modules.messaging.repository.ConversationParticipantRepository;
import com.lucy.api.modules.messaging.repository.ConversationRepository;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;

@Slf4j
@Component
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MessagingJoinConversationCommandHandler implements WebSocketCommandHandler {

    ExecutorService messagingWebSocketExecutor;

    WebSocketSessionService sessionService;
    ConversationRepository conversationRepository;
    ConversationParticipantRepository conversationParticipantRepository;
    RedisPubSubSubscriptionService redisPubSubSubscriptionService;
    WebSocketPayloadCodec payloadCodec;
    MessageSource messageSource;

    public MessagingJoinConversationCommandHandler(
            @Qualifier("messagingWebSocketExecutor") ExecutorService messagingWebSocketExecutor,
            WebSocketSessionService sessionService,
            ConversationRepository conversationRepository,
            ConversationParticipantRepository conversationParticipantRepository,
            RedisPubSubSubscriptionService redisPubSubSubscriptionService,
            WebSocketPayloadCodec payloadCodec,
            MessageSource messageSource
    ) {
        this.messagingWebSocketExecutor = messagingWebSocketExecutor;
        this.sessionService = sessionService;
        this.conversationRepository = conversationRepository;
        this.conversationParticipantRepository = conversationParticipantRepository;
        this.redisPubSubSubscriptionService = redisPubSubSubscriptionService;
        this.payloadCodec = payloadCodec;
        this.messageSource = messageSource;
    }

    @Override
    public String getType() {
        return WebSocketMessageType.JOIN_CONVERSATION.name();
    }

    @Override
    public void handle(ChannelHandlerContext ctx, String payloadJson, String sessionId) {
        messagingWebSocketExecutor.execute(() -> doHandle(ctx, payloadJson, sessionId));
    }

    private void doHandle(ChannelHandlerContext ctx, String payloadJson, String sessionId) {
        try {
            WebSocketJoinConversationRequest request =
                    payloadCodec.parseMessage(payloadJson, WebSocketJoinConversationRequest.class);
            if (request == null || request.getConversationId() == null || request.getConversationId().isBlank()) {
                sendError(ctx, WebSocketErrorCodeConstants.INVALID_MESSAGE, WebSocketMessageKeys.CONVERSATION_ID_REQUIRED);
                return;
            }

            var sessionOpt = sessionService.getSession(sessionId);
            if (sessionOpt.isEmpty()) {
                sendError(ctx, WebSocketErrorCodeConstants.SESSION_NOT_FOUND, WebSocketMessageKeys.SESSION_NOT_FOUND);
                return;
            }

            String conversationId = request.getConversationId().trim();
            conversationRepository.findById(conversationId)
                    .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));

            WebSocketSession session = sessionOpt.get();
            boolean active = conversationParticipantRepository.existsByConversationIdAndUserIdAndStatus(
                    conversationId, session.getUserId(), ParticipantStatus.ACTIVE);
            if (!active) {
                sendError(ctx, WebSocketErrorCodeConstants.MESSAGING_FORBIDDEN, MessagingErrorKeys.NOT_PARTICIPANT);
                return;
            }

            String previousConversationId = session.getConversationId();
            if (previousConversationId != null && !previousConversationId.equals(conversationId)) {
                sessionService.removeSessionFromConversation(sessionId, previousConversationId);
            }

            sessionService.addSessionToConversation(sessionId, conversationId);
            redisPubSubSubscriptionService.subscribeToConversation(conversationId);

            session.setConversationId(conversationId);
            session.setStatus(WebSocketConnectionStatus.JOINED);
            session.setLastActivityAt(Instant.now());
            sessionService.updateSession(sessionId, session);

            String body = payloadCodec.toJson(Map.of(
                    WebSocketConstants.FIELD_TYPE, MessagingWebSocketFrameConstants.JOIN_CONVERSATION,
                    MessagingWebSocketFrameConstants.FIELD_CONVERSATION_ID, conversationId,
                    MessagingWebSocketFrameConstants.FIELD_SUCCESS, Boolean.TRUE
            ));
            if (body != null) {
                ctx.channel().writeAndFlush(new TextWebSocketFrame(body));
            }
            log.debug("Session {} joined conversation {}", sessionId, conversationId);
        } catch (AppException e) {
            sendAppException(ctx, e);
        } catch (Exception e) {
            log.error("Error joining conversation", e);
            sendError(ctx, WebSocketErrorCodeConstants.INVALID_MESSAGE, WebSocketMessageKeys.PROCESS_FAILED);
        }
    }

    private void sendAppException(ChannelHandlerContext ctx, AppException ex) {
        String resolved = messageSource.getMessage(ex.getErrorCode(), null, ex.getErrorCode(), Locale.ENGLISH);
        String errorJson = payloadCodec.toJson(Map.of(
                WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.ERROR,
                WebSocketConstants.FIELD_ERROR_CODE, WebSocketErrorCodeConstants.MESSAGING_FORBIDDEN,
                WebSocketConstants.FIELD_MESSAGE, resolved,
                WebSocketConstants.FIELD_MESSAGE_KEY, ex.getErrorCode()
        ));
        if (errorJson != null) {
            ctx.channel().writeAndFlush(new TextWebSocketFrame(errorJson));
        }
    }

    private void sendError(ChannelHandlerContext ctx, String errorCode, String messageKey) {
        String text = messageSource.getMessage(messageKey, null, Locale.ENGLISH);
        String errorJson = payloadCodec.toJson(Map.of(
                WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.ERROR,
                WebSocketConstants.FIELD_ERROR_CODE, errorCode,
                WebSocketConstants.FIELD_MESSAGE, text,
                WebSocketConstants.FIELD_MESSAGE_KEY, messageKey
        ));
        if (errorJson != null) {
            ctx.channel().writeAndFlush(new TextWebSocketFrame(errorJson));
        }
    }
}
