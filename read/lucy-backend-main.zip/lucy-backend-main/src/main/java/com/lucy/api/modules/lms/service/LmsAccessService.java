package com.lucy.api.modules.lms.service;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.commerce.entity.enums.LearningEntitlementStatus;
import com.lucy.api.modules.commerce.repository.LearningEntitlementRepository;
import com.lucy.api.modules.identity.entity.enums.UserRole;
import com.lucy.api.modules.identity.service.impl.CurrentUserService;
import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole;
import com.lucy.api.modules.organization.service.OrganizationAccessService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class LmsAccessService {
    CurrentUserService currentUserService;
    OrganizationAccessService organizationAccessService;
    LearningEntitlementRepository learningEntitlementRepository;

    @Transactional(readOnly = true)
    public void assertCanReadCourseRun(CourseRun courseRun) {
        if (courseRun.getAccessScope() == LmsAccessScope.PUBLIC) {
            return;
        }
        if (courseRun.getOrganization() == null) {
            throw new AppException("lms.organization_required", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        organizationAccessService.assertActiveMembership(courseRun.getOrganization().getId());
    }

    @Transactional(readOnly = true)
    public void assertCanManageOrganizationCourseRun(CourseRun courseRun) {
        if (courseRun.getAccessScope() != LmsAccessScope.ORGANIZATION || courseRun.getOrganization() == null) {
            throw new AppException("lms.organization_scope_required", HttpStatus.BAD_REQUEST);
        }
        organizationAccessService.assertOrganizationRole(
                courseRun.getOrganization().getId(),
                OrganizationMembershipRole.OWNER,
                OrganizationMembershipRole.ADMIN,
                OrganizationMembershipRole.INSTRUCTOR
        );
    }

    @Transactional(readOnly = true)
    public void assertCanSelfEnroll(CourseRun courseRun, String userId) {
        if (courseRun.getAccessScope() == LmsAccessScope.PUBLIC) {
            boolean entitled = learningEntitlementRepository.existsByUser_IdAndCourseRun_IdAndStatus(
                    userId, courseRun.getId(), LearningEntitlementStatus.ACTIVE
            );
            if (!entitled) {
                throw new AppException("lms.entitlement_required", HttpStatus.FORBIDDEN);
            }
            return;
        }
        if (courseRun.getOrganization() == null) {
            throw new AppException("lms.organization_required", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        organizationAccessService.assertActiveMembership(courseRun.getOrganization().getId());
        boolean allowSelfEnrollment = courseRun.getMetadata() != null
                && Boolean.TRUE.equals(courseRun.getMetadata().get("allowSelfEnrollment"));
        if (!allowSelfEnrollment) {
            throw new AppException("lms.organization_self_enroll_disabled", HttpStatus.FORBIDDEN);
        }
    }

    @Transactional(readOnly = true)
    public void assertCanManualEnroll(CourseRun courseRun) {
        if (currentUserService.getCurrentUser().getRoleName() == UserRole.ADMIN) {
            return;
        }
        if (courseRun.getAccessScope() == LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_manual_enrollment_forbidden", HttpStatus.FORBIDDEN);
        }
        if (courseRun.getOrganization() == null) {
            throw new AppException("lms.organization_required", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        organizationAccessService.assertOrganizationRole(
                courseRun.getOrganization().getId(),
                OrganizationMembershipRole.OWNER,
                OrganizationMembershipRole.ADMIN,
                OrganizationMembershipRole.INSTRUCTOR
        );
    }
}
