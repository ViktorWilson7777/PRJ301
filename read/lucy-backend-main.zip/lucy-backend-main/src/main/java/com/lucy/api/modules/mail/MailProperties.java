package com.lucy.api.modules.mail;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app.mail")
@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MailProperties {
    String frontendUrl;
    String from;
}
