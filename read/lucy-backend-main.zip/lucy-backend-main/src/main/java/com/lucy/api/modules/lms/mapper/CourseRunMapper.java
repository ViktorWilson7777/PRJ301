package com.lucy.api.modules.lms.mapper;

import com.lucy.api.modules.lms.mapper.ChapterMapper;
import com.lucy.api.modules.lms.dto.request.CourseRunUpsertRequest;
import com.lucy.api.modules.lms.dto.response.CourseRunResponse;
import com.lucy.api.modules.lms.entity.CourseRun;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring", uses = {ChapterMapper.class, MapperUtils.class})
public interface CourseRunMapper {

    @Mapping(target = "course", ignore = true)
    @Mapping(target = "deletedAt", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "chapters", ignore = true)
    @Mapping(target = "organization", ignore = true)
    @Mapping(target = "accessScope", ignore = true)
    @Mapping(target = "code", source = "code", qualifiedByName = "trimValue")
    @Mapping(target = "enrollmentStartDate", source = "enrollmentStartDate")
    @Mapping(target = "enrollmentEndDate", source = "enrollmentEndDate")
    @Mapping(target = "capacity", source = "capacity")
    @Mapping(target = "prerequisiteCourseRunId", source = "prerequisiteCourseRunId")
    CourseRun toEntity(CourseRunUpsertRequest request);

    @Mapping(target = "course", ignore = true)
    @Mapping(target = "deletedAt", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "chapters", ignore = true)
    @Mapping(target = "organization", ignore = true)
    @Mapping(target = "accessScope", ignore = true)
    @Mapping(target = "code", source = "code", qualifiedByName = "trimValue")
    @Mapping(target = "enrollmentStartDate", source = "enrollmentStartDate")
    @Mapping(target = "enrollmentEndDate", source = "enrollmentEndDate")
    @Mapping(target = "capacity", source = "capacity")
    @Mapping(target = "prerequisiteCourseRunId", source = "prerequisiteCourseRunId")
    void updateEntity(@MappingTarget CourseRun courseRun, CourseRunUpsertRequest request);

    @Mapping(target = "courseId", source = "course.id")
    @Mapping(target = "organizationId", source = "organization.id")
    CourseRunResponse toResponse(CourseRun courseRun);
}
