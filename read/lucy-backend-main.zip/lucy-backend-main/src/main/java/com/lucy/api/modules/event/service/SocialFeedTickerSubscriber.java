package com.lucy.api.modules.event.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.modules.event.dto.realtime.SocialFeedTickerMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class SocialFeedTickerSubscriber {
    private final ObjectMapper objectMapper;
    private final SimpMessagingTemplate messagingTemplate;

    public void onMessage(String payload, String channel) {
        try {
            SocialFeedTickerMessage message = objectMapper.readValue(payload, SocialFeedTickerMessage.class);
            messagingTemplate.convertAndSend(SocialFeedTickerChannels.WEBSOCKET_TOPIC, message);
        } catch (Exception ex) {
            log.warn("Failed to process social feed ticker message on channel={}", channel, ex);
        }
    }
}
