package com.lucy.api.modules.agora.service;

import com.lucy.api.modules.agora.dto.request.AgoraTokenRequest;
import com.lucy.api.modules.agora.dto.response.AgoraTokenResponse;
import com.lucy.api.modules.agora.exception.AgoraConfigException;
import com.lucy.api.modules.agora.token.RtcTokenBuilder2;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Instant;

@Service
@Slf4j
@RequiredArgsConstructor
public class AgoraTokenService {

    @Value("${agora.app-id:}")
    private String appId;

    @Value("${agora.app-certificate:}")
    private String appCertificate;

    @Value("${agora.token-expire-seconds:${AGORA_TOKEN_EXPIRE_SECONDS:3600}}")
    private Long tokenExpireSeconds;

    public AgoraTokenResponse generateRtcToken(AgoraTokenRequest request) {
        return generateRtcToken(request.getChannelId(), request.getUid());
    }

    public AgoraTokenResponse generateRtcToken(String channelId, Integer uid) {
        validateConfig();

        long currentTs = Instant.now().getEpochSecond();
        long expireAt = currentTs + tokenExpireSeconds;

        RtcTokenBuilder2 tokenBuilder = new RtcTokenBuilder2();
        String token = tokenBuilder.buildTokenWithUid(
                appId,
                appCertificate,
                channelId,
                uid,
                RtcTokenBuilder2.Role.ROLE_PUBLISHER,
                Math.toIntExact(tokenExpireSeconds),
                Math.toIntExact(expireAt)
        );

        if (!StringUtils.hasText(token)) {
            throw new AgoraConfigException("Agora config missing");
        }

        log.info("Agora token generated for channelId={}, uid={}, expireAt={}, tokenPrefix={}",
                channelId,
                uid,
                expireAt,
                maskToken(token));

        return AgoraTokenResponse.builder()
                .token(token)
                .channelId(channelId)
                .uid(uid)
                .expireAt(expireAt)
                .build();
    }

    private void validateConfig() {
        if (!StringUtils.hasText(appId) || !StringUtils.hasText(appCertificate)) {
            log.error("Agora config missing: appIdPresent={}, appCertificatePresent={}",
                    StringUtils.hasText(appId),
                    StringUtils.hasText(appCertificate));
            throw new AgoraConfigException("Agora config missing");
        }

        if (tokenExpireSeconds == null || tokenExpireSeconds <= 0) {
            log.error("Invalid AGORA_TOKEN_EXPIRE_SECONDS={}", tokenExpireSeconds);
            throw new AgoraConfigException("Agora config missing");
        }
    }

    private String maskToken(String token) {
        if (token.length() <= 10) {
            return "***";
        }
        return token.substring(0, 10) + "...";
    }
}
