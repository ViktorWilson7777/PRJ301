package com.lucy.api.modules.lms.dto.request.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum FilterField {
    KEYWORD("keyword"),
    ROLE("role"),
    INACTIVE_FOR_MORE_THAN("inactiveForMoreThan");

    private final String value;

    FilterField(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    @JsonCreator
    public static FilterField fromValue(String value) {
        for (FilterField field : values()) {
            if (field.value.equalsIgnoreCase(value)) {
                return field;
            }
        }
        throw new IllegalArgumentException("Unknown filter field: " + value);
    }
}
