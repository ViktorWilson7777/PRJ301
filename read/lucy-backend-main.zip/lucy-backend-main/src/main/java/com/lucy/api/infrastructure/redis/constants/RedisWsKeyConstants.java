package com.lucy.api.infrastructure.redis.constants;

/**
 * Key pattern Redis dùng cho session WebSocket (scan subscribe lúc bootstrap).
 */
public final class RedisWsKeyConstants {

    private RedisWsKeyConstants() {
    }

    public static final String PREFIX_CONVERSATION_SESSIONS = "ws:conversation:";
    public static final String SUFFIX_CONVERSATION_SESSIONS = ":sessions";
    public static final String PREFIX_USER_SESSIONS = "ws:user:";
    public static final String SUFFIX_USER_SESSIONS = ":sessions";
}
