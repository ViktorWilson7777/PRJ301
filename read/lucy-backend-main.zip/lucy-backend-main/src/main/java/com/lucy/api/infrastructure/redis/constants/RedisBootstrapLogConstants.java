package com.lucy.api.infrastructure.redis.constants;

public final class RedisBootstrapLogConstants {

    private RedisBootstrapLogConstants() {
    }

    public static final String INIT_OK = "Redis pub/sub bootstrap initialized successfully";
    public static final String INIT_WARN =
            "Redis is not available during pub/sub bootstrap. Channels will be subscribed dynamically when needed. Error: {}";
}
