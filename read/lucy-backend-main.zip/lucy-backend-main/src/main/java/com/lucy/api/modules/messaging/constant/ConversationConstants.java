package com.lucy.api.modules.messaging.constant;

public final class ConversationConstants {

    public static final String TABLE_CONVERSATIONS = "conversations";

    public static final String COL_MODE = "mode";
    public static final String COL_COURSE_RUN_ID = "course_run_id";
    public static final String COL_ROOM_ID = "room_id";
    public static final String COL_DIRECT_KEY = "direct_key";
    public static final String COL_GROUP_NAME = "group_name";
    public static final String COL_CREATED_BY = "created_by";
    public static final String COL_STATUS = "status";

    public static final int LENGTH_DIRECT_KEY = 80;
    public static final int LENGTH_GROUP_NAME = 120;
    public static final int LENGTH_CREATED_BY = 36;

    private ConversationConstants() {
    }
}
