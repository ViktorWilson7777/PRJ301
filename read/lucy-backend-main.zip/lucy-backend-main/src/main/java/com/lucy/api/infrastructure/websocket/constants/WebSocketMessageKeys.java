package com.lucy.api.infrastructure.websocket.constants;

/**
 * Key i18n (basename messages) cho nội dung lỗi WebSocket.
 */
public final class WebSocketMessageKeys {

    private WebSocketMessageKeys() {
    }

    public static final String TOKEN_REQUIRED = "websocket.error.token_required";
    public static final String INVALID_TOKEN = "websocket.error.invalid_token";
    public static final String USER_NOT_IN_TOKEN = "websocket.error.user_not_in_token";
    public static final String AUTH_FAILED = "websocket.error.auth_failed";
    public static final String INVALID_MESSAGE = "websocket.error.invalid_message";
    public static final String UNSUPPORTED_TYPE = "websocket.error.unsupported_type";
    public static final String UNAUTHENTICATED = "websocket.error.unauthenticated";
    public static final String PROCESS_FAILED = "websocket.error.process_failed";
    public static final String SESSION_NOT_FOUND = "websocket.error.session_not_found";
    public static final String CONVERSATION_ID_REQUIRED = "websocket.error.conversation_id_required";
    public static final String MESSAGE_CONTENT_REQUIRED = "websocket.error.message_content_required";
    public static final String NOT_JOINED_CONVERSATION = "websocket.error.not_joined_conversation";
    public static final String MESSAGE_SEND_FAILED = "websocket.error.message_send_failed";
}
