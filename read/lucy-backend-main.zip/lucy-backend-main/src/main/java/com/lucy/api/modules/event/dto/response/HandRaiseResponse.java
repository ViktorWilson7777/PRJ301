package com.lucy.api.modules.event.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Response DTO for hand raise events
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HandRaiseResponse {
    private UUID roomId;
    private UUID userId;
    private String displayName;
    private boolean raiseHand;
}
