package com.lucy.api.modules.lms.service.api;

import com.lucy.api.modules.lms.dto.request.LessonUpsertRequest;
import com.lucy.api.modules.lms.dto.response.LessonFileUploadResponse;
import com.lucy.api.modules.lms.dto.response.LessonResponse;
import com.lucy.api.modules.lms.entity.Lesson;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface LessonService {
    LessonResponse create(LessonUpsertRequest request);

    List<LessonResponse> findAll(String chapterId);

    LessonResponse findById(String lessonId);

    LessonResponse update(String lessonId, LessonUpsertRequest request);

    void delete(String lessonId);

    LessonFileUploadResponse attachFileToLesson(String lessonId, MultipartFile file);

    Lesson getEntityById(String lessonId);
}
