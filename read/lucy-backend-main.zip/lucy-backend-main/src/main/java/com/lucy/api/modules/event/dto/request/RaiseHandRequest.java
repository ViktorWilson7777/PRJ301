package com.lucy.api.modules.event.dto.request;

import com.fasterxml.jackson.annotation.JsonAlias;
import jakarta.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.UUID;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RaiseHandRequest {
    private UUID roomId;

    @JsonAlias("raised")
    @NotNull(message = "event.raise_hand_required")
    private Boolean raiseHand;

    public boolean isRaiseHand() {
        return Boolean.TRUE.equals(raiseHand);
    }
}
