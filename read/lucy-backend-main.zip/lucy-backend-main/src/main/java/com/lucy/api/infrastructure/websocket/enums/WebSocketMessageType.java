package com.lucy.api.infrastructure.websocket.enums;

public enum WebSocketMessageType {
    AUTH,
    JOIN_CONVERSATION,
    MESSAGE,
    NOTIFICATION,
    ERROR,
    PING,
    PONG,
    ECHO
}
