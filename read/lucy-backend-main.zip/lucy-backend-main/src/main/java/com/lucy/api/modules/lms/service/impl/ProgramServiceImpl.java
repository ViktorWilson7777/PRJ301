package com.lucy.api.modules.lms.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.lms.dto.request.ProgramUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ProgramResponse;
import com.lucy.api.modules.lms.entity.Program;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.lms.mapper.ProgramMapper;
import com.lucy.api.modules.lms.repository.ProgramRepository;
import com.lucy.api.modules.lms.service.PublicCreatorAccessService;
import com.lucy.api.modules.lms.service.api.ProgramService;
import com.lucy.api.modules.organization.entity.Organization;
import com.lucy.api.modules.organization.repository.OrganizationRepository;
import com.lucy.api.modules.organization.service.OrganizationAccessService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProgramServiceImpl implements ProgramService {
    private final ProgramRepository programRepository;
    private final ProgramMapper programMapper;
    private final PublicCreatorAccessService publicCreatorAccessService;
    private final OrganizationRepository organizationRepository;
    private final OrganizationAccessService organizationAccessService;

    @Override
    @Transactional
    public ProgramResponse create(ProgramUpsertRequest request) {
        return createPublic(request);
    }

    @Override
    @Transactional
    public ProgramResponse createPublic(ProgramUpsertRequest request) {
        User actor = publicCreatorAccessService.assertCanCreatePublicCatalog();
        validateCode(request.getCode(), null, LmsAccessScope.PUBLIC, null);
        Program program = programMapper.toEntity(request);
        program.setAccessScope(LmsAccessScope.PUBLIC);
        program.setOrganization(null);
        program.setOwnerUserId(actor.getId());
        program.setPublishedAt(resolvePublishedAt(request.getIsPublished(), request.getPublishedAt()));
        return programMapper.toResponse(programRepository.save(program));
    }

    @Override
    @Transactional
    public ProgramResponse createForOrganization(String organizationId, ProgramUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        Organization organization = getOrganization(organizationId);
        validateCode(request.getCode(), null, LmsAccessScope.ORGANIZATION, organizationId);
        Program program = programMapper.toEntity(request);
        program.setAccessScope(LmsAccessScope.ORGANIZATION);
        program.setOrganization(organization);
        program.setOwnerUserId(null);
        program.setPublishedAt(resolvePublishedAt(request.getIsPublished(), request.getPublishedAt()));
        return programMapper.toResponse(programRepository.save(program));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProgramResponse> findAll() {
        return findAllPublic();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProgramResponse> findAllPublic() {
        return programRepository.findAllByAccessScopeAndDeletedAtIsNullOrderByCreatedAtDesc(LmsAccessScope.PUBLIC).stream()
                .map(programMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProgramResponse> findAllByOrganization(String organizationId) {
        organizationAccessService.assertActiveMembership(organizationId);
        return programRepository.findAllByOrganization_IdAndDeletedAtIsNullOrderByCreatedAtDesc(organizationId).stream()
                .filter(program -> program.getAccessScope() == LmsAccessScope.ORGANIZATION)
                .map(programMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public ProgramResponse findById(String programId) {
        return findPublicById(programId);
    }

    @Override
    @Transactional(readOnly = true)
    public ProgramResponse findPublicById(String programId) {
        Program program = getEntityById(programId);
        assertPublicProgram(program);
        return programMapper.toResponse(program);
    }

    @Override
    @Transactional(readOnly = true)
    public ProgramResponse findByOrganizationAndId(String organizationId, String programId) {
        organizationAccessService.assertActiveMembership(organizationId);
        Program program = getEntityById(programId);
        assertOrganizationProgram(program, organizationId);
        return programMapper.toResponse(program);
    }

    @Override
    @Transactional
    public ProgramResponse update(String programId, ProgramUpsertRequest request) {
        return updatePublic(programId, request);
    }

    @Override
    @Transactional
    public ProgramResponse updatePublic(String programId, ProgramUpsertRequest request) {
        Program program = getEntityById(programId);
        assertPublicProgram(program);
        publicCreatorAccessService.assertCanManagePublicProgram(program);
        validateCode(request.getCode(), programId, LmsAccessScope.PUBLIC, null);
        programMapper.updateEntity(program, request);
        program.setPublishedAt(resolvePublishedAt(request.getIsPublished(), request.getPublishedAt()));
        return programMapper.toResponse(programRepository.save(program));
    }

    @Override
    @Transactional
    public ProgramResponse updateForOrganization(String organizationId, String programId, ProgramUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        Program program = getEntityById(programId);
        assertOrganizationProgram(program, organizationId);
        validateCode(request.getCode(), programId, LmsAccessScope.ORGANIZATION, organizationId);
        programMapper.updateEntity(program, request);
        program.setPublishedAt(resolvePublishedAt(request.getIsPublished(), request.getPublishedAt()));
        return programMapper.toResponse(programRepository.save(program));
    }

    @Override
    @Transactional
    public void delete(String programId) {
        deletePublic(programId);
    }

    @Override
    @Transactional
    public void deletePublic(String programId) {
        Program program = getEntityById(programId);
        assertPublicProgram(program);
        publicCreatorAccessService.assertCanManagePublicProgram(program);
        program.setDeletedAt(Instant.now());
        programRepository.save(program);
    }

    @Override
    @Transactional
    public void deleteForOrganization(String organizationId, String programId) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        Program program = getEntityById(programId);
        assertOrganizationProgram(program, organizationId);
        program.setDeletedAt(Instant.now());
        programRepository.save(program);
    }

    @Override
    @Transactional(readOnly = true)
    public Program getEntityById(String programId) {
        return programRepository.findByIdAndDeletedAtIsNull(programId)
                .orElseThrow(() -> new AppException("lms.program_not_found", HttpStatus.NOT_FOUND));
    }

    private void validateCode(String code, String currentProgramId, LmsAccessScope scope, String organizationId) {
        String normalizedCode = code.trim();
        boolean existed;
        if (scope == LmsAccessScope.PUBLIC) {
            existed = currentProgramId == null
                    ? programRepository.existsByCodeIgnoreCaseAndAccessScopeAndOrganizationIsNull(normalizedCode, scope)
                    : programRepository.existsByCodeIgnoreCaseAndAccessScopeAndOrganizationIsNullAndIdNot(normalizedCode, scope, currentProgramId);
        } else {
            existed = currentProgramId == null
                    ? programRepository.existsByCodeIgnoreCaseAndOrganization_Id(normalizedCode, organizationId)
                    : programRepository.existsByCodeIgnoreCaseAndOrganization_IdAndIdNot(normalizedCode, organizationId, currentProgramId);
        }
        if (existed) {
            throw new AppException("lms.program_code_exists", HttpStatus.CONFLICT);
        }
    }

    private Instant resolvePublishedAt(Boolean isPublished, Instant publishedAt) {
        if (!Boolean.TRUE.equals(isPublished)) {
            return null;
        }
        return publishedAt != null ? publishedAt : Instant.now();
    }

    private void assertPublicProgram(Program program) {
        if (program.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_program_not_found", HttpStatus.NOT_FOUND);
        }
    }

    private void assertOrganizationProgram(Program program, String organizationId) {
        if (program.getAccessScope() != LmsAccessScope.ORGANIZATION
                || program.getOrganization() == null
                || !organizationId.equals(program.getOrganization().getId())) {
            throw new AppException("lms.organization_program_not_found", HttpStatus.NOT_FOUND);
        }
    }

    private Organization getOrganization(String organizationId) {
        return organizationRepository.findByIdAndDeletedAtIsNull(organizationId)
                .orElseThrow(() -> new AppException("organization.not_found", HttpStatus.NOT_FOUND));
    }
}
