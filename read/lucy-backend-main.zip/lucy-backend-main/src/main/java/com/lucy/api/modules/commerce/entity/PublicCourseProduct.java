package com.lucy.api.modules.commerce.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.commerce.entity.enums.PublicCoursePurchaseType;
import com.lucy.api.modules.lms.entity.CourseRun;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "public_course_products", uniqueConstraints = @UniqueConstraint(name = "public_course_products_run_key", columnNames = "course_run_id"))
public class PublicCourseProduct extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "course_run_id", nullable = false)
    CourseRun courseRun;

    @Column(nullable = false, precision = 19, scale = 2)
    BigDecimal priceAmount;

    @Column(nullable = false, length = 10)
    String currency;

    @Column(nullable = false)
    @Builder.Default
    boolean isActive = true;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    PublicCoursePurchaseType purchaseType = PublicCoursePurchaseType.ONE_TIME;
}
