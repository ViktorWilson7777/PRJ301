package com.lucy.api.modules.commerce.entity.enums;

public enum PublicOrderStatus {
    PENDING,
    PAID,
    FAILED,
    CANCELED,
    REFUNDED
}
