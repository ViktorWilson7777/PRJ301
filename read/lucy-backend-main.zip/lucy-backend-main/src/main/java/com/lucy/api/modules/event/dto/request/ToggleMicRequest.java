package com.lucy.api.modules.event.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Request DTO for toggling microphone status
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ToggleMicRequest {
    private UUID roomId;
    private boolean micEnabled;
}
