package com.lucy.api.modules.messaging.enums;

public enum ParticipantStatus {
    ACTIVE,
    INVITED,
    LEFT,
    KICKED
}
