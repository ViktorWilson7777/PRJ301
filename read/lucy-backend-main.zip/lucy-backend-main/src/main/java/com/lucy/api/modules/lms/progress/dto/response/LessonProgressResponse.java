package com.lucy.api.modules.lms.progress.dto.response;

import com.lucy.api.modules.lms.progress.enums.LessonProgressStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class LessonProgressResponse {
    String id;
    String enrollmentId;
    String lessonId;
    LessonProgressStatus status;
    Integer progressPercent;
    Integer lastPositionSeconds;
    Instant completedAt;
    Instant createdAt;
    Instant updatedAt;
}

