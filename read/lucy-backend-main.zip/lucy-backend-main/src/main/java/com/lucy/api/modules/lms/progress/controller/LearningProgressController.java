package com.lucy.api.modules.lms.progress.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import com.lucy.api.modules.lms.progress.dto.request.SubmitQuizAttemptRequest;
import com.lucy.api.modules.lms.progress.dto.request.UpsertLessonProgressRequest;
import com.lucy.api.modules.lms.progress.dto.response.CourseRunProgressSummaryResponse;
import com.lucy.api.modules.lms.progress.dto.response.LessonProgressResponse;
import com.lucy.api.modules.lms.progress.dto.response.QuizAttemptResultResponse;
import com.lucy.api.modules.lms.progress.service.api.LearningProgressService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/progress")
@Tag(name = "LMS Progress", description = "APIs for tracking learning progress per lesson and course run")
public class LearningProgressController {

    private final LearningProgressService learningProgressService;

    @GetMapping("/me/course-runs/{courseRunId}/summary")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's progress summary for a course run")
    public ResponseEntity<ApiResponse<CourseRunProgressSummaryResponse>> getMyCourseRunSummary(
            @PathVariable String courseRunId
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.<CourseRunProgressSummaryResponse>builder()
                .success(true)
                .data(learningProgressService.getMyCourseRunSummary(userId, courseRunId))
                .build());
    }

    @GetMapping("/me/course-runs/{courseRunId}/lessons")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's per-lesson progress list for a course run")
    public ResponseEntity<ApiResponse<List<LessonProgressResponse>>> getMyLessonProgresses(
            @PathVariable String courseRunId
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.<List<LessonProgressResponse>>builder()
                .success(true)
                .data(learningProgressService.getMyLessonProgresses(userId, courseRunId))
                .build());
    }

    @PutMapping("/me/course-runs/{courseRunId}/lessons/{lessonId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Upsert current user's progress for a lesson within a course run")
    public ResponseEntity<ApiResponse<LessonProgressResponse>> upsertMyLessonProgress(
            @PathVariable String courseRunId,
            @PathVariable String lessonId,
            @Valid @RequestBody UpsertLessonProgressRequest request
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.<LessonProgressResponse>builder()
                .success(true)
                .data(learningProgressService.upsertMyLessonProgress(userId, courseRunId, lessonId, request))
                .build());
    }

        @PutMapping("/me/course-runs/{courseRunId}/lessons/{lessonId}/quiz-attempt")
        @PreAuthorize("isAuthenticated()")
        @Operation(summary = "Submit current user's quiz attempt for a lesson")
        public ResponseEntity<ApiResponse<QuizAttemptResultResponse>> submitMyQuizAttempt(
                        @PathVariable String courseRunId,
                        @PathVariable String lessonId,
                        @Valid @RequestBody SubmitQuizAttemptRequest request
        ) {
                String userId = IdentityUtils.getCurrentUserId();
                return ResponseEntity.ok(ApiResponse.<QuizAttemptResultResponse>builder()
                                .success(true)
                                .data(learningProgressService.submitMyQuizAttempt(userId, courseRunId, lessonId, request))
                                .build());
        }
}

