package com.lucy.api.modules.identity.repository;

import com.lucy.api.modules.identity.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String> {

    Optional<User> findByIdAndDeletedAtIsNull(String id);

    Page<User> findAllByDeletedAtIsNull(Pageable pageable);

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    Optional<User> findByEmailAndDeletedAtIsNull(String email);

    @Query("""
    select u from User u
      left join u.profile p
    where u.deletedAt is null
      and (:keyword is null or (
        lower(coalesce(p.displayName, '')) like concat('%', cast(:keyword as string), '%')
        or lower(u.email) like concat('%', cast(:keyword as string), '%')
      ))
    """)
    Page<User> searchUsers(@Param("keyword") String keyword, Pageable pageable);

    List<User> findTop200ByDeletedAtIsNotNullAndDeletedAtBefore(Instant cutoff);

    @Modifying
    @Query("update UserProfile p set p.speakingMinutesTotal = p.speakingMinutesTotal + :minutes, p.speakingMinutesCurrent = p.speakingMinutesCurrent + :minutes where p.id = :userId")
    void incrementSpeakingMinutesTotal(@Param("userId") String userId, @Param("minutes") int minutes);
}
