package com.lucy.api.modules.event.repository;

import java.time.Instant;
import java.util.UUID;

public interface RoomChatMessageProjection {
    UUID getId();
    UUID getSenderId();
    String getContent();
    Instant getCreatedAt();
}
