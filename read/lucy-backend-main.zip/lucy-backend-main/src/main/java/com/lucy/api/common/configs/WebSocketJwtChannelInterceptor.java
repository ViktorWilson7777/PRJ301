package com.lucy.api.common.configs;

import com.lucy.api.common.constants.JwtClaimSetConstant;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class WebSocketJwtChannelInterceptor implements ChannelInterceptor {
    private final JwtDecoder jwtDecoder;
    private final WebSocketSessionStore webSocketSessionStore;

    @Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {
        StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
        if (accessor == null || !StompCommand.CONNECT.equals(accessor.getCommand())) {
            return message;
        }

        String rawToken = resolveToken(accessor);
        if (!StringUtils.hasText(rawToken)) {
            return message;
        }

        try {
            Jwt jwt = jwtDecoder.decode(rawToken);
            UUID userId = extractUserId(jwt);
            var authentication = new UsernamePasswordAuthenticationToken(userId.toString(), null, List.of());
            accessor.setUser(authentication);
            webSocketSessionStore.put(accessor.getSessionId(), authentication);
            return message;
        } catch (Exception ex) {
            throw new MessagingException("Invalid WebSocket token", ex);
        }
    }

    private String resolveToken(StompHeaderAccessor accessor) {
        String authorization = accessor.getFirstNativeHeader("Authorization");
        if (!StringUtils.hasText(authorization)) {
            authorization = accessor.getFirstNativeHeader("authorization");
        }
        if (!StringUtils.hasText(authorization)) {
            return null;
        }
        if (authorization.startsWith("Bearer ")) {
            return authorization.substring(7);
        }
        return authorization;
    }

    private UUID extractUserId(Jwt jwt) {
        String claimUserId = jwt.getClaimAsString(JwtClaimSetConstant.CLAIM_USER_ID);
        if (!StringUtils.hasText(claimUserId)) {
            claimUserId = jwt.getSubject();
        }
        return UUID.fromString(claimUserId);
    }
}
