package com.lucy.api.modules.identity.constants.user;

public final class UserErrorCodeConstants {

    private UserErrorCodeConstants() {}

    // ===== AUTH (i18n keys) =====
    public static final String AUTH_UNAUTHENTICATED = "auth.unauthenticated";
    public static final String AUTH_USER_NOT_EXISTED = "auth.user_not_existed";
    public static final String AUTH_USER_NOT_VERIFIED = "auth.user_not_verified";
    public static final String AUTH_ROLE_NOT_EXISTED = "auth.role_not_existed";
    public static final String AUTH_INVALID_OTP = "auth.invalid_otp";
    public static final String AUTH_OTP_COOLDOWN = "auth.otp_cooldown";
    public static final String AUTH_WRONG_PASSWORD = "auth.wrong_password";
    public static final String AUTH_PASSWORD_SAME = "auth.password_same";

    // ===== COMMON (i18n keys) =====
    public static final String COMMON_INVALID_PARAM = "common.invalid_param";
    public static final String COMMON_INVALID_UUID = "common.invalid_uuid";

    // ===== USER (i18n keys) =====
    public static final String USER_EMAIL_EXISTED = "user.email_existed";
}


