package com.lucy.api.modules.event.service;

import com.lucy.api.modules.agora.dto.response.AgoraTokenResponse;
import com.lucy.api.modules.agora.service.AgoraTokenService;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.event.constants.MeetingType;
import com.lucy.api.modules.event.constants.RoomStatus;
import com.lucy.api.modules.event.constants.RoomType;
import com.lucy.api.modules.event.dto.request.CreateEventRequest;
import com.lucy.api.modules.event.dto.request.CreateCommentRequest;
import com.lucy.api.modules.event.dto.request.EventFeedRequest;
import com.lucy.api.modules.event.dto.request.InterestRequest;
import com.lucy.api.modules.event.dto.request.LikeRequest;
import com.lucy.api.modules.event.dto.request.MicToggleRequest;
import com.lucy.api.modules.event.dto.request.RaiseHandRequest;
import com.lucy.api.modules.event.dto.response.CommentItemResponse;
import com.lucy.api.modules.event.dto.response.CommentListResponse;
import com.lucy.api.modules.event.dto.response.CreateEventResponse;
import com.lucy.api.modules.event.dto.response.ChatMessageItemResponse;
import com.lucy.api.modules.event.dto.response.ChatMessageListResponse;
import com.lucy.api.modules.event.dto.response.EventDetailResponse;
import com.lucy.api.modules.event.dto.response.EventFeedItemResponse;
import com.lucy.api.modules.event.dto.response.EventFeedResponse;
import com.lucy.api.modules.event.dto.response.JoinEventResponse;
import com.lucy.api.modules.event.dto.response.ParticipantResponse;
import com.lucy.api.modules.event.dto.response.ParticipantRealtimeStateResponse;
import com.lucy.api.modules.event.entity.RoomCommentEntity;
import com.lucy.api.modules.event.entity.RoomChatMessageEntity;
import com.lucy.api.modules.event.entity.RoomEntity;
import com.lucy.api.modules.event.entity.RoomEventEntity;
import com.lucy.api.modules.event.entity.RoomInterestEntity;
import com.lucy.api.modules.event.entity.RoomLikeEntity;
import com.lucy.api.modules.event.entity.RoomCommentLikeEntity;
import com.lucy.api.modules.event.entity.RoomParticipantEntity;
import com.lucy.api.modules.event.entity.RoomParticipantSessionEntity;
import com.lucy.api.modules.event.exception.EventApiException;
import com.lucy.api.modules.event.repository.EventFeedProjection;
import com.lucy.api.modules.event.repository.RoomEventRepository;
import com.lucy.api.modules.event.repository.RoomChatMessageProjection;
import com.lucy.api.modules.event.repository.RoomChatMessageRepository;
import com.lucy.api.modules.event.repository.RoomCommentProjection;
import com.lucy.api.modules.event.repository.RoomCommentRepository;
import com.lucy.api.modules.event.repository.RoomInterestRepository;
import com.lucy.api.modules.event.repository.RoomLikeRepository;
import com.lucy.api.modules.event.repository.RoomCommentLikeRepository;
import com.lucy.api.modules.event.repository.RoomParticipantRepository;
import com.lucy.api.modules.event.repository.RoomParticipantSessionRepository;
import com.lucy.api.modules.event.repository.RoomRepository;
import com.lucy.api.modules.story.entity.AskProfileEntity;
import com.lucy.api.modules.story.repository.AskProfileRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.Optional;
import java.time.Duration;
import java.util.HashMap;
import java.util.Locale;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class EventService {
    private static final int DEFAULT_LIMIT = 20;
    private static final int DEFAULT_COMMENT_LIMIT = 20;

    private final RoomRepository roomRepository;
    private final RoomParticipantRepository roomParticipantRepository;
    private final RoomInterestRepository roomInterestRepository;
    private final RoomLikeRepository roomLikeRepository;
    private final RoomCommentLikeRepository roomCommentLikeRepository;
    private final RoomCommentRepository roomCommentRepository;
    private final RoomChatMessageRepository roomChatMessageRepository;
    private final RoomEventRepository roomEventRepository;
    private final RoomParticipantSessionRepository roomParticipantSessionRepository;
    private final AgoraTokenService agoraTokenService;
    private final RedisRateLimitService rateLimitService;
    private final UserRepository userRepository;
    private final EventRealtimePublisher eventRealtimePublisher;
    private final SocialFeedTickerPublisher socialFeedTickerPublisher;
    private final EventParticipantRealtimeStateService participantRealtimeStateService;
    private final AskProfileRepository askProfileRepository;

    @Transactional
    public CreateEventResponse createEvent(CreateEventRequest request, UUID currentUserId) {
        if (request.getEventDatetime().isBefore(Instant.now())) {
            throw new EventApiException("BAD_REQUEST", "eventDatetime must be in the future", HttpStatus.BAD_REQUEST);
        }

        RoomEntity event = RoomEntity.builder()
                .name(request.getTitle())
                .title(request.getTitle())
                .description(request.getDescription())
                .topic(request.getTopic())
                .category(request.getCategory())
                .level(request.getLevel())
                .meetingType(MeetingType.ONLINE)
                .eventDatetime(request.getEventDatetime())
                .location(emptyToNull(request.getLocation()))
                .maxParticipants(request.getMaxParticipants() == null ? 6 : request.getMaxParticipants())
                .monitorId(currentUserId)
                .status(RoomStatus.SCHEDULED)
                .roomType(RoomType.EVENT)
                .likesCount(0)
                .commentsCount(0)
                .interestedCount(0)
                .build();

        RoomEntity saved = roomRepository.save(event);
        appendRoomEvent(saved.getId(), currentUserId, "event_created", Map.of("status", RoomStatus.SCHEDULED));
        publishTickerAfterCommit("EVENT_CREATED", "event", saved.getId(), currentUserId, Map.of(
                "status", RoomStatus.SCHEDULED,
                "title", saved.getTitle(),
                "eventDatetime", saved.getEventDatetime()
        ));
        return CreateEventResponse.builder()
                .eventId(saved.getId())
                .status(saved.getStatus())
                .build();
    }

    @Transactional(readOnly = true)
    public EventFeedResponse listEvents(EventFeedRequest request, UUID currentUserId) {
        int limit = request.getLimit() == null ? DEFAULT_LIMIT : request.getLimit();
        if (limit < 1 || limit > 50) {
            throw new EventApiException("BAD_REQUEST", "limit must be between 1 and 50", HttpStatus.BAD_REQUEST);
        }
        EventCursorUtil.CursorData cursor = null;
        if (StringUtils.hasText(request.getCursor())) {
            cursor = EventCursorUtil.decode(request.getCursor());
        }
        Instant from = parseInstantOrNull(request.getFrom(), "from");
        Instant to = parseInstantOrNull(request.getTo(), "to");
        String keyword = normalizeQueryKeyword(request.getQuery());

        List<EventFeedProjection> projections = roomRepository.findEventFeed(
                emptyToNull(request.getStatus()),
                Boolean.TRUE.equals(request.getMine()) ? currentUserId : null,
                Boolean.TRUE.equals(request.getInterested()) ? currentUserId : null,
                from,
                to,
                keyword,
                cursor != null ? cursor.eventDatetime() : null,
                cursor != null ? cursor.id() : null,
                PageRequest.of(0, limit + 1)
        );

        boolean hasMore = projections.size() > limit;
        List<EventFeedProjection> page = hasMore ? projections.subList(0, limit) : projections;
        Map<String, User> monitorsById = new HashMap<>();
        List<String> monitorIds = page.stream()
                .map(EventFeedProjection::getMonitorId)
                .filter(java.util.Objects::nonNull)
                .map(UUID::toString)
                .distinct()
                .toList();
        userRepository.findAllById(monitorIds)
                .forEach(user -> monitorsById.put(user.getId(), user));
        String nextCursor = null;
        if (hasMore && !page.isEmpty()) {
            EventFeedProjection last = page.getLast();
            nextCursor = EventCursorUtil.encode(last.getEventDatetime(), last.getId());
        }

        return EventFeedResponse.builder()
                .items(page.stream().map(item -> toFeedItem(item, monitorsById.get(item.getMonitorId() == null ? null : item.getMonitorId().toString()), currentUserId)).toList())
                .hasMore(hasMore)
                .nextCursor(nextCursor)
                .build();
    }

    @Transactional(readOnly = true)
    public EventDetailResponse getEventDetail(UUID eventId, UUID currentUserId) {
        RoomEntity event = getEvent(eventId);
        long participants = roomParticipantRepository.countByRoomId(event.getId());
        return toDetail(event, participants, currentUserId);
    }

    @Transactional
    public JoinEventResponse joinEvent(UUID eventId, UUID currentUserId) {
        RoomEntity room = getEvent(eventId);
        ensureRoomJoinable(room);

        String rateKey = "join:" + currentUserId;
        if (!rateLimitService.allow(rateKey, 20, 60)) {
            throw new EventApiException("TOO_MANY_REQUESTS", "Too many join requests", HttpStatus.TOO_MANY_REQUESTS);
        }

        boolean alreadyJoined = roomParticipantRepository.findByRoomIdAndUserId(room.getId(), currentUserId).isPresent();
        RoomParticipantEntity participant = roomParticipantRepository.findByRoomIdAndUserId(room.getId(), currentUserId)
                .orElseGet(() -> roomParticipantRepository.save(RoomParticipantEntity.builder()
                        .roomId(room.getId())
                        .userId(currentUserId)
                        .isMonitor(currentUserId.equals(room.getMonitorId()))
                        .micEnabled(false)
                        .role("participant")
                        .build()));

        long participantCount = roomParticipantRepository.countByRoomId(room.getId());
        if (participantCount > room.getMaxParticipants()) {
            throw new EventApiException("ROOM_FULL", "Room is full", HttpStatus.CONFLICT);
        }

        int uid = generateRtcUid(currentUserId);
        AgoraTokenResponse tokenResponse = agoraTokenService.generateRtcToken(buildChannelId(room.getId()), uid);
        participantRealtimeStateService.setMicState(room.getId(), room.getId(), currentUserId, false);
        participantRealtimeStateService.setRaisedState(room.getId(), room.getId(), currentUserId, false);
        openParticipationSession(room.getId(), currentUserId);
        if (!alreadyJoined) {
            appendRoomEvent(room.getId(), currentUserId, "participant_joined", Map.of("uid", uid, "participantId", participant.getId()));
            publishAfterCommit(() -> eventRealtimePublisher.publishParticipantJoined(room.getId(), currentUserId, participantCount));
            publishTickerAfterCommit("PARTICIPANT_JOINED", "room", room.getId(), currentUserId, Map.of(
                    "participantCount", participantCount,
                    "participantId", participant.getId()
            ));
        }

        return JoinEventResponse.builder()
                .roomId(room.getId())
                .channelId(tokenResponse.getChannelId())
                .uid(uid)
                .token(tokenResponse.getToken())
                .expireAt(tokenResponse.getExpireAt())
                .build();
    }

    @Transactional
    public JoinEventResponse issueRtcToken(UUID eventId, UUID currentUserId) {
        RoomEntity room = getEvent(eventId);
        roomParticipantRepository.findByRoomIdAndUserId(room.getId(), currentUserId)
                .orElseThrow(() -> new EventApiException("FORBIDDEN", "Join room before requesting token", HttpStatus.FORBIDDEN));

        String rateKey = "rtc_token:" + currentUserId;
        if (!rateLimitService.allow(rateKey, 30, 60)) {
            throw new EventApiException("TOO_MANY_REQUESTS", "Too many token requests", HttpStatus.TOO_MANY_REQUESTS);
        }

        int uid = generateRtcUid(currentUserId);
        AgoraTokenResponse tokenResponse = agoraTokenService.generateRtcToken(buildChannelId(room.getId()), uid);
        return JoinEventResponse.builder()
                .roomId(room.getId())
                .channelId(tokenResponse.getChannelId())
                .uid(uid)
                .token(tokenResponse.getToken())
                .expireAt(tokenResponse.getExpireAt())
                .build();
    }

    @Transactional
    public void updateInterest(UUID eventId, InterestRequest request, UUID currentUserId) {
        RoomEntity room = getEvent(eventId);
        var existed = roomInterestRepository.findByRoomIdAndUserId(room.getId(), currentUserId);
        if (Boolean.TRUE.equals(request.getInterested())) {
            if (existed.isEmpty()) {
                roomInterestRepository.save(RoomInterestEntity.builder()
                        .roomId(room.getId())
                        .userId(currentUserId)
                        .createdAt(Instant.now())
                        .build());
                roomRepository.incrementInterestedCount(room.getId(), 1);
                long interestedCount = roomInterestRepository.countByRoomId(room.getId());
                publishAfterCommit(() -> eventRealtimePublisher.publishInterestUpdated(room.getId(), currentUserId, true, interestedCount));
                publishTickerAfterCommit("INTEREST_UPDATED", "event", room.getId(), currentUserId, Map.of(
                        "interested", true,
                        "interestedCount", interestedCount
                ));
            }
            return;
        }
        existed.ifPresent(it -> {
            roomInterestRepository.delete(it);
            roomRepository.incrementInterestedCount(room.getId(), -1);
            long interestedCount = roomInterestRepository.countByRoomId(room.getId());
            publishAfterCommit(() -> eventRealtimePublisher.publishInterestUpdated(room.getId(), currentUserId, false, interestedCount));
            publishTickerAfterCommit("INTEREST_UPDATED", "event", room.getId(), currentUserId, Map.of(
                    "interested", false,
                    "interestedCount", interestedCount
            ));
        });
    }

    @Transactional
    public void updateLike(UUID eventId, LikeRequest request, UUID currentUserId) {
        RoomEntity room = getEvent(eventId);
        var existed = roomLikeRepository.findByRoomIdAndUserId(room.getId(), currentUserId);
        boolean changed = false;
        boolean likedState = Boolean.TRUE.equals(request.getLiked());
        if (Boolean.TRUE.equals(request.getLiked())) {
            if (existed.isEmpty()) {
                roomLikeRepository.save(RoomLikeEntity.builder()
                        .roomId(room.getId())
                        .userId(currentUserId)
                        .createdAt(Instant.now())
                        .build());
                roomRepository.incrementLikesCount(room.getId(), 1);
                changed = true;
            }
        } else {
            if (existed.isPresent()) {
                roomLikeRepository.delete(existed.get());
                roomRepository.incrementLikesCount(room.getId(), -1);
                changed = true;
            }
        }

        if (changed) {
            long likesCount = roomLikeRepository.countByRoomId(room.getId());
            publishAfterCommit(() -> eventRealtimePublisher.publishLikeUpdated(room.getId(), currentUserId, likedState, likesCount));
            publishTickerAfterCommit("LIKE_UPDATED", "event", room.getId(), currentUserId, Map.of(
                    "liked", likedState,
                    "likesCount", likesCount
            ));
        }
    }

    @Transactional
    public CommentItemResponse createComment(UUID eventId, CreateCommentRequest request, UUID currentUserId) {
        RoomEntity room = getEvent(eventId);
        
        RoomCommentEntity comment = RoomCommentEntity.builder()
                .roomId(room.getId())
                .userId(currentUserId)
                .content(request.getContent().trim())
                .level(1)
                .createdAt(Instant.now())
                .build();

        if (request.getParentId() != null) {
            RoomCommentEntity parent = roomCommentRepository.findById(request.getParentId())
                    .orElseThrow(() -> new EventApiException("NOT_FOUND", "Parent comment not found", HttpStatus.NOT_FOUND));
            
            if (!parent.getRoomId().equals(eventId)) {
                throw new EventApiException("BAD_REQUEST", "Parent comment does not belong to this event", HttpStatus.BAD_REQUEST);
            }

            UUID rootId = parent.getParentId() != null ? parent.getParentId() : parent.getId();
            comment.setParentId(rootId);
            comment.setLevel(2);

            roomCommentRepository.incrementRepliesCount(rootId, 1);
        }

        RoomCommentEntity savedComment = roomCommentRepository.save(comment);
        roomRepository.incrementCommentsCount(room.getId(), 1);
        long commentsCount = roomCommentRepository.countByRoomId(room.getId());
        publishAfterCommit(() -> eventRealtimePublisher.publishCommentCreated(
                room.getId(),
                currentUserId,
                savedComment.getId(),
                savedComment.getContent(),
                savedComment.getCreatedAt(),
                commentsCount
        ));
        publishTickerAfterCommit("COMMENT_CREATED", "event", room.getId(), currentUserId, Map.of(
                "commentId", savedComment.getId(),
                "content", savedComment.getContent(),
                "createdAt", savedComment.getCreatedAt(),
                "commentsCount", commentsCount
        ));

        User author = userRepository.findByIdAndDeletedAtIsNull(currentUserId.toString()).orElse(null);
        String displayName = resolveDisplayName(author != null && author.getProfile() != null ? author.getProfile().getDisplayName() : null);
        String avatarUrl = author != null && author.getProfile() != null ? author.getProfile().getAvatarUrl() : null;

        return CommentItemResponse.builder()
                .id(savedComment.getId())
                .userId(savedComment.getUserId())
                .parentId(savedComment.getParentId())
                .content(savedComment.getContent())
                .level(savedComment.getLevel())
                .likesCount(0)
                .repliesCount(0)
                .isLiked(false)
                .createdAt(savedComment.getCreatedAt())
                .userDisplayName(displayName)
                .userAvatarUrl(avatarUrl)
                .replies(List.of())
                .build();
    }

    @Transactional
    public void toggleLikeComment(UUID commentId, UUID currentUserId) {
        if (!roomCommentRepository.existsById(commentId)) {
            throw new EventApiException("NOT_FOUND", "Comment not found", HttpStatus.NOT_FOUND);
        }

        Optional<RoomCommentLikeEntity> existingLike = roomCommentLikeRepository.findByCommentIdAndUserId(commentId, currentUserId);
        int delta;
        if (existingLike.isPresent()) {
            roomCommentLikeRepository.delete(existingLike.get());
            delta = -1;
        } else {
            roomCommentLikeRepository.save(RoomCommentLikeEntity.builder()
                    .commentId(commentId)
                    .userId(currentUserId)
                    .build());
            delta = 1;
        }
        roomCommentRepository.incrementLikesCount(commentId, delta);
    }

    @Transactional
    public void deleteComment(UUID commentId, UUID currentUserId) {
        RoomCommentEntity comment = roomCommentRepository.findById(commentId)
                .orElseThrow(() -> new EventApiException("NOT_FOUND", "Comment not found", HttpStatus.NOT_FOUND));

        if (!comment.getUserId().equals(currentUserId)) {
            throw new EventApiException("FORBIDDEN", "You can only delete your own comments", HttpStatus.FORBIDDEN);
        }

        comment.setDeletedAt(Instant.now());
        roomCommentRepository.save(comment);

        roomRepository.incrementCommentsCount(comment.getRoomId(), -1);
        
        if (comment.getParentId() != null) {
            roomCommentRepository.incrementRepliesCount(comment.getParentId(), -1);
        }
    }

    @Transactional
    public void leaveEvent(UUID eventId, UUID currentUserId) {
        leaveEventInternal(eventId, currentUserId, payload ->
                appendRoomEvent(eventId, currentUserId, "participant_left", payload)
        );
    }

    @Transactional
    public void leaveEventOnDisconnect(UUID eventId, UUID currentUserId) {
        leaveEventInternal(eventId, currentUserId, payload ->
                appendRoomEvent(eventId, currentUserId, "participant_left", payload)
        );
    }

    @Transactional(readOnly = true)
    public CommentListResponse listComments(UUID eventId, String cursor, Integer limit, UUID currentUserId) {
        RoomEntity room = getEvent(eventId);
        int validatedLimit = limit == null ? DEFAULT_COMMENT_LIMIT : limit;
        if (validatedLimit < 1 || validatedLimit > 50) {
            throw new EventApiException("BAD_REQUEST", "limit must be between 1 and 50", HttpStatus.BAD_REQUEST);
        }

        CommentCursorUtil.CursorData cursorData = null;
        if (StringUtils.hasText(cursor)) {
            cursorData = CommentCursorUtil.decode(cursor);
        }

        List<RoomCommentProjection> projections = roomCommentRepository.findCommentsByRoomId(
                room.getId(),
                cursorData != null ? cursorData.createdAt() : null,
                cursorData != null ? cursorData.id() : null,
                PageRequest.of(0, validatedLimit + 1)
        );

        boolean hasMore = projections.size() > validatedLimit;
        List<RoomCommentProjection> page = hasMore ? projections.subList(0, validatedLimit) : projections;
        String nextCursor = null;
        if (hasMore && !page.isEmpty()) {
            RoomCommentProjection last = page.getLast();
            nextCursor = CommentCursorUtil.encode(last.getCreatedAt(), last.getId());
        }

        return CommentListResponse.builder()
                .items(page.stream().map(item -> toCommentItem(item, currentUserId)).toList())
                .hasMore(hasMore)
                .nextCursor(nextCursor)
                .build();
    }

    @Transactional
    public void startRoom(UUID roomId, UUID currentUserId) {
        RoomEntity room = getEvent(roomId);
        validateHostPermission(room, currentUserId);
        room.setStatus(RoomStatus.LIVE);
        room.setStartedAt(Instant.now());
        roomRepository.save(room);
        appendRoomEvent(room.getId(), currentUserId, "room_started", Map.of());
        publishTickerAfterCommit("ROOM_STARTED", "room", room.getId(), currentUserId, Map.of());
    }

    @Transactional
    public void endRoom(UUID roomId, UUID currentUserId) {
        RoomEntity room = getEvent(roomId);
        validateHostPermission(room, currentUserId);
        roomParticipantSessionRepository.findByRoomIdAndLeftAtIsNull(roomId)
                .forEach(session -> closeSessionAndReward(session.getRoomId(), session.getUserId()));
        room.setStatus(RoomStatus.ENDED);
        roomRepository.save(room);
        appendRoomEvent(room.getId(), currentUserId, "room_ended", Map.of());
        publishTickerAfterCommit("ROOM_ENDED", "room", room.getId(), currentUserId, Map.of());
    }

    @Transactional(readOnly = true)
    public List<ParticipantResponse> listParticipants(UUID roomId) {
        getEvent(roomId);
        List<RoomParticipantEntity> participants = roomParticipantRepository.findByRoomIdOrderByJoinedAtAsc(roomId);
        Map<String, String> displayNamesByUserId = userRepository.findAllById(
                        participants.stream()
                                .map(RoomParticipantEntity::getUserId)
                                .map(UUID::toString)
                                .toList()
                ).stream()
                .collect(Collectors.toMap(User::getId, u -> u.getProfile() != null ? u.getProfile().getDisplayName() : null));

        return participants.stream()
                .map(item -> ParticipantResponse.builder()
                        .userId(item.getUserId())
                        .displayName(resolveDisplayName(displayNamesByUserId.get(item.getUserId().toString())))
                        .monitor(item.isMonitor())
                        .role(item.getRole())
                        .micEnabled(item.isMicEnabled())
                        .raiseHand(item.isRaiseHand() || participantRealtimeStateService.isRaised(roomId, roomId, item.getUserId()))
                        .joinedAt(item.getJoinedAt())
                        .rtcUid(generateRtcUid(item.getUserId()))
                        .build())
                .toList();
    }

    @Transactional(readOnly = true)
    public List<ParticipantResponse> listParticipants(UUID eventId, UUID roomId) {
        validateRoomPath(eventId, roomId);
        return listParticipants(roomId);
    }

    @Transactional
    public void toggleMic(UUID eventId, UUID roomId, MicToggleRequest request, UUID currentUserId) {
        RoomParticipantEntity participant = requireParticipant(eventId, roomId, currentUserId);
        boolean enabled = Boolean.TRUE.equals(request.getEnabled());
        participant.setMicEnabled(enabled);
        roomParticipantRepository.save(participant);
        participantRealtimeStateService.setMicState(eventId, roomId, currentUserId, enabled);
        appendRoomEvent(roomId, currentUserId, "mic_toggled", Map.of("enabled", enabled));
        publishAfterCommit(() -> eventRealtimePublisher.publishMicToggled(roomId, currentUserId, enabled));
        publishTickerAfterCommit("MIC_TOGGLED", "room", roomId, currentUserId, Map.of("enabled", enabled));
    }

    @Transactional
    public void monitorToggleMic(UUID eventId,
                                 UUID roomId,
                                 UUID participantUserId,
                                 MicToggleRequest request,
                                 UUID currentUserId) {
        RoomEntity room = getEvent(eventId);
        if (!room.getId().equals(roomId)) {
            throw new EventApiException("BAD_REQUEST", "roomId does not match eventId", HttpStatus.BAD_REQUEST);
        }
        if (!room.getMonitorId().equals(currentUserId)) {
            throw new EventApiException("FORBIDDEN", "Only monitor can toggle participant mic", HttpStatus.FORBIDDEN);
        }

        RoomParticipantEntity participant = roomParticipantRepository.findByRoomIdAndUserId(roomId, participantUserId)
                .orElseThrow(() -> new EventApiException("NOT_FOUND", "Participant not found in room", HttpStatus.NOT_FOUND));
        boolean enabled = Boolean.TRUE.equals(request.getEnabled());
        participant.setMicEnabled(enabled);
        roomParticipantRepository.save(participant);
        participantRealtimeStateService.setMicState(eventId, roomId, participantUserId, enabled);
        appendRoomEvent(roomId, currentUserId, "monitor_mic_toggled", Map.of(
                "targetUserId", participantUserId,
                "enabled", enabled
        ));
        publishAfterCommit(() -> eventRealtimePublisher.publishMicToggled(roomId, participantUserId, enabled));
        publishTickerAfterCommit("MIC_TOGGLED", "room", roomId, currentUserId, Map.of(
                "targetUserId", participantUserId,
                "enabled", enabled
        ));
    }

    @Transactional
    public void updateMicStatus(UUID roomId, UUID userId, boolean enabled) {
        RoomParticipantEntity participant = requireParticipant(roomId, roomId, userId);
        participant.setMicEnabled(enabled);
        roomParticipantRepository.save(participant);
        participantRealtimeStateService.setMicState(roomId, roomId, userId, enabled);
        appendRoomEvent(roomId, userId, "mic_toggled", Map.of("enabled", enabled));
        publishAfterCommit(() -> eventRealtimePublisher.publishMicToggled(roomId, userId, enabled));
        publishTickerAfterCommit("MIC_TOGGLED", "room", roomId, userId, Map.of("enabled", enabled));
    }

    @Transactional
    public void updateRaiseHand(UUID eventId, UUID roomId, RaiseHandRequest request, UUID currentUserId) {
        RoomParticipantEntity participant = requireParticipant(eventId, roomId, currentUserId);
        boolean raised = Boolean.TRUE.equals(request.getRaiseHand());
        participant.setRaiseHand(raised);
        roomParticipantRepository.save(participant);
        int handCount = participantRealtimeStateService.setRaisedState(eventId, roomId, currentUserId, raised);
        appendRoomEvent(roomId, currentUserId, raised ? "hand_raised" : "hand_lowered", Map.of("raised", raised));
        publishAfterCommit(() -> eventRealtimePublisher.publishHandStatusChanged(roomId, currentUserId, raised, handCount));
        publishTickerAfterCommit("HAND_STATUS_CHANGED", "room", roomId, currentUserId, Map.of(
                "raised", raised,
                "handCount", handCount
        ));
    }

    @Transactional
    public void updateRaiseHand(UUID roomId, UUID userId, boolean raised) {
        RoomParticipantEntity participant = requireParticipant(roomId, roomId, userId);
        participant.setRaiseHand(raised);
        roomParticipantRepository.save(participant);
        int handCount = participantRealtimeStateService.setRaisedState(roomId, roomId, userId, raised);
        appendRoomEvent(roomId, userId, raised ? "hand_raised" : "hand_lowered", Map.of("raised", raised));
        publishAfterCommit(() -> eventRealtimePublisher.publishHandStatusChanged(roomId, userId, raised, handCount));
        publishTickerAfterCommit("HAND_STATUS_CHANGED", "room", roomId, userId, Map.of(
                "raised", raised,
                "handCount", handCount
        ));
    }
    
    @Transactional
    public RoomChatMessageEntity saveChatMessage(UUID roomId, UUID userId, String content) {
        return roomChatMessageRepository.save(RoomChatMessageEntity.builder()
                .roomId(roomId)
                .senderId(userId)
                .content(content.trim())
                .messageType("text")
                .createdAt(Instant.now())
                .build());
    }

    @Transactional(readOnly = true)
    public ChatMessageListResponse listRoomChatMessages(UUID roomId, String cursor, Integer limit) {
        getEvent(roomId);
        int validatedLimit = limit == null ? DEFAULT_COMMENT_LIMIT : limit;
        if (validatedLimit < 1 || validatedLimit > 50) {
            throw new EventApiException("BAD_REQUEST", "limit must be between 1 and 50", HttpStatus.BAD_REQUEST);
        }

        CommentCursorUtil.CursorData cursorData = null;
        if (StringUtils.hasText(cursor)) {
            cursorData = CommentCursorUtil.decode(cursor);
        }

        List<RoomChatMessageProjection> projections = roomChatMessageRepository.findByRoomId(
                roomId,
                cursorData != null ? cursorData.createdAt() : null,
                cursorData != null ? cursorData.id() : null,
                PageRequest.of(0, validatedLimit + 1)
        );
        boolean hasMore = projections.size() > validatedLimit;
        List<RoomChatMessageProjection> page = hasMore ? projections.subList(0, validatedLimit) : projections;
        String nextCursor = null;
        if (hasMore && !page.isEmpty()) {
            RoomChatMessageProjection last = page.getLast();
            nextCursor = CommentCursorUtil.encode(last.getCreatedAt(), last.getId());
        }

        return ChatMessageListResponse.builder()
                .items(page.stream().map(this::toChatMessageItem).toList())
                .nextCursor(nextCursor)
                .hasMore(hasMore)
                .build();
    }

    @Transactional(readOnly = true)
    public ParticipantResponse requireParticipantState(UUID roomId, UUID userId) {
        RoomParticipantEntity participant = requireParticipant(roomId, roomId, userId);
        String name = resolveDisplayName(userRepository.findByIdAndDeletedAtIsNull(userId.toString()).map(u -> u.getProfile() != null ? u.getProfile().getDisplayName() : null).orElse(null));
        return ParticipantResponse.builder()
                .userId(userId)
                .displayName(name)
                .monitor(participant.isMonitor())
                .role(participant.getRole())
                .micEnabled(participant.isMicEnabled())
                .raiseHand(participant.isRaiseHand() || participantRealtimeStateService.isRaised(roomId, roomId, userId))
                .joinedAt(participant.getJoinedAt())
                .rtcUid(generateRtcUid(userId))
                .build();
    }

    @Transactional(readOnly = true)
    public java.util.Optional<ParticipantResponse> findParticipantState(UUID roomId, UUID userId) {
        return roomParticipantRepository.findByRoomIdAndUserId(roomId, userId)
                .map(participant -> {
                    String name = resolveDisplayName(userRepository.findByIdAndDeletedAtIsNull(userId.toString()).map(u -> u.getProfile() != null ? u.getProfile().getDisplayName() : null).orElse(null));
                    return ParticipantResponse.builder()
                            .userId(userId)
                            .displayName(name)
                            .monitor(participant.isMonitor())
                            .role(participant.getRole())
                            .micEnabled(participant.isMicEnabled())
                            .raiseHand(participant.isRaiseHand() || participantRealtimeStateService.isRaised(roomId, roomId, userId))
                            .joinedAt(participant.getJoinedAt())
                            .rtcUid(generateRtcUid(userId))
                            .build();
                });
    }

    @Transactional(readOnly = true)
    public com.lucy.api.modules.event.dto.response.ParticipantSnapshotResponse getParticipantSnapshot(UUID roomId) {
        List<ParticipantResponse> participants = listParticipants(roomId);
        return com.lucy.api.modules.event.dto.response.ParticipantSnapshotResponse.builder()
                .roomId(roomId)
                .totalParticipants(participants.size())
                .participants(participants)
                .generatedAt(Instant.now())
                .build();
    }

    @Transactional(readOnly = true)
    public ParticipantRealtimeStateResponse getRealtimeParticipantState(UUID eventId, UUID roomId) {
        validateRoomPath(eventId, roomId);
        return ParticipantRealtimeStateResponse.builder()
                .micStates(participantRealtimeStateService.getMicStates(eventId, roomId))
                .handQueue(participantRealtimeStateService.getHandQueue(eventId, roomId))
                .build();
    }

    private void appendRoomEvent(UUID roomId, UUID userId, String type, Map<String, Object> payload) {
        roomEventRepository.save(RoomEventEntity.builder()
                .roomId(roomId)
                .userId(userId)
                .type(type)
                .payload(payload)
                .createdAt(Instant.now())
                .build());
    }

    private void publishAfterCommit(Runnable callback) {
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    callback.run();
                }
            });
            return;
        }
        callback.run();
    }

    private void leaveEventInternal(UUID eventId, UUID currentUserId, Consumer<Map<String, Object>> appendEvent) {
        RoomEntity room = getEvent(eventId);
        RoomParticipantEntity participant = roomParticipantRepository.findByRoomIdAndUserId(room.getId(), currentUserId)
                .orElse(null);
        if (participant == null) {
            return;
        }

        roomParticipantRepository.delete(participant);
        closeSessionAndReward(room.getId(), currentUserId);
        participantRealtimeStateService.removeParticipantState(room.getId(), room.getId(), currentUserId);
        long participantCount = roomParticipantRepository.countByRoomId(room.getId());
        appendEvent.accept(Map.of("participantId", participant.getId()));
        publishAfterCommit(() -> eventRealtimePublisher.publishParticipantLeft(room.getId(), currentUserId, participantCount));
        publishTickerAfterCommit("PARTICIPANT_LEFT", "room", room.getId(), currentUserId, Map.of(
                "participantCount", participantCount,
                "participantId", participant.getId()
        ));
    }

    private void publishTickerAfterCommit(String type,
                                          String entityType,
                                          UUID entityId,
                                          UUID actorUserId,
                                          Map<String, Object> data) {
        publishAfterCommit(() -> socialFeedTickerPublisher.publish(type, entityType, entityId, actorUserId, data));
    }

    private RoomEntity getEvent(UUID eventId) {
        return roomRepository.findEventById(eventId)
                .orElseThrow(() -> new EventApiException("NOT_FOUND", "Event not found", HttpStatus.NOT_FOUND));
    }

    private RoomParticipantEntity requireParticipant(UUID eventId, UUID roomId, UUID currentUserId) {
        validateRoomPath(eventId, roomId);
        return roomParticipantRepository.findByRoomIdAndUserId(roomId, currentUserId)
                .orElseThrow(() -> new EventApiException("FORBIDDEN", "Join room before performing this action", HttpStatus.FORBIDDEN));
    }

    private void validateRoomPath(UUID eventId, UUID roomId) {
        RoomEntity room = getEvent(eventId);
        if (!room.getId().equals(roomId)) {
            throw new EventApiException("BAD_REQUEST", "roomId does not match eventId", HttpStatus.BAD_REQUEST);
        }
    }

    private void ensureRoomJoinable(RoomEntity room) {
        if (!RoomStatus.SCHEDULED.equals(room.getStatus()) && !RoomStatus.LIVE.equals(room.getStatus())) {
            throw new EventApiException("ROOM_NOT_JOINABLE", "Room is not joinable", HttpStatus.CONFLICT);
        }
    }

    private void validateHostPermission(RoomEntity room, UUID userId) {
        if (!room.getMonitorId().equals(userId)) {
            throw new EventApiException("FORBIDDEN", "Only host can perform this action", HttpStatus.FORBIDDEN);
        }
    }

    private String buildChannelId(UUID roomId) {
        return "event_" + roomId.toString().replace("-", "").substring(0, 20);
    }

    private int generateRtcUid(UUID userId) {
        return Math.abs(userId.hashCode());
    }

    private EventFeedItemResponse toFeedItem(EventFeedProjection item, User monitor, UUID currentUserId) {
        boolean isLiked = currentUserId != null && roomLikeRepository.findByRoomIdAndUserId(item.getId(), currentUserId).isPresent();
        boolean isInterested = currentUserId != null && roomInterestRepository.findByRoomIdAndUserId(item.getId(), currentUserId).isPresent();

        return EventFeedItemResponse.builder()
                .id(item.getId())
                .title(item.getTitle())
                .description(item.getDescription())
                .topic(item.getTopic())
                .category(item.getCategory())
                .level(item.getLevel())
                .status(item.getStatus())
                .eventDatetime(item.getEventDatetime())
                .location(item.getLocation())
                .maxParticipants(item.getMaxParticipants())
                .interestedCount(item.getInterestedCount())
                .likesCount(item.getLikesCount())
                .commentsCount(item.getCommentsCount())
                .monitorId(item.getMonitorId())
                .monitorDisplayName(resolveMonitorDisplayName(monitor))
                .monitorAvatarUrl(monitor != null && monitor.getProfile() != null ? monitor.getProfile().getAvatarUrl() : null)
                .isLiked(isLiked)
                .isInterested(isInterested)
                .build();
    }

    private EventDetailResponse toDetail(RoomEntity room, long participantCount, UUID currentUserId) {
        boolean isLiked = currentUserId != null && roomLikeRepository.findByRoomIdAndUserId(room.getId(), currentUserId).isPresent();
        boolean isInterested = currentUserId != null && roomInterestRepository.findByRoomIdAndUserId(room.getId(), currentUserId).isPresent();

        return EventDetailResponse.builder()
                .id(room.getId())
                .title(room.getTitle())
                .description(room.getDescription())
                .topic(room.getTopic())
                .category(room.getCategory())
                .level(room.getLevel())
                .status(room.getStatus())
                .eventDatetime(room.getEventDatetime())
                .location(room.getLocation())
                .maxParticipants(room.getMaxParticipants())
                .interestedCount(room.getInterestedCount())
                .likesCount(room.getLikesCount())
                .commentsCount(room.getCommentsCount())
                .monitorId(room.getMonitorId())
                .startedAt(room.getStartedAt())
                .participantCount((int) participantCount)
                .isLiked(isLiked)
                .isInterested(isInterested)
                .build();
    }

    private CommentItemResponse toCommentItem(RoomCommentProjection item, UUID currentUserId) {
        boolean isLiked = currentUserId != null && roomCommentLikeRepository.findByCommentIdAndUserId(item.getId(), currentUserId).isPresent();
        
        List<CommentItemResponse> replies = List.of();
        if (item.getLevel() == 1 && item.getRepliesCount() > 0) {
            replies = roomCommentRepository.findRepliesByParentId(item.getId())
                    .stream()
                    .map(reply -> toCommentItem(reply, currentUserId))
                    .toList();
        }

        return CommentItemResponse.builder()
                .id(item.getId())
                .userId(item.getUserId())
                .parentId(item.getParentId())
                .content(item.getContent())
                .level(item.getLevel())
                .likesCount(item.getLikesCount())
                .repliesCount(item.getRepliesCount())
                .isLiked(isLiked)
                .createdAt(item.getCreatedAt())
                .userDisplayName(item.getUserDisplayName())
                .userAvatarUrl(item.getUserAvatarUrl())
                .replies(replies)
                .build();
    }

    private ChatMessageItemResponse toChatMessageItem(RoomChatMessageProjection item) {
        return ChatMessageItemResponse.builder()
                .id(item.getId())
                .senderId(item.getSenderId())
                .content(item.getContent())
                .createdAt(item.getCreatedAt())
                .build();
    }

    private void openParticipationSession(UUID roomId, UUID userId) {
        roomParticipantSessionRepository.findByRoomIdAndUserIdAndLeftAtIsNull(roomId, userId)
                .orElseGet(() -> roomParticipantSessionRepository.save(RoomParticipantSessionEntity.builder()
                        .roomId(roomId)
                        .userId(userId)
                        .joinedAt(Instant.now())
                        .rewardedMinutes(0)
                        .build()));
    }

    private void closeSessionAndReward(UUID roomId, UUID userId) {
        roomParticipantSessionRepository.findByRoomIdAndUserIdAndLeftAtIsNull(roomId, userId)
                .ifPresent(session -> {
                    Instant leftAt = Instant.now();
                    session.setLeftAt(leftAt);
                    long minutes = Math.max(0, Duration.between(session.getJoinedAt(), leftAt).toMinutes());
                    int rewarded = Math.toIntExact(minutes);
                    session.setRewardedMinutes(rewarded);
                    roomParticipantSessionRepository.save(session);
                    rewardAskByMinutes(userId, rewarded);
                });
    }

    private void rewardAskByMinutes(UUID userId, int minutes) {
        if (minutes <= 0) {
            return;
        }
        ensureAskProfile(userId);
        askProfileRepository.incrementSkillsScore(userId, minutes);
        userRepository.incrementSpeakingMinutesTotal(userId.toString(), minutes);
    }

    private void ensureAskProfile(UUID userId) {
        askProfileRepository.findById(userId)
                .orElseGet(() -> askProfileRepository.save(AskProfileEntity.builder()
                        .userId(userId)
                        .attitudeScore(0)
                        .skillsScore(0)
                        .knowledgeScore(0)
                        .bio("")
                        .updatedAt(Instant.now())
                        .build()));
    }

    private String emptyToNull(String value) {
        return StringUtils.hasText(value) ? value : null;
    }

    private String normalizeQueryKeyword(String value) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        return value.trim().toLowerCase(Locale.ROOT);
    }

    private Instant parseInstantOrNull(String value, String fieldName) {
        if (!StringUtils.hasText(value)) {
            return null;
        }
        try {
            return Instant.parse(value.trim());
        } catch (Exception ex) {
            throw new EventApiException(
                    "BAD_REQUEST",
                    fieldName + " must be ISO-8601 datetime string",
                    HttpStatus.BAD_REQUEST
            );
        }
    }

    private String resolveDisplayName(String displayName) {
        return StringUtils.hasText(displayName) ? displayName : "Unknown";
    }

    private String resolveMonitorDisplayName(User monitor) {
        if (monitor == null) {
            return "Host";
        }
        if (monitor.getProfile() != null && StringUtils.hasText(monitor.getProfile().getDisplayName())) {
            return monitor.getProfile().getDisplayName().trim();
        }
        if (StringUtils.hasText(monitor.getEmail())) {
            String email = monitor.getEmail().trim();
            int split = email.indexOf('@');
            if (split > 0) {
                return email.substring(0, split);
            }
            return email;
        }
        return "Host";
    }
}
