package com.lucy.api.modules.audit.entity;

import com.lucy.api.modules.audit.constants.AuditLogConstants;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;


@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(
        name = AuditLogConstants.TABLE_AUDIT_LOGS,
        indexes = {
                @Index(name = "idx_audit_logs_actor_user_id", columnList = AuditLogConstants.COL_ACTOR_USER_ID),
                @Index(name = "idx_audit_logs_action",        columnList = AuditLogConstants.COL_ACTION),
                @Index(name = "idx_audit_logs_entity",        columnList = AuditLogConstants.COL_ENTITY_TYPE + ", " + AuditLogConstants.COL_ENTITY_ID),
                @Index(name = "idx_audit_logs_created_at",    columnList = AuditLogConstants.COL_CREATED_AT)
        }
)
public class AuditLog {

    @Id
    @Column(updatable = false, nullable = false)
    UUID id;


    @Column(name = AuditLogConstants.COL_ACTOR_USER_ID, updatable = false)
    UUID actorUserId;

    /** 'user' | 'system' | 'service' — default 'user'. */
    @Column(name = AuditLogConstants.COL_ACTOR_TYPE,
            nullable = false,
            updatable = false,
            length = AuditLogConstants.LENGTH_ACTOR_TYPE)
    @Builder.Default
    String actorType = AuditLogConstants.ACTOR_TYPE_USER;

    @Column(name = AuditLogConstants.COL_ACTOR_DISPLAY,
            updatable = false,
            length = 255)
    String actorDisplay;


    @Column(name = AuditLogConstants.COL_ACTION,
            nullable = false,
            updatable = false,
            length = AuditLogConstants.LENGTH_ACTION)
    String action;

    @Column(name = AuditLogConstants.COL_ENTITY_TYPE,
            updatable = false,
            length = AuditLogConstants.LENGTH_ENTITY_TYPE)
    String entityType;

    @Column(name = AuditLogConstants.COL_ENTITY_ID, updatable = false)
    UUID entityId;


    @Column(name = AuditLogConstants.COL_REQUEST_ID,
            updatable = false,
            length = AuditLogConstants.LENGTH_REQUEST_ID)
    String requestId;

    @JdbcTypeCode(SqlTypes.INET)
    @Column(name = AuditLogConstants.COL_IP_ADDRESS, updatable = false)
    String ipAddress;

    @Column(name = AuditLogConstants.COL_USER_AGENT,
            updatable = false,
            length = 512)
    String userAgent;


    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = AuditLogConstants.COL_METADATA,
            nullable = false,
            updatable = false)
    @Builder.Default
    Map<String, Object> metadata = Map.of();


    @CreationTimestamp
    @Column(name = AuditLogConstants.COL_CREATED_AT,
            nullable = false,
            updatable = false)
    Instant createdAt;


    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = UUID.randomUUID();
        }
    }
}
