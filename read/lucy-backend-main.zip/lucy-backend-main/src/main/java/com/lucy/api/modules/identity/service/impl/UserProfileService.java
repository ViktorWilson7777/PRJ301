package com.lucy.api.modules.identity.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.enums.ProfileRole;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.UserProfile;
import com.lucy.api.modules.identity.repository.UserProfileRepository;
import com.lucy.api.modules.identity.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.function.Consumer;

@Service
@RequiredArgsConstructor
public class UserProfileService {
    private final UserRepository userRepository;
    private final UserProfileRepository userProfileRepository;

    @Transactional
    public UserProfile getOrCreate(User user) {
        UserProfile profile = userProfileRepository.findById(user.getId())
                .orElseGet(() -> userProfileRepository.save(UserProfile.builder()
                        .user(user)
                        .displayName(defaultDisplayName(user))
                        .profileRole(defaultProfileRole(user))
                        .build()));
        checkProfileCompletion(user, profile);
        return profile;
    }

    @Transactional
    public UserProfile getOrCreate(User user, String displayName, String avatarUrl) {
        UserProfile profile = getOrCreate(user);
        boolean changed = false;
        if (displayName != null && !displayName.isBlank() && !displayName.equals(profile.getDisplayName())) {
            profile.setDisplayName(displayName.trim());
            changed = true;
        }
        if (avatarUrl != null && !avatarUrl.isBlank() && !avatarUrl.equals(profile.getAvatarUrl())) {
            profile.setAvatarUrl(avatarUrl.trim());
            changed = true;
        }
        if (changed) {
            profile = userProfileRepository.save(profile);
            checkProfileCompletion(user, profile);
        }
        return profile;
    }

    private String defaultDisplayName(User user) {
        String email = user.getEmail();
        if (email == null || email.isBlank() || !email.contains("@")) {
            return user.getId();
        }
        return email.substring(0, email.indexOf('@'));
    }

    private ProfileRole defaultProfileRole(User user) {
        return ProfileRole.LUCY;
    }

    @Transactional
    public UserProfile updateProfile(String userId, Consumer<UserProfile> updater) {
        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException("profile.user_not_found", HttpStatus.NOT_FOUND));
        UserProfile profile = getOrCreate(user);
        updater.accept(profile);
        UserProfile savedProfile = userProfileRepository.save(profile);
        checkProfileCompletion(user, savedProfile);
        return savedProfile;
    }

    private void checkProfileCompletion(User user, UserProfile profile) {
        if (user.isProfileCompleted()) {
            return;
        }

        String currentDisplayName = profile.getDisplayName();
        String defaultName = defaultDisplayName(user);
        boolean hasCustomDisplayName = currentDisplayName != null
                && !currentDisplayName.isBlank()
                && !currentDisplayName.equals(defaultName);
        boolean hasAvatar = profile.getAvatarKey() != null && !profile.getAvatarKey().isBlank();
        boolean hasSpecialty = profile.getSpecialty() != null && !profile.getSpecialty().isBlank();
        boolean hasInterests = profile.getInterests() != null && !profile.getInterests().isEmpty();
        boolean isCompleted = hasCustomDisplayName && hasAvatar && hasSpecialty && hasInterests;

        if (isCompleted) {
            user.setProfileCompleted(true);
            userRepository.save(user);
        }
    }
}
