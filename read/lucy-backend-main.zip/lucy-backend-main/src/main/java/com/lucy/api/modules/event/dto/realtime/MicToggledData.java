package com.lucy.api.modules.event.dto.realtime;

public record MicToggledData(
        boolean enabled
) {
}
