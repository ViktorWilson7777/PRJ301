package com.lucy.api.modules.lms.progress.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.lms.entity.Enrollment;
import com.lucy.api.modules.lms.entity.Lesson;
import com.lucy.api.modules.lms.progress.enums.LessonProgressStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
@Table(
        name = "lesson_progress",
        uniqueConstraints = @UniqueConstraint(name = "lesson_progress_enrollment_lesson_key", columnNames = {"enrollment_id", "lesson_id"}),
        indexes = {
                @Index(name = "lesson_progress_enrollment_idx", columnList = "enrollment_id"),
                @Index(name = "lesson_progress_lesson_idx", columnList = "lesson_id"),
                @Index(name = "lesson_progress_updated_at_idx", columnList = "updated_at")
        }
)
public class LessonProgress extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "enrollment_id", nullable = false)
    Enrollment enrollment;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "lesson_id", nullable = false)
    Lesson lesson;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    LessonProgressStatus status;

    /**
     * Percentage in range [0..100].
     */
    @Column(name = "progress_percent")
    Integer progressPercent;

    /**
     * Best-effort last position for video/audio in seconds.
     */
    @Column(name = "last_position_seconds")
    Integer lastPositionSeconds;

    @Column(name = "completed_at")
    Instant completedAt;
}

