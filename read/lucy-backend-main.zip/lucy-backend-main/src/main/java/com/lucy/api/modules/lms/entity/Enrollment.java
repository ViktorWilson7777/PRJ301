package com.lucy.api.modules.lms.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.lms.entity.enums.EnrollmentMethod;
import com.lucy.api.modules.lms.entity.enums.EnrollmentRole;
import com.lucy.api.modules.lms.entity.enums.EnrollmentStatus;
import com.lucy.api.modules.organization.entity.Organization;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table(name = "enrollments", uniqueConstraints = {
        @UniqueConstraint(columnNames = { "user_id", "course_run_id" })
})
public class Enrollment extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "course_run_id", nullable = false)
    CourseRun courseRun;

    @Enumerated(EnumType.STRING)
    @Column(name = "access_scope", nullable = false, length = 20)
    @Builder.Default
    LmsAccessScope accessScope = LmsAccessScope.PUBLIC;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    Organization organization;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    EnrollmentStatus status = EnrollmentStatus.ACTIVE;

    @Enumerated(EnumType.STRING)
    @Column(length = 50)
    @Builder.Default
    EnrollmentRole role = EnrollmentRole.STUDENT;

    @Enumerated(EnumType.STRING)
    @Column(name = "enrolment_method", length = 100)
    EnrollmentMethod enrolmentMethod; // Cohort sync, Manual enrolments

    @Column(name = "last_accessed_at")
    Instant lastAccessedAt;

    @Column(name = "enrolled_at", nullable = false)
    @Builder.Default
    Instant enrolledAt = Instant.now();

    @Column(name = "completed_at")
    Instant completedAt;

    @Column(name = "progress_percent")
    @Builder.Default
    Integer progressPercent = 0;

}
