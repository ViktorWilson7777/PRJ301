package com.lucy.api.modules.event.repository;

import com.lucy.api.modules.event.entity.RoomLikeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RoomLikeRepository extends JpaRepository<RoomLikeEntity, UUID> {
    Optional<RoomLikeEntity> findByRoomIdAndUserId(UUID roomId, UUID userId);
    long countByRoomId(UUID roomId);
    void deleteAllByUserIdIn(List<UUID> userIds);
    void deleteAllByRoomIdIn(List<UUID> roomIds);
}
