package com.lucy.api.modules.livesessions.entity;

import com.lucy.api.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "live_sessions")
public class LiveSession extends BaseEntity {

    @Column(name = "room_code", nullable = false, unique = true)
    String roomCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    LiveSessionType type;

    @Column(name = "status")
    String status;

    @Column(name = "owner_id")
    String ownerId;

    @Column(name = "event_id")
    String eventId;

    @Column(name = "program_id")
    String programId;

    @Column(name = "course_id")
    String courseId;

    Instant deletedAt;
}
