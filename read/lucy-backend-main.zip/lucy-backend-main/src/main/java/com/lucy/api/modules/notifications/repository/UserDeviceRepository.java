package com.lucy.api.modules.notifications.repository;

import com.lucy.api.modules.notifications.entity.UserDevice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserDeviceRepository extends JpaRepository<UserDevice, String> {
    Optional<UserDevice> findByDeviceToken(String deviceToken);

    List<UserDevice> findByUserIdIn(List<String> userIds);

    @Modifying
    @Transactional
    @Query("DELETE FROM UserDevice u WHERE u.userId = :userId")
    void deleteAllByUserId(String userId);

    @Modifying
    @Transactional
    @Query("DELETE FROM UserDevice u WHERE u.userId IN :userIds")
    void deleteAllByUserIdIn(List<String> userIds);

    @Modifying
    @Transactional
    @Query("DELETE FROM UserDevice u WHERE u.deviceToken = :deviceToken")
    void deleteByDeviceToken(String deviceToken);

    @Modifying
    @Transactional
    @Query("DELETE FROM UserDevice u WHERE u.deviceToken IN :deviceTokens")
    void deleteAllByDeviceTokenIn(List<String> deviceTokens);
}
