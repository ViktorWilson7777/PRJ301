package com.lucy.api.modules.relationship.constants;

public final class RelationshipErrorCodeConstants {

    private RelationshipErrorCodeConstants() {}

    public static final String RELATIONSHIP_NOT_FOUND = "relationship.not_found";
    public static final String RELATIONSHIP_SELF_REQUEST_NOT_ALLOWED = "relationship.self_request_not_allowed";
    public static final String RELATIONSHIP_REQUEST_ALREADY_SENT = "relationship.request_already_sent";
    public static final String RELATIONSHIP_REQUEST_ALREADY_RECEIVED = "relationship.request_already_received";
    public static final String RELATIONSHIP_ALREADY_FRIENDS = "relationship.already_friends";
    public static final String RELATIONSHIP_INVALID_ACCEPT = "relationship.invalid_accept";
    public static final String RELATIONSHIP_INVALID_REJECT = "relationship.invalid_reject";
    public static final String RELATIONSHIP_INVALID_CANCEL = "relationship.invalid_cancel";
    public static final String RELATIONSHIP_INVALID_UNFRIEND = "relationship.invalid_unfriend";
    public static final String RELATIONSHIP_USER_NOT_FOUND = "relationship.user_not_found";
}
