package com.lucy.api.modules.messaging.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RenameGroupConversationRequest {
    @NotBlank
    private String groupName;
}

