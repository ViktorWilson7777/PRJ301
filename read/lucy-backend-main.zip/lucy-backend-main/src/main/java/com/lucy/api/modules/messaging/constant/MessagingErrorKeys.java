package com.lucy.api.modules.messaging.constant;

public final class MessagingErrorKeys {

    private MessagingErrorKeys() {
    }

    public static final String CONVERSATION_NOT_FOUND = "messaging.conversation_not_found";
    public static final String NOT_PARTICIPANT = "messaging.not_participant";
    public static final String COURSE_RUN_CHAT_NOT_ALLOWED = "messaging.course_run_chat_not_allowed";
    public static final String DIRECT_SELF_NOT_ALLOWED = "messaging.direct_self_not_allowed";
    public static final String INVALID_DIRECT_KEY = "messaging.invalid_direct_key";
    public static final String MESSAGE_NOT_FOUND = "messaging.message_not_found";
    public static final String NOT_MESSAGE_SENDER = "messaging.not_message_sender";
    public static final String EMPTY_MESSAGE = "messaging.empty_message";
    public static final String REPLY_WRONG_CONVERSATION = "messaging.reply_wrong_conversation";
    public static final String ENROLLMENT_REQUIRED = "messaging.enrollment_required";
    public static final String CONVERSATION_OR_PEER_REQUIRED = "messaging.conversation_or_peer_required";
}
