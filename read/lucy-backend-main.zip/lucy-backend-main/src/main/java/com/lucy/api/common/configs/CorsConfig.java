package com.lucy.api.common.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Configuration
public class CorsConfig {

    @Value("${cors.allowed-origins.local:http://localhost:3000,http://localhost:5173}")
    private String allowedOriginsLocal;

    @Value("${cors.allowed-origins.prod:}")
    private String allowedOriginsProd;

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        List<String> origins = Stream.of(allowedOriginsLocal, allowedOriginsProd)
                .filter(StringUtils::hasText)
                .flatMap(value -> Stream.of(value.split(",")))
                .map(String::trim)
                .collect(Collectors.toList());

        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(origins);
        config.setAllowedMethods(List.of("*"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
