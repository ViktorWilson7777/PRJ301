package com.lucy.api.modules.identity.service.impl;

import com.lucy.api.common.constants.GlobalVariableConstant;
import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.common.utils.PagingUtil;
import com.lucy.api.modules.identity.constants.user.UserErrorCodeConstants;
import com.lucy.api.modules.identity.dtos.request.user.UserCreationRequest;
import com.lucy.api.modules.identity.dtos.response.user.UserResponse;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.mapper.UserMapper;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.service.interfaces.UserService;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;
    private final com.lucy.api.modules.notifications.repository.UserDeviceRepository userDeviceRepository;
    private final UserProfileService userProfileService;

    @Override
    public UserResponse getMe() {
        String userId = IdentityUtils.getCurrentUserId();
        User entity = getActiveUser(userId);
        return userMapper.toUserResponse(entity);
    }

    @Override
    @Transactional
    public void deleteMe() {
        String userId = IdentityUtils.getCurrentUserId();
        User entity = getActiveUser(userId);
        entity.setActive(false);
        if (entity.getDeletedAt() == null) {
            entity.setDeletedAt(Instant.now());
        }
        userRepository.save(entity);
        userDeviceRepository.deleteAllByUserId(userId);
    }

    @Override
    public PagingResponse<UserResponse> getUsers(String keyword, PagingRequest pagingRequest) {
        int pageIndex = pagingRequest.getPage() - GlobalVariableConstant.PAGE_SIZE_INDEX;
        Pageable pageable = PageRequest.of(pageIndex, pagingRequest.getPageSize(), PagingUtil.createSort(pagingRequest));
        Page<User> page = userRepository.searchUsers(keyword, pageable);
        List<UserResponse> dtos = page.getContent().stream().map(userMapper::toUserResponse).toList();
        return PagingResponse.<UserResponse>builder()
                .currentPage(pagingRequest.getPage())
                .pageSize(page.getSize())
                .totalPages(page.getTotalPages())
                .totalElement(page.getTotalElements())
                .data(dtos)
                .build();
    }

    @Override
    public UserResponse getById(String userId) {
        User entity = getActiveUser(userId);
        return userMapper.toUserResponse(entity);
    }

    @Override
    @Transactional
    public UserResponse create(UserCreationRequest request) {
        if (request == null
                || request.getEmail() == null || request.getEmail().isBlank()
                || request.getDisplayName() == null || request.getDisplayName().isBlank()
                || request.getPasswordHash() == null || request.getPasswordHash().isBlank()) {
            throw new AppException(UserErrorCodeConstants.COMMON_INVALID_PARAM, HttpStatus.BAD_REQUEST);
        }
        if (userRepository.existsByEmail(request.getEmail().trim())) {
            throw new AppException(UserErrorCodeConstants.USER_EMAIL_EXISTED, HttpStatus.CONFLICT);
        }

        User user = User.builder()
                .email(request.getEmail().trim())
                .passwordHash(passwordEncoder.encode(request.getPasswordHash()))
                .isVerified(false)
                .verifiedAt(null)
                .isProfileCompleted(false)
                .build();
        User savedUser = userRepository.save(user);

        userProfileService.getOrCreate(savedUser, request.getDisplayName().trim(), null);

        return userMapper.toUserResponse(savedUser);
    }

    @Override
    public User getEntityById(String userId) {
        return getActiveUser(userId);
    }

    private User getActiveUser(String userId) {
        return userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));
    }

}
