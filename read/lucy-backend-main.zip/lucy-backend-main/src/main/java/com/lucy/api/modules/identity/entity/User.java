package com.lucy.api.modules.identity.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.constants.user.UserConstants;
import com.lucy.api.modules.identity.entity.enums.UserRole;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = UserConstants.TABLE_USERS)
public class User extends BaseEntity {

    @Column(name = UserConstants.COL_EMAIL, nullable = false, unique = true)
    String email;

    @Column(name = UserConstants.COL_PASSWORD_HASH)
    String passwordHash;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = UserConstants.COL_USER_METADATA, columnDefinition = UserConstants.JSONB_DEFINITION)
    @Builder.Default
    Map<String, Object> userMetadata = new HashMap<>();

    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
    UserProfile profile;

    @Column(name = UserConstants.COL_IS_ACTIVE, nullable = false)
    @Builder.Default
    boolean isActive = true;

    @Column(name = UserConstants.COL_IS_VERIFIED, nullable = false)
    @Builder.Default
    boolean isVerified = false;

    @Column(name = UserConstants.COL_VERIFIED_AT)
    Instant verifiedAt;

    @Column(name = UserConstants.COL_BANNED_UNTIL)
    Instant bannedUntil;

    @Column(name = UserConstants.COL_LAST_SIGN_IN_AT)
    Instant lastSignInAt;

    @Column(name = UserConstants.COL_DELETED_AT)
    Instant deletedAt;
 
    @Column(name = UserConstants.COL_IS_PROFILE_COMPLETED, nullable = false, columnDefinition = "boolean default false")
    @Builder.Default
    boolean isProfileCompleted = false;

    @Enumerated(EnumType.STRING)
    @Column(name = "role_name", nullable = false, length = 50, columnDefinition = "varchar(50) default 'MEMBER'")
    @Builder.Default
    UserRole roleName = UserRole.MEMBER;
}

