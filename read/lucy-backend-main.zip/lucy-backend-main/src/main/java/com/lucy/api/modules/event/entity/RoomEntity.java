package com.lucy.api.modules.event.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "rooms")
public class RoomEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(updatable = false, columnDefinition = "uuid")
    UUID id;

    @Column(nullable = false)
    String name;

    @Column(nullable = false)
    String topic;

    @Column(nullable = false)
    String category;

    @Column(nullable = false)
    String level;

    @Column(name = "monitor_id", columnDefinition = "uuid")
    UUID monitorId;

    @Column(name = "max_participants")
    Integer maxParticipants;

    @Column(nullable = false)
    String status;

    @Column(name = "created_at", updatable = false)
    Instant createdAt;

    @Column(name = "updated_at")
    Instant updatedAt;

    @Column(name = "started_at")
    Instant startedAt;

    @Column(name = "event_datetime")
    Instant eventDatetime;

    String location;

    @Column(name = "meeting_type")
    String meetingType;

    @Column(name = "likes_count")
    Integer likesCount;

    @Column(name = "comments_count")
    Integer commentsCount;

    @Column(name = "interested_count")
    Integer interestedCount;

    String title;
    String description;

    @Column(name = "room_type")
    String roomType;

    @PrePersist
    void prePersist() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    @PreUpdate
    void preUpdate() {
        this.updatedAt = Instant.now();
    }
}
