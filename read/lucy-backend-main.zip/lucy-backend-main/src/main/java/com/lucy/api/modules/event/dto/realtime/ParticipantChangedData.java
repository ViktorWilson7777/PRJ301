package com.lucy.api.modules.event.dto.realtime;

public record ParticipantChangedData(
        long participantCount
) {
}
