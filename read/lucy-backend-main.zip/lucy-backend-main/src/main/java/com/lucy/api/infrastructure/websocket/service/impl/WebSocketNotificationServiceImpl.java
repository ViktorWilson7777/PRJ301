package com.lucy.api.infrastructure.websocket.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.infrastructure.redis.constants.RedisChannelPrefixes;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketFrameTypeConstants;
import com.lucy.api.infrastructure.websocket.dto.response.WebSocketNotificationResponse;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketNotificationService;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketSessionService;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Slf4j
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WebSocketNotificationServiceImpl implements WebSocketNotificationService {

    StringRedisTemplate stringRedisTemplate;
    ObjectMapper objectMapper;
    WebSocketSessionService sessionService;
    ConcurrentMap<String, Channel> sessionChannels = new ConcurrentHashMap<>();

    @Override
    public void registerChannel(String sessionId, Channel channel) {
        sessionChannels.put(sessionId, channel);
    }

    @Override
    public void unregisterChannel(String sessionId) {
        sessionChannels.remove(sessionId);
    }

    @Override
    public void sendNotificationToUser(String userId, WebSocketNotificationResponse notification) {
        publishNotificationToRedis(userId, notification);
    }

    @Override
    public void broadcastToLocalSessions(String userId, WebSocketNotificationResponse notification) {
        try {
            List<String> sessionIds = sessionService.getUserSessions(userId);
            String notificationJson = objectMapper.writeValueAsString(notification);

            for (String sessionId : sessionIds) {
                Channel channel = sessionChannels.get(sessionId);
                if (channel != null && channel.isActive()) {
                    String wrappedNotification =
                            wrapNotificationWithType(notificationJson, WebSocketFrameTypeConstants.NOTIFICATION);
                    channel.writeAndFlush(new TextWebSocketFrame(wrappedNotification));
                }
            }

            log.info("Broadcasted notification to {} sessions for user {}", sessionIds.size(), userId);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize notification for user {}", userId, e);
        }
    }

    @Override
    public void publishNotificationToRedis(String userId, WebSocketNotificationResponse notification) {
        try {
            String channel = RedisChannelPrefixes.WS_NOTIFICATION + userId;
            String notificationJson = objectMapper.writeValueAsString(notification);
            stringRedisTemplate.convertAndSend(channel, notificationJson);
            log.info("Published notification to Redis channel: {}", channel);
        } catch (Exception e) {
            log.error("Failed to publish notification to Redis for user {}", userId, e);
        }
    }

    @SuppressWarnings("unchecked")
    private String wrapNotificationWithType(String notificationJson, String type) {
        try {
            Map<String, Object> map = (Map<String, Object>) objectMapper.readValue(notificationJson, Map.class);
            map.put(WebSocketConstants.FIELD_TYPE, type);
            return objectMapper.writeValueAsString(map);
        } catch (Exception e) {
            log.error("Failed to wrap notification with type", e);
            return notificationJson;
        }
    }
}
