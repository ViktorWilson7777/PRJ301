package com.lucy.api.modules.commerce.entity.enums;

public enum LearningEntitlementSourceType {
    PURCHASE,
    MANUAL_GRANT,
    ORG_MEMBERSHIP
}
