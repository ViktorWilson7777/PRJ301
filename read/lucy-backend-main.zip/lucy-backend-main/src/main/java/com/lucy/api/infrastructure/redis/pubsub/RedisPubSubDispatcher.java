package com.lucy.api.infrastructure.redis.pubsub;

import com.lucy.api.infrastructure.redis.constants.RedisPubSubLogConstants;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class RedisPubSubDispatcher implements MessageListener {

    List<RedisEventHandler> handlers;

    @Override
    public void onMessage(Message message, byte[] pattern) {
        try {
            String channel = new String(message.getChannel(), StandardCharsets.UTF_8);
            String payload = new String(message.getBody(), StandardCharsets.UTF_8);

            long matchCount = handlers.stream().filter(h -> h.supports(channel)).count();
            if (matchCount > 1) {
                log.warn(RedisPubSubLogConstants.MULTI_HANDLER, channel, matchCount);
            }

            handlers.stream()
                    .filter(h -> h.supports(channel))
                    .findFirst()
                    .ifPresentOrElse(
                            h -> h.handle(channel, payload),
                            () -> log.warn(RedisPubSubLogConstants.NO_HANDLER, channel)
                    );
        } catch (Exception e) {
            log.error(RedisPubSubLogConstants.DISPATCH_ERROR, e);
        }
    }
}
