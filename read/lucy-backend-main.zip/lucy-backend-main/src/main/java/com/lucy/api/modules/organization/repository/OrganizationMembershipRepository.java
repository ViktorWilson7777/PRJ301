package com.lucy.api.modules.organization.repository;

import com.lucy.api.modules.organization.entity.OrganizationMembership;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface OrganizationMembershipRepository extends JpaRepository<OrganizationMembership, String> {
    Optional<OrganizationMembership> findByOrganization_IdAndUser_Id(String organizationId, String userId);

    boolean existsByOrganization_IdAndUser_IdAndStatus(String organizationId, String userId, OrganizationMembershipStatus status);

    List<OrganizationMembership> findAllByOrganization_IdOrderByCreatedAtAsc(String organizationId);

    Optional<OrganizationMembership> findByIdAndOrganization_Id(String membershipId, String organizationId);
}
