package com.lucy.api.modules.lms.mapper;

import com.lucy.api.modules.cloudinary.dto.StoredFileInfo;
import com.lucy.api.modules.lms.dto.request.LessonUpsertRequest;
import com.lucy.api.modules.lms.dto.response.LessonFileAttachmentResponse;
import com.lucy.api.modules.lms.dto.response.LessonFileUploadResponse;
import com.lucy.api.modules.lms.dto.response.LessonResponse;
import com.lucy.api.modules.lms.entity.Lesson;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
@Mapper(componentModel = "spring", uses = {MapperUtils.class})
public interface LessonMapper {

    @Mapping(target = "chapter", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "type", source = "type", qualifiedByName = "trimValue")
    @Mapping(target = "title", source = "title", qualifiedByName = "trimValue")
    Lesson toEntity(LessonUpsertRequest request);

    @Mapping(target = "chapter", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "type", source = "type", qualifiedByName = "trimValue")
    @Mapping(target = "title", source = "title", qualifiedByName = "trimValue")
    void updateEntity(@MappingTarget Lesson lesson, LessonUpsertRequest request);

    @Mapping(target = "chapterId", source = "chapter.id")
    @Mapping(target = "chapterTitle", source = "chapter.title")
    LessonResponse toResponse(Lesson lesson);

    LessonFileAttachmentResponse toAttachmentResponse(StoredFileInfo storedFileInfo);

    @Mapping(target = "lessonId", source = "lessonId")
    @Mapping(target = "attachment", source = "attachment")
    LessonFileUploadResponse toFileUploadResponse(String lessonId, LessonFileAttachmentResponse attachment);
}
