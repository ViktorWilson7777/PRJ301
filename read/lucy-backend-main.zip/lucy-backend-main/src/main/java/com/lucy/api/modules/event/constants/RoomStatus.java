package com.lucy.api.modules.event.constants;

public final class RoomStatus {
    public static final String SCHEDULED = "scheduled";
    public static final String LIVE = "live";
    public static final String ENDED = "ended";
    public static final String CANCELLED = "cancelled";

    private RoomStatus() {
    }
}
