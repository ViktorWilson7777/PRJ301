package com.lucy.api.modules.messaging.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.event.repository.RoomParticipantRepository;
import com.lucy.api.modules.event.repository.RoomRepository;
import com.lucy.api.modules.lms.entity.enums.EnrollmentStatus;
import com.lucy.api.modules.lms.repository.EnrollmentRepository;
import com.lucy.api.modules.messaging.constant.MessagingCourseRunConstants;
import com.lucy.api.modules.messaging.constant.MessagingErrorKeys;
import com.lucy.api.modules.messaging.dto.response.ConversationParticipantResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationListItemResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationResponse;
import com.lucy.api.modules.messaging.entity.Conversation;
import com.lucy.api.modules.messaging.entity.ConversationParticipant;
import com.lucy.api.modules.messaging.enums.ConversationMode;
import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import com.lucy.api.modules.messaging.mapper.ChatMessageMapper;
import com.lucy.api.modules.messaging.repository.ChatMessageRepository;
import com.lucy.api.modules.messaging.repository.ConversationParticipantRepository;
import com.lucy.api.modules.messaging.repository.ConversationRepository;
import com.lucy.api.modules.messaging.service.interfaces.MessagingConversationService;
import com.lucy.api.modules.messaging.service.domain.ConversationParticipantDomainService;
import com.lucy.api.modules.messaging.service.facade.CourseRunGroupChatFacade;
import com.lucy.api.modules.messaging.service.domain.ConversationDomainService;
import com.lucy.api.modules.relationship.service.interfaces.RelationshipService;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;
import com.lucy.api.modules.messaging.dto.response.ChatSenderInfoResponse;
import com.lucy.api.modules.messaging.entity.ChatMessage;
import com.lucy.api.modules.identity.repository.UserRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MessagingConversationServiceImpl implements MessagingConversationService {

    ConversationRepository conversationRepository;
    ConversationParticipantRepository conversationParticipantRepository;
    ConversationParticipantDomainService conversationParticipantDomainService;
    EnrollmentRepository enrollmentRepository;
    CourseRunGroupChatFacade courseRunGroupChatFacade;
    ConversationDomainService conversationDomainService;
    RelationshipService relationshipService;
    ChatMessageRepository chatMessageRepository;
    ChatMessageMapper chatMessageMapper;
    UserRepository userRepository;
    RoomRepository roomRepository;
    RoomParticipantRepository roomParticipantRepository;

    @Override
    @Transactional
    public ConversationResponse getGroupConversationForEnrolledUser(String courseRunId, String currentUserId) {
        if (!enrollmentRepository.existsByUser_IdAndCourseRun_IdAndStatus(
                currentUserId, courseRunId, EnrollmentStatus.ACTIVE)) {
            throw new AppException(MessagingErrorKeys.ENROLLMENT_REQUIRED, HttpStatus.FORBIDDEN);
        }
        if (conversationRepository.findByCourseRun_IdAndMode(courseRunId, ConversationMode.GROUP).isEmpty()) {
            courseRunGroupChatFacade.syncAfterEnrollmentActivated(currentUserId, courseRunId);
        }
        Conversation conversation = conversationRepository
                .findByCourseRun_IdAndMode(courseRunId, ConversationMode.GROUP)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));
        assertGroupChatAllowed(conversation);
        conversationParticipantDomainService.requireActiveParticipant(conversation.getId(), currentUserId);
        return toResponse(conversation, currentUserId);
    }

    @Override
    @Transactional
    public ConversationResponse getGroupConversationForRoomParticipant(String roomId, String currentUserId) {
        UUID roomUuid = parseUuid(roomId);
        UUID userUuid = parseUuid(currentUserId);

        roomRepository.findEventById(roomUuid)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));

        if (roomParticipantRepository.findByRoomIdAndUserId(roomUuid, userUuid).isEmpty()) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }

        Conversation conversation = conversationRepository.findByRoomIdAndMode(roomId, ConversationMode.GROUP)
                .orElseGet(() -> createRoomConversation(roomId, currentUserId));
        conversationParticipantDomainService.ensureActiveParticipant(conversation.getId(), currentUserId);
        return toResponse(conversation, currentUserId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ConversationParticipantResponse> listParticipants(String conversationId, String currentUserId) {
        conversationParticipantDomainService.requireActiveParticipant(conversationId, currentUserId);
        return conversationParticipantRepository
                .findByConversationIdAndStatus(conversationId, ParticipantStatus.ACTIVE)
                .stream()
                .map(this::toParticipantResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ConversationListItemResponse> listMyConversations(String currentUserId) {
        List<String> conversationIds = conversationParticipantRepository
                .findConversationIdsByUserIdAndStatusIn(
                        currentUserId,
                        List.of(ParticipantStatus.ACTIVE, ParticipantStatus.INVITED)
                );
        if (conversationIds == null || conversationIds.isEmpty()) {
            return List.of();
        }

        List<Conversation> conversations = conversationRepository.findAllById(conversationIds);
        return conversations.stream()
                .map(c -> ConversationListItemResponse.builder()
                        .conversation(toResponse(c, currentUserId))
                        .lastMessage(resolveLastMessage(c.getId(), currentUserId).orElse(null))
                        .build())
                .sorted((a, b) -> {
                    var at = a.getLastMessage() != null ? a.getLastMessage().getCreatedAt() : null;
                    var bt = b.getLastMessage() != null ? b.getLastMessage().getCreatedAt() : null;
                    if (at == null && bt == null) return 0;
                    if (at == null) return 1;
                    if (bt == null) return -1;
                    return bt.compareTo(at);
                })
                .toList();
    }

    @Override
    @Transactional
    public ConversationResponse getOrCreateDirectConversation(String currentUserId, String peerUserId) {
        if (!relationshipService.canMessage(currentUserId, peerUserId)) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }
        Conversation direct = conversationDomainService.ensureDirectConversation(currentUserId, peerUserId);
        conversationParticipantDomainService.ensureActiveParticipant(direct.getId(), currentUserId);
        conversationParticipantDomainService.ensureActiveParticipant(direct.getId(), peerUserId);
        return toResponse(direct, currentUserId);
    }

    @Override
    @Transactional
    public ConversationResponse createAdhocGroupConversation(String currentUserId, String groupName, List<String> memberUserIds) {
        if (memberUserIds == null) memberUserIds = List.of();
        // Create conversation first
        Conversation created = conversationDomainService.createAdhocGroupConversation(groupName, currentUserId);

        // Creator is ACTIVE
        conversationParticipantDomainService.ensureActiveParticipant(created.getId(), currentUserId);

        // Invite others (only friends)
        for (String uid : memberUserIds) {
            if (uid == null) continue;
            String trimmed = uid.trim();
            if (trimmed.isEmpty() || trimmed.equals(currentUserId)) continue;
            if (!relationshipService.canMessage(currentUserId, trimmed)) {
                continue;
            }
            conversationParticipantDomainService.ensureInvitedParticipant(created.getId(), trimmed);
        }
        return toResponse(created, currentUserId);
    }

    @Override
    @Transactional
    public void inviteMembers(String conversationId, String inviterUserId, List<String> memberUserIds) {
        conversationParticipantDomainService.requireActiveParticipant(conversationId, inviterUserId);
        Conversation conversation = conversationRepository.findById(conversationId)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));
        if (conversation.getMode() != ConversationMode.GROUP || conversation.getCourseRun() != null) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }
        if (conversation.getCreatedBy() == null || !conversation.getCreatedBy().equals(inviterUserId)) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }
        if (memberUserIds == null || memberUserIds.isEmpty()) return;
        for (String uid : memberUserIds) {
            if (uid == null) continue;
            String trimmed = uid.trim();
            if (trimmed.isEmpty() || trimmed.equals(inviterUserId)) continue;
            if (!relationshipService.canMessage(inviterUserId, trimmed)) {
                continue;
            }
            conversationParticipantDomainService.ensureInvitedParticipant(conversationId, trimmed);
        }
    }

    @Override
    @Transactional
    public ConversationResponse renameGroupConversation(String conversationId, String ownerUserId, String groupName) {
        Conversation conversation = conversationRepository.findById(conversationId)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));
        if (conversation.getMode() != ConversationMode.GROUP || conversation.getCourseRun() != null) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }
        if (conversation.getCreatedBy() == null || !conversation.getCreatedBy().equals(ownerUserId)) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }
        conversation.setGroupName(groupName != null ? groupName.trim() : null);
        conversation = conversationRepository.save(conversation);
        return toResponse(conversation, ownerUserId);
    }

    @Override
    @Transactional(readOnly = true)
    public String getMyParticipantStatus(String conversationId, String currentUserId) {
        ParticipantStatus status = conversationParticipantDomainService.getMyStatus(conversationId, currentUserId);
        return status != null ? status.name() : null;
    }

    @Override
    @Transactional
    public void acceptInvite(String conversationId, String currentUserId) {
        conversationParticipantDomainService.acceptInvite(conversationId, currentUserId);
    }

    @Override
    @Transactional
    public void rejectInvite(String conversationId, String currentUserId) {
        conversationParticipantDomainService.rejectInvite(conversationId, currentUserId);
    }

    private void assertGroupChatAllowed(Conversation conversation) {
        if (conversation.getCourseRun() == null) {
            return;
        }
        if (conversation.getCourseRun().getDeletedAt() != null) {
            throw new AppException(MessagingErrorKeys.COURSE_RUN_CHAT_NOT_ALLOWED, HttpStatus.UNPROCESSABLE_ENTITY);
        }
        if (!MessagingCourseRunConstants.STATUS_OPEN.equalsIgnoreCase(conversation.getCourseRun().getStatus())) {
            throw new AppException(MessagingErrorKeys.COURSE_RUN_CHAT_NOT_ALLOWED, HttpStatus.UNPROCESSABLE_ENTITY);
        }
    }

    private ConversationResponse toResponse(Conversation conversation) {
        return toResponse(conversation, null);
    }

    private ConversationResponse toResponse(Conversation conversation, String currentUserId) {
        List<ConversationParticipantResponse> participants = conversationParticipantRepository
                .findByConversationIdAndStatus(conversation.getId(), ParticipantStatus.ACTIVE)
                .stream()
                .map(this::toParticipantResponse)
                .toList();
        String courseRunId = conversation.getCourseRun() != null ? conversation.getCourseRun().getId() : null;
        String myStatus = null;
        if (currentUserId != null) {
            ParticipantStatus s = conversationParticipantDomainService.getMyStatus(conversation.getId(), currentUserId);
            myStatus = s != null ? s.name() : null;
        }
        return ConversationResponse.builder()
                .id(conversation.getId())
                .mode(conversation.getMode())
                .courseRunId(courseRunId)
                .groupName(conversation.getGroupName())
                .createdBy(conversation.getCreatedBy())
                .status(conversation.getStatus())
                .participants(participants)
                .myParticipantStatus(myStatus)
                .build();
    }

    private ConversationParticipantResponse toParticipantResponse(ConversationParticipant p) {
        return ConversationParticipantResponse.builder()
                .userId(p.getUser().getId())
                .displayName(p.getUser().getProfile() != null ? p.getUser().getProfile().getDisplayName() : p.getUser().getEmail())
                .status(p.getStatus())
                .joinedAt(p.getJoinedAt())
                .leftAt(p.getLeftAt())
                .build();
    }

    private Optional<ChatMessageResponse> resolveLastMessage(String conversationId, String readerUserId) {
        Optional<ChatMessage> lastOpt = chatMessageRepository.findFirstByConversationIdOrderByCreatedAtDesc(conversationId);
        if (lastOpt.isEmpty()) return Optional.empty();
        ChatMessage last = lastOpt.get();
        ChatMessageResponse r = chatMessageMapper.toResponse(last);
        r.setAttachments(chatMessageMapper.toAttachmentList(last.getAttachments()));
        boolean isEcho = last.getSender() != null && readerUserId.equals(last.getSender().getId());
        r.setIsEcho(isEcho);

        if (r.getSenderId() != null) {
            userRepository.findByIdAndDeletedAtIsNull(r.getSenderId()).ifPresent(u -> {
                ChatSenderInfoResponse info = ChatSenderInfoResponse.builder()
                        .userId(u.getId())
                        .username(u.getProfile() != null ? u.getProfile().getDisplayName() : u.getEmail())
                        .fullName(u.getProfile() != null ? u.getProfile().getDisplayName() : u.getEmail())
                        .avatarUrl(u.getProfile() != null ? u.getProfile().getAvatarUrl() : null)
                        .build();
                r.setSenderInfo(info);
            });
        }
        return Optional.of(r);
    }

    private Conversation createRoomConversation(String roomId, String currentUserId) {
        try {
            Conversation created = Conversation.builder()
                    .mode(ConversationMode.GROUP)
                    .roomId(roomId)
                    .createdBy(currentUserId)
                    .status(com.lucy.api.modules.messaging.enums.ConversationStatus.OPEN)
                    .build();
            return conversationRepository.save(created);
        } catch (DataIntegrityViolationException ex) {
            return conversationRepository.findByRoomIdAndMode(roomId, ConversationMode.GROUP)
                    .orElseThrow(() -> ex);
        }
    }

    private UUID parseUuid(String raw) {
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException ex) {
            throw new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }
}
