package com.lucy.api.modules.audit.dto.request;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AuditLogSearchRequest {

    @Builder.Default
    int page = 1;

    @Builder.Default
    int size = 20;

    String action;
    String entityType;
    String actorUserId;
}
