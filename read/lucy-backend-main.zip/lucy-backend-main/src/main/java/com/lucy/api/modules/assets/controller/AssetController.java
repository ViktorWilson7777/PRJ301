package com.lucy.api.modules.assets.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.assets.dto.response.PresignedUploadResponse;
import com.lucy.api.modules.assets.dto.response.UploadResponse;
import com.lucy.api.modules.cloudinary.dto.StoredFileInfo;
import com.lucy.api.modules.cloudinary.service.api.FileStorageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/assets")
@Tag(name = "Assets", description = "File upload and asset management")
public class AssetController {

    private final FileStorageService r2FileStorageServiceImpl;

    public AssetController(
            @Qualifier("r2FileStorageServiceImpl") FileStorageService r2FileStorageServiceImpl
    ) {
        this.r2FileStorageServiceImpl = r2FileStorageServiceImpl;
    }

    @PostMapping("/upload")
    @Operation(summary = "Upload a file to R2 (legacy cloudinary route)")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<UploadResponse>> upload(@RequestParam("file") MultipartFile file) throws IOException {
        StoredFileInfo storedFile = r2FileStorageServiceImpl.upload(file, "assets");
        
        UploadResponse response = UploadResponse.builder()
                .url(storedFile.getUrl())
                .publicId(storedFile.getPublicId())
                .build();

        return ResponseEntity.ok(ApiResponse.<UploadResponse>builder()
                .success(true)
                .data(response)
                .build());
    }

    @PostMapping("/r2/upload")
    @Operation(summary = "Upload a file to Cloudflare R2")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<UploadResponse>> uploadToR2(@RequestParam("file") MultipartFile file) throws IOException {
        StoredFileInfo storedFile = r2FileStorageServiceImpl.upload(file, "assets");
        
        UploadResponse response = UploadResponse.builder()
                .url(storedFile.getUrl())
                .publicId(storedFile.getPublicId())
                .build();

        return ResponseEntity.ok(ApiResponse.<UploadResponse>builder()
                .success(true)
                .data(response)
                .build());
    }

    @GetMapping("/r2/presigned-upload")
    @Operation(summary = "Get a presigned URL for direct upload to R2 (Delegated upload)")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<PresignedUploadResponse>> getPresignedUploadUrl(
            @RequestParam("fileName") String fileName,
            @RequestParam("contentType") String contentType
    ) {
        String key = "assets/" + UUID.randomUUID() + "-" + fileName;
        String uploadUrl = r2FileStorageServiceImpl.getPresignedUploadUrl(key, contentType);
        String downloadUrl = r2FileStorageServiceImpl.getFileUrl(key);

        PresignedUploadResponse response = PresignedUploadResponse.builder()
                .uploadUrl(uploadUrl)
                .downloadUrl(downloadUrl)
                .publicId(key)
                .build();

        return ResponseEntity.ok(ApiResponse.<PresignedUploadResponse>builder()
                .success(true)
                .data(response)
                .build());
    }

    @GetMapping("/r2/presigned-download")
    @Operation(summary = "Get a presigned URL to temporarily download or view a private R2 file")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> getPresignedDownloadUrl(
            @RequestParam("key") String key
    ) {
        String downloadUrl = r2FileStorageServiceImpl.getPresignedDownloadUrl(key);
        return ResponseEntity.ok(ApiResponse.<String>builder()
                .success(true)
                .data(downloadUrl)
                .build());
    }

    @DeleteMapping("/r2")
    @Operation(summary = "Delete an asset from Cloudflare R2")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Void>> deleteR2Asset(
            @RequestParam("key") String key
    ) {
        r2FileStorageServiceImpl.delete(key);
        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .success(true)
                .build());
    }

    @DeleteMapping("/cloudinary")
    @Operation(summary = "Delete an asset from R2 (legacy cloudinary route)")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Void>> deleteCloudinaryAsset(
            @RequestParam("publicId") String publicId
    ) {
        r2FileStorageServiceImpl.delete(publicId);
        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .success(true)
                .build());
    }
}
