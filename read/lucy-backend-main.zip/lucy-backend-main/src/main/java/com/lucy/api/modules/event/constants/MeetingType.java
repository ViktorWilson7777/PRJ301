package com.lucy.api.modules.event.constants;

public final class MeetingType {
    public static final String ONLINE = "online";
    public static final String OFFLINE = "offline";

    private MeetingType() {
    }
}
