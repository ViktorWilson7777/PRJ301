package com.lucy.api.modules.identity.constants.auth;

import java.time.Duration;

public final class OtpConstants {
    private OtpConstants(){}

    public static final String OTP_KEY_PREFIX = "otp:forgot-password:";
    public static final String COOLDOWN_KEY_PREFIX = "otp:cooldown:";

    /** Đăng ký — tách key khớp quên mật khẩu để không đụng OTP. */
    public static final String OTP_REGISTER_KEY_PREFIX = "otp:register:";
    public static final String COOLDOWN_REGISTER_KEY_PREFIX = "otp:cooldown:register:";

    public static final Duration OTP_TTL = Duration.ofMinutes(5);
    public static final Duration COOLDOWN_TTL = Duration.ofSeconds(60);

    public static final int OTP_LENGTH = 6;
}
