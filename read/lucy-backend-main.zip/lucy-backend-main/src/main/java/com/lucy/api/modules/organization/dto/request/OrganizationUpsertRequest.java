package com.lucy.api.modules.organization.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizationUpsertRequest {
    @NotBlank(message = "common.field_required")
    @Size(max = 100, message = "common.validation")
    String code;

    @NotBlank(message = "common.field_required")
    @Size(max = 255, message = "common.validation")
    String name;

    String description;
    String logoUrl;
}
