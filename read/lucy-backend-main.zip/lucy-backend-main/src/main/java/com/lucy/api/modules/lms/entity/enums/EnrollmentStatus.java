package com.lucy.api.modules.lms.entity.enums;

public enum EnrollmentStatus {
    ACTIVE,
    COMPLETED,
    SUSPENDED
}
