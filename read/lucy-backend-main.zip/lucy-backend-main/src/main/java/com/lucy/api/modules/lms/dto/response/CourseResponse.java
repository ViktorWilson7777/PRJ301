package com.lucy.api.modules.lms.dto.response;

import com.lucy.api.modules.lms.dto.response.CourseRunResponse;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CourseResponse {
    String id;
    String code;
    String title;
    String description;
    String level;
    String thumbnailUrl;
    String category;
    String programId;
    String programCode;
    LmsAccessScope accessScope;
    String organizationId;
    Integer orderIndex;
    List<String> tags;
    List<CourseRunResponse> courseRuns;
    Instant createdAt;
    Instant updatedAt;
}
