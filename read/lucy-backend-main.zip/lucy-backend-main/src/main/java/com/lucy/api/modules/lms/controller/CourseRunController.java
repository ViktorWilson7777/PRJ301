package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.lms.dto.request.CourseRunUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.dto.response.CourseRunResponse;
import com.lucy.api.modules.lms.dto.response.LessonResponse;
import com.lucy.api.modules.lms.service.api.ChapterService;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import com.lucy.api.modules.lms.service.api.LessonService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/course-runs")
@Tag(name = "LMS Course Runs", description = "CRUD APIs for course runs")
public class CourseRunController {
    private final CourseRunService courseRunService;
    private final ChapterService chapterService;
    private final LessonService lessonService;

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Create a new course run")
    public ResponseEntity<ApiResponse<CourseRunResponse>> create(@Valid @RequestBody CourseRunUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.create(request)).build());
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get all course runs")
    public ResponseEntity<ApiResponse<List<CourseRunResponse>>> findAll(@RequestParam(required = false) String courseId) {
        return ResponseEntity.ok(ApiResponse.<List<CourseRunResponse>>builder().success(true).data(courseRunService.findAll(courseId)).build());
    }

    @GetMapping("/{courseRunId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get a course run by id")
    public ResponseEntity<ApiResponse<CourseRunResponse>> findById(@PathVariable String courseRunId) {
        return ResponseEntity.ok(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.findById(courseRunId)).build());
    }

    @GetMapping("/{courseRunId}/roadmap")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get chapter and lesson roadmap for a course run")
    public ResponseEntity<ApiResponse<List<ChapterResponse>>> getRoadmap(@PathVariable String courseRunId) {
        courseRunService.findById(courseRunId);
        List<ChapterResponse> chapters = chapterService.findAll(courseRunId);
        for (ChapterResponse chapter : chapters) {
            List<LessonResponse> lessons = lessonService.findAll(chapter.getId());
            chapter.setLessons(lessons);
        }
        return ResponseEntity.ok(
                ApiResponse.<List<ChapterResponse>>builder()
                        .success(true)
                        .data(chapters)
                        .build()
        );
    }

    @PutMapping("/{courseRunId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Update a course run")
    public ResponseEntity<ApiResponse<CourseRunResponse>> update(@PathVariable String courseRunId, @Valid @RequestBody CourseRunUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.update(courseRunId, request)).build());
    }

    @DeleteMapping("/{courseRunId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Delete a course run")
    public ResponseEntity<ApiResponse<String>> delete(@PathVariable String courseRunId) {
        courseRunService.delete(courseRunId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Course run deleted successfully").build());
    }
}
