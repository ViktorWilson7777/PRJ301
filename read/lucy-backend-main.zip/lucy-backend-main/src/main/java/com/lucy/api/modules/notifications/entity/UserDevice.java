package com.lucy.api.modules.notifications.entity;

import com.lucy.api.common.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "user_devices")
public class UserDevice extends BaseEntity {

    /** FK to the users table */
    @Column(name = "user_id", nullable = false, length = 36)
    String userId;

    /** Firebase Cloud Messaging Token */
    @Column(name = "device_token", nullable = false, columnDefinition = "TEXT", unique = true)
    String deviceToken;

    /** e.g. iOS, Android, Web */
    @Column(name = "os_type", length = 50)
    String osType;
}
