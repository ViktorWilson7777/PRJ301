package com.lucy.api.common.constants;

public class InitializerOrder {
    public static final int PERMISSION = 1;
    public static final int ROLE = 2;
    public static final int ADMIN = 3;
}
