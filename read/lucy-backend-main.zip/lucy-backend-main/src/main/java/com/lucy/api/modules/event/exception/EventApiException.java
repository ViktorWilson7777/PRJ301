package com.lucy.api.modules.event.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class EventApiException extends RuntimeException {
    private final String code;
    private final HttpStatus status;

    public EventApiException(String code, String message, HttpStatus status) {
        super(message);
        this.code = code;
        this.status = status;
    }
}
