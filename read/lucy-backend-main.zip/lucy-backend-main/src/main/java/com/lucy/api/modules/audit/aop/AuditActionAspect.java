package com.lucy.api.modules.audit.aop;

import com.lucy.api.modules.audit.annotation.AuditAction;
import com.lucy.api.modules.audit.constants.AuditLogConstants;
import com.lucy.api.modules.audit.dto.request.AuditLogMessage;
import com.lucy.api.modules.audit.service.api.AuditLogService;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import jakarta.servlet.http.HttpServletRequest;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Aspect
@Component
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class AuditActionAspect {

    AuditLogService auditLogService;
    com.fasterxml.jackson.databind.ObjectMapper objectMapper;

    @AfterReturning(pointcut = "@annotation(auditAction)", returning = "result")
    public void logAuditAction(JoinPoint joinPoint, AuditAction auditAction, Object result) {

        // 1. Get Actor User ID
        UUID actorUserId = null;
        String actorType = AuditLogConstants.ACTOR_TYPE_USER;
        try {
            String userIdStr = IdentityUtils.getCurrentUserId();
            if (userIdStr != null && !userIdStr.isBlank()) {
                actorUserId = UUID.fromString(userIdStr);
            }
        } catch (Exception e) {
            // Handled as system/anonymous action if user cannot be tied.
            actorType = AuditLogConstants.ACTOR_TYPE_SYSTEM;
        }

        // 2. Request details (IP, User-Agent, RequestId)
        String ipAddress = null;
        String userAgent = null;
        String requestId = null;

        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attributes != null) {
            HttpServletRequest request = attributes.getRequest();
            ipAddress = getClientIp(request);
            userAgent = request.getHeader(AuditLogConstants.HEADER_USER_AGENT);
            
            requestId = (String) request.getAttribute(com.lucy.api.common.configs.TraceIdFilter.TRACE_ID_HEADER);
            if (requestId == null) {
                requestId = UUID.randomUUID().toString();
            }
        }

        // 3. Metadata details (method arguments)
        Map<String, Object> metadata = extractMetadata(joinPoint);

        // 4. Entity ID (Extract from args, fallback to response result for CREATE)
        UUID entityId = extractEntityId(metadata, result);

        // 5. Fire async log
        auditLogService.log(AuditLogMessage.builder()
                .actorUserId(actorUserId)
                .actorType(actorType)
                .actorDisplay(null) // resolved asynchronously in service
                .action(auditAction.action())
                .entityType(auditAction.entityType())
                .entityId(entityId)
                .requestId(requestId)
                .ipAddress(ipAddress)
                .userAgent(userAgent)
                .metadata(metadata)
                .build());
    }

    private String getClientIp(HttpServletRequest request) {
        String xfHeader = request.getHeader(AuditLogConstants.HEADER_X_FORWARDED_FOR);
        if (xfHeader == null || xfHeader.isEmpty() || !xfHeader.contains(request.getRemoteAddr())) {
            return request.getRemoteAddr();
        }
        return xfHeader.split(",")[0].trim();
    }

    private Map<String, Object> extractMetadata(JoinPoint joinPoint) {
        Map<String, Object> metadata = new HashMap<>();
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        String[] paramNames = signature.getParameterNames();
        Object[] args = joinPoint.getArgs();

        if (paramNames != null && args != null) {
            for (int i = 0; i < paramNames.length; i++) {
                if (args[i] != null && !args[i].getClass().getName().startsWith(AuditLogConstants.PACKAGE_SPRINGFRAMEWORK)) {
                    metadata.put(paramNames[i], args[i]);
                }
            }
        }
        return metadata;
    }

    private UUID extractEntityId(Map<String, Object> metadata, Object result) {
        // 1. Try to find ID in method arguments (e.g. @PathVariable("courseId"))
        Object potentialId = metadata.get(AuditLogConstants.JSON_KEY_ID);
        if (potentialId == null) {
            for (Map.Entry<String, Object> entry : metadata.entrySet()) {
                if (entry.getKey().toLowerCase().endsWith(AuditLogConstants.JSON_KEY_ID) && entry.getValue() instanceof String) {
                    potentialId = entry.getValue();
                    break;
                }
            }
        }

        // 2. Try to find ID in the returned result (for CREATE actions)
        if (potentialId == null && result != null) {
            try {
                Object body = result;
                if (result instanceof org.springframework.http.ResponseEntity) {
                    body = ((org.springframework.http.ResponseEntity<?>) result).getBody();
                }

                if (body != null) {
                    com.fasterxml.jackson.databind.JsonNode root = objectMapper.valueToTree(body);
                    if (root.has(AuditLogConstants.JSON_KEY_DATA) && !root.get(AuditLogConstants.JSON_KEY_DATA).isNull() && root.get(AuditLogConstants.JSON_KEY_DATA).has(AuditLogConstants.JSON_KEY_ID)) {
                        potentialId = root.get(AuditLogConstants.JSON_KEY_DATA).get(AuditLogConstants.JSON_KEY_ID).asText();
                    } else if (root.has(AuditLogConstants.JSON_KEY_ID)) {
                        potentialId = root.get(AuditLogConstants.JSON_KEY_ID).asText();
                    }
                }
            } catch (Exception ignored) {
            }
        }

        if (potentialId != null) {
            try {
                return UUID.fromString(potentialId.toString());
            } catch (IllegalArgumentException ignored) {
            }
        }
        return null;
    }
}
