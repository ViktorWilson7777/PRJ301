package com.lucy.api.modules.livesessions.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.event.entity.RoomEntity;
import com.lucy.api.modules.event.repository.RoomRepository;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.livesessions.dto.request.CreateLiveSessionRequest;
import com.lucy.api.modules.livesessions.dto.response.LiveSessionResponse;
import com.lucy.api.modules.livesessions.dto.response.MeetingTokenResponse;
import com.lucy.api.modules.livesessions.entity.LiveSession;
import com.lucy.api.modules.livesessions.entity.LiveSessionType;
import com.lucy.api.modules.livesessions.repository.LiveSessionRepository;
import com.lucy.api.modules.livesessions.service.api.LiveSessionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class LiveSessionServiceImpl implements LiveSessionService {

    private final LiveSessionRepository liveSessionRepository;
    private final RoomRepository roomRepository;
    private final UserRepository userRepository;
    private final RestTemplate restTemplate = new RestTemplate();

    // Prefer internal gateway URL in containerized deployments to avoid SSL/domain coupling.
    @Value("${app.meet-service.url:http://gateway:8090}")
    private String meetServiceUrl;

    @Value("${app.meet-service.api-secret:wajlc-secret}")
    private String apiSecret;

    @Value("${app.meet-service.api-key:wajlc}")
    private String apiKey;

    @Override
    public MeetingTokenResponse getJoinToken(String roomCode, String userId) {
        // 1. Validate Room & User locally in Java DB
        LiveSession session = liveSessionRepository.findByRoomCodeAndDeletedAtIsNull(roomCode)
                .orElseThrow(() -> new AppException("meeting.room_not_found", HttpStatus.NOT_FOUND));

        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException("auth.user_not_found", HttpStatus.NOT_FOUND));

        RoomEntity event = null;
        if (session.getEventId() != null) {
            try {
                event = roomRepository.findEventById(UUID.fromString(session.getEventId())).orElse(null);
            } catch (IllegalArgumentException ignored) {
                event = null;
            }
        }

        // 2. Timing check (Torii Join Window logic)
        if (event != null) {
            Instant now = Instant.now();
            Instant start = event.getEventDatetime();
            if (start != null && now.isBefore(start.minusSeconds(1800))) {
                throw new AppException("meeting.not_started_yet", HttpStatus.BAD_REQUEST);
            }
            Instant endEstimate = start != null ? start.plusSeconds(2 * 3600L) : null;
            if (endEstimate != null && now.isAfter(endEstimate.plusSeconds(3600))) { // 1h buffer at end
                throw new AppException("meeting.already_ended", HttpStatus.BAD_REQUEST);
            }
        }

        // 3. Check if room is active in Meet Service (using Gateway)
        boolean isActive = isRoomActive(roomCode);
        
        // Determine if user is owner/author (Tutor)
        boolean isOwner = user.getId().equals(session.getOwnerId()) ||
                (event != null && event.getMonitorId() != null && user.getId().equals(event.getMonitorId().toString()));

        if (!isActive) {
            if (!isOwner) {
                // If the room isn't active and student joins, reject
                throw new AppException("meeting.not_started_by_tutor", HttpStatus.BAD_REQUEST);
            }
            // 4. Create room (for Tutor/Owner) - Initializes the session in Meet/LiveKit
            createRoom(roomCode, event != null ? event.getTitle() : "Live Session");
        }

        // 5. Generate Join Token
        return generateToken(roomCode, user, isOwner);
    }

    private boolean isRoomActive(String roomCode) {
        try {
            // Meet service may return `is_active` (proto JSON) or `isActive` (camelCase)
            // across different gateway versions.
            Map<String, String> payload = Map.of(
                "room_id", roomCode,
                "roomId", roomCode
            );
            String jsonBody = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(payload);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("api-key", apiKey);
            headers.set("hash-signature", calculateHmacSha256(jsonBody, apiSecret));

            HttpEntity<String> entity = new HttpEntity<>(jsonBody, headers);
            ResponseEntity<Map> response = restTemplate.postForEntity(
                meetServiceUrl + "/auth/room/isRoomActive", entity, Map.class);

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map body = response.getBody();
                Object raw = body.get("isActive");
                if (raw == null) {
                    raw = body.get("is_active");
                }

                if (raw instanceof Boolean) return (Boolean) raw;
                if (raw instanceof Number) return ((Number) raw).intValue() == 1;
                if (raw instanceof String) {
                    String s = ((String) raw).trim();
                    return s.equalsIgnoreCase("true") || s.equals("1");
                }
            }
        } catch (Exception e) {
            log.warn("Error checking room activity for room {}: {}", roomCode, e.getMessage());
        }
        return false;
    }

    private void createRoom(String roomCode, String title) {
        try {
            // Build CreateRoomReq payload fully aligned with web/mobile `createRoom()` defaults
            // (see `zen-leader/lib/features/meet/data/datasources/meet_api_service.dart`).
            // This avoids "missing defaults" issues inside `prepareDefaultRoomFeatures()`
            // when we provide partial nested feature objects.

            Map<String, Object> recordingFeatures = Map.of(
                "isAllow", true,
                "isAllowCloud", true,
                "isAllowLocal", true,
                "enableAutoCloudRecording", false,
                "onlyRecordAdminWebcams", false
            );

            Map<String, Object> chatFeatures = Map.of(
                "isAllow", true,
                "isAllowFileUpload", true,
                // Keep aligned with mobile payload; meet service will enforce/override defaults if needed.
                "maxFileSize", "50",
                "allowedFileTypes", new String[] { "jpg", "png", "zip", "pdf" }
            );

            Map<String, Object> whiteboardFeatures = Map.of(
                "isAllow", true,
                // Match meet backend defaults (used when feature object is missing).
                "visible", false,
                "whiteboardFileId", "default",
                "fileName", "default",
                "filePath", "",
                "totalPages", 10
            );

            Map<String, Object> breakoutRoomFeatures = Map.of(
                "isAllow", true,
                "isActive", false,
                "allowedNumberRooms", 6
            );

            Map<String, Object> waitingRoomFeatures = Map.of(
                "isActive", true,
                "waitingRoomMsg", ""
            );

            Map<String, Object> externalMediaPlayerFeatures = Map.of(
                "isAllow", true
            );

            Map<String, Object> displayExternalLinkFeatures = Map.of(
                "isAllow", true
            );

            Map<String, Object> ingressFeatures = Map.of(
                "isAllow", true
            );

            Map<String, Object> pollsFeatures = Map.of(
                "isAllow", true
            );

            Map<String, Object> insightsFeatures = Map.of(
                "isAllow", true,
                "transcriptionFeatures", Map.of(
                    "isAllow", true,
                    "isAllowTranslation", true,
                    "isAllowSpeechSynthesis", true
                ),
                "chatTranslationFeatures", Map.of(
                    "isAllow", true
                ),
                "aiFeatures", Map.of(
                    "isAllow", true,
                    "aiTextChatFeatures", Map.of(
                        "isAllow", true
                    ),
                    "meetingSummarizationFeatures", Map.of(
                        "isAllow", true
                    )
                )
            );

            Map<String, Object> endToEndEncryptionFeatures = Map.of(
                "isEnabled", false,
                "includedChatMessages", false,
                "includedWhiteboard", false,
                "enabledSelfInsertEncryptionKey", false
            );

            // Map.of() chỉ hỗ trợ tối đa 10 cặp key/value, nên với feature nhiều hơn
            // bắt buộc phải dùng Map.ofEntries để tránh lỗi compile.
            Map<String, Object> roomFeatures = Map.ofEntries(
                Map.entry("allowWebcams", true),
                Map.entry("muteOnStart", false),
                Map.entry("allowScreenShare", true),
                Map.entry("allowRtmp", true),
                Map.entry("adminOnlyWebcams", false),
                Map.entry("allowViewOtherWebcams", true),
                Map.entry("allowViewOtherUsersList", true),
                Map.entry("roomDuration", "0"),
                Map.entry("enableAnalytics", true),
                Map.entry("allowVirtualBg", true),
                Map.entry("allowRaiseHand", true),
                Map.entry("recordingFeatures", recordingFeatures),
                Map.entry("chatFeatures", chatFeatures),
                Map.entry("whiteboardFeatures", whiteboardFeatures),
                Map.entry("externalMediaPlayerFeatures", externalMediaPlayerFeatures),
                Map.entry("waitingRoomFeatures", waitingRoomFeatures),
                Map.entry("breakoutRoomFeatures", breakoutRoomFeatures),
                Map.entry("displayExternalLinkFeatures", displayExternalLinkFeatures),
                Map.entry("ingressFeatures", ingressFeatures),
                Map.entry("pollsFeatures", pollsFeatures),
                Map.entry("insightsFeatures", insightsFeatures),
                Map.entry("endToEndEncryptionFeatures", endToEndEncryptionFeatures)
            );

            Map<String, Object> metadata = Map.of(
                "roomTitle", title,
                "welcomeMessage", "Welcome to ZenLeader Meet session!",
                "roomFeatures", roomFeatures
            );

            Map<String, Object> payload = Map.of(
                "roomId", roomCode,
                "emptyTimeout", 7200,
                "metadata", metadata
            );

            String jsonBody = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(payload);
            // Debug: log the exact JSON payload sent to meet service (no secrets).
            // This helps verify roomDuration type/value and catch accidental null/undefined-like values.
            log.info("Meet createRoom request payload for roomCode={}: {}", roomCode, jsonBody);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("api-key", apiKey);
            headers.set("hash-signature", calculateHmacSha256(jsonBody, apiSecret));

            HttpEntity<String> entity = new HttpEntity<>(jsonBody, headers);
            ResponseEntity<Map> response = restTemplate.postForEntity(meetServiceUrl + "/auth/room/create", entity, Map.class);
            log.info("Meet createRoom response for roomCode={} status={} body={}",
                    roomCode, response.getStatusCode(), response.getBody());
            
            if (response.getStatusCode() != HttpStatus.OK || response.getBody() == null || 
                !Boolean.TRUE.equals(response.getBody().get("status"))) {
                log.error("Failed to create room: {}", response.getBody());
                throw new AppException("meeting.create_failed", HttpStatus.INTERNAL_SERVER_ERROR);
            }
            
        } catch (AppException ae) {
            throw ae;
        } catch (Exception e) {
            log.error("Error creating room", e);
            throw new AppException("meeting.internal_error", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private MeetingTokenResponse generateToken(String roomCode, User user, boolean isAdmin) {
        try {
            // Nested metadata structure as expected by torii-monorepo backend
            Map<String, Object> userMetadata = Map.of(
                "profilePic", (user.getProfile() != null && user.getProfile().getAvatarUrl() != null) ? user.getProfile().getAvatarUrl() : "",
                "isAdmin", isAdmin
            );

            Map<String, Object> userInfo = Map.of(
                "userId", user.getId(),
                "name", (user.getProfile() != null && user.getProfile().getDisplayName() != null) ? user.getProfile().getDisplayName() : "User_" + user.getId().substring(0, 4),
                "isAdmin", isAdmin,
                "userMetadata", userMetadata
            );

            Map<String, Object> payload = Map.of(
                "roomId", roomCode,
                "userInfo", userInfo
            );

            String jsonBody = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(payload);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("api-key", apiKey);
            headers.set("hash-signature", calculateHmacSha256(jsonBody, apiSecret));

            HttpEntity<String> entity = new HttpEntity<>(jsonBody, headers);
            ResponseEntity<Map> response = restTemplate.postForEntity(
                meetServiceUrl + "/auth/room/getJoinToken", entity, Map.class);

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map<String, Object> body = response.getBody();
                if (Boolean.TRUE.equals(body.get("status"))) {
                    return MeetingTokenResponse.builder()
                            .token((String) body.get("token"))
                            .roomCode(roomCode)
                            .build();
                } else {
                    log.error("Meet service error: {}", body.get("msg"));
                }
            }
            throw new AppException("meeting.token_gen_failed", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error generating token", e);
            throw new AppException("meeting.internal_error", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }




    private String calculateHmacSha256(String data, String key) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKeySpec);
        byte[] rawHmac = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return HexFormat.of().formatHex(rawHmac);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Standalone LiveSession CRUD
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public LiveSessionResponse createSession(CreateLiveSessionRequest request, String ownerId) {
        // Validate that roomCode is not already taken
        liveSessionRepository.findByRoomCodeAndDeletedAtIsNull(request.getRoomCode()).ifPresent(existing -> {
            throw new AppException("meeting.room_code_exists", HttpStatus.CONFLICT);
        });

        LiveSession session = LiveSession.builder()
                .roomCode(request.getRoomCode())
                .type(request.getType() != null ? request.getType() : LiveSessionType.TORII_MEET)
                .status("ACTIVE")
                .ownerId(ownerId)
                .eventId(request.getEventId())
                .programId(request.getProgramId())
                .courseId(request.getCourseId())
                .build();

        LiveSession saved = liveSessionRepository.save(session);
        return LiveSessionResponse.fromEntity(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public LiveSessionResponse getSessionById(String sessionId) {
        LiveSession session = liveSessionRepository.findByIdAndDeletedAtIsNull(sessionId)
                .orElseThrow(() -> new AppException("meeting.room_not_found", HttpStatus.NOT_FOUND));
        return LiveSessionResponse.fromEntity(session);
    }

    @Override
    @Transactional(readOnly = true)
    public LiveSessionResponse getSessionByRoomCode(String roomCode) {
        LiveSession session = liveSessionRepository.findByRoomCodeAndDeletedAtIsNull(roomCode)
                .orElseThrow(() -> new AppException("meeting.room_not_found", HttpStatus.NOT_FOUND));
        return LiveSessionResponse.fromEntity(session);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LiveSessionResponse> getSessionsByOwner(String ownerId) {
        return liveSessionRepository.findByOwnerIdAndDeletedAtIsNull(ownerId)
                .stream()
                .map(LiveSessionResponse::fromEntity)
                .toList();
    }

    @Override
    @Transactional
    public LiveSessionResponse endSession(String sessionId, String requesterId) {
        LiveSession session = liveSessionRepository.findByIdAndDeletedAtIsNull(sessionId)
                .orElseThrow(() -> new AppException("meeting.room_not_found", HttpStatus.NOT_FOUND));
        checkOwnerOrThrow(session, requesterId);
        session.setStatus("ENDED");
        liveSessionRepository.save(session);
        return LiveSessionResponse.fromEntity(session);
    }

    @Override
    @Transactional
    public void deleteSession(String sessionId, String requesterId) {
        LiveSession session = liveSessionRepository.findByIdAndDeletedAtIsNull(sessionId)
                .orElseThrow(() -> new AppException("meeting.room_not_found", HttpStatus.NOT_FOUND));
        checkOwnerOrThrow(session, requesterId);
        session.setDeletedAt(Instant.now());
        liveSessionRepository.save(session);
    }

    /** Throws FORBIDDEN if requester is not the session owner. */
    private void checkOwnerOrThrow(LiveSession session, String requesterId) {
        if (!requesterId.equals(session.getOwnerId())) {
            throw new AppException("meeting.forbidden", HttpStatus.FORBIDDEN);
        }
    }
}
