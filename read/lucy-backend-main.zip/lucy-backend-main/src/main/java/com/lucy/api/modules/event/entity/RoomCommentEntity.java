package com.lucy.api.modules.event.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "room_comments")
public class RoomCommentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(updatable = false, columnDefinition = "uuid")
    UUID id;

    @Column(name = "room_id", nullable = false, columnDefinition = "uuid")
    UUID roomId;

    @Column(name = "user_id", nullable = false, columnDefinition = "uuid")
    UUID userId;

    @Column(name = "parent_id", columnDefinition = "uuid")
    UUID parentId;

    @Column(nullable = false)
    String content;

    @Column(nullable = false)
    @Builder.Default
    Integer level = 1;

    @Column(name = "likes_count", nullable = false)
    @Builder.Default
    Integer likesCount = 0;

    @Column(name = "replies_count", nullable = false)
    @Builder.Default
    Integer repliesCount = 0;

    @Column(name = "created_at")
    Instant createdAt;

    @Column(name = "deleted_at")
    Instant deletedAt;

    @PrePersist
    void prePersist() {
        if (this.createdAt == null) {
            this.createdAt = Instant.now();
        }
        if (this.level == null) {
            this.level = 1;
        }
        if (this.likesCount == null) {
            this.likesCount = 0;
        }
        if (this.repliesCount == null) {
            this.repliesCount = 0;
        }
    }
}
