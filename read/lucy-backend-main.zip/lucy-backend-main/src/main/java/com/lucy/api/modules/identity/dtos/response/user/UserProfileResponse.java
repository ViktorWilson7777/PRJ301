package com.lucy.api.modules.identity.dtos.response.user;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserProfileResponse {
    String userId;
    String displayName;
    String avatarUrl;
    String avatarKey;
    String backgroundUrl;
    Map<String, Object> backgroundMetadata;
    Integer level;
    Integer speakingMinutesTotal;
    Integer speakingMinutesCurrent;
    String interest;
    String specialty;
    List<String> interests;
    boolean isProCertified;
    Integer evolutionStage;
}
