package com.lucy.api.modules.cloudinary.service.api;

import com.lucy.api.modules.cloudinary.dto.StoredFileInfo;
import org.springframework.web.multipart.MultipartFile;

public interface FileStorageService {
    StoredFileInfo upload(MultipartFile file, String folder);
    String getPresignedUploadUrl(String key, String contentType);
    String getPresignedDownloadUrl(String key);
    String getFileUrl(String key);
    void delete(String key);
}
