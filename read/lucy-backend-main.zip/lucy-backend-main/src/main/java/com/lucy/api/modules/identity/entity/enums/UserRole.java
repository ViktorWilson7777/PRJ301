package com.lucy.api.modules.identity.entity.enums;

public enum UserRole {
    ADMIN,
    MEMBER
}
