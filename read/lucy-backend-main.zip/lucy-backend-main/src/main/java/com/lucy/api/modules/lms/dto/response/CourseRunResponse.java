package com.lucy.api.modules.lms.dto.response;

import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CourseRunResponse {
    String id;
    String courseId;
    String code;
    String status;
    Instant startsAt;
    Instant endsAt;
    String timezone;
    Map<String, Object> metadata;
    Instant enrollmentStartDate;
    Instant enrollmentEndDate;
    Integer capacity;
    String prerequisiteCourseRunId;
    LmsAccessScope accessScope;
    String organizationId;
    List<ChapterResponse> chapters;
    Instant createdAt;
    Instant updatedAt;
}
