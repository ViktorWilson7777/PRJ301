package com.lucy.api.modules.identity.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.constants.user.UserConstants;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = UserConstants.TABLE_SESSIONS)
public class Session extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = UserConstants.COL_USER_ID, nullable = false)
    User user;

    @Column(name = UserConstants.COL_TOKEN_HASH, nullable = false, unique = true)
    String tokenHash;

    @Column(name = UserConstants.COL_DEVICE_INFO)
    String deviceInfo;

    @Column(name = UserConstants.COL_IP_ADDRESS)
    String ipAddress;

    @Column(name = UserConstants.COL_EXPIRES_AT, nullable = false)
    Instant expiresAt;

    @Column(name = UserConstants.COL_REVOKED_AT)
    Instant revokedAt;
}
