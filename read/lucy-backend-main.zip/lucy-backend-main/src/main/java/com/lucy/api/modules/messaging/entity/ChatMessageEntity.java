package com.lucy.api.modules.messaging.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "chat_messages")
public class ChatMessageEntity {
    @Id
    @Column(updatable = false, length = 36)
    String id;

    @Column(name = "conversation_id", nullable = false, length = 36)
    String conversationId;

    @Column(name = "sender_id", nullable = false, length = 36)
    String senderId;

    @Column(name = "text")
    String text;

    @Column(name = "reply_to_message_id", length = 36)
    String replyToMessageId;

    @Column(name = "is_edited", nullable = false)
    boolean isEdited;

    @Column(name = "edit_count", nullable = false)
    int editCount;

    @Column(name = "created_at", nullable = false)
    Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    Instant updatedAt;

    @PrePersist
    void prePersist() {
        Instant now = Instant.now();
        if (id == null) {
            id = UUID.randomUUID().toString();
        }
        if (createdAt == null) {
            createdAt = now;
        }
        updatedAt = now;
    }

    @PreUpdate
    void preUpdate() {
        updatedAt = Instant.now();
    }
}
