package com.lucy.api.modules.relationship.dtos.response;

import com.lucy.api.modules.relationship.enums.RelationshipStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RelationshipStatusResponse {
    RelationshipUserSummaryResponse otherUser;
    RelationshipStatus status;
    boolean isRequester;
    boolean isAddressee;
    boolean canMessage;
}
