package com.lucy.api.modules.event.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EventFeedRequest {
    String status;
    Boolean mine;
    Boolean interested;
    String from;
    String to;
    String cursor;
    String query;

    @Min(value = 1, message = "event.limit_invalid")
    @Max(value = 50, message = "event.limit_invalid")
    Integer limit;
}
