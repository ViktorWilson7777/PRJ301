package com.lucy.api.modules.identity.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.constants.user.UserErrorCodeConstants;
import com.lucy.api.modules.identity.dtos.request.admin.AdminBanUserRequest;
import com.lucy.api.modules.identity.dtos.request.admin.AdminUpdateUserRolesRequest;
import com.lucy.api.modules.identity.dtos.request.admin.AdminUpdateUserStatusRequest;
import com.lucy.api.modules.identity.dtos.response.user.UserResponse;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.enums.UserRole;
import com.lucy.api.modules.identity.mapper.UserMapper;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.service.interfaces.AdminUserService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class AdminUserServiceImpl implements AdminUserService {

    UserRepository userRepository;
    UserMapper userMapper;

    @Override
    @Transactional
    public UserResponse updateStatus(String userId, AdminUpdateUserStatusRequest request) {
        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));

        if (request.getIsActive() != null) {
            user.setActive(request.getIsActive());
        }

        User saved = userRepository.save(user);
        return userMapper.toUserResponse(saved);
    }

    @Override
    @Transactional
    public UserResponse ban(String userId, AdminBanUserRequest request) {
        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));

        user.setBannedUntil(request.getBannedUntil());

        User saved = userRepository.save(user);
        return userMapper.toUserResponse(saved);
    }

    @Override
    @Transactional
    public UserResponse updateRoles(String userId, AdminUpdateUserRolesRequest request) {
        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));

        List<String> roleNames = request.getRoles();
        if (roleNames == null || roleNames.isEmpty()) {
            throw new AppException(UserErrorCodeConstants.COMMON_INVALID_PARAM, HttpStatus.BAD_REQUEST);
        }

        // Use the first role provided in the request
        try {
            UserRole newRole = UserRole.valueOf(roleNames.get(0).toUpperCase());
            user.setRoleName(newRole);
        } catch (IllegalArgumentException e) {
            throw new AppException(UserErrorCodeConstants.AUTH_ROLE_NOT_EXISTED, HttpStatus.NOT_FOUND);
        }

        User saved = userRepository.save(user);
        return userMapper.toUserResponse(saved);
    }

}
