package com.lucy.api.modules.lms.mapper;

import com.lucy.api.modules.lms.dto.request.ChapterUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.entity.Chapter;
import com.lucy.api.modules.lms.mapper.LessonMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", uses = {LessonMapper.class, MapperUtils.class})
public interface ChapterMapper {

    @Mapping(target = "courseRun", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "lessons", ignore = true)
    @Mapping(target = "title", source = "title", qualifiedByName = "trimValue")
    Chapter toEntity(ChapterUpsertRequest request);

    @Mapping(target = "courseRun", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "lessons", ignore = true)
    @Mapping(target = "title", source = "title", qualifiedByName = "trimValue")
    void updateEntity(@MappingTarget Chapter chapter, ChapterUpsertRequest request);

    @Mapping(target = "courseRunId", source = "courseRun.id")
    @Mapping(target = "courseRunCode", source = "courseRun.code")
    ChapterResponse toResponse(Chapter chapter);
}
