package com.lucy.api.modules.story.dto.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StoryItemResponse {
    UUID id;
    UUID userId;
    String displayName;
    String avatarUrl;
    String mediaUrl;
    String thumbnailUrl;
    String caption;
    String storyType;
    Instant expiresAt;
    Instant createdAt;
    boolean viewed;
}
