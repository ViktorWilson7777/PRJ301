package com.lucy.api.modules.audit.constants;

public final class AuditLogConstants {

    private AuditLogConstants() {}

    // ===== TABLE =====
    public static final String TABLE_AUDIT_LOGS = "audit_logs";

    // ===== COLUMNS =====
    public static final String COL_ACTOR_USER_ID  = "actor_user_id";
    public static final String COL_ACTOR_TYPE     = "actor_type";
    public static final String COL_ACTOR_DISPLAY  = "actor_display";
    public static final String COL_ACTION         = "action";
    public static final String COL_ENTITY_TYPE    = "entity_type";
    public static final String COL_ENTITY_ID      = "entity_id";
    public static final String COL_REQUEST_ID     = "request_id";
    public static final String COL_IP_ADDRESS     = "ip_address";
    public static final String COL_USER_AGENT     = "user_agent";
    public static final String COL_METADATA       = "metadata";
    public static final String COL_CREATED_AT     = "created_at";

    // ===== LENGTHS =====
    public static final int LENGTH_ACTOR_TYPE  = 30;
    public static final int LENGTH_ACTION      = 120;
    public static final int LENGTH_ENTITY_TYPE = 80;
    public static final int LENGTH_REQUEST_ID  = 128;

    // ===== COLUMN DEFINITIONS =====
    public static final String JSONB_DEFINITION = "jsonb";

    // ===== ACTOR TYPES =====
    public static final String ACTOR_TYPE_USER    = "user";
    public static final String ACTOR_TYPE_SYSTEM  = "system";
    public static final String ACTOR_TYPE_SERVICE = "service";

    // ===== HTTP HEADERS & JSON KEYS =====
    public static final String HEADER_X_FORWARDED_FOR  = "X-Forwarded-For";
    public static final String HEADER_USER_AGENT       = "User-Agent";
    public static final String JSON_KEY_DATA           = "data";
    public static final String JSON_KEY_ID             = "id";
    public static final String PACKAGE_SPRINGFRAMEWORK = "org.springframework";

    // ===== FIELD NAMES (JPA CRITERIA) =====
    public static final String FIELD_ACTION         = "action";
    public static final String FIELD_ENTITY_TYPE    = "entityType";
    public static final String FIELD_ACTOR_USER_ID  = "actorUserId";
    public static final String FIELD_CREATED_AT     = "createdAt";

}
