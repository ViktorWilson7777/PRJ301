package com.lucy.api.modules.messaging.service.domain;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.messaging.constant.MessagingErrorKeys;
import com.lucy.api.modules.messaging.entity.Conversation;
import com.lucy.api.modules.messaging.entity.ConversationParticipant;
import com.lucy.api.modules.messaging.enums.ConversationMode;
import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import com.lucy.api.modules.messaging.repository.ConversationParticipantRepository;
import com.lucy.api.modules.messaging.repository.ConversationRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Optional;

/**
 * Domain: participant — thêm/cập nhật, không event, không Redis.
 */
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ConversationParticipantDomainService {

    ConversationRepository conversationRepository;
    ConversationParticipantRepository conversationParticipantRepository;
    UserRepository userRepository;

    @Transactional(readOnly = true)
    public void requireActiveParticipant(String conversationId, String userId) {
        if (!conversationParticipantRepository.existsByConversationIdAndUserIdAndStatus(
                conversationId, userId, ParticipantStatus.ACTIVE)) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }
    }

    /**
     * Idempotent: đã ACTIVE thì return; có row LEFT thì reactivate.
     */
    @Transactional
    public void ensureActiveParticipant(String conversationId, String userId) {
        if (conversationParticipantRepository.existsByConversationIdAndUserIdAndStatus(
                conversationId, userId, ParticipantStatus.ACTIVE)) {
            return;
        }
        Optional<ConversationParticipant> opt =
                conversationParticipantRepository.findByConversationIdAndUserId(conversationId, userId);
        if (opt.isPresent()) {
            ConversationParticipant p = opt.get();
            p.setStatus(ParticipantStatus.ACTIVE);
            p.setJoinedAt(Instant.now());
            p.setLeftAt(null);
            conversationParticipantRepository.save(p);
            return;
        }
        Conversation conversation = conversationRepository.getReferenceById(conversationId);
        User user = userRepository.getReferenceById(userId);
        ConversationParticipant participant = ConversationParticipant.builder()
                .conversation(conversation)
                .user(user)
                .status(ParticipantStatus.ACTIVE)
                .joinedAt(Instant.now())
                .build();
        conversationParticipantRepository.save(participant);
    }

    /**
     * Ensure INVITED row exists for user (does not auto-activate).
     */
    @Transactional
    public void ensureInvitedParticipant(String conversationId, String userId) {
        Optional<ConversationParticipant> opt =
                conversationParticipantRepository.findByConversationIdAndUserId(conversationId, userId);
        if (opt.isPresent()) {
            ConversationParticipant p = opt.get();
            if (p.getStatus() == ParticipantStatus.ACTIVE) return;
            p.setStatus(ParticipantStatus.INVITED);
            p.setJoinedAt(Instant.now());
            p.setLeftAt(null);
            conversationParticipantRepository.save(p);
            return;
        }
        Conversation conversation = conversationRepository.getReferenceById(conversationId);
        User user = userRepository.getReferenceById(userId);
        ConversationParticipant participant = ConversationParticipant.builder()
                .conversation(conversation)
                .user(user)
                .status(ParticipantStatus.INVITED)
                .joinedAt(Instant.now())
                .build();
        conversationParticipantRepository.save(participant);
    }

    @Transactional(readOnly = true)
    public ParticipantStatus getMyStatus(String conversationId, String userId) {
        return conversationParticipantRepository.findByConversationIdAndUserId(conversationId, userId)
                .map(ConversationParticipant::getStatus)
                .orElse(null);
    }

    @Transactional
    public void acceptInvite(String conversationId, String userId) {
        ConversationParticipant p = conversationParticipantRepository
                .findByConversationIdAndUserId(conversationId, userId)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN));
        if (p.getStatus() != ParticipantStatus.INVITED) return;
        p.setStatus(ParticipantStatus.ACTIVE);
        p.setJoinedAt(Instant.now());
        p.setLeftAt(null);
        conversationParticipantRepository.save(p);
    }

    @Transactional
    public void rejectInvite(String conversationId, String userId) {
        ConversationParticipant p = conversationParticipantRepository
                .findByConversationIdAndUserId(conversationId, userId)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN));
        if (p.getStatus() != ParticipantStatus.INVITED) return;
        p.setStatus(ParticipantStatus.LEFT);
        p.setLeftAt(Instant.now());
        conversationParticipantRepository.save(p);
    }

    @Transactional
    public void markParticipantLeft(String conversationId, String userId) {
        conversationParticipantRepository.findByConversationIdAndUserId(conversationId, userId)
                .ifPresent(p -> {
                    p.setStatus(ParticipantStatus.LEFT);
                    p.setLeftAt(Instant.now());
                    conversationParticipantRepository.save(p);
                });
    }

    @Transactional
    public void markParticipantLeftForCourseRunGroup(String userId, String courseRunId) {
        conversationRepository.findByCourseRun_IdAndMode(courseRunId, ConversationMode.GROUP)
                .ifPresent(c -> markParticipantLeft(c.getId(), userId));
    }
}
