package com.lucy.api.modules.lms.progress.dto.request;

import com.lucy.api.modules.lms.progress.enums.LessonProgressStatus;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UpsertLessonProgressRequest {

    LessonProgressStatus status;

    @Min(0)
    @Max(100)
    Integer progressPercent;

    @Min(0)
    Integer lastPositionSeconds;
}

