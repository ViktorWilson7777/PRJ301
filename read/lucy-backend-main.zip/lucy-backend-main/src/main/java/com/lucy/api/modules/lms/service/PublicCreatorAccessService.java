package com.lucy.api.modules.lms.service;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.enums.ProfileRole;
import com.lucy.api.modules.identity.entity.enums.UserRole;
import com.lucy.api.modules.identity.service.impl.CurrentUserService;
import com.lucy.api.modules.lms.entity.Chapter;
import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.lms.entity.Lesson;
import com.lucy.api.modules.lms.entity.Program;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PublicCreatorAccessService {
    CurrentUserService currentUserService;

    @Transactional(readOnly = true)
    public User assertCanCreatePublicCatalog() {
        User currentUser = currentUserService.getCurrentUser();
        if (currentUser.getRoleName() == UserRole.ADMIN) {
            return currentUser;
        }
        ProfileRole profileRole = currentUserService.getCurrentProfileRole();
        if (profileRole != ProfileRole.PRO && profileRole != ProfileRole.SUPER) {
            throw new AppException("lms.public_creator_required", HttpStatus.FORBIDDEN);
        }
        return currentUser;
    }

    @Transactional(readOnly = true)
    public void assertCanManagePublicProgram(Program program) {
        User currentUser = currentUserService.getCurrentUser();
        if (currentUser.getRoleName() == UserRole.ADMIN) {
            return;
        }
        ProfileRole profileRole = currentUserService.getCurrentProfileRole();
        if (profileRole == ProfileRole.SUPER) {
            return;
        }
        if (profileRole != ProfileRole.PRO) {
            throw new AppException("lms.public_creator_required", HttpStatus.FORBIDDEN);
        }
        if (program.getOwnerUserId() == null || !program.getOwnerUserId().equals(currentUser.getId())) {
            throw new AppException("lms.public_program_forbidden", HttpStatus.FORBIDDEN);
        }
    }

    @Transactional(readOnly = true)
    public void assertCanManagePublicCourseRun(CourseRun courseRun) {
        assertCanManagePublicProgram(courseRun.getCourse().getProgram());
    }

    @Transactional(readOnly = true)
    public void assertCanManagePublicChapter(Chapter chapter) {
        assertCanManagePublicCourseRun(chapter.getCourseRun());
    }

    @Transactional(readOnly = true)
    public void assertCanManagePublicLesson(Lesson lesson) {
        assertCanManagePublicChapter(lesson.getChapter());
    }
}
