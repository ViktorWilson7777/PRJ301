package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.lms.dto.request.EnrollMeRequest;
import com.lucy.api.modules.lms.dto.request.EnrollmentFilterRequest;
import com.lucy.api.modules.lms.dto.request.ManualEnrollmentRequest;
import com.lucy.api.modules.lms.dto.request.EnrollmentUpdateRequest;
import com.lucy.api.modules.lms.dto.response.EnrollmentImportResponse;
import com.lucy.api.modules.lms.dto.response.EnrollmentResponse;
import com.lucy.api.modules.lms.service.api.EnrollmentService;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/enrollments")
@Tag(name = "LMS Enrollments", description = "APIs for managing course run enrollments")
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    @PostMapping("/me")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Self-enroll authenticated user into a course run")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> enrollMe(
            @Valid @RequestBody EnrollMeRequest request) {
        String userId = IdentityUtils.getCurrentUserId();
        request.setUserId(userId);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<EnrollmentResponse>builder()
                        .success(true)
                        .data(enrollmentService.enrollMe(request))
                        .build());
    }

    @PostMapping("/manual")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Manually enroll a user into a course run")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> manualEnroll(
            @Valid @RequestBody ManualEnrollmentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<EnrollmentResponse>builder()
                        .success(true)
                        .data(enrollmentService.manualEnroll(request))
                        .build());
    }

    @PostMapping("/import")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Import enrollments from Excel file by email")
    public ResponseEntity<ApiResponse<EnrollmentImportResponse>> importEnrollments(
            @RequestParam("file") MultipartFile file,
            @RequestParam("courseRunId") String courseRunId,
            @RequestParam(value = "dryRun", defaultValue = "false") boolean dryRun) {
        return ResponseEntity.ok(
                ApiResponse.<EnrollmentImportResponse>builder()
                        .success(true)
                        .data(enrollmentService.importFromExcel(file, courseRunId, dryRun))
                        .build());
    }

    @GetMapping("/import-template")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Download Excel template for enrollment import")
    public ResponseEntity<byte[]> downloadImportTemplate() {
        byte[] content = enrollmentService.generateImportTemplate();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=enrollment-import-template.xlsx")
                .body(content);
    }

    @GetMapping("/me/by-course-run/{courseRunId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Check current user's active enrollment for a course run")
    public ResponseEntity<ApiResponse<Boolean>> checkMyAccessByCourseRun(
            @PathVariable String courseRunId) {
        String userId = IdentityUtils.getCurrentUserId();
        return ResponseEntity.ok(
                ApiResponse.<Boolean>builder()
                        .success(true)
                        .data(enrollmentService.hasActiveEnrollment(userId, courseRunId))
                        .build());
    }

    @PostMapping("/filter")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Filter enrollments with compound conditions")
    public ResponseEntity<ApiResponse<PagingResponse<EnrollmentResponse>>> filter(
            @Valid @RequestBody EnrollmentFilterRequest request) {
        return ResponseEntity.ok(
                ApiResponse.<PagingResponse<EnrollmentResponse>>builder()
                        .success(true)
                        .data(enrollmentService.getList(request))
                        .build());
    }

    @GetMapping("/by-course-run/{courseRunId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get all enrollments for a course run")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByCourseRunId(
            @PathVariable String courseRunId) {
        return ResponseEntity.ok(
                ApiResponse.<List<EnrollmentResponse>>builder()
                        .success(true)
                        .data(enrollmentService.getByCourseRunId(courseRunId))
                        .build());
    }

    @GetMapping("/by-user/{userId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get all enrollments for a user")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByUserId(
            @PathVariable String userId) {
        return ResponseEntity.ok(
                ApiResponse.<List<EnrollmentResponse>>builder()
                        .success(true)
                        .data(enrollmentService.getByUserId(userId))
                        .build());
    }

    @GetMapping("/{enrollmentId}")
    @Operation(summary = "Get enrollment detail by id")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> getById(
            @PathVariable String enrollmentId) {
        return ResponseEntity.ok(
                ApiResponse.<EnrollmentResponse>builder()
                        .success(true)
                        .data(enrollmentService.getById(enrollmentId))
                        .build());
    }

    @PutMapping("/{enrollmentId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Update enrollment status, role, or other fields")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> update(
            @PathVariable String enrollmentId,
            @Valid @RequestBody EnrollmentUpdateRequest request) {
        return ResponseEntity.ok(
                ApiResponse.<EnrollmentResponse>builder()
                        .success(true)
                        .data(enrollmentService.update(enrollmentId, request))
                        .build());
    }

    @DeleteMapping("/{enrollmentId}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Delete an enrollment")
    public ResponseEntity<ApiResponse<String>> delete(
            @PathVariable String enrollmentId) {
        enrollmentService.delete(enrollmentId);
        return ResponseEntity.ok(
                ApiResponse.<String>builder()
                        .success(true)
                        .data("Enrollment deleted successfully")
                        .build());
    }
}
