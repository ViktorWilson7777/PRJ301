package com.lucy.api.modules.messaging.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.messaging.constant.ConversationConstants;
import com.lucy.api.modules.messaging.enums.ConversationMode;
import com.lucy.api.modules.messaging.enums.ConversationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = ConversationConstants.TABLE_CONVERSATIONS)
public class Conversation extends BaseEntity {

    @Enumerated(EnumType.STRING)
    @Column(name = ConversationConstants.COL_MODE, nullable = false, length = 20)
    ConversationMode mode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = ConversationConstants.COL_COURSE_RUN_ID)
    CourseRun courseRun;

    @Column(name = ConversationConstants.COL_ROOM_ID, length = 36)
    String roomId;

    @Column(name = ConversationConstants.COL_DIRECT_KEY, length = ConversationConstants.LENGTH_DIRECT_KEY)
    String directKey;

    @Column(name = ConversationConstants.COL_GROUP_NAME, length = ConversationConstants.LENGTH_GROUP_NAME)
    String groupName;

    @Column(name = ConversationConstants.COL_CREATED_BY, length = ConversationConstants.LENGTH_CREATED_BY)
    String createdBy;

    @Enumerated(EnumType.STRING)
    @Column(name = ConversationConstants.COL_STATUS, nullable = false, length = 20)
    ConversationStatus status = ConversationStatus.OPEN;
}
