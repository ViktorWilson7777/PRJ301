package com.lucy.api.modules.messaging.websocket;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketErrorCodeConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketFrameTypeConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketMessageKeys;
import com.lucy.api.infrastructure.websocket.entity.WebSocketSession;
import com.lucy.api.infrastructure.websocket.enums.WebSocketMessageType;
import com.lucy.api.infrastructure.websocket.handler.WebSocketCommandHandler;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketSessionService;
import com.lucy.api.infrastructure.websocket.utils.WebSocketPayloadCodec;
import com.lucy.api.modules.messaging.constant.MessagingErrorKeys;
import com.lucy.api.modules.messaging.constant.MessagingWebSocketFrameConstants;
import com.lucy.api.modules.messaging.dto.request.AttachmentRequest;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;
import com.lucy.api.modules.messaging.dto.websocket.WebSocketSendMessageRequest;
import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import com.lucy.api.modules.messaging.repository.ConversationParticipantRepository;
import com.lucy.api.modules.messaging.repository.ConversationRepository;
import com.lucy.api.modules.messaging.service.facade.MessagingFacade;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;

@Slf4j
@Component
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MessagingSendMessageCommandHandler implements WebSocketCommandHandler {

    ExecutorService messagingWebSocketExecutor;

    WebSocketSessionService sessionService;
    ConversationRepository conversationRepository;
    ConversationParticipantRepository conversationParticipantRepository;
    MessagingFacade messagingFacade;
    WebSocketPayloadCodec payloadCodec;
    MessageSource messageSource;

    public MessagingSendMessageCommandHandler(
            @Qualifier("messagingWebSocketExecutor") ExecutorService messagingWebSocketExecutor,
            WebSocketSessionService sessionService,
            ConversationRepository conversationRepository,
            ConversationParticipantRepository conversationParticipantRepository,
            MessagingFacade messagingFacade,
            WebSocketPayloadCodec payloadCodec,
            MessageSource messageSource
    ) {
        this.messagingWebSocketExecutor = messagingWebSocketExecutor;
        this.sessionService = sessionService;
        this.conversationRepository = conversationRepository;
        this.conversationParticipantRepository = conversationParticipantRepository;
        this.messagingFacade = messagingFacade;
        this.payloadCodec = payloadCodec;
        this.messageSource = messageSource;
    }

    @Override
    public String getType() {
        return WebSocketMessageType.MESSAGE.name();
    }

    @Override
    public void handle(ChannelHandlerContext ctx, String payloadJson, String sessionId) {
        messagingWebSocketExecutor.execute(() -> doHandle(ctx, payloadJson, sessionId));
    }

    private void doHandle(ChannelHandlerContext ctx, String payloadJson, String sessionId) {
        try {
            WebSocketSendMessageRequest request =
                    payloadCodec.parseMessage(payloadJson, WebSocketSendMessageRequest.class);
            if (request == null || !StringUtils.hasText(request.getConversationId())) {
                sendError(ctx, WebSocketErrorCodeConstants.INVALID_MESSAGE, WebSocketMessageKeys.CONVERSATION_ID_REQUIRED);
                return;
            }

            boolean hasText = request.getText() != null && !request.getText().trim().isEmpty();
            boolean hasAttachment = StringUtils.hasText(request.getAttachmentUrl());
            if (!hasText && !hasAttachment) {
                sendError(ctx, WebSocketErrorCodeConstants.INVALID_MESSAGE, WebSocketMessageKeys.MESSAGE_CONTENT_REQUIRED);
                return;
            }

            var sessionOpt = sessionService.getSession(sessionId);
            if (sessionOpt.isEmpty()) {
                sendError(ctx, WebSocketErrorCodeConstants.SESSION_NOT_FOUND, WebSocketMessageKeys.SESSION_NOT_FOUND);
                return;
            }

            WebSocketSession session = sessionOpt.get();
            String conversationId = request.getConversationId().trim();

            if (session.getConversationId() == null || !conversationId.equals(session.getConversationId())) {
                sendError(ctx, WebSocketErrorCodeConstants.MESSAGING_FORBIDDEN, WebSocketMessageKeys.NOT_JOINED_CONVERSATION);
                return;
            }

            conversationRepository.findById(conversationId)
                    .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));

            boolean active = conversationParticipantRepository.existsByConversationIdAndUserIdAndStatus(
                    conversationId, session.getUserId(), ParticipantStatus.ACTIVE);
            if (!active) {
                sendError(ctx, WebSocketErrorCodeConstants.MESSAGING_FORBIDDEN, MessagingErrorKeys.NOT_PARTICIPANT);
                return;
            }

            List<AttachmentRequest> attachments = null;
            if (hasAttachment) {
                attachments = List.of(AttachmentRequest.builder()
                        .type(StringUtils.hasText(request.getAttachmentType()) ? request.getAttachmentType().trim() : null)
                        .url(request.getAttachmentUrl().trim())
                        .title(null)
                        .build());
            }

            ChatMessageResponse saved = messagingFacade.sendMessage(
                    conversationId,
                    null,
                    session.getUserId(),
                    request.getText(),
                    attachments,
                    null
            );

            session.setLastActivityAt(Instant.now());
            sessionService.updateSession(sessionId, session);

            String body = payloadCodec.toJson(Map.of(
                    WebSocketConstants.FIELD_TYPE, MessagingWebSocketFrameConstants.MESSAGE_ACK,
                    MessagingWebSocketFrameConstants.FIELD_SUCCESS, Boolean.TRUE,
                    MessagingWebSocketFrameConstants.FIELD_CONVERSATION_ID, conversationId,
                    MessagingWebSocketFrameConstants.FIELD_MESSAGE_ID, saved.getId()
            ));
            if (body != null) {
                ctx.channel().writeAndFlush(new TextWebSocketFrame(body));
            }
            log.debug("Message sent from session {} to conversation {}", sessionId, conversationId);
        } catch (AppException e) {
            sendAppException(ctx, e);
        } catch (Exception e) {
            log.error("Error sending messaging WebSocket message", e);
            sendError(ctx, WebSocketErrorCodeConstants.MESSAGE_SEND_FAILED, WebSocketMessageKeys.MESSAGE_SEND_FAILED);
        }
    }

    private void sendAppException(ChannelHandlerContext ctx, AppException ex) {
        String resolved = messageSource.getMessage(ex.getErrorCode(), null, ex.getErrorCode(), Locale.ENGLISH);
        String errorJson = payloadCodec.toJson(Map.of(
                WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.ERROR,
                WebSocketConstants.FIELD_ERROR_CODE, WebSocketErrorCodeConstants.MESSAGING_FORBIDDEN,
                WebSocketConstants.FIELD_MESSAGE, resolved,
                WebSocketConstants.FIELD_MESSAGE_KEY, ex.getErrorCode()
        ));
        if (errorJson != null) {
            ctx.channel().writeAndFlush(new TextWebSocketFrame(errorJson));
        }
    }

    private void sendError(ChannelHandlerContext ctx, String errorCode, String messageKey) {
        String text = messageSource.getMessage(messageKey, null, Locale.ENGLISH);
        String errorJson = payloadCodec.toJson(Map.of(
                WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.ERROR,
                WebSocketConstants.FIELD_ERROR_CODE, errorCode,
                WebSocketConstants.FIELD_MESSAGE, text,
                WebSocketConstants.FIELD_MESSAGE_KEY, messageKey
        ));
        if (errorJson != null) {
            ctx.channel().writeAndFlush(new TextWebSocketFrame(errorJson));
        }
    }
}
