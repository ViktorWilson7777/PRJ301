package com.lucy.api.modules.event.repository;

import com.lucy.api.modules.event.entity.RoomCommentLikeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface RoomCommentLikeRepository extends JpaRepository<RoomCommentLikeEntity, UUID> {
    Optional<RoomCommentLikeEntity> findByCommentIdAndUserId(UUID commentId, UUID userId);
    long countByCommentId(UUID commentId);
    void deleteAllByUserIdIn(List<UUID> userIds);
}
