package com.lucy.api.modules.event.dto.realtime;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

public record SocialFeedTickerMessage(
        String type,
        String entityType,
        UUID entityId,
        UUID actorUserId,
        Instant occurredAt,
        Map<String, Object> data
) {
}
