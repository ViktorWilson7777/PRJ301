package com.lucy.api.modules.commerce.repository;

import com.lucy.api.modules.commerce.entity.PublicOrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PublicOrderItemRepository extends JpaRepository<PublicOrderItem, String> {
    List<PublicOrderItem> findAllByOrder_IdOrderByCreatedAtAsc(String orderId);
}
