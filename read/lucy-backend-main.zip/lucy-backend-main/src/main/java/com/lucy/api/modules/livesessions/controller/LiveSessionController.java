package com.lucy.api.modules.livesessions.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.livesessions.dto.request.CreateLiveSessionRequest;
import com.lucy.api.modules.livesessions.dto.response.LiveSessionResponse;
import com.lucy.api.modules.livesessions.service.api.LiveSessionService;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/live-sessions")
@RequiredArgsConstructor
@Tag(name = "Live Sessions", description = "Standalone live session management (CRUD, status)")
public class LiveSessionController {

    private final LiveSessionService liveSessionService;

    // ─────────────────────────────────────────────────────
    //  Create — only ADMIN or TUTOR role
    // ─────────────────────────────────────────────────────

    @PostMapping
    @Operation(summary = "Create a standalone live session (ADMIN/TUTOR)")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LiveSessionResponse>> createSession(
            @Valid @RequestBody CreateLiveSessionRequest request
    ) {
        String ownerId = IdentityUtils.getCurrentUserId();
        LiveSessionResponse response = liveSessionService.createSession(request, ownerId);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<LiveSessionResponse>builder()
                        .success(true)
                        .data(response)
                        .build());
    }

    // ─────────────────────────────────────────────────────
    //  Read — any authenticated user
    // ─────────────────────────────────────────────────────

    @GetMapping("/{sessionId}")
    @Operation(summary = "Get a live session by ID")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LiveSessionResponse>> getById(@PathVariable String sessionId) {
        return ResponseEntity.ok(ApiResponse.<LiveSessionResponse>builder()
                .success(true)
                .data(liveSessionService.getSessionById(sessionId))
                .build());
    }

    @GetMapping("/by-room/{roomCode}")
    @Operation(summary = "Get a live session by room code")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LiveSessionResponse>> getByRoomCode(@PathVariable String roomCode) {
        return ResponseEntity.ok(ApiResponse.<LiveSessionResponse>builder()
                .success(true)
                .data(liveSessionService.getSessionByRoomCode(roomCode))
                .build());
    }

    @GetMapping("/my-sessions")
    @Operation(summary = "Get all sessions created by the authenticated user")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<LiveSessionResponse>>> getMySessions() {
        String ownerId = IdentityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.<List<LiveSessionResponse>>builder()
                .success(true)
                .data(liveSessionService.getSessionsByOwner(ownerId))
                .build());
    }

    // ─────────────────────────────────────────────────────
    //  Status management — owner or ADMIN
    // ─────────────────────────────────────────────────────

    @PatchMapping("/{sessionId}/end")
    @Operation(summary = "End (terminate) a live session")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LiveSessionResponse>> endSession(@PathVariable String sessionId) {
        String requesterId = IdentityUtils.getCurrentUserId();
        return ResponseEntity.ok(ApiResponse.<LiveSessionResponse>builder()
                .success(true)
                .data(liveSessionService.endSession(sessionId, requesterId))
                .build());
    }

    // ─────────────────────────────────────────────────────
    //  Delete — owner or ADMIN
    // ─────────────────────────────────────────────────────

    @DeleteMapping("/{sessionId}")
    @Operation(summary = "Delete a live session record")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteSession(@PathVariable String sessionId) {
        String requesterId = IdentityUtils.getCurrentUserId();
        liveSessionService.deleteSession(sessionId, requesterId);
        return ResponseEntity.ok(ApiResponse.<String>builder()
                .success(true)
                .data("Live session deleted successfully")
                .build());
    }
}
