package com.lucy.api.modules.commerce.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.commerce.entity.enums.PublicOrderStatus;
import com.lucy.api.modules.identity.entity.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "public_orders")
public class PublicOrder extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "buyer_user_id", nullable = false)
    User buyerUser;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    PublicOrderStatus status = PublicOrderStatus.PENDING;

    @Column(nullable = false, precision = 19, scale = 2)
    BigDecimal totalAmount;

    @Column(nullable = false, length = 10)
    String currency;

    @Column(nullable = false, length = 50)
    String provider;

    @Column(length = 255)
    String providerTransactionId;

    Instant paidAt;
}
