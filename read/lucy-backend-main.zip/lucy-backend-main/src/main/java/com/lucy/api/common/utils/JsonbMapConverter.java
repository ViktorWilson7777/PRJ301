package com.lucy.api.common.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.common.exceptions.AppException;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import org.springframework.http.HttpStatus;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

@Converter
public class JsonbMapConverter implements AttributeConverter<Map<String, Object>, String> {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper().findAndRegisterModules();
    private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE =
            new TypeReference<Map<String, Object>>() {
            };

    @Override
    public String convertToDatabaseColumn(Map<String, Object> attribute) {
        if (attribute == null || attribute.isEmpty()) {
            return "{}";
        }

        try {
            return OBJECT_MAPPER.writeValueAsString(attribute);
        } catch (Exception e) {
            Map<String, Object> params = new LinkedHashMap<>();
            params.put("source", "jsonb_write");
            params.put("detail", e.getMessage());
            throw new AppException("system.database_error", HttpStatus.INTERNAL_SERVER_ERROR, params);
        }
    }

    @Override
    public Map<String, Object> convertToEntityAttribute(String dbData) {
        if (dbData == null || dbData.isBlank()) {
            return Collections.emptyMap();
        }

        try {
            return readJsonMap(dbData);
        } catch (Exception e) {
            Map<String, Object> params = new LinkedHashMap<>();
            params.put("source", "jsonb_read");
            params.put("detail", e.getMessage());
            throw new AppException("system.database_error", HttpStatus.INTERNAL_SERVER_ERROR, params);
        }
    }

    private Map<String, Object> readJsonMap(String rawJson) throws Exception {
        JsonNode jsonNode = OBJECT_MAPPER.readTree(rawJson);
        if (jsonNode == null || jsonNode.isNull()) {
            return Collections.emptyMap();
        }

        if (jsonNode.isObject()) {
            return OBJECT_MAPPER.convertValue(jsonNode, MAP_TYPE_REFERENCE);
        }

        if (jsonNode.isTextual()) {
            String nestedJson = jsonNode.asText();
            if (nestedJson == null || nestedJson.isBlank()) {
                return Collections.emptyMap();
            }
            return readJsonMap(nestedJson);
        }

        return Collections.emptyMap();
    }
}

