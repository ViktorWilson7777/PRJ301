package com.lucy.api.modules.messaging.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.messaging.constant.ChatAttachmentConstants;
import com.lucy.api.modules.messaging.constant.ChatMessageConstants;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = ChatMessageConstants.TABLE_CHAT_MESSAGES)
public class ChatMessage extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = ChatMessageConstants.COL_CONVERSATION_ID,
            nullable = false,
            foreignKey = @ForeignKey(name = "fk_chat_msg_conversation")
    )
    Conversation conversation;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = ChatMessageConstants.COL_SENDER_ID,
            nullable = false,
            foreignKey = @ForeignKey(name = "fk_chat_msg_sender")
    )
    User sender;

    @Column(name = ChatMessageConstants.COL_TEXT, length = 4000)
    String text;

    @Column(name = ChatMessageConstants.COL_REPLY_TO_MESSAGE_ID, length = 36)
    String replyToMessageId;

    @Column(name = ChatMessageConstants.COL_IS_EDITED)
    Boolean isEdited;

    @Column(name = ChatMessageConstants.COL_EDIT_COUNT)
    Integer editCount;

    @Column(name = ChatMessageConstants.COL_IS_ECHO)
    Boolean isEcho;

    @ElementCollection
    @CollectionTable(
            name = ChatAttachmentConstants.TABLE_CHAT_MESSAGE_ATTACHMENTS,
            joinColumns = @JoinColumn(name = ChatAttachmentConstants.COL_MESSAGE_ID)
    )
    List<ChatAttachment> attachments = new ArrayList<>();
}
