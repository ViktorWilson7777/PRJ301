package com.lucy.api.modules.event.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.event.dto.request.CreateEventRequest;
import com.lucy.api.modules.event.dto.request.CreateCommentRequest;
import com.lucy.api.modules.event.dto.request.EventFeedRequest;
import com.lucy.api.modules.event.dto.request.InterestRequest;
import com.lucy.api.modules.event.dto.request.LikeRequest;
import com.lucy.api.modules.event.dto.request.MicToggleRequest;
import com.lucy.api.modules.event.dto.request.RaiseHandRequest;
import com.lucy.api.modules.event.dto.response.CommentListResponse;
import com.lucy.api.modules.event.dto.response.CommentItemResponse;
import com.lucy.api.modules.event.dto.response.CreateEventResponse;
import com.lucy.api.modules.event.dto.response.EventDetailResponse;
import com.lucy.api.modules.event.dto.response.EventFeedResponse;
import com.lucy.api.modules.event.dto.response.JoinEventResponse;
import com.lucy.api.modules.event.dto.response.ParticipantResponse;
import com.lucy.api.modules.event.dto.response.ParticipantRealtimeStateResponse;
import com.lucy.api.modules.event.service.EventAuthContextService;
import com.lucy.api.modules.event.service.EventService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
public class EventController {
    private final EventService eventService;
    private final EventAuthContextService eventAuthContextService;

    @PostMapping
    public ResponseEntity<ApiResponse<CreateEventResponse>> createEvent(
            @Valid @RequestBody CreateEventRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<CreateEventResponse>builder()
                .success(true)
                .data(eventService.createEvent(request, currentUserId))
                .build());
    }

    @GetMapping
    public ResponseEntity<ApiResponse<EventFeedResponse>> listEvents(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Boolean mine,
            @RequestParam(required = false) Boolean interested,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(required = false) String cursor,
            @RequestParam(required = false) String query,
            @RequestParam(required = false) Integer limit,
            @AuthenticationPrincipal Jwt jwt
    ) {
        EventFeedRequest request = new EventFeedRequest(status, mine, interested, from, to, cursor, query, limit);
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<EventFeedResponse>builder()
                .success(true)
                .data(eventService.listEvents(request, currentUserId))
                .build());
    }

    @GetMapping("/{eventId}")
    public ResponseEntity<ApiResponse<EventDetailResponse>> getEventDetail(
            @PathVariable UUID eventId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        UUID currentUserId = eventAuthContextService.getUserId(jwt).orElse(null);
        return ResponseEntity.ok(ApiResponse.<EventDetailResponse>builder()
                .success(true)
                .data(eventService.getEventDetail(eventId, currentUserId))
                .build());
    }

    @PostMapping("/{eventId}/interest")
    public ResponseEntity<ApiResponse<Object>> updateInterest(
            @PathVariable UUID eventId,
            @Valid @RequestBody InterestRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.updateInterest(eventId, request, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @PostMapping("/{eventId}/like")
    public ResponseEntity<ApiResponse<Object>> updateLike(
            @PathVariable UUID eventId,
            @Valid @RequestBody LikeRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.updateLike(eventId, request, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @DeleteMapping("/{eventId}/like")
    public ResponseEntity<ApiResponse<Object>> removeLike(
            @PathVariable UUID eventId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        LikeRequest request = new LikeRequest(false);
        eventService.updateLike(eventId, request, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @PostMapping("/{eventId}/comments")
    public ResponseEntity<ApiResponse<CommentItemResponse>> createComment(
            @PathVariable UUID eventId,
            @Valid @RequestBody CreateCommentRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<CommentItemResponse>builder()
                .success(true)
                .data(eventService.createComment(eventId, request, currentUserId))
                .build());
    }

    @GetMapping("/{eventId}/comments")
    public ResponseEntity<ApiResponse<CommentListResponse>> listComments(
            @PathVariable UUID eventId,
            @RequestParam(required = false) String cursor,
            @RequestParam(required = false) Integer limit,
            @AuthenticationPrincipal Jwt jwt
    ) {
        UUID currentUserId = eventAuthContextService.getUserId(jwt).orElse(null);
        return ResponseEntity.ok(ApiResponse.<CommentListResponse>builder()
                .success(true)
                .data(eventService.listComments(eventId, cursor, limit, currentUserId))
                .build());
    }

    @PostMapping("/comments/{commentId}/like")
    public ResponseEntity<ApiResponse<Object>> toggleLikeComment(
            @PathVariable UUID commentId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.toggleLikeComment(commentId, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @DeleteMapping("/comments/{commentId}")
    public ResponseEntity<ApiResponse<Object>> deleteComment(
            @PathVariable UUID commentId,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.deleteComment(commentId, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @PostMapping("/{eventId}/join")
    public ResponseEntity<ApiResponse<JoinEventResponse>> joinEvent(@PathVariable UUID eventId, @AuthenticationPrincipal Jwt jwt) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<JoinEventResponse>builder()
                .success(true)
                .data(eventService.joinEvent(eventId, currentUserId))
                .build());
    }

    @PostMapping("/{eventId}/leave")
    public ResponseEntity<ApiResponse<Object>> leaveEvent(@PathVariable UUID eventId, @AuthenticationPrincipal Jwt jwt) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.leaveEvent(eventId, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @PostMapping("/{eventId}/rtc-token")
    public ResponseEntity<ApiResponse<JoinEventResponse>> issueRtcToken(@PathVariable UUID eventId, @AuthenticationPrincipal Jwt jwt) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        return ResponseEntity.ok(ApiResponse.<JoinEventResponse>builder()
                .success(true)
                .data(eventService.issueRtcToken(eventId, currentUserId))
                .build());
    }

    @PostMapping("/rooms/{roomId}/start")
    public ResponseEntity<ApiResponse<Object>> startRoom(@PathVariable UUID roomId, @AuthenticationPrincipal Jwt jwt) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.startRoom(roomId, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @PostMapping("/rooms/{roomId}/end")
    public ResponseEntity<ApiResponse<Object>> endRoom(@PathVariable UUID roomId, @AuthenticationPrincipal Jwt jwt) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.endRoom(roomId, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @GetMapping("/rooms/{roomId}/participants")
    public ResponseEntity<ApiResponse<List<ParticipantResponse>>> listParticipants(@PathVariable UUID roomId) {
        return ResponseEntity.ok(ApiResponse.<List<ParticipantResponse>>builder()
                .success(true)
                .data(eventService.listParticipants(roomId))
                .build());
    }

    @GetMapping("/{eventId}/rooms/{roomId}/participants")
    public ResponseEntity<ApiResponse<List<ParticipantResponse>>> listParticipantsByEventRoom(
            @PathVariable UUID eventId,
            @PathVariable UUID roomId
    ) {
        return ResponseEntity.ok(ApiResponse.<List<ParticipantResponse>>builder()
                .success(true)
                .data(eventService.listParticipants(eventId, roomId))
                .build());
    }

    @PostMapping("/{eventId}/rooms/{roomId}/participants/me/mic-toggle")
    public ResponseEntity<ApiResponse<Object>> toggleMic(
            @PathVariable UUID eventId,
            @PathVariable UUID roomId,
            @Valid @RequestBody MicToggleRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.toggleMic(eventId, roomId, request, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @PostMapping("/{eventId}/rooms/{roomId}/participants/{participantUserId}/mic-toggle")
    public ResponseEntity<ApiResponse<Object>> monitorToggleParticipantMic(
            @PathVariable UUID eventId,
            @PathVariable UUID roomId,
            @PathVariable UUID participantUserId,
            @Valid @RequestBody MicToggleRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.monitorToggleMic(eventId, roomId, participantUserId, request, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @PostMapping("/{eventId}/rooms/{roomId}/participants/me/raise-hand")
    public ResponseEntity<ApiResponse<Object>> raiseHand(
            @PathVariable UUID eventId,
            @PathVariable UUID roomId,
            @Valid @RequestBody RaiseHandRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        var currentUserId = eventAuthContextService.requireUserId(jwt);
        eventService.updateRaiseHand(eventId, roomId, request, currentUserId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @GetMapping("/{eventId}/rooms/{roomId}/participants/realtime-state")
    public ResponseEntity<ApiResponse<ParticipantRealtimeStateResponse>> getParticipantRealtimeState(
            @PathVariable UUID eventId,
            @PathVariable UUID roomId
    ) {
        return ResponseEntity.ok(ApiResponse.<ParticipantRealtimeStateResponse>builder()
                .success(true)
                .data(eventService.getRealtimeParticipantState(eventId, roomId))
                .build());
    }
}
