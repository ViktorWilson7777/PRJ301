package com.lucy.api.infrastructure.redis.constants;

/**
 * Chuỗi log cố định cho pub/sub Redis (tránh hardcode rải rác).
 */
public final class RedisPubSubLogConstants {

    private RedisPubSubLogConstants() {
    }

    public static final String NO_HANDLER = "No RedisEventHandler for channel: {}";
    public static final String MULTI_HANDLER = "Multiple RedisEventHandler matched channel: {} (count={})";
    public static final String DISPATCH_ERROR = "Error dispatching Redis pub/sub message";
}
