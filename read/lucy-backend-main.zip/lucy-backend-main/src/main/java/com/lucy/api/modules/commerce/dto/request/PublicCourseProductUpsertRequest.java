package com.lucy.api.modules.commerce.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class PublicCourseProductUpsertRequest {
    @NotNull(message = "common.field_required")
    @DecimalMin(value = "0.0", inclusive = false, message = "common.validation")
    BigDecimal priceAmount;

    @NotBlank(message = "common.field_required")
    @Size(max = 10, message = "common.validation")
    String currency;

    Boolean active = Boolean.TRUE;
}
