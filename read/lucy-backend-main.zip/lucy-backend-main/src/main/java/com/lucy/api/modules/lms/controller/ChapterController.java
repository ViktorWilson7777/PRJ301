package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.audit.annotation.AuditAction;
import com.lucy.api.modules.audit.constants.AuditActionType;
import com.lucy.api.modules.audit.constants.AuditEntityType;
import com.lucy.api.modules.lms.dto.request.ChapterUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.service.api.ChapterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/chapters")
@Tag(name = "LMS Chapters", description = "CRUD APIs for chapters")
public class ChapterController {
    private final ChapterService chapterService;

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Create a new chapter")
    @AuditAction(action = AuditActionType.CHAPTER_CREATE, entityType = AuditEntityType.CHAPTER)
    public ResponseEntity<ApiResponse<ChapterResponse>> create(@Valid @RequestBody ChapterUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.create(request)).build());
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get all chapters")
    public ResponseEntity<ApiResponse<List<ChapterResponse>>> findAll(@RequestParam(required = false) String courseRunId) {
        return ResponseEntity.ok(ApiResponse.<List<ChapterResponse>>builder().success(true).data(chapterService.findAll(courseRunId)).build());
    }

    @GetMapping("/{chapterId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get a chapter by id")
    public ResponseEntity<ApiResponse<ChapterResponse>> findById(@PathVariable String chapterId) {
        return ResponseEntity.ok(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.findById(chapterId)).build());
    }

    @PutMapping("/{chapterId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Update a chapter")
    @AuditAction(action = AuditActionType.CHAPTER_UPDATE, entityType = AuditEntityType.CHAPTER)
    public ResponseEntity<ApiResponse<ChapterResponse>> update(@PathVariable String chapterId, @Valid @RequestBody ChapterUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.update(chapterId, request)).build());
    }

    @DeleteMapping("/{chapterId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Delete a chapter")
    @AuditAction(action = AuditActionType.CHAPTER_DELETE, entityType = AuditEntityType.CHAPTER)
    public ResponseEntity<ApiResponse<String>> delete(@PathVariable String chapterId) {
        chapterService.delete(chapterId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Chapter deleted successfully").build());
    }
}
