package com.lucy.api.modules.lms.progress.repository;

import com.lucy.api.modules.lms.progress.entity.LessonProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface LessonProgressRepository extends JpaRepository<LessonProgress, String> {

    Optional<LessonProgress> findByEnrollment_IdAndLesson_Id(String enrollmentId, String lessonId);

    List<LessonProgress> findAllByEnrollment_Id(String enrollmentId);

    @Query("""
            select count(lp)
            from LessonProgress lp
            where lp.enrollment.id = :enrollmentId
              and lp.status = com.lucy.api.modules.lms.progress.enums.LessonProgressStatus.COMPLETED
            """)
    long countCompletedByEnrollmentId(String enrollmentId);

    interface EnrollmentCompletedCount {
        String getEnrollmentId();
        long getCompletedLessons();
    }

    @Query("""
            select lp.enrollment.id as enrollmentId, count(lp) as completedLessons
            from LessonProgress lp
            where lp.enrollment.id in :enrollmentIds
              and lp.status = com.lucy.api.modules.lms.progress.enums.LessonProgressStatus.COMPLETED
            group by lp.enrollment.id
            """)
    List<EnrollmentCompletedCount> countCompletedByEnrollmentIds(@Param("enrollmentIds") List<String> enrollmentIds);

    @Modifying
    @Transactional
    void deleteAllByEnrollment_IdIn(List<String> enrollmentIds);
}

