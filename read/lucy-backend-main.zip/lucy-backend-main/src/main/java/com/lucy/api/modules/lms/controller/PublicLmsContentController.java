package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.lms.dto.request.ChapterUpsertRequest;
import com.lucy.api.modules.lms.dto.request.LessonFileUploadRequest;
import com.lucy.api.modules.lms.dto.request.LessonUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.dto.response.LessonFileUploadResponse;
import com.lucy.api.modules.lms.dto.response.LessonResponse;
import com.lucy.api.modules.lms.entity.Chapter;
import com.lucy.api.modules.lms.entity.Lesson;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.lms.service.PublicCreatorAccessService;
import com.lucy.api.modules.lms.service.api.ChapterService;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import com.lucy.api.modules.lms.service.api.LessonService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/public")
public class PublicLmsContentController {
    private final ChapterService chapterService;
    private final LessonService lessonService;
    private final CourseRunService courseRunService;
    private final PublicCreatorAccessService publicCreatorAccessService;

    @PostMapping("/chapters")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ChapterResponse>> createChapter(@Valid @RequestBody ChapterUpsertRequest request) {
        publicCreatorAccessService.assertCanManagePublicCourseRun(courseRunService.getEntityById(request.getCourseRunId()));
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.create(request)).build());
    }

    @GetMapping("/chapters")
    public ResponseEntity<ApiResponse<List<ChapterResponse>>> getChapters(@RequestParam String courseRunId) {
        courseRunService.findPublicById(courseRunId);
        return ResponseEntity.ok(ApiResponse.<List<ChapterResponse>>builder().success(true).data(chapterService.findAll(courseRunId)).build());
    }

    @GetMapping("/chapters/{chapterId}")
    public ResponseEntity<ApiResponse<ChapterResponse>> getChapter(@PathVariable String chapterId) {
        Chapter chapter = chapterService.getEntityById(chapterId);
        if (chapter.getCourseRun().getAccessScope() != LmsAccessScope.PUBLIC) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.<ChapterResponse>builder().success(false).build());
        }
        return ResponseEntity.ok(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.findById(chapterId)).build());
    }

    @PutMapping("/chapters/{chapterId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ChapterResponse>> updateChapter(@PathVariable String chapterId, @Valid @RequestBody ChapterUpsertRequest request) {
        publicCreatorAccessService.assertCanManagePublicChapter(chapterService.getEntityById(chapterId));
        return ResponseEntity.ok(ApiResponse.<ChapterResponse>builder().success(true).data(chapterService.update(chapterId, request)).build());
    }

    @DeleteMapping("/chapters/{chapterId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteChapter(@PathVariable String chapterId) {
        publicCreatorAccessService.assertCanManagePublicChapter(chapterService.getEntityById(chapterId));
        chapterService.delete(chapterId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Public chapter deleted successfully").build());
    }

    @PostMapping("/lessons")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LessonResponse>> createLesson(@Valid @RequestBody LessonUpsertRequest request) {
        Chapter chapter = chapterService.getEntityById(request.getChapterId());
        publicCreatorAccessService.assertCanManagePublicChapter(chapter);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.create(request)).build());
    }

    @GetMapping("/lessons")
    public ResponseEntity<ApiResponse<List<LessonResponse>>> getLessons(@RequestParam String chapterId) {
        Chapter chapter = chapterService.getEntityById(chapterId);
        if (chapter.getCourseRun().getAccessScope() != LmsAccessScope.PUBLIC) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.<List<LessonResponse>>builder().success(false).build());
        }
        return ResponseEntity.ok(ApiResponse.<List<LessonResponse>>builder().success(true).data(lessonService.findAll(chapterId)).build());
    }

    @GetMapping("/lessons/{lessonId}")
    public ResponseEntity<ApiResponse<LessonResponse>> getLesson(@PathVariable String lessonId) {
        Lesson lesson = lessonService.getEntityById(lessonId);
        if (lesson.getChapter().getCourseRun().getAccessScope() != LmsAccessScope.PUBLIC) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse.<LessonResponse>builder().success(false).build());
        }
        return ResponseEntity.ok(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.findById(lessonId)).build());
    }

    @PutMapping("/lessons/{lessonId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LessonResponse>> updateLesson(@PathVariable String lessonId, @Valid @RequestBody LessonUpsertRequest request) {
        publicCreatorAccessService.assertCanManagePublicLesson(lessonService.getEntityById(lessonId));
        return ResponseEntity.ok(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.update(lessonId, request)).build());
    }

    @DeleteMapping("/lessons/{lessonId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteLesson(@PathVariable String lessonId) {
        publicCreatorAccessService.assertCanManagePublicLesson(lessonService.getEntityById(lessonId));
        lessonService.delete(lessonId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Public lesson deleted successfully").build());
    }

    @PostMapping("/lessons/{lessonId}/files")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<LessonFileUploadResponse>> uploadLessonFile(
            @PathVariable String lessonId,
            @Valid @ModelAttribute LessonFileUploadRequest request) {
        publicCreatorAccessService.assertCanManagePublicLesson(lessonService.getEntityById(lessonId));
        return ResponseEntity.ok(ApiResponse.<LessonFileUploadResponse>builder().success(true).data(lessonService.attachFileToLesson(lessonId, request.getFile())).build());
    }
}
