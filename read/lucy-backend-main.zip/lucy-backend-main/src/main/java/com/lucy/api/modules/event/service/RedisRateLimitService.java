package com.lucy.api.modules.event.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

@Service
@RequiredArgsConstructor
@Slf4j
public class RedisRateLimitService {
    private final StringRedisTemplate redisTemplate;

    public boolean allow(String key, int maxRequests, long windowSeconds) {
        String redisKey = "rate_limit:" + key;
        try {
            Long value = redisTemplate.opsForValue().increment(redisKey);
            if (value != null && value == 1L) {
                redisTemplate.expire(redisKey, Duration.ofSeconds(windowSeconds));
            }
            return value == null || value <= maxRequests;
        } catch (Exception ex) {
            // Fail-open to avoid blocking traffic when Redis is temporarily unavailable.
            log.warn("Redis rate-limit unavailable for key={}: {}", key, ex.getMessage());
            return true;
        }
    }
}
