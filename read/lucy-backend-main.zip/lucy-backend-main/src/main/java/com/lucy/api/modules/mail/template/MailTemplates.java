package com.lucy.api.modules.mail.template;

public final class MailTemplates {

    private MailTemplates() {}

    public static final String OTP_RESET_PASSWORD_SUBJECT = "Zen Leader - Mã xác thực đặt lại mật khẩu";

    public static final String OTP_VERIFY_EMAIL_SUBJECT = "Zen Leader - Xác minh địa chỉ email của bạn";

    public static final String OTP_RESET_PASSWORD = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Reset Your Password - Zen Leader</title>
        </head>
        <body style="margin:0;padding:0;background-color:#f4f7fa;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#f4f7fa;padding:40px 0;">
                <tr>
                    <td align="center">
                        <table role="presentation" width="480" cellspacing="0" cellpadding="0"
                               style="background-color:#ffffff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.08);overflow:hidden;">
                            <!-- Header -->
                            <tr>
                                <td style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:32px 40px;text-align:center;">
                                    <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:700;letter-spacing:0.5px;">🧘 Zen Leader</h1>
                                </td>
                            </tr>
                            <!-- Body -->
                            <tr>
                                <td style="padding:40px;">
                                    <h2 style="margin:0 0 16px;color:#1a1a2e;font-size:20px;font-weight:600;">Reset Your Password</h2>
                                    <p style="margin:0 0 24px;color:#555;font-size:15px;line-height:1.6;">
                                        We received a request to reset your password. Please use the verification code below to proceed:
                                    </p>
                                    <!-- OTP Code -->
                                    <div style="background-color:#f0f4ff;border:2px dashed #667eea;border-radius:8px;padding:20px;text-align:center;margin:0 0 24px;">
                                        <span style="font-size:36px;font-weight:700;letter-spacing:12px;color:#667eea;">{{otp}}</span>
                                    </div>
                                    <p style="margin:0 0 8px;color:#555;font-size:14px;line-height:1.6;">
                                        ⏱ This code is valid for <strong>{{expireMinutes}} minutes</strong>.
                                    </p>
                                    <p style="margin:0 0 24px;color:#888;font-size:13px;line-height:1.6;">
                                        If you did not request a password reset, please ignore this email.
                                    </p>
                                    <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
                                    <p style="margin:0;color:#aaa;font-size:12px;text-align:center;">
                                        © 2026 Zen Leader. All rights reserved.
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>
        """;

    public static final String OTP_VERIFY_EMAIL = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Verify Email - Zen Leader</title>
        </head>
        <body style="margin:0;padding:0;background-color:#f4f7fa;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#f4f7fa;padding:40px 0;">
                <tr>
                    <td align="center">
                        <table role="presentation" width="480" cellspacing="0" cellpadding="0"
                               style="background-color:#ffffff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.08);overflow:hidden;">
                            <tr>
                                <td style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:32px 40px;text-align:center;">
                                    <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:700;letter-spacing:0.5px;">🧘 Zen Leader</h1>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:40px;">
                                    <h2 style="margin:0 0 16px;color:#1a1a2e;font-size:20px;font-weight:600;">Verify your email</h2>
                                    <p style="margin:0 0 24px;color:#555;font-size:15px;line-height:1.6;">
                                        Thanks for signing up. Enter this code in the app to verify your email and sign in:
                                    </p>
                                    <div style="background-color:#f0f4ff;border:2px dashed #667eea;border-radius:8px;padding:20px;text-align:center;margin:0 0 24px;">
                                        <span style="font-size:36px;font-weight:700;letter-spacing:12px;color:#667eea;">{{otp}}</span>
                                    </div>
                                    <p style="margin:0 0 8px;color:#555;font-size:14px;line-height:1.6;">
                                        ⏱ This code is valid for <strong>{{expireMinutes}} minutes</strong>.
                                    </p>
                                    <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
                                    <p style="margin:0;color:#aaa;font-size:12px;text-align:center;">
                                        © 2026 Zen Leader. All rights reserved.
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>
        """;
}
