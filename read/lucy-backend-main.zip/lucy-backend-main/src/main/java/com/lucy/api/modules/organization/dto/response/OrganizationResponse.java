package com.lucy.api.modules.organization.dto.response;

import com.lucy.api.modules.organization.entity.enums.OrganizationStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OrganizationResponse {
    String id;
    String code;
    String name;
    String description;
    String logoUrl;
    OrganizationStatus status;
    Instant createdAt;
    Instant updatedAt;
}
