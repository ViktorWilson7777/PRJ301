package com.lucy.api.infrastructure.websocket.service.api;

import com.lucy.api.infrastructure.websocket.dto.response.WebSocketNotificationResponse;
import io.netty.channel.Channel;

public interface WebSocketNotificationService {

    void registerChannel(String sessionId, Channel channel);

    void unregisterChannel(String sessionId);

    void sendNotificationToUser(String userId, WebSocketNotificationResponse notification);

    void broadcastToLocalSessions(String userId, WebSocketNotificationResponse notification);

    void publishNotificationToRedis(String userId, WebSocketNotificationResponse notification);
}
