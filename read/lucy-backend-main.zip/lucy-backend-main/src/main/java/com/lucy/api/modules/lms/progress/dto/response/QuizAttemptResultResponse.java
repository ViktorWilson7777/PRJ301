package com.lucy.api.modules.lms.progress.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class QuizAttemptResultResponse {

    String courseRunId;
    String lessonId;

    Integer totalQuestions;
    Integer answeredQuestions;
    Integer correctAnswers;
    Integer scorePercent;
    Integer passPercent;
    Boolean passed;

    Instant attemptedAt;
}