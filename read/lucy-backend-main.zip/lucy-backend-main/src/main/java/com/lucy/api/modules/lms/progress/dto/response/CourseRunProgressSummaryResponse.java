package com.lucy.api.modules.lms.progress.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CourseRunProgressSummaryResponse {
    String courseRunId;
    String enrollmentId;
    long totalLessons;
    long completedLessons;
    Integer progressPercent;
    Instant lastUpdatedAt;
}

