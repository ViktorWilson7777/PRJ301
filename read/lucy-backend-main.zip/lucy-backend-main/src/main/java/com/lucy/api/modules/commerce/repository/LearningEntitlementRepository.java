package com.lucy.api.modules.commerce.repository;

import com.lucy.api.modules.commerce.entity.LearningEntitlement;
import com.lucy.api.modules.commerce.entity.enums.LearningEntitlementStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LearningEntitlementRepository extends JpaRepository<LearningEntitlement, String> {
    boolean existsByUser_IdAndCourseRun_IdAndStatus(String userId, String courseRunId, LearningEntitlementStatus status);

    List<LearningEntitlement> findAllByUser_IdOrderByCreatedAtDesc(String userId);

    Optional<LearningEntitlement> findByUser_IdAndCourseRun_IdAndStatus(String userId, String courseRunId, LearningEntitlementStatus status);
}
