package com.lucy.api.modules.lms.repository;

import com.lucy.api.modules.lms.entity.Course;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CourseRepository extends JpaRepository<Course, String> {
    boolean existsByCodeIgnoreCase(String code);

    boolean existsByCodeIgnoreCaseAndIdNot(String code, String id);

    boolean existsByCodeIgnoreCaseAndAccessScopeAndOrganizationIsNull(String code, LmsAccessScope accessScope);

    boolean existsByCodeIgnoreCaseAndAccessScopeAndOrganizationIsNullAndIdNot(String code, LmsAccessScope accessScope, String id);

    boolean existsByCodeIgnoreCaseAndOrganization_Id(String code, String organizationId);

    boolean existsByCodeIgnoreCaseAndOrganization_IdAndIdNot(String code, String organizationId, String id);

    List<Course> findAllByDeletedAtIsNullOrderByCreatedAtDesc();

    List<Course> findAllByProgram_IdAndDeletedAtIsNullOrderByOrderIndexAscCreatedAtAsc(String programId);

    Optional<Course> findByIdAndDeletedAtIsNull(String id);

    List<Course> findAllByAccessScopeAndDeletedAtIsNullOrderByCreatedAtDesc(LmsAccessScope accessScope);

    List<Course> findAllByOrganization_IdAndDeletedAtIsNullOrderByCreatedAtDesc(String organizationId);
}
