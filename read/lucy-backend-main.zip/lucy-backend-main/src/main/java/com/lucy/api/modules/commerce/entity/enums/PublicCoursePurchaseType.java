package com.lucy.api.modules.commerce.entity.enums;

public enum PublicCoursePurchaseType {
    ONE_TIME
}
