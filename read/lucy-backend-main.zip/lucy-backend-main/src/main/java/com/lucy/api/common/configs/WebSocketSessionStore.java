package com.lucy.api.common.configs;

import org.springframework.stereotype.Component;

import java.security.Principal;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class WebSocketSessionStore {
    private final Map<String, Principal> sessions = new ConcurrentHashMap<>();
    private final Map<String, Set<UUID>> joinedRoomsBySession = new ConcurrentHashMap<>();

    public void put(String sessionId, Principal principal) {
        if (sessionId != null && principal != null) {
            sessions.put(sessionId, principal);
        }
    }

    public Optional<Principal> get(String sessionId) {
        if (sessionId == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(sessions.get(sessionId));
    }

    public boolean trackRoom(String sessionId, UUID roomId) {
        if (sessionId == null || roomId == null) {
            return false;
        }

        return joinedRoomsBySession
                .computeIfAbsent(sessionId, ignored -> ConcurrentHashMap.newKeySet())
                .add(roomId);
    }

    public void untrackRoom(String sessionId, UUID roomId) {
        if (sessionId == null || roomId == null) {
            return;
        }

        joinedRoomsBySession.computeIfPresent(sessionId, (ignored, roomIds) -> {
            roomIds.remove(roomId);
            return roomIds.isEmpty() ? null : roomIds;
        });
    }

    public WebSocketSessionState removeSession(String sessionId) {
        if (sessionId == null) {
            return new WebSocketSessionState(null, Set.of());
        }

        Principal principal = sessions.remove(sessionId);
        Set<UUID> roomIds = joinedRoomsBySession.remove(sessionId);
        return new WebSocketSessionState(principal, roomIds == null ? Set.of() : Set.copyOf(roomIds));
    }
}
