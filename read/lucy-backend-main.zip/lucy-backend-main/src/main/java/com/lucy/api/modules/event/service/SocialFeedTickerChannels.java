package com.lucy.api.modules.event.service;

public final class SocialFeedTickerChannels {
    public static final String REDIS_CHANNEL = "social.feed.ticker";
    public static final String WEBSOCKET_TOPIC = "/topic/social-feed/ticker";

    private SocialFeedTickerChannels() {
    }
}
