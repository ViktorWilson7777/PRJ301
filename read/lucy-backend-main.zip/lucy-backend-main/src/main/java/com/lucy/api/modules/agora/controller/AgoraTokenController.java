package com.lucy.api.modules.agora.controller;

import com.lucy.api.modules.agora.dto.request.AgoraTokenRequest;
import com.lucy.api.modules.agora.dto.response.AgoraTokenResponse;
import com.lucy.api.modules.agora.service.AgoraTokenService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/agora")
@RequiredArgsConstructor
public class AgoraTokenController {
    private final AgoraTokenService agoraTokenService;

    @PostMapping("/token")
    public ResponseEntity<AgoraTokenResponse> generateToken(@Valid @RequestBody AgoraTokenRequest request) {
        return ResponseEntity.ok(agoraTokenService.generateRtcToken(request));
    }
}
