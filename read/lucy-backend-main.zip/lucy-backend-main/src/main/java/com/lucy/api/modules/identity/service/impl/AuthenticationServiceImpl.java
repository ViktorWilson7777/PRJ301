package com.lucy.api.modules.identity.service.impl;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.lucy.api.common.constants.JwtClaimSetConstant;
import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.constants.rbac.AuthenticationConstants;
import com.lucy.api.modules.identity.constants.user.UserErrorCodeConstants;
import com.lucy.api.modules.identity.dtos.request.auth.AppleAuthRequest;
import com.lucy.api.modules.identity.dtos.request.auth.AppleNotificationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.AuthenticationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.GoogleAuthRequest;
import com.lucy.api.modules.identity.dtos.request.auth.IntrospectRequest;
import com.lucy.api.modules.identity.dtos.request.auth.RefreshTokenRequest;
import com.lucy.api.modules.identity.dtos.request.auth.RegisterRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ResendVerificationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.VerifyEmailRequest;
import com.lucy.api.modules.identity.dtos.request.user.UserCreationRequest;
import com.lucy.api.modules.identity.dtos.response.auth.AuthenticationResponse;
import com.lucy.api.modules.identity.dtos.response.auth.IntrospectResponse;
import com.lucy.api.modules.identity.entity.Session;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.UserIdentity;
import com.lucy.api.modules.identity.repository.SessionRepository;
import com.lucy.api.modules.identity.repository.UserIdentityRepository;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.service.interfaces.AuthenticationService;
import com.lucy.api.modules.identity.service.interfaces.OtpService;
import com.lucy.api.modules.identity.service.interfaces.UserService;
import com.lucy.api.modules.identity.utils.AppleAuthUtil;
import com.lucy.api.modules.identity.utils.GoogleAuthUtil;
import com.lucy.api.modules.mail.service.interfaces.EmailService;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class AuthenticationServiceImpl implements AuthenticationService {
    UserRepository userRepository;
    UserIdentityRepository userIdentityRepository;
    SessionRepository sessionRepository;
    UserService userService;
    OtpService otpService;
    EmailService emailService;
    PasswordEncoder passwordEncoder;
    AppleAuthUtil appleAuthUtil;
    GoogleAuthUtil googleAuthUtil;
    com.lucy.api.modules.identity.mapper.UserMapper userMapper;
    UserProfileService userProfileService;

    @NonFinal
    @Value(value = "${security.jwt.signer-key}")
    String SIGNER_KEY;

    @Override
    @Transactional
    public AuthenticationResponse authenticate(AuthenticationRequest request) {
        User user = userRepository.findByEmailAndDeletedAtIsNull(request.getEmail())
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));

        boolean authenticated = passwordEncoder.matches(request.getPassword(), user.getPasswordHash());
        if (!authenticated) {
            throw new AppException(UserErrorCodeConstants.AUTH_UNAUTHENTICATED, HttpStatus.UNAUTHORIZED);
        }
        if (!user.isVerified()) {
            throw new AppException(UserErrorCodeConstants.AUTH_USER_NOT_VERIFIED, HttpStatus.FORBIDDEN);
        }

        String token = generateToken(user);
        String refreshToken = generateRefreshToken(user);
        createSession(user, refreshToken);

        return AuthenticationResponse.builder()
                .authenticated(true)
                .accessToken(token)
                .refreshToken(refreshToken)
                .user(userMapper.toUserResponse(user))
                .build();
    }

    @Override
    @Transactional
    public AuthenticationResponse refreshToken(RefreshTokenRequest request) throws ParseException {
        String rawToken = request.getRefreshToken();
        Session session = findValidSession(rawToken);
        User user = session.getUser();

        session.setRevokedAt(Instant.now());
        sessionRepository.save(session);

        String accessToken = generateToken(user);
        String newRefreshToken = generateRefreshToken(user);
        createSession(user, newRefreshToken);

        return AuthenticationResponse.builder()
                .authenticated(true)
                .accessToken(accessToken)
                .refreshToken(newRefreshToken)
                .user(userMapper.toUserResponse(user))
                .build();
    }

    @Override
    @Transactional
    public void logout(RefreshTokenRequest request) throws ParseException {
        Session session = findValidSession(request.getRefreshToken());
        session.setRevokedAt(Instant.now());
        sessionRepository.save(session);
    }

    @Override
    public IntrospectResponse introspect(IntrospectRequest request) throws ParseException {
        return IntrospectResponse.builder().isValid(true).build();
    }

    @Override
    @Transactional
    public AuthenticationResponse authenticateWithGoogle(GoogleAuthRequest request) throws GeneralSecurityException, IOException {
        GoogleIdToken.Payload payload = googleAuthUtil.verify(request.getIdToken());
        String email = payload.getEmail();
        String subject = payload.getSubject();
        String name = (String) payload.get("name");
        String pictureUrl = (String) payload.get("picture");

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("provider", AuthenticationConstants.PROVIDER_GOOGLE);
        metadata.put("provider_user_id", subject);
        metadata.put("email", email);
        metadata.put("name", name);
        metadata.put("picture", pictureUrl);
        metadata.put("email_verified", payload.getEmailVerified());
        metadata.put("locale", payload.get("locale"));
        metadata.put("last_sign_in_at", Instant.now().toString());

        UserIdentity identity = userIdentityRepository.findByProviderAndProviderUserId(AuthenticationConstants.PROVIDER_GOOGLE, subject).orElse(null);
        User user;
        if (identity != null) {
            user = identity.getUser();
            identity.setLastSignInAt(Instant.now());
            identity.setProviderData(metadata);
        } else {
            user = userRepository.findByEmailAndDeletedAtIsNull(email).orElseGet(() -> User.builder()
                    .email(email)
                    .passwordHash(passwordEncoder.encode(UUID.randomUUID().toString()))
                    .isVerified(true)
                    .verifiedAt(Instant.now())
                    .lastSignInAt(Instant.now())
                    .userMetadata(metadata)
                    .build());
            user.setLastSignInAt(Instant.now());
            user.setUserMetadata(metadata);
            user = userRepository.save(user);

            identity = UserIdentity.builder()
                    .user(user)
                    .provider(AuthenticationConstants.PROVIDER_GOOGLE)
                    .providerUserId(subject)
                    .providerData(metadata)
                    .lastSignInAt(Instant.now())
                    .build();
        }

        userProfileService.getOrCreate(user, name, pictureUrl);
        userIdentityRepository.save(identity);

        String token = generateToken(user);
        String refreshToken = generateRefreshToken(user);
        createSession(user, refreshToken);

        return AuthenticationResponse.builder()
                .authenticated(true)
                .accessToken(token)
                .refreshToken(refreshToken)
                .user(userMapper.toUserResponse(user))
                .build();
    }

    @Override
    @Transactional
    public AuthenticationResponse authenticateWithApple(AppleAuthRequest request) {
        Map<String, Object> claims = appleAuthUtil.verifyIdentityToken(request.getIdentityToken());
        String subject = (String) claims.get("sub");
        String email = (String) claims.get("email");
        boolean emailVerified = "true".equalsIgnoreCase(String.valueOf(claims.get("email_verified")));

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("provider", AuthenticationConstants.PROVIDER_APPLE);
        metadata.put("provider_user_id", subject);
        metadata.put("email", email);
        metadata.put("email_verified", claims.get("email_verified"));
        metadata.put("authorization_code", request.getAuthorizationCode());
        metadata.put("user_identifier", request.getUserIdentifier());
        metadata.put("given_name", request.getGivenName());
        metadata.put("family_name", request.getFamilyName());
        metadata.put("last_sign_in_at", Instant.now().toString());

        UserIdentity identity = userIdentityRepository.findByProviderAndProviderUserId(AuthenticationConstants.PROVIDER_APPLE, subject).orElse(null);
        User user;
        if (identity != null) {
            user = identity.getUser();
            identity.setLastSignInAt(Instant.now());
            identity.setProviderData(metadata);
        } else {
            user = userRepository.findByEmailAndDeletedAtIsNull(email).orElseGet(() -> User.builder()
                    .email(email)
                    .passwordHash(passwordEncoder.encode(UUID.randomUUID().toString()))
                    .isVerified(emailVerified)
                    .verifiedAt(emailVerified ? Instant.now() : null)
                    .lastSignInAt(Instant.now())
                    .userMetadata(metadata)
                    .build());
            user.setLastSignInAt(Instant.now());
            user.setUserMetadata(metadata);
            user = userRepository.save(user);

            identity = UserIdentity.builder()
                    .user(user)
                    .provider(AuthenticationConstants.PROVIDER_APPLE)
                    .providerUserId(subject)
                    .providerData(metadata)
                    .lastSignInAt(Instant.now())
                    .build();
        }

        userProfileService.getOrCreate(user, null, null);
        userIdentityRepository.save(identity);

        String token = generateToken(user);
        String refreshToken = generateRefreshToken(user);
        createSession(user, refreshToken);

        return AuthenticationResponse.builder()
                .authenticated(true)
                .accessToken(token)
                .refreshToken(refreshToken)
                .user(userMapper.toUserResponse(user))
                .build();
    }

    @Override
    @Transactional
    public void handleAppleServerNotification(AppleNotificationRequest request) {
        // unchanged business flow for now
    }

    @Override
    public void register(RegisterRequest request) {
        if (request == null) {
            throw new AppException(UserErrorCodeConstants.COMMON_INVALID_PARAM, HttpStatus.BAD_REQUEST);
        }
        UserCreationRequest userCreationRequest = UserCreationRequest.builder()
                .email(request.getEmail())
                .displayName(request.getDisplayName())
                .passwordHash(request.getPassword())
                .build();
        userService.create(userCreationRequest);
        String email = request.getEmail().trim();
        String otp = otpService.generateAndStoreRegistrationOtp(email);
        emailService.sendRegistrationOtpEmail(email, otp);
    }

    @Override
    @Transactional
    public void verifyEmail(VerifyEmailRequest request) {
        User user = userRepository.findByEmailAndDeletedAtIsNull(request.getEmail().trim())
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));
        if (otpService.verifyRegistrationOtp(request.getEmail().trim(), request.getOtp())) {
            user.setVerified(true);
            user.setVerifiedAt(Instant.now());
            userRepository.save(user);
            otpService.deleteRegistrationOtp(request.getEmail().trim());
        }
    }

    @Override
    public void resendVerificationEmail(ResendVerificationRequest request) {
        String email = request.getEmail().trim();
        User user = userRepository.findByEmailAndDeletedAtIsNull(email)
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));
        if (user.isVerified()) {
            return;
        }
        String otp = otpService.generateAndStoreRegistrationOtp(email);
        emailService.sendRegistrationOtpEmail(email, otp);
    }

    private Session findValidSession(String rawToken) throws ParseException {
        String hashedToken = hashToken(rawToken);
        Session session = sessionRepository.findByTokenHashAndRevokedAtIsNull(hashedToken)
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_UNAUTHENTICATED, HttpStatus.UNAUTHORIZED));
        if (session.getExpiresAt().isBefore(Instant.now())) {
            throw new AppException(UserErrorCodeConstants.AUTH_UNAUTHENTICATED, HttpStatus.UNAUTHORIZED);
        }
        return session;
    }

    private String generateToken(User user) {
        return generateToken(user, 1, ChronoUnit.HOURS);
    }

    private String generateRefreshToken(User user) {
        return generateToken(user, 30, ChronoUnit.DAYS);
    }

    private String generateToken(User user, long duration, ChronoUnit unit) {
        JWSHeader jwsHeader = new JWSHeader(JWSAlgorithm.HS512);

        JWTClaimsSet jwtClaimsSet = new JWTClaimsSet.Builder()
                .subject(user.getEmail())
                .issueTime(new Date())
                .expirationTime(Date.from(Instant.now().plus(duration, unit)))
                .jwtID(UUID.randomUUID().toString())
                .claim(JwtClaimSetConstant.CLAIM_USER_ID, user.getId())
                .claim(JwtClaimSetConstant.CLAIM_SCOPE, buildScope(user))
                .build();
        Payload payload = new Payload(jwtClaimsSet.toJSONObject());

        JWSObject jwsObject = new JWSObject(jwsHeader, payload);

        try {
            jwsObject.sign(new MACSigner(SIGNER_KEY.getBytes()));
            return jwsObject.serialize();
        } catch (JOSEException e) {
            log.error("Failed to sign JWT token", e);
            throw new AppException(AuthenticationConstants.JWT_GENERATION_FAIL, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void createSession(User user, String refreshToken) {
        try {
            SignedJWT signedJWT = SignedJWT.parse(refreshToken);
            Instant expiresAt = signedJWT.getJWTClaimsSet().getExpirationTime().toInstant();

            Session session = Session.builder()
                    .user(user)
                    .tokenHash(hashToken(refreshToken))
                    .expiresAt(expiresAt)
                    .build();
            sessionRepository.save(session);
        } catch (ParseException e) {
            log.error("Failed to parse refresh token for session creation", e);
            throw new AppException(AuthenticationConstants.JWT_GENERATION_FAIL, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private String hashToken(String token) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(token.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder(2 * encodedhash.length);
            for (byte b : encodedhash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }

    private String buildScope(User user) {
        if (user.getRoleName() == null) {
            return "ROLE_MEMBER";
        }
        return "ROLE_" + user.getRoleName().name();
    }
}

