package com.lucy.api.infrastructure.websocket.constants;

import com.lucy.api.infrastructure.redis.constants.RedisChannelPrefixes;
import com.lucy.api.infrastructure.redis.constants.RedisWsKeyConstants;

public final class WebSocketConstants {

    private WebSocketConstants() {
    }

    public static final String REDIS_KEY_PREFIX_SESSION = "ws:session:";
    public static final String REDIS_KEY_PREFIX_USER_SESSIONS = RedisWsKeyConstants.PREFIX_USER_SESSIONS;
    public static final String REDIS_KEY_SUFFIX_SESSIONS = RedisWsKeyConstants.SUFFIX_USER_SESSIONS;
    public static final String REDIS_KEY_PREFIX_CONVERSATION_SESSIONS = RedisWsKeyConstants.PREFIX_CONVERSATION_SESSIONS;
    public static final String REDIS_KEY_SUFFIX_CONVERSATION_SESSIONS = RedisWsKeyConstants.SUFFIX_CONVERSATION_SESSIONS;

    public static final String REDIS_CHANNEL_PREFIX_MESSAGE = RedisChannelPrefixes.WS_MESSAGE;
    public static final String REDIS_CHANNEL_PREFIX_NOTIFICATION = RedisChannelPrefixes.WS_NOTIFICATION;

    public static final String OUTBOUND_FRAME_TYPE_MESSAGE = "MESSAGE";

    public static final String FIELD_TYPE = "type";
    public static final String FIELD_SESSION_ID = "sessionId";
    public static final String FIELD_USER_ID = "userId";
    public static final String FIELD_ERROR_CODE = "errorCode";
    public static final String FIELD_MESSAGE = "message";
    public static final String FIELD_MESSAGE_KEY = "messageKey";
    public static final String FIELD_ECHO = "echo";
}
