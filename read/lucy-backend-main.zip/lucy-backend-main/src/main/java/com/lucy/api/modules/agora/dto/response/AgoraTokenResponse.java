package com.lucy.api.modules.agora.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AgoraTokenResponse {
    String token;

    @JsonProperty("channelId")
    String channelId;

    Integer uid;

    @JsonProperty("expireAt")
    Long expireAt;
}
