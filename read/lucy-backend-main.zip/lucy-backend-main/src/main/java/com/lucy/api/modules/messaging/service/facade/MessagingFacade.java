package com.lucy.api.modules.messaging.service.facade;

import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.messaging.dto.request.AttachmentRequest;
import com.lucy.api.modules.messaging.dto.request.EditMessageRequest;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationListItemResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationParticipantResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationResponse;

import java.util.List;

/**
 * Application facade: REST/WS gọi lớp này (orchestration), không xử lý enrollment trong controller.
 */
public interface MessagingFacade {

    ConversationResponse getGroupConversationForEnrolledUser(String courseRunId, String currentUserId);
    ConversationResponse getGroupConversationForRoomParticipant(String roomId, String currentUserId);

    List<ConversationParticipantResponse> listParticipants(String conversationId, String currentUserId);

    List<ConversationListItemResponse> listMyConversations(String currentUserId);

    ConversationResponse getOrCreateDirectConversation(String currentUserId, String peerUserId);

    ConversationResponse createAdhocGroupConversation(String currentUserId, String groupName, List<String> memberUserIds);

    void inviteMembers(String conversationId, String inviterUserId, List<String> memberUserIds);

    ConversationResponse renameGroupConversation(String conversationId, String ownerUserId, String groupName);

    String getMyParticipantStatus(String conversationId, String currentUserId);

    void acceptInvite(String conversationId, String currentUserId);

    void rejectInvite(String conversationId, String currentUserId);

    ChatMessageResponse sendMessage(
            String conversationId,
            String peerUserId,
            String senderUserId,
            String text,
            List<AttachmentRequest> attachments,
            String replyToMessageId
    );

    PagingResponse<ChatMessageResponse> getMessages(
            String conversationId,
            String readerUserId,
            PagingRequest pagingRequest
    );

    ChatMessageResponse editMessage(String messageId, String editorUserId, EditMessageRequest request);
}
