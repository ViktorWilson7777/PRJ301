package com.lucy.api.modules.messaging.constant;

public final class ChatMessageConstants {

    public static final String TABLE_CHAT_MESSAGES = "chat_messages";

    public static final String COL_CONVERSATION_ID = "conversation_id";
    public static final String COL_SENDER_ID = "sender_id";
    public static final String COL_TEXT = "text";
    public static final String COL_REPLY_TO_MESSAGE_ID = "reply_to_message_id";
    public static final String COL_IS_EDITED = "is_edited";
    public static final String COL_EDIT_COUNT = "edit_count";
    public static final String COL_IS_ECHO = "is_echo";

    private ChatMessageConstants() {
    }
}
