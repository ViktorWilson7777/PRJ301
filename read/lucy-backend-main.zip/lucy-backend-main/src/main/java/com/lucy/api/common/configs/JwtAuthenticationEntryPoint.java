package com.lucy.api.common.configs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.common.dtos.ErrorMessage;
import com.lucy.api.common.dtos.response.ApiResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.jspecify.annotations.NonNull;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import lombok.RequiredArgsConstructor;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.io.IOException;

@RequiredArgsConstructor
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private final MessageSource messageSource;

    @Override
    public void commence(@NonNull HttpServletRequest request,
                         HttpServletResponse response,
                         @NonNull AuthenticationException authException) throws IOException, ServletException {
        String errorCode = "auth.unauthenticated";
        String localizedMessage = messageSource.getMessage(errorCode, null, LocaleContextHolder.getLocale());

        ApiResponse<?> genericResponse = ApiResponse.builder()
                .success(false)
                .errorMessage(ErrorMessage.builder()
                        .errorCode(errorCode)
                        .message(localizedMessage)
                        .build())
                .build();
        ObjectMapper objectMapper = new ObjectMapper();
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().write(objectMapper.writeValueAsString(genericResponse));
        response.flushBuffer();
    }
}
