package com.lucy.api.modules.event.service;

import com.lucy.api.common.constants.JwtClaimSetConstant;
import com.lucy.api.modules.event.exception.EventApiException;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class EventAuthContextService {
    public UUID requireUserId(Jwt jwt) {
        if (jwt == null) {
            throw new EventApiException("UNAUTHORIZED", "Authentication required", HttpStatus.UNAUTHORIZED);
        }

        String claimUserId = jwt.getClaimAsString(JwtClaimSetConstant.CLAIM_USER_ID);
        if (claimUserId == null || claimUserId.isBlank()) {
            claimUserId = jwt.getSubject();
        }

        try {
            return UUID.fromString(claimUserId);
        } catch (Exception e) {
            throw new EventApiException("UNAUTHORIZED", "Invalid user id in token", HttpStatus.UNAUTHORIZED);
        }
    }

    public Optional<UUID> getUserId(Jwt jwt) {
        if (jwt == null) {
            return Optional.empty();
        }

        String claimUserId = jwt.getClaimAsString(JwtClaimSetConstant.CLAIM_USER_ID);
        if (claimUserId == null || claimUserId.isBlank()) {
            claimUserId = jwt.getSubject();
        }

        try {
            return Optional.of(UUID.fromString(claimUserId));
        } catch (Exception e) {
            return Optional.empty();
        }
    }
}
