package com.lucy.api.modules.mail.utils;

import java.util.Map;

public class MailTemplateUtils {

    private MailTemplateUtils() {
    }

    /**
     * Replace variables in a template string
     * @param templateContent the raw HTML template string
     * @param variables map of variable names to their values
     * @return the processed HTML string
     */
    public static String buildEmailFromTemplate(String templateContent, Map<String, String> variables) {
        if (templateContent == null || variables == null || variables.isEmpty()) {
            return templateContent;
        }

        String result = templateContent;
        for (Map.Entry<String, String> entry : variables.entrySet()) {
            String placeholder = "{{" + entry.getKey() + "}}";
            result = result.replace(placeholder, entry.getValue());
        }
        return result;
    }
}
