package com.lucy.api.infrastructure.websocket.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WebSocketNotificationResponse {
    String type;
    String title;
    String message;
    String conversationId;
    String notificationId;
    String roomId;
    String payload;
    List<WebSocketNotificationAction> actions;
    Instant timestamp;
}
