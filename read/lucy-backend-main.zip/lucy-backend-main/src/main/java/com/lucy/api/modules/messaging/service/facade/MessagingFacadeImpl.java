package com.lucy.api.modules.messaging.service.facade;

import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.messaging.constant.MessagingErrorKeys;
import com.lucy.api.modules.messaging.dto.request.AttachmentRequest;
import com.lucy.api.modules.messaging.dto.request.EditMessageRequest;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationListItemResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationParticipantResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationResponse;
import com.lucy.api.modules.messaging.entity.Conversation;
import com.lucy.api.modules.messaging.repository.ConversationRepository;
import com.lucy.api.modules.messaging.service.domain.ConversationDomainService;
import com.lucy.api.modules.messaging.service.domain.ConversationParticipantDomainService;
import com.lucy.api.modules.messaging.service.interfaces.ChatMessageService;
import com.lucy.api.modules.messaging.service.interfaces.MessagingConversationService;
import com.lucy.api.modules.relationship.service.interfaces.RelationshipService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MessagingFacadeImpl implements MessagingFacade {

    MessagingConversationService messagingConversationService;
    ChatMessageService chatMessageService;
    ConversationDomainService conversationDomainService;
    ConversationParticipantDomainService conversationParticipantDomainService;
    ConversationRepository conversationRepository;
    RelationshipService relationshipService;

    @Override
    public ConversationResponse getGroupConversationForEnrolledUser(String courseRunId, String currentUserId) {
        return messagingConversationService.getGroupConversationForEnrolledUser(courseRunId, currentUserId);
    }

    @Override
    public ConversationResponse getGroupConversationForRoomParticipant(String roomId, String currentUserId) {
        return messagingConversationService.getGroupConversationForRoomParticipant(roomId, currentUserId);
    }

    @Override
    public List<ConversationParticipantResponse> listParticipants(String conversationId, String currentUserId) {
        return messagingConversationService.listParticipants(conversationId, currentUserId);
    }

    @Override
    public List<ConversationListItemResponse> listMyConversations(String currentUserId) {
        return messagingConversationService.listMyConversations(currentUserId);
    }

    @Override
    public ConversationResponse getOrCreateDirectConversation(String currentUserId, String peerUserId) {
        return messagingConversationService.getOrCreateDirectConversation(currentUserId, peerUserId);
    }

    @Override
    public ConversationResponse createAdhocGroupConversation(String currentUserId, String groupName, List<String> memberUserIds) {
        return messagingConversationService.createAdhocGroupConversation(currentUserId, groupName, memberUserIds);
    }

    @Override
    public void inviteMembers(String conversationId, String inviterUserId, List<String> memberUserIds) {
        messagingConversationService.inviteMembers(conversationId, inviterUserId, memberUserIds);
    }

    @Override
    public ConversationResponse renameGroupConversation(String conversationId, String ownerUserId, String groupName) {
        return messagingConversationService.renameGroupConversation(conversationId, ownerUserId, groupName);
    }

    @Override
    public String getMyParticipantStatus(String conversationId, String currentUserId) {
        return messagingConversationService.getMyParticipantStatus(conversationId, currentUserId);
    }

    @Override
    public void acceptInvite(String conversationId, String currentUserId) {
        messagingConversationService.acceptInvite(conversationId, currentUserId);
    }

    @Override
    public void rejectInvite(String conversationId, String currentUserId) {
        messagingConversationService.rejectInvite(conversationId, currentUserId);
    }

    @Override
    @Transactional
    public ChatMessageResponse sendMessage(
            String conversationId,
            String peerUserId,
            String senderUserId,
            String text,
            List<AttachmentRequest> attachments,
            String replyToMessageId
    ) {
        String resolvedConversationId = resolveConversationId(conversationId, peerUserId, senderUserId);
        return chatMessageService.sendMessage(resolvedConversationId, senderUserId, text, attachments, replyToMessageId);
    }

    @Override
    public PagingResponse<ChatMessageResponse> getMessages(
            String conversationId,
            String readerUserId,
            PagingRequest pagingRequest
    ) {
        return chatMessageService.getMessages(conversationId, readerUserId, pagingRequest);
    }

    @Override
    public ChatMessageResponse editMessage(String messageId, String editorUserId, EditMessageRequest request) {
        return chatMessageService.editMessage(messageId, editorUserId, request);
    }

    private String resolveConversationId(String conversationId, String peerUserId, String senderUserId) {
        if (StringUtils.hasText(conversationId)) {
            Conversation conversation = conversationRepository.findById(conversationId.trim())
                    .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));
            return conversation.getId();
        }

        if (!StringUtils.hasText(peerUserId)) {
            throw new AppException(MessagingErrorKeys.CONVERSATION_OR_PEER_REQUIRED, HttpStatus.BAD_REQUEST);
        }

        if (!relationshipService.canMessage(senderUserId, peerUserId.trim())) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }

        Conversation directConversation = conversationDomainService
                .ensureDirectConversation(senderUserId, peerUserId.trim());
        conversationParticipantDomainService.ensureActiveParticipant(directConversation.getId(), senderUserId);
        conversationParticipantDomainService.ensureActiveParticipant(directConversation.getId(), peerUserId.trim());
        return directConversation.getId();
    }
}
