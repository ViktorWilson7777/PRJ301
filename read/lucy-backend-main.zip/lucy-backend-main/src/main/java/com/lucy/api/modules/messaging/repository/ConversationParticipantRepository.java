package com.lucy.api.modules.messaging.repository;

import com.lucy.api.modules.messaging.entity.ConversationParticipant;
import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface ConversationParticipantRepository extends JpaRepository<ConversationParticipant, String> {

    boolean existsByConversationIdAndUserIdAndStatus(String conversationId, String userId, ParticipantStatus status);

    Optional<ConversationParticipant> findByConversationIdAndUserId(String conversationId, String userId);

    List<ConversationParticipant> findByConversationIdAndStatus(String conversationId, ParticipantStatus status);

    @Query("""
            select cp.conversation.id
            from ConversationParticipant cp
            where cp.user.id = :userId
              and cp.status = :status
            """)
    List<String> findConversationIdsByUserIdAndStatus(
            @Param("userId") String userId,
            @Param("status") ParticipantStatus status
    );

    @Query("""
            select cp.conversation.id
            from ConversationParticipant cp
            where cp.user.id = :userId
              and cp.status in :statuses
            """)
    List<String> findConversationIdsByUserIdAndStatusIn(
            @Param("userId") String userId,
            @Param("statuses") List<ParticipantStatus> statuses
    );

    @Modifying
    @Transactional
    void deleteAllByUser_IdIn(List<String> userIds);
}
