package com.lucy.api.modules.event.repository;

import com.lucy.api.modules.event.entity.RoomCommentEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public interface RoomCommentRepository extends JpaRepository<RoomCommentEntity, UUID> {
    long countByRoomId(UUID roomId);

    @Query("""
    select c.id as id, c.userId as userId, c.parentId as parentId, c.content as content, 
           c.level as level, c.likesCount as likesCount, c.repliesCount as repliesCount, 
           c.createdAt as createdAt, c.deletedAt as deletedAt,
           u.profile.displayName as userDisplayName, u.profile.avatarUrl as userAvatarUrl
    from RoomCommentEntity c
    left join com.lucy.api.modules.identity.entity.User u on c.userId = cast(u.id as uuid)
    where c.roomId = :roomId
      and c.level = 1
      and c.deletedAt is null
      and (
            (cast(:cursorCreatedAt as Instant) is null and cast(:cursorId as uuid) is null)
            or (c.createdAt < :cursorCreatedAt)
            or (c.createdAt = :cursorCreatedAt and c.id < :cursorId)
          )
    order by c.createdAt desc, c.id desc
    """)
    List<RoomCommentProjection> findCommentsByRoomId(
            @Param("roomId") UUID roomId,
            @Param("cursorCreatedAt") Instant cursorCreatedAt,
            @Param("cursorId") UUID cursorId,
            Pageable pageable
    );

    @Query("""
    select c.id as id, c.userId as userId, c.parentId as parentId, c.content as content, 
           c.level as level, c.likesCount as likesCount, c.repliesCount as repliesCount, 
           c.createdAt as createdAt, c.deletedAt as deletedAt,
           u.profile.displayName as userDisplayName, u.profile.avatarUrl as userAvatarUrl
    from RoomCommentEntity c
    left join com.lucy.api.modules.identity.entity.User u on c.userId = cast(u.id as uuid)
    where c.parentId = :parentId
      and c.deletedAt is null
    order by c.createdAt asc, c.id asc
    """)
    List<RoomCommentProjection> findRepliesByParentId(@Param("parentId") UUID parentId);

    @Modifying
    @Query("update RoomCommentEntity c set c.likesCount = c.likesCount + :delta where c.id = :commentId")
    int incrementLikesCount(@Param("commentId") UUID commentId, @Param("delta") int delta);

    @Modifying
    @Query("update RoomCommentEntity c set c.repliesCount = c.repliesCount + :delta where c.id = :commentId")
    int incrementRepliesCount(@Param("commentId") UUID commentId, @Param("delta") int delta);

    void deleteAllByUserIdIn(List<UUID> userIds);

    void deleteAllByRoomIdIn(List<UUID> roomIds);
}
