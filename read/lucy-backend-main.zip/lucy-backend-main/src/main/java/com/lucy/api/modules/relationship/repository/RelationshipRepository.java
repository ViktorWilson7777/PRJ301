package com.lucy.api.modules.relationship.repository;

import com.lucy.api.modules.relationship.entity.Relationship;
import com.lucy.api.modules.relationship.enums.RelationshipStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface RelationshipRepository extends JpaRepository<Relationship, String> {

    @Query("""
            select r
            from Relationship r
            where (r.requester.id = :firstUserId and r.addressee.id = :secondUserId)
               or (r.requester.id = :secondUserId and r.addressee.id = :firstUserId)
            """)
    Optional<Relationship> findBetweenUsers(
            @Param("firstUserId") String firstUserId,
            @Param("secondUserId") String secondUserId
    );

    List<Relationship> findAllByAddressee_IdAndStatusOrderByRequestedAtDesc(String addresseeId, RelationshipStatus status);

    List<Relationship> findAllByRequester_IdAndStatusOrderByRequestedAtDesc(String requesterId, RelationshipStatus status);

    @Query("""
            select r
            from Relationship r
            where r.status = :status
              and (r.requester.id = :userId or r.addressee.id = :userId)
            order by r.respondedAt desc, r.updatedAt desc
            """)
    List<Relationship> findAllByUserIdAndStatus(
            @Param("userId") String userId,
            @Param("status") RelationshipStatus status
    );

    @Modifying
    @Transactional
    void deleteAllByRequester_IdInOrAddressee_IdIn(List<String> requesterIds, List<String> addresseeIds);
}
