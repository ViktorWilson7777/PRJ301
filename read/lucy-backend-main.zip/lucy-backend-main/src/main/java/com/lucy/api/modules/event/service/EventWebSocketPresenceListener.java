package com.lucy.api.modules.event.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;
import org.springframework.web.socket.messaging.SessionConnectedEvent;
import org.springframework.web.socket.messaging.SessionSubscribeEvent;

import java.security.Principal;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@RequiredArgsConstructor
@Slf4j
public class EventWebSocketPresenceListener {
    private static final Pattern PARTICIPANT_TOPIC_PATTERN = Pattern.compile("^/topic/rooms/([0-9a-fA-F-]{36})/participants$");

    private final EventWebSocketSessionRegistry sessionRegistry;
    private final EventService eventService;
    private final com.lucy.api.common.configs.WebSocketSessionStore webSocketSessionStore;

    @EventListener
    public void onConnected(SessionConnectedEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        if (accessor.getSessionId() != null && accessor.getUser() != null) {
            webSocketSessionStore.put(accessor.getSessionId(), accessor.getUser());
        }
    }

    @EventListener
    public void onSubscribe(SessionSubscribeEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        String destination = accessor.getDestination();
        Principal principal = accessor.getUser();
        String sessionId = accessor.getSessionId();

        UUID roomId = parseRoomId(destination);
        UUID userId = parseUserId(principal);
        if (roomId == null || userId == null || !StringUtils.hasText(sessionId)) {
            return;
        }
        sessionRegistry.bind(sessionId, userId, roomId);
    }

    @EventListener
    public void onDisconnect(SessionDisconnectEvent event) {
        EventWebSocketSessionRegistry.SessionBinding binding = sessionRegistry.unbind(event.getSessionId());
        if (binding == null) {
            return;
        }

        try {
            eventService.leaveEventOnDisconnect(binding.roomId(), binding.userId());
        } catch (Exception ex) {
            log.debug("Skip leave-on-disconnect for room={} user={}", binding.roomId(), binding.userId(), ex);
        }
    }

    private UUID parseRoomId(String destination) {
        if (!StringUtils.hasText(destination)) {
            return null;
        }
        Matcher matcher = PARTICIPANT_TOPIC_PATTERN.matcher(destination);
        if (!matcher.matches()) {
            return null;
        }
        return UUID.fromString(matcher.group(1));
    }

    private UUID parseUserId(Principal principal) {
        if (principal == null || !StringUtils.hasText(principal.getName())) {
            return null;
        }
        try {
            return UUID.fromString(principal.getName());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
