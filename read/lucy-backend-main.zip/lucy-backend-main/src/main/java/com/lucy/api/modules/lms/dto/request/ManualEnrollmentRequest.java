package com.lucy.api.modules.lms.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ManualEnrollmentRequest {

    @NotBlank(message = "common.field_required")
    String userId;

    @NotBlank(message = "common.field_required")
    String courseRunId;
}

