package com.lucy.api.modules.notifications.service;

import com.lucy.api.modules.notifications.dto.request.UserDeviceRequest;
import com.lucy.api.modules.notifications.entity.UserDevice;
import com.lucy.api.modules.notifications.repository.UserDeviceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserDeviceService {

    private final UserDeviceRepository userDeviceRepository;
    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(UserDeviceService.class);

    @Transactional
    public void registerDevice(String currentUserId, UserDeviceRequest request) {
        // Find existing token
        UserDevice existing = userDeviceRepository.findByDeviceToken(request.getToken()).orElse(null);
        
        if (existing != null) {
            // Update owner if token changed hands
            if (!existing.getUserId().equals(currentUserId)) {
                existing.setUserId(currentUserId);
                userDeviceRepository.save(existing);
            }
            return;
        }

        // New Device Registration
        UserDevice device = UserDevice.builder()
                .userId(currentUserId)
                .deviceToken(request.getToken())
                .osType(request.getOsType())
                .build();

        userDeviceRepository.save(device);
    }

    @Transactional
    public void unregisterDevice(String deviceToken) {
        userDeviceRepository.deleteByDeviceToken(deviceToken);
        logger.info("[DeviceToken] Successfully unregistered token: {}", 
                deviceToken.substring(0, Math.min(deviceToken.length(), 20)) + "...");
    }
}
