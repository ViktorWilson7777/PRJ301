package com.lucy.api.modules.identity.mapper;

import com.lucy.api.modules.identity.dtos.response.user.UserProfileResponse;
import com.lucy.api.modules.identity.entity.UserProfile;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserProfileMapper {
    UserProfileResponse toResponse(UserProfile entity);
}
