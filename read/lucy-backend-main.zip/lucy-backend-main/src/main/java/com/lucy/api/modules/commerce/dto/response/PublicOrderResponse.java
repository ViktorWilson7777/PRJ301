package com.lucy.api.modules.commerce.dto.response;

import com.lucy.api.modules.commerce.entity.enums.PublicOrderStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PublicOrderResponse {
    String id;
    String buyerUserId;
    PublicOrderStatus status;
    BigDecimal totalAmount;
    String currency;
    String provider;
    String providerTransactionId;
    Instant paidAt;
    Instant createdAt;
    Instant updatedAt;
    List<PublicOrderItemResponse> items;
}
