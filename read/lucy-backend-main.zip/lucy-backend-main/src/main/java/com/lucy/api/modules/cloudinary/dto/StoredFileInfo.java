package com.lucy.api.modules.cloudinary.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StoredFileInfo {
    String provider;
    String fileName;
    String mimeType;
    Long size;
    String url;
    String publicId;
    String resourceType;
}
