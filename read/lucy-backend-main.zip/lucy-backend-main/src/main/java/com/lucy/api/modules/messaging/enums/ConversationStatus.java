package com.lucy.api.modules.messaging.enums;

public enum ConversationStatus {
    OPEN,
    CLOSED,
    BLOCKING
}
