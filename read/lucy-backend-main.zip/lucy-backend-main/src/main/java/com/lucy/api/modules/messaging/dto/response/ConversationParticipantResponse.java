package com.lucy.api.modules.messaging.dto.response;

import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ConversationParticipantResponse {
    String userId;
    String displayName;
    ParticipantStatus status;
    Instant joinedAt;
    Instant leftAt;
}
