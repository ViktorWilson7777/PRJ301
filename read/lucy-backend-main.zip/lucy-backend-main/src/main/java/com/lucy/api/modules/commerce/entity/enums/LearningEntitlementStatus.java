package com.lucy.api.modules.commerce.entity.enums;

public enum LearningEntitlementStatus {
    ACTIVE,
    REVOKED
}
