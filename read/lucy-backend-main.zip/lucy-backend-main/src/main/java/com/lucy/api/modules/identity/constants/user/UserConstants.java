package com.lucy.api.modules.identity.constants.user;

public final class UserConstants {

    private UserConstants() {}

    // ===== TABLE =====
    public static final String TABLE_USERS = "users";
    public static final String TABLE_USER_IDENTITIES = "user_identities";
    public static final String TABLE_USER_PROFILES = "user_profiles";
    public static final String TABLE_SESSIONS = "sessions";

    // ===== COLUMNS =====
    public static final String COL_EMAIL = "email";
    public static final String COL_DISPLAY_NAME = "display_name";
    public static final String COL_PASSWORD_HASH = "password_hash";
    // user_identities columns
    public static final String COL_USER_ID = "user_id";
    public static final String COL_PROVIDER = "provider";
    public static final String COL_PROVIDER_USER_ID = "provider_user_id";
    public static final String COL_PROVIDER_DATA = "provider_data";
    public static final String COL_AVATAR_URL = "avatar_url";
    public static final String COL_BACKGROUND_URL = "background_url";

    public static final String COL_IS_ACTIVE = "is_active";
    public static final String COL_IS_VERIFIED = "is_verified";
    public static final String COL_VERIFIED_AT = "verified_at";
    public static final String COL_BANNED_UNTIL = "banned_until";
    public static final String COL_LAST_SIGN_IN_AT = "last_sign_in_at";
    public static final String COL_IS_PROFILE_COMPLETED = "is_profile_completed";

    public static final String COL_APP_METADATA = "app_metadata";
    public static final String COL_USER_METADATA = "user_metadata";

    public static final String COL_DELETED_AT = "deleted_at";
    public static final String COL_REFRESH_TOKEN = "refresh_token";

    public static final String COL_LEVEL = "level";
    public static final String COL_SPEAKING_MINUTES_TOTAL = "speaking_minutes_total";
    public static final String COL_SPEAKING_MINUTES_CURRENT = "speaking_minutes_current";
    public static final String COL_INTEREST = "interest";
    public static final String COL_SPECIALTY = "specialty";
    public static final String COL_INTERESTS = "interests";
    public static final String COL_IS_PRO_CERTIFIED = "is_pro_certified";
    public static final String COL_EVOLUTION_STAGE = "evolution_stage";
    public static final String COL_BACKGROUND_METADATA = "background_metadata";
    public static final String COL_AVATAR_KEY = "avatar_key";
    public static final String COL_PUBLIC_PROFILE_SETTINGS = "public_profile_settings";

    // session columns
    public static final String COL_TOKEN_HASH = "token_hash";
    public static final String COL_DEVICE_INFO = "device_info";
    public static final String COL_IP_ADDRESS = "ip_address";
    public static final String COL_EXPIRES_AT = "expires_at";
    public static final String COL_REVOKED_AT = "revoked_at";

    // ===== COLUMN DEFINITIONS =====
    public static final String JSONB_DEFINITION = "jsonb";

    // ===== PATH PARAM REGEX =====
    public static final String UUID_REGEX =
            "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";


}
