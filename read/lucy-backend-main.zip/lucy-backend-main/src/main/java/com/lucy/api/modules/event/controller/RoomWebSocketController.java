package com.lucy.api.modules.event.controller;

import com.lucy.api.common.configs.WebSocketSessionStore;
import com.lucy.api.modules.event.dto.request.JoinRoomRequest;
import com.lucy.api.modules.event.dto.request.LeaveRoomRequest;
import com.lucy.api.modules.event.dto.request.RaiseHandRequest;
import com.lucy.api.modules.event.dto.request.ToggleMicRequest;
import com.lucy.api.modules.event.dto.response.HandRaiseResponse;
import com.lucy.api.modules.event.dto.response.MicStatusResponse;
import com.lucy.api.modules.event.dto.response.ParticipantResponse;
import com.lucy.api.modules.event.dto.response.ParticipantSnapshotResponse;
import com.lucy.api.modules.event.dto.response.UserJoinedResponse;
import com.lucy.api.modules.event.dto.response.UserLeftResponse;
import com.lucy.api.modules.event.dto.response.WebSocketErrorResponse;
import com.lucy.api.modules.event.service.EventService;
import com.lucy.api.modules.event.service.RoomRealtimePublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;

import java.security.Principal;
import java.time.Instant;
import java.util.UUID;

/**
 * WebSocket controller for room lifecycle events only.
 * Chat is handled in {@link RoomChatWebSocketController}.
 */
@Controller
@RequiredArgsConstructor
@Slf4j
public class RoomWebSocketController {

    private final RoomRealtimePublisher realtimePublisher;
    private final EventService eventService;
    private final WebSocketSessionStore webSocketSessionStore;

    @MessageMapping("/room/join")
    public void handleJoinRoom(
            @Payload JoinRoomRequest request,
            Principal principal,
            SimpMessageHeaderAccessor headerAccessor) {
        UUID roomId = request != null ? request.getRoomId() : null;
        try {
            roomId = requireRoomId(roomId);
            UUID userId = requireUserId(principal, headerAccessor);
            ParticipantResponse participant = eventService.requireParticipantState(roomId, userId);
            ParticipantSnapshotResponse snapshot = eventService.getParticipantSnapshot(roomId);
            String sessionId = sessionId(headerAccessor);
            boolean firstJoinForSession = sessionId == null || webSocketSessionStore.trackRoom(sessionId, roomId);

            if (sessionId != null && !firstJoinForSession) {
                log.debug("Ignoring duplicate join signal for user {} in room {}", userId, roomId);
                return;
            }

            UserJoinedResponse response = UserJoinedResponse.builder()
                    .roomId(roomId)
                    .userId(userId)
                    .displayName(participant.getDisplayName())
                    .isMonitor(participant.isMonitor())
                    .joinedAt(participant.getJoinedAt() != null ? participant.getJoinedAt() : Instant.now())
                    .totalParticipants(snapshot.getTotalParticipants())
                    .rtcUid(participant.getRtcUid())
                    .build();

            realtimePublisher.publishParticipants(roomId, response);
        } catch (Exception e) {
            log.error("Error handling join room event", e);
            sendError(roomId, "JOIN_ERROR", e.getMessage(), principal, headerAccessor);
        }
    }

    @MessageMapping("/room/leave")
    public void handleLeaveRoom(
            @Payload LeaveRoomRequest request,
            Principal principal,
            SimpMessageHeaderAccessor headerAccessor) {
        UUID roomId = request != null ? request.getRoomId() : null;
        try {
            roomId = requireRoomId(roomId);
            UUID userId = requireUserId(principal, headerAccessor);
            ParticipantResponse participant = eventService.requireParticipantState(roomId, userId);

            eventService.leaveEvent(roomId, userId);
            webSocketSessionStore.untrackRoom(sessionId(headerAccessor), roomId);
            ParticipantSnapshotResponse snapshot = eventService.getParticipantSnapshot(roomId);

            UserLeftResponse response = UserLeftResponse.builder()
                    .roomId(roomId)
                    .userId(userId)
                    .displayName(participant.getDisplayName())
                    .reason(request != null && StringUtils.hasText(request.getReason()) ? request.getReason() : "manual")
                    .leftAt(Instant.now())
                    .totalParticipants(snapshot.getTotalParticipants())
                    .build();

            realtimePublisher.publishParticipants(roomId, response);
        } catch (Exception e) {
            log.error("Error handling leave room event", e);
            sendError(roomId, "LEAVE_ERROR", e.getMessage(), principal, headerAccessor);
        }
    }

    @MessageMapping("/room/mic/toggle")
    public void handleToggleMic(
            @Payload ToggleMicRequest request,
            Principal principal,
            SimpMessageHeaderAccessor headerAccessor) {
        UUID roomId = request != null ? request.getRoomId() : null;
        try {
            roomId = requireRoomId(roomId);
            UUID userId = requireUserId(principal, headerAccessor);
            trackSessionRoom(headerAccessor, roomId);
            ParticipantResponse participant = eventService.requireParticipantState(roomId, userId);
            boolean micEnabled = request != null && request.isMicEnabled();

            eventService.updateMicStatus(roomId, userId, micEnabled);

            MicStatusResponse response = MicStatusResponse.builder()
                    .roomId(roomId)
                    .userId(userId)
                    .displayName(participant.getDisplayName())
                    .micEnabled(micEnabled)
                    .build();

            realtimePublisher.publishParticipants(roomId, response);
        } catch (Exception e) {
            log.error("Error handling mic toggle", e);
            sendError(roomId, "MIC_ERROR", e.getMessage(), principal, headerAccessor);
        }
    }

    @MessageMapping("/room/hand/raise")
    public void handleRaiseHand(
            @Payload RaiseHandRequest request,
            Principal principal,
            SimpMessageHeaderAccessor headerAccessor) {
        UUID roomId = request != null ? request.getRoomId() : null;
        try {
            roomId = requireRoomId(roomId);
            UUID userId = requireUserId(principal, headerAccessor);
            trackSessionRoom(headerAccessor, roomId);
            ParticipantResponse participant = eventService.requireParticipantState(roomId, userId);
            boolean raiseHand = request != null && request.isRaiseHand();

            eventService.updateRaiseHand(roomId, userId, raiseHand);

            HandRaiseResponse response = HandRaiseResponse.builder()
                    .roomId(roomId)
                    .userId(userId)
                    .displayName(participant.getDisplayName())
                    .raiseHand(raiseHand)
                    .build();

            realtimePublisher.publishParticipants(roomId, response);
        } catch (Exception e) {
            log.error("Error handling hand raise", e);
            sendError(roomId, "HAND_ERROR", e.getMessage(), principal, headerAccessor);
        }
    }

    private void sendError(UUID roomId, String errorCode, String errorMessage, Principal principal, SimpMessageHeaderAccessor headerAccessor) {
        WebSocketErrorResponse error = WebSocketErrorResponse.builder()
                .errorCode(errorCode)
                .errorMessage(errorMessage)
                .roomId(roomId)
                .timestamp(Instant.now().toString())
                .build();

        String userId = resolvePrincipalName(principal, headerAccessor);
        String sessionId = sessionId(headerAccessor);
        if (StringUtils.hasText(userId) && StringUtils.hasText(sessionId)) {
            realtimePublisher.publishErrorToUserSession(userId, sessionId, error);
        }
    }

    private UUID requireUserId(Principal principal, SimpMessageHeaderAccessor headerAccessor) {
        String userId = resolvePrincipalName(principal, headerAccessor);
        if (!StringUtils.hasText(userId)) {
            throw new IllegalArgumentException("Authentication required");
        }
        return UUID.fromString(userId);
    }

    private UUID requireRoomId(UUID roomId) {
        if (roomId == null) {
            throw new IllegalArgumentException("roomId is required");
        }
        return roomId;
    }

    private void trackSessionRoom(SimpMessageHeaderAccessor headerAccessor, UUID roomId) {
        String sessionId = sessionId(headerAccessor);
        if (sessionId != null) {
            webSocketSessionStore.trackRoom(sessionId, roomId);
        }
    }

    private String sessionId(SimpMessageHeaderAccessor headerAccessor) {
        return headerAccessor != null ? headerAccessor.getSessionId() : null;
    }

    private String resolvePrincipalName(Principal principal, SimpMessageHeaderAccessor headerAccessor) {
        Principal effectivePrincipal = principal;
        if ((effectivePrincipal == null || !StringUtils.hasText(effectivePrincipal.getName())) && headerAccessor != null) {
            effectivePrincipal = headerAccessor.getUser();
        }
        if ((effectivePrincipal == null || !StringUtils.hasText(effectivePrincipal.getName())) && headerAccessor != null) {
            effectivePrincipal = webSocketSessionStore.get(headerAccessor.getSessionId()).orElse(null);
        }
        return effectivePrincipal != null ? effectivePrincipal.getName() : null;
    }
}
