package com.lucy.api.modules.messaging.dto.response;

import com.lucy.api.modules.messaging.enums.ConversationMode;
import com.lucy.api.modules.messaging.enums.ConversationStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ConversationResponse {
    String id;
    ConversationMode mode;
    String courseRunId;
    String groupName;
    String createdBy;
    ConversationStatus status;
    List<ConversationParticipantResponse> participants;
    String myParticipantStatus;
}
