package com.lucy.api.modules.organization.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(
        name = "organization_memberships",
        uniqueConstraints = @UniqueConstraint(name = "organization_memberships_org_user_key", columnNames = {"organization_id", "user_id"})
)
public class OrganizationMembership extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "organization_id", nullable = false)
    Organization organization;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    OrganizationMembershipRole role;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    OrganizationMembershipStatus status = OrganizationMembershipStatus.ACTIVE;

    @Column(nullable = false)
    @Builder.Default
    Instant joinedAt = Instant.now();
}
