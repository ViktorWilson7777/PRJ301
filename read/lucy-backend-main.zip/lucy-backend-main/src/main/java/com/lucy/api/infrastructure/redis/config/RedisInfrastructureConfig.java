package com.lucy.api.infrastructure.redis.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
public class RedisInfrastructureConfig {

    @Bean(destroyMethod = "close")
    ExecutorService redisPubSubTaskExecutor() {
        return Executors.newVirtualThreadPerTaskExecutor();
    }

    @Bean(destroyMethod = "close")
    ExecutorService redisPubSubSubscriptionExecutor() {
        return Executors.newVirtualThreadPerTaskExecutor();
    }

    @Bean
    public RedisMessageListenerContainer redisMessageListenerContainer(
            RedisConnectionFactory connectionFactory,
            ExecutorService redisPubSubTaskExecutor,
            ExecutorService redisPubSubSubscriptionExecutor
    ) {
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setTaskExecutor(redisPubSubTaskExecutor);
        container.setSubscriptionExecutor(redisPubSubSubscriptionExecutor);
        return container;
    }
}
