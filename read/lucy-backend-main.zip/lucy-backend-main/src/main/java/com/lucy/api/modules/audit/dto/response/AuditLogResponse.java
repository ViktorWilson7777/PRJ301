package com.lucy.api.modules.audit.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AuditLogResponse {
    UUID id;
    UUID actorUserId;
    String actorType;
    String actorDisplay;
    String action;
    String entityType;
    UUID entityId;
    String requestId;
    String ipAddress;
    String userAgent;
    Map<String, Object> metadata;
    Instant createdAt;
}
