package com.lucy.api.modules.messaging.service.facade;

import com.lucy.api.modules.messaging.entity.Conversation;
import com.lucy.api.modules.messaging.service.domain.ConversationDomainService;
import com.lucy.api.modules.messaging.service.domain.ConversationParticipantDomainService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Application facade: orchestration enrollment → conversation nhóm.
 */
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class CourseRunGroupChatFacade {

    ConversationDomainService conversationDomainService;
    ConversationParticipantDomainService conversationParticipantDomainService;

    @Transactional
    public void syncAfterEnrollmentActivated(String userId, String courseRunId) {
        Conversation conversation = conversationDomainService.ensureGroupConversation(courseRunId);
        conversationParticipantDomainService.ensureActiveParticipant(conversation.getId(), userId);
    }

    @Transactional
    public void syncAfterEnrollmentRemoved(String userId, String courseRunId) {
        conversationParticipantDomainService.markParticipantLeftForCourseRunGroup(userId, courseRunId);
    }
}
