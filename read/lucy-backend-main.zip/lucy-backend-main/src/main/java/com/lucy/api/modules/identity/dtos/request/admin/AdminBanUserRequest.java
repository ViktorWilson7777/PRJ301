package com.lucy.api.modules.identity.dtos.request.admin;

import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Getter
@Setter
public class AdminBanUserRequest {
    /**
     * If null -> unban.
     * If provided -> user is considered banned until this instant.
     */
    private Instant bannedUntil;
}

