package com.lucy.api.modules.messaging.constant;

/**
 * Trạng thái {@link com.lucy.api.modules.lms.entity.CourseRun} cho phép chat nhóm.
 */
public final class MessagingCourseRunConstants {

    private MessagingCourseRunConstants() {
    }

    public static final String STATUS_OPEN = "OPEN";
}
