package com.lucy.api.modules.lms.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.lms.dto.request.ChapterUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.entity.Chapter;
import com.lucy.api.modules.lms.mapper.ChapterMapper;
import com.lucy.api.modules.lms.repository.ChapterRepository;
import com.lucy.api.modules.lms.service.api.ChapterService;
import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ChapterServiceImpl implements ChapterService {
    private final ChapterRepository chapterRepository;
    private final ChapterMapper chapterMapper;
    private final CourseRunService courseRunService;

    @Override
    @Transactional
    public ChapterResponse create(ChapterUpsertRequest request) {
        CourseRun courseRun = courseRunService.getEntityById(request.getCourseRunId());
        Chapter chapter = chapterMapper.toEntity(request);
        chapter.setCourseRun(courseRun);
        return chapterMapper.toResponse(chapterRepository.save(chapter));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChapterResponse> findAll(String courseRunId) {
        if (courseRunId != null) {
            courseRunService.getEntityById(courseRunId);
        }

        List<Chapter> chapters = courseRunId == null
                ? chapterRepository.findAll(Sort.by(Sort.Order.asc("orderIndex"), Sort.Order.desc("createdAt")))
                : chapterRepository.findAllByCourseRun_IdOrderByOrderIndexAscCreatedAtAsc(courseRunId);

        return chapters.stream().map(chapterMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public ChapterResponse findById(String chapterId) {
        return chapterMapper.toResponse(getEntityById(chapterId));
    }

    @Override
    @Transactional
    public ChapterResponse update(String chapterId, ChapterUpsertRequest request) {
        Chapter chapter = getEntityById(chapterId);
        CourseRun courseRun = courseRunService.getEntityById(request.getCourseRunId());
        chapterMapper.updateEntity(chapter, request);
        chapter.setCourseRun(courseRun);
        return chapterMapper.toResponse(chapterRepository.save(chapter));
    }

    @Override
    @Transactional
    public void delete(String chapterId) {
        chapterRepository.delete(getEntityById(chapterId));
    }

    @Override
    @Transactional(readOnly = true)
    public Chapter getEntityById(String chapterId) {
        return chapterRepository.findById(chapterId)
                .orElseThrow(() -> new AppException("lms.chapter_not_found", HttpStatus.NOT_FOUND));
    }
}
