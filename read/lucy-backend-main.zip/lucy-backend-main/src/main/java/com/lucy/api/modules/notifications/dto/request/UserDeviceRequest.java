package com.lucy.api.modules.notifications.dto.request;

import com.fasterxml.jackson.annotation.JsonAlias;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.util.StringUtils;

@Data
public class UserDeviceRequest {
    @NotBlank(message = "Token cannot be empty")
    @JsonAlias("deviceToken")
    private String token;

    @JsonAlias("platform")
    private String osType; // e.g. "ANDROID", "IOS"

    @JsonAlias("deviceId")
    private String deviceId;

    public String getOsType() {
        if (StringUtils.hasText(osType)) {
            return osType;
        }
        return "UNKNOWN";
    }
}
