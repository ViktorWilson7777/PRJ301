package com.lucy.api.infrastructure.websocket.service.api;

import io.netty.channel.Channel;

/**
 * Tin chat realtime: chiến lược fan-out là <strong>chỉ publish Redis</strong> ({@link #sendToTopic} → {@link #publishToRedis}).
 * Mọi instance (kể cả instance gửi) nhận một lần qua subscriber Redis rồi {@link #broadcastToLocalSessions} — tránh double delivery
 * khi vừa broadcast local vừa nhận lại cùng message trên cùng node.
 */
public interface WebSocketMessageService {

    void registerChannel(String sessionId, Channel channel);

    void unregisterChannel(String sessionId);

    Channel getChannel(String sessionId);

    /**
     * Gửi payload tới mọi client đang subscribe topic (conversation). Implementation chỉ đẩy Redis, không broadcast local trực tiếp.
     */
    void sendToTopic(String topicId, Object payload, String type);

    void broadcastToLocalSessions(String topicId, Object payload, String type);

    void publishToRedis(String topicId, Object payload, String type);
}
