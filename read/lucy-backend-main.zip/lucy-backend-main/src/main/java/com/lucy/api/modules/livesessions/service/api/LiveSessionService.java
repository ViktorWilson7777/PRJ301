package com.lucy.api.modules.livesessions.service.api;

import com.lucy.api.modules.livesessions.dto.request.CreateLiveSessionRequest;
import com.lucy.api.modules.livesessions.dto.response.LiveSessionResponse;
import com.lucy.api.modules.livesessions.dto.response.MeetingTokenResponse;

import java.util.List;

public interface LiveSessionService {

    /** Generate a join token for a room. */
    MeetingTokenResponse getJoinToken(String roomCode, String userId);

    /**
     * Create a standalone LiveSession (not tied to an Event via EventService).
     * The owner will be set to the authenticated user.
     */
    LiveSessionResponse createSession(CreateLiveSessionRequest request, String ownerId);

    /** Get a single LiveSession by its database ID. */
    LiveSessionResponse getSessionById(String sessionId);

    /** Get a single LiveSession by its roomCode. */
    LiveSessionResponse getSessionByRoomCode(String roomCode);

    /** List all sessions owned by a specific user. */
    List<LiveSessionResponse> getSessionsByOwner(String ownerId);

    /**
     * End (terminate) a session — sets status to ENDED.
     * Only the owner or ADMIN can call this.
     */
    LiveSessionResponse endSession(String sessionId, String requesterId);

    /**
     * Delete a LiveSession record.
     * Only the owner or ADMIN can call this.
     */
    void deleteSession(String sessionId, String requesterId);
}
