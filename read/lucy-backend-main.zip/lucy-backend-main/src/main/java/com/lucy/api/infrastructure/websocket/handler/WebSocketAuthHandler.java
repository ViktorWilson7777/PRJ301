package com.lucy.api.infrastructure.websocket.handler;

import com.lucy.api.common.constants.JwtClaimSetConstant;
import com.lucy.api.infrastructure.redis.pubsub.RedisPubSubSubscriptionService;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketErrorCodeConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketFrameTypeConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketMessageKeys;
import com.lucy.api.infrastructure.websocket.dto.request.WebSocketAuthRequest;
import com.lucy.api.infrastructure.websocket.dto.response.WebSocketAuthResponse;
import com.lucy.api.infrastructure.websocket.entity.WebSocketSession;
import com.lucy.api.infrastructure.websocket.enums.WebSocketConnectionStatus;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketMessageService;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketNotificationService;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketSessionService;
import com.lucy.api.infrastructure.websocket.utils.WebSocketPayloadCodec;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Slf4j
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WebSocketAuthHandler {

    JwtDecoder jwtDecoder;
    WebSocketSessionService sessionService;
    WebSocketMessageService messageService;
    WebSocketNotificationService notificationService;
    RedisPubSubSubscriptionService redisPubSubSubscriptionService;
    WebSocketPayloadCodec payloadCodec;
    MessageSource messageSource;

    public void handleAuth(ChannelHandlerContext ctx, String messageJson, String sessionId) {
        try {
            WebSocketAuthRequest request = payloadCodec.parseMessage(messageJson, WebSocketAuthRequest.class);
            if (request == null || request.getToken() == null) {
                sendError(ctx, WebSocketErrorCodeConstants.INVALID_TOKEN, WebSocketMessageKeys.TOKEN_REQUIRED);
                return;
            }

            Jwt jwt = jwtDecoder.decode(request.getToken());
            String userId = jwt.getClaimAsString(JwtClaimSetConstant.CLAIM_USER_ID);
            if (userId == null) {
                sendError(ctx, WebSocketErrorCodeConstants.INVALID_TOKEN, WebSocketMessageKeys.USER_NOT_IN_TOKEN);
                return;
            }

            Set<String> authorities = extractAuthorities(jwt);

            WebSocketSession session = WebSocketSession.builder()
                    .sessionId(sessionId)
                    .userId(userId)
                    .channelId(ctx.channel().id().asShortText())
                    .status(WebSocketConnectionStatus.AUTHENTICATED)
                    .connectedAt(Instant.now())
                    .lastActivityAt(Instant.now())
                    .authorities(authorities)
                    .build();

            sessionService.createSession(session);
            messageService.registerChannel(sessionId, ctx.channel());
            notificationService.registerChannel(sessionId, ctx.channel());
            redisPubSubSubscriptionService.subscribeToUserNotifications(userId);

            WebSocketAuthResponse response = WebSocketAuthResponse.builder()
                    .sessionId(sessionId)
                    .userId(userId)
                    .authenticated(true)
                    .build();

            String body = payloadCodec.toJson(Map.of(
                    WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.AUTH,
                    WebSocketConstants.FIELD_SESSION_ID, response.getSessionId(),
                    WebSocketConstants.FIELD_USER_ID, response.getUserId(),
                    "authenticated", response.getAuthenticated()
            ));
            if (body != null) {
                ctx.channel().writeAndFlush(new TextWebSocketFrame(body));
            }

            log.debug("WebSocket authenticated: sessionId={}, userId={}", sessionId, userId);
        } catch (JwtException e) {
            log.error("JWT validation failed", e);
            sendError(ctx, WebSocketErrorCodeConstants.INVALID_TOKEN, WebSocketMessageKeys.INVALID_TOKEN);
        } catch (Exception e) {
            log.error("Error during WebSocket authentication", e);
            sendError(ctx, WebSocketErrorCodeConstants.UNAUTHENTICATED, WebSocketMessageKeys.AUTH_FAILED);
        }
    }

    private Set<String> extractAuthorities(Jwt jwt) {
        Set<String> authorities = new HashSet<>();
        Object rawScope = jwt.getClaims().get(JwtClaimSetConstant.CLAIM_SCOPE);
        if (rawScope instanceof String scopeString) {
            if (StringUtils.hasText(scopeString)) {
                for (String role : scopeString.trim().split("\\s+")) {
                    if (StringUtils.hasText(role)) {
                        authorities.add(role);
                    }
                }
            }
        } else if (rawScope instanceof Collection<?> scopeCollection) {
            scopeCollection.forEach(role -> {
                if (role instanceof String roleText && StringUtils.hasText(roleText)) {
                    authorities.add(roleText);
                }
            });
        }

        List<String> permissions = jwt.getClaimAsStringList(JwtClaimSetConstant.CLAIM_PERMISSION);
        if (permissions != null) {
            permissions.forEach(permission -> {
                if (StringUtils.hasText(permission)) {
                    authorities.add(permission);
                }
            });
        }
        return authorities;
    }

    public void handleDisconnect(String sessionId) {
        try {
            Optional<WebSocketSession> sessionOpt = sessionService.getSession(sessionId);
            if (sessionOpt.isPresent()) {
                messageService.unregisterChannel(sessionId);
                notificationService.unregisterChannel(sessionId);
            }
            sessionService.removeSession(sessionId);
            log.debug("WebSocket session disconnected: {}", sessionId);
        } catch (Exception e) {
            log.error("Error during session cleanup", e);
        }
    }

    private void sendError(ChannelHandlerContext ctx, String errorCode, String messageKey) {
        String text = messageSource.getMessage(messageKey, null, Locale.ENGLISH);
        String errorJson = payloadCodec.toJson(Map.of(
                WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.ERROR,
                WebSocketConstants.FIELD_ERROR_CODE, errorCode,
                WebSocketConstants.FIELD_MESSAGE, text,
                WebSocketConstants.FIELD_MESSAGE_KEY, messageKey
        ));
        if (errorJson != null) {
            ctx.channel().writeAndFlush(new TextWebSocketFrame(errorJson));
        }
    }
}
