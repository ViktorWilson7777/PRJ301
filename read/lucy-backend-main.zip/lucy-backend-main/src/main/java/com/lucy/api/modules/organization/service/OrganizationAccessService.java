package com.lucy.api.modules.organization.service;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.enums.UserRole;
import com.lucy.api.modules.identity.service.impl.CurrentUserService;
import com.lucy.api.modules.organization.entity.OrganizationMembership;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipStatus;
import com.lucy.api.modules.organization.repository.OrganizationMembershipRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class OrganizationAccessService {
    CurrentUserService currentUserService;
    OrganizationMembershipRepository organizationMembershipRepository;

    @Transactional(readOnly = true)
    public OrganizationMembership assertActiveMembership(String organizationId) {
        String userId = currentUserService.getCurrentUserId();
        return organizationMembershipRepository.findByOrganization_IdAndUser_Id(organizationId, userId)
                .filter(it -> it.getStatus() == OrganizationMembershipStatus.ACTIVE)
                .orElseThrow(() -> new AppException("organization.membership_required", HttpStatus.FORBIDDEN));
    }

    @Transactional(readOnly = true)
    public OrganizationMembership assertOrganizationRole(String organizationId, OrganizationMembershipRole... allowedRoles) {
        User currentUser = currentUserService.getCurrentUser();
        if (currentUser.getRoleName() == UserRole.ADMIN) {
            return null;
        }
        OrganizationMembership membership = assertActiveMembership(organizationId);
        if (allowedRoles.length == 0) {
            return membership;
        }
        boolean allowed = Arrays.stream(allowedRoles).anyMatch(role -> role == membership.getRole());
        if (!allowed) {
            throw new AppException("organization.forbidden", HttpStatus.FORBIDDEN);
        }
        return membership;
    }

    @Transactional(readOnly = true)
    public boolean isPlatformAdmin() {
        return currentUserService.getCurrentUser().getRoleName() == UserRole.ADMIN;
    }
}
