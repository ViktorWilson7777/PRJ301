package com.lucy.api.modules.messaging.util;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.messaging.constant.MessagingErrorKeys;
import org.springframework.http.HttpStatus;

import java.util.Locale;
import java.util.UUID;

/**
 * Chuẩn hóa directKey: trim, lowercase UUID, thứ tự min|max; chặn chat với chính mình.
 */
public final class DirectKeyNormalizer {

    public static final String SEPARATOR = "|";

    private DirectKeyNormalizer() {
    }

    public static String buildDirectKey(String userIdA, String userIdB) {
        String a = normalizeUserId(userIdA);
        String b = normalizeUserId(userIdB);
        if (a.equals(b)) {
            throw new AppException(MessagingErrorKeys.DIRECT_SELF_NOT_ALLOWED, HttpStatus.BAD_REQUEST);
        }
        return a.compareTo(b) <= 0 ? a + SEPARATOR + b : b + SEPARATOR + a;
    }

    public static String normalizeUserId(String raw) {
        if (raw == null) {
            throw new AppException(MessagingErrorKeys.INVALID_DIRECT_KEY, HttpStatus.BAD_REQUEST);
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            throw new AppException(MessagingErrorKeys.INVALID_DIRECT_KEY, HttpStatus.BAD_REQUEST);
        }
        try {
            return UUID.fromString(trimmed).toString().toLowerCase(Locale.ROOT);
        } catch (IllegalArgumentException e) {
            throw new AppException(MessagingErrorKeys.INVALID_DIRECT_KEY, HttpStatus.BAD_REQUEST);
        }
    }
}
