package com.lucy.api.modules.lms.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class LessonUpsertRequest {
    @NotNull(message = "common.field_required")
    private String chapterId;

    @NotBlank(message = "common.field_required")
    @Size(max = 30, message = "common.validation")
    private String type;

    @NotBlank(message = "common.field_required")
    @Size(max = 255, message = "common.validation")
    private String title;

    private String description;

    @NotNull(message = "common.field_required")
    @PositiveOrZero(message = "common.validation")
    private Integer orderIndex;

    private Boolean isHidden = Boolean.FALSE;

    private Boolean isOptional = Boolean.FALSE;

    private Map<String, Object> contentData;
}
