package com.lucy.api.modules.commerce.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.commerce.entity.enums.LearningEntitlementSourceType;
import com.lucy.api.modules.commerce.entity.enums.LearningEntitlementStatus;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.lms.entity.CourseRun;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(
        name = "learning_entitlements",
        uniqueConstraints = @UniqueConstraint(
                name = "learning_entitlements_user_run_source_key",
                columnNames = {"user_id", "course_run_id", "source_type", "source_ref_id"}
        )
)
public class LearningEntitlement extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "course_run_id", nullable = false)
    CourseRun courseRun;

    @Enumerated(EnumType.STRING)
    @Column(name = "source_type", nullable = false, length = 30)
    LearningEntitlementSourceType sourceType;

    @Column(name = "source_ref_id", nullable = false, length = 36)
    String sourceRefId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    LearningEntitlementStatus status = LearningEntitlementStatus.ACTIVE;
}
