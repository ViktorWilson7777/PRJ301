package com.lucy.api.modules.lms.progress.enums;

public enum LessonProgressStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}

