package com.lucy.api.modules.event.service;

import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessageType;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@RequiredArgsConstructor
public class RoomRealtimePublisher {
    private final SimpMessagingTemplate messagingTemplate;

    public void publishParticipants(UUID roomId, Object payload) {
        messagingTemplate.convertAndSend("/topic/room/" + roomId + "/participants", payload);
    }

    public void publishChat(UUID roomId, Object payload) {
        messagingTemplate.convertAndSend("/topic/room/" + roomId + "/chat", payload);
    }

    public void publishErrorToUserSession(String userId, String sessionId, Object payload) {
        SimpMessageHeaderAccessor accessor = SimpMessageHeaderAccessor.create(SimpMessageType.MESSAGE);
        accessor.setSessionId(sessionId);
        accessor.setLeaveMutable(true);

        messagingTemplate.convertAndSendToUser(userId, "/queue/errors", payload, accessor.getMessageHeaders());
        messagingTemplate.convertAndSend("/queue/errors-user" + sessionId, payload);
    }
}
