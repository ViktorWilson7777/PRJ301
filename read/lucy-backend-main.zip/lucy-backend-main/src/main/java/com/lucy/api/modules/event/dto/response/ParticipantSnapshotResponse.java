package com.lucy.api.modules.event.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ParticipantSnapshotResponse {
    private UUID roomId;
    private int totalParticipants;
    private List<ParticipantResponse> participants;
    private Instant generatedAt;
}
