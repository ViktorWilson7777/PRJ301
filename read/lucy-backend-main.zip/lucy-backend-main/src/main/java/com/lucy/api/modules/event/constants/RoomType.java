package com.lucy.api.modules.event.constants;

public final class RoomType {
    public static final String EVENT = "event";

    private RoomType() {
    }
}
