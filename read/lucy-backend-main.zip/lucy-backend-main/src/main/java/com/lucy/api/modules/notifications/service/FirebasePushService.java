package com.lucy.api.modules.notifications.service;

import com.google.firebase.messaging.*;
import com.lucy.api.modules.notifications.repository.UserDeviceRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class FirebasePushService {

    private static final Logger logger = LoggerFactory.getLogger(FirebasePushService.class);
    private static final int FCM_BATCH_LIMIT = 500;

    private final UserDeviceRepository userDeviceRepository;

    @Value("${zenleader.fcm.enabled:true}")
    private boolean fcmEnabled;

    public void sendMulticastPush(List<String> deviceTokens, String title, String body, String eventId) {
        Map<String, String> data = new HashMap<>();
        data.put("eventId", eventId != null ? eventId : "");
        sendMulticastPushWithDataAndTag(deviceTokens, title, body, data, null);
    }

    public void sendMulticastPushWithData(
            List<String> deviceTokens,
            String title,
            String body,
            Map<String, String> data
    ) {
        sendMulticastPushWithDataAndTag(deviceTokens, title, body, data, null);
    }

    public void sendMulticastPushWithDataAndTag(
            List<String> deviceTokens,
            String title,
            String body,
            Map<String, String> data,
            String notificationTag
    ) {
        if (!fcmEnabled) {
            logger.debug("[FCM] Skipped (zenleader.fcm.enabled=false).");
            return;
        }
        if (deviceTokens == null || deviceTokens.isEmpty()) {
            return;
        }

        Notification notification = Notification.builder()
                .setTitle(title)
                .setBody(body)
                .build();

        AndroidConfig androidConfig = AndroidConfig.builder()
                .setPriority(AndroidConfig.Priority.HIGH)
                .setNotification(AndroidNotification.builder()
                        .setSound("default")
                        .setClickAction("FLUTTER_NOTIFICATION_CLICK")
                        .setTag(notificationTag)
                        .build())
                .build();

        // Chia nhỏ thành các batch tối đa 500 token/lần (giới hạn của Firebase)
        List<List<String>> batches = partitionList(deviceTokens, FCM_BATCH_LIMIT);

        for (int batchIndex = 0; batchIndex < batches.size(); batchIndex++) {
            List<String> batch = batches.get(batchIndex);

            MulticastMessage message = MulticastMessage.builder()
                    .addAllTokens(batch)
                    .setNotification(notification)
                    .setAndroidConfig(androidConfig)
                    .putAllData(data != null ? data : Map.of())
                    .build();

            try {
                BatchResponse response = FirebaseMessaging.getInstance().sendEachForMulticast(message);
                logger.info("[FCM] Batch {}/{}: Sent to {} token(s). Success: {}, Fail: {}",
                        batchIndex + 1, batches.size(),
                        batch.size(), response.getSuccessCount(), response.getFailureCount());

                // Tự động dọn rác: xóa các token bị Firebase báo UNREGISTERED
                if (response.getFailureCount() > 0) {
                    List<String> staleTokens = new ArrayList<>();
                    List<SendResponse> responses = response.getResponses();

                    for (int i = 0; i < responses.size(); i++) {
                        if (!responses.get(i).isSuccessful()) {
                            FirebaseMessagingException ex = responses.get(i).getException();
                            MessagingErrorCode code = ex.getMessagingErrorCode();

                            if (code == MessagingErrorCode.UNREGISTERED) {
                                staleTokens.add(batch.get(i));
                            } else {
                                logger.error("[FCM] Token failed. Code: {} | Error: {}", code, ex.getMessage());
                            }
                        }
                    }

                    if (!staleTokens.isEmpty()) {
                        userDeviceRepository.deleteAllByDeviceTokenIn(staleTokens);
                        logger.info("[FCM] Cleaned up {} stale/unregistered token(s).", staleTokens.size());
                    }
                }
            } catch (Exception e) {
                logger.error("[FCM] Fatal error sending batch {}/{}", batchIndex + 1, batches.size(), e);
            }
        }
    }

    /** Chia list lớn thành nhiều list nhỏ theo kích thước cho trước */
    private <T> List<List<T>> partitionList(List<T> list, int size) {
        List<List<T>> partitions = new ArrayList<>();
        for (int i = 0; i < list.size(); i += size) {
            partitions.add(list.subList(i, Math.min(i + size, list.size())));
        }
        return partitions;
    }
}
