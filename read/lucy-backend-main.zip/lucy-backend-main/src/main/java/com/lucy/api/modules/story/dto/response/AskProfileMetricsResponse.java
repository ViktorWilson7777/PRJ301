package com.lucy.api.modules.story.dto.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AskProfileMetricsResponse {
    Integer attitudeScore;
    /** Điểm consistency để hiển thị tab Attitude. */
    Integer consistencyScore;
    /** Điểm motivation để hiển thị tab Attitude. */
    Integer motivationScore;
    /** Điểm focus để hiển thị tab Attitude. */
    Integer focusScore;
    /** Tổng phút nói (speaker) trong room đã cộng cho ASK — dùng để tính level. */
    Integer skillsScore;
    Integer knowledgeScore;
    String bio;
    /** Level ASK (1+), tính từ tổng phút nói và bậc thang phút/level. */
    Integer askLevel;
    /** Phút đã tích hướng tới level tiếp theo (0 … minutesRequiredForNextLevel − 1). */
    Integer speakingMinutesProgress;
    /** Phút cần thêm để lên đúng 1 level kể từ askLevel hiện tại. */
    Integer minutesRequiredForNextLevel;
}
