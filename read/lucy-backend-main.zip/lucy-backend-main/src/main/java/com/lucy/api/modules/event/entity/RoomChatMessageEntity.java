package com.lucy.api.modules.event.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "room_chat_messages")
public class RoomChatMessageEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(updatable = false, columnDefinition = "uuid")
    UUID id;

    @Column(name = "room_id", nullable = false, columnDefinition = "uuid")
    UUID roomId;

    @Column(name = "sender_id", nullable = false, columnDefinition = "uuid")
    UUID senderId;

    @Column(nullable = false)
    String content;

    @Column(name = "message_type", nullable = false)
    String messageType;

    @Column(name = "created_at")
    Instant createdAt;

    @Column(name = "deleted_at")
    Instant deletedAt;

    @PrePersist
    void prePersist() {
        if (this.createdAt == null) {
            this.createdAt = Instant.now();
        }
        if (this.messageType == null) {
            this.messageType = "text";
        }
    }
}
