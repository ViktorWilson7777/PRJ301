package com.lucy.api.infrastructure.websocket.config;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "app.websocket.netty")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WebSocketNettyProperties {
    boolean enabled = true;
    int port = 8081;
    String path = "/ws-netty";
    int maxFrameSize = 65536;
    long pingInterval = 30000L;
    long sessionTimeout = 3600000L;
}
