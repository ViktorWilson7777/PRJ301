package com.lucy.api.modules.story.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.event.service.EventAuthContextService;
import com.lucy.api.modules.story.dto.response.ProfileResponse;
import com.lucy.api.modules.story.dto.response.UserFollowListResponse;
import com.lucy.api.modules.story.dto.response.UserStatsResponse;
import com.lucy.api.modules.story.service.ProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserProfileController {
    private final ProfileService profileService;
    private final EventAuthContextService eventAuthContextService;

    @GetMapping("/{userIdentifier}/profile")
    public ResponseEntity<ApiResponse<ProfileResponse>> getUserProfile(@PathVariable String userIdentifier) {
        return ResponseEntity.ok(ApiResponse.<ProfileResponse>builder()
                .success(true)
                .data(profileService.getProfileByIdentifier(userIdentifier))
                .build());
    }

    @PostMapping("/{userId}/follow")
    public ResponseEntity<ApiResponse<Object>> followUser(@PathVariable UUID userId,
                                                          @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        profileService.followUser(currentUserId, userId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @DeleteMapping("/{userId}/follow")
    public ResponseEntity<ApiResponse<Object>> unfollowUser(@PathVariable UUID userId,
                                                            @AuthenticationPrincipal Jwt jwt) {
        UUID currentUserId = eventAuthContextService.requireUserId(jwt);
        profileService.unfollowUser(currentUserId, userId);
        return ResponseEntity.ok(ApiResponse.builder().success(true).build());
    }

    @GetMapping("/{userId}/followers")
    public ResponseEntity<ApiResponse<UserFollowListResponse>> listFollowers(@PathVariable UUID userId,
                                                                              @RequestParam(required = false) String cursor,
                                                                              @RequestParam(required = false) Integer limit) {
        return ResponseEntity.ok(ApiResponse.<UserFollowListResponse>builder()
                .success(true)
                .data(profileService.listFollowers(userId, cursor, limit))
                .build());
    }

    @GetMapping("/{userId}/following")
    public ResponseEntity<ApiResponse<UserFollowListResponse>> listFollowing(@PathVariable UUID userId,
                                                                              @RequestParam(required = false) String cursor,
                                                                              @RequestParam(required = false) Integer limit) {
        return ResponseEntity.ok(ApiResponse.<UserFollowListResponse>builder()
                .success(true)
                .data(profileService.listFollowing(userId, cursor, limit))
                .build());
    }

    @GetMapping("/{userId}/stats")
    public ResponseEntity<ApiResponse<UserStatsResponse>> getUserStats(@PathVariable UUID userId) {
        return ResponseEntity.ok(ApiResponse.<UserStatsResponse>builder()
                .success(true)
                .data(profileService.getUserStats(userId))
                .build());
    }
}
