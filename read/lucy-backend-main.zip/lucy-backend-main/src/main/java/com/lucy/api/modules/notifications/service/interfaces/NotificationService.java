package com.lucy.api.modules.notifications.service.interfaces;

import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.notifications.dtos.response.NotificationResponse;

import java.util.List;

public interface NotificationService {
    void createNotification(User user, String title, String message, String type);
    void createNotification(User user, String title, String message, String type, String conversationId, String payload);

    List<NotificationResponse> getMyNotifications(String userId);

    void markAsRead(String notificationId);

    void markAllAsRead(String userId);

    long countUnreadNotifications(String userId);
}
