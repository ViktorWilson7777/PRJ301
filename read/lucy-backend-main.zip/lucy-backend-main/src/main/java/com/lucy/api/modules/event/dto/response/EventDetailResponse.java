package com.lucy.api.modules.event.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EventDetailResponse {
    UUID id;
    String title;
    String description;
    String topic;
    String category;
    String level;
    String status;
    Instant eventDatetime;
    String location;
    Integer maxParticipants;
    Integer interestedCount;
    Integer likesCount;
    Integer commentsCount;
    UUID monitorId;
    Instant startedAt;
    Integer participantCount;
    Boolean isLiked;
    Boolean isInterested;
}
