package com.lucy.api.modules.event.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Response DTO for microphone status changes
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MicStatusResponse {
    private UUID roomId;
    private UUID userId;
    private String displayName;
    private boolean micEnabled;
}
