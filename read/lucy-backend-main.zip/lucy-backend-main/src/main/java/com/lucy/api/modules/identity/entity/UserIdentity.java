package com.lucy.api.modules.identity.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.constants.user.UserConstants;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = UserConstants.TABLE_USER_IDENTITIES, uniqueConstraints = {
        @UniqueConstraint(columnNames = {UserConstants.COL_PROVIDER, UserConstants.COL_PROVIDER_USER_ID})
})
public class UserIdentity extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = UserConstants.COL_USER_ID, nullable = false)
    User user;

    @Column(name = UserConstants.COL_PROVIDER, nullable = false, length = 50)
    String provider;

    @Column(name = UserConstants.COL_PROVIDER_USER_ID, nullable = false)
    String providerUserId;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = UserConstants.COL_PROVIDER_DATA, columnDefinition = UserConstants.JSONB_DEFINITION)
    @Builder.Default
    Map<String, Object> providerData = new HashMap<>();

    @Column(name = UserConstants.COL_LAST_SIGN_IN_AT)
    Instant lastSignInAt;
}
