package com.lucy.api.modules.lms.mapper;

import com.lucy.api.modules.lms.dto.request.EnrollmentUpdateRequest;
import com.lucy.api.modules.lms.dto.response.EnrollmentResponse;
import com.lucy.api.modules.lms.entity.Enrollment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(
    componentModel = "spring",
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
)
public interface EnrollmentMapper {

    @Mapping(target = "userId",          expression = "java(enrollment.getUser().getId())")
    @Mapping(target = "userDisplayName", source = "user.profile.displayName")
    @Mapping(target = "userEmail",       source = "user.email")
    @Mapping(target = "userAvatarUrl",   source = "user.profile.avatarUrl")
    @Mapping(target = "courseRunId",     source = "courseRun.id")
    @Mapping(target = "courseRunCode",   source = "courseRun.code")
    @Mapping(target = "organizationId",  source = "organization.id")
    EnrollmentResponse toResponse(Enrollment enrollment);

    /**
     * Partially update an existing Enrollment from an update request.
     * Null values in the request are ignored (IGNORE strategy above).
     */
    @Mapping(target = "id",          ignore = true)
    @Mapping(target = "version",     ignore = true)
    @Mapping(target = "createdAt",   ignore = true)
    @Mapping(target = "updatedAt",   ignore = true)
    @Mapping(target = "user",        ignore = true)
    @Mapping(target = "courseRun",   ignore = true)
    @Mapping(target = "organization", ignore = true)
    @Mapping(target = "accessScope", ignore = true)
    @Mapping(target = "enrolledAt",  ignore = true)
    @Mapping(target = "progressPercent", ignore = true)
    void updateEntity(@MappingTarget Enrollment enrollment, EnrollmentUpdateRequest request);
}
