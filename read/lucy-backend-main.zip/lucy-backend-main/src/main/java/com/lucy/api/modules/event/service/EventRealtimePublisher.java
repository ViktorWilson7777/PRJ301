package com.lucy.api.modules.event.service;

import com.lucy.api.modules.event.dto.realtime.CommentCreatedData;
import com.lucy.api.modules.event.dto.realtime.HandStatusChangedData;
import com.lucy.api.modules.event.dto.realtime.InterestUpdatedData;
import com.lucy.api.modules.event.dto.realtime.LikeUpdatedData;
import com.lucy.api.modules.event.dto.realtime.MicToggledData;
import com.lucy.api.modules.event.dto.realtime.ParticipantChangedData;
import com.lucy.api.modules.event.dto.realtime.RealtimeMessage;
import com.lucy.api.modules.event.dto.realtime.RealtimeMessageType;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class EventRealtimePublisher {
    private final SimpMessagingTemplate messagingTemplate;

    public void publishLikeUpdated(UUID eventId, UUID actorUserId, boolean liked, long likesCount) {
        RealtimeMessage message = new RealtimeMessage(
                RealtimeMessageType.LIKE_UPDATED,
                eventId,
                eventId,
                actorUserId,
                Instant.now(),
                new LikeUpdatedData(liked, likesCount)
        );
        sendToEventTopics(eventId, message);
    }

    public void publishInterestUpdated(UUID eventId, UUID actorUserId, boolean interested, long interestedCount) {
        RealtimeMessage message = new RealtimeMessage(
                RealtimeMessageType.INTEREST_UPDATED,
                eventId,
                eventId,
                actorUserId,
                Instant.now(),
                new InterestUpdatedData(interested, interestedCount)
        );
        sendToEventTopics(eventId, message);
    }

    public void publishCommentCreated(UUID eventId,
                                      UUID actorUserId,
                                      UUID commentId,
                                      String content,
                                      Instant createdAt,
                                      long commentsCount) {
        RealtimeMessage message = new RealtimeMessage(
                RealtimeMessageType.COMMENT_CREATED,
                eventId,
                eventId,
                actorUserId,
                Instant.now(),
                new CommentCreatedData(commentId, content, createdAt, commentsCount)
        );
        sendToEventTopics(eventId, message);
    }

    public void publishParticipantJoined(UUID roomId, UUID actorUserId, long participantCount) {
        RealtimeMessage message = new RealtimeMessage(
                RealtimeMessageType.PARTICIPANT_JOINED,
                roomId,
                roomId,
                actorUserId,
                Instant.now(),
                new ParticipantChangedData(participantCount)
        );
        sendToParticipantTopics(roomId, message);
    }

    public void publishParticipantLeft(UUID roomId, UUID actorUserId, long participantCount) {
        RealtimeMessage message = new RealtimeMessage(
                RealtimeMessageType.PARTICIPANT_LEFT,
                roomId,
                roomId,
                actorUserId,
                Instant.now(),
                new ParticipantChangedData(participantCount)
        );
        sendToParticipantTopics(roomId, message);
    }

    public void publishMicToggled(UUID roomId, UUID actorUserId, boolean enabled) {
        RealtimeMessage message = new RealtimeMessage(
                RealtimeMessageType.MIC_TOGGLED,
                roomId,
                roomId,
                actorUserId,
                Instant.now(),
                new MicToggledData(enabled)
        );
        sendToParticipantTopics(roomId, message);
    }

    public void publishHandStatusChanged(UUID roomId, UUID actorUserId, boolean raised, int handCount) {
        RealtimeMessage message = new RealtimeMessage(
                RealtimeMessageType.HAND_STATUS_CHANGED,
                roomId,
                roomId,
                actorUserId,
                Instant.now(),
                new HandStatusChangedData(raised, handCount)
        );
        sendToParticipantTopics(roomId, message);
    }

    private String eventTopic(UUID eventId) {
        return "/topic/events/" + eventId;
    }

    private String legacyEventTopic(UUID eventId) {
        return "/topic/event/" + eventId;
    }

    private String participantTopic(UUID roomId) {
        return "/topic/rooms/" + roomId + "/participants";
    }

    private String legacyParticipantTopic(UUID roomId) {
        return "/topic/room/" + roomId + "/participants";
    }

    private void sendToEventTopics(UUID eventId, RealtimeMessage message) {
        messagingTemplate.convertAndSend(eventTopic(eventId), message);
        messagingTemplate.convertAndSend(legacyEventTopic(eventId), message);
    }

    private void sendToParticipantTopics(UUID roomId, RealtimeMessage message) {
        messagingTemplate.convertAndSend(participantTopic(roomId), message);
        messagingTemplate.convertAndSend(legacyParticipantTopic(roomId), message);
    }
}
