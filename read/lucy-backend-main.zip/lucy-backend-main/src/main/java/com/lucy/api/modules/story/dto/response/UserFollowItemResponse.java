package com.lucy.api.modules.story.dto.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserFollowItemResponse {
    String userId;
    String displayName;
    String avatarUrl;
    Instant followedAt;
}
