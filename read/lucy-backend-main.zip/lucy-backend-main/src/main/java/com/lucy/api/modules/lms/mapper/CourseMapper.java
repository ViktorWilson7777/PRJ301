package com.lucy.api.modules.lms.mapper;

import com.lucy.api.modules.lms.dto.request.CourseUpsertRequest;
import com.lucy.api.modules.lms.dto.response.CourseResponse;
import com.lucy.api.modules.lms.entity.Course;
import com.lucy.api.modules.lms.mapper.CourseRunMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

import java.util.Arrays;
import java.util.List;

@Mapper(componentModel = "spring", uses = {CourseRunMapper.class, MapperUtils.class})
public interface CourseMapper {

    @Mapping(target = "program", ignore = true)
    @Mapping(target = "deletedAt", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "courseRuns", ignore = true)
    @Mapping(target = "organization", ignore = true)
    @Mapping(target = "accessScope", ignore = true)
    @Mapping(target = "code", source = "code", qualifiedByName = "trimValue")
    @Mapping(target = "title", source = "title", qualifiedByName = "trimValue")
    @Mapping(target = "tags", source = "tags", qualifiedByName = "mapTagsToArray")
    Course toEntity(CourseUpsertRequest request);

    @Mapping(target = "program", ignore = true)
    @Mapping(target = "deletedAt", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "courseRuns", ignore = true)
    @Mapping(target = "organization", ignore = true)
    @Mapping(target = "accessScope", ignore = true)
    @Mapping(target = "code", source = "code", qualifiedByName = "trimValue")
    @Mapping(target = "title", source = "title", qualifiedByName = "trimValue")
    @Mapping(target = "tags", source = "tags", qualifiedByName = "mapTagsToArray")
    void updateEntity(@MappingTarget Course course, CourseUpsertRequest request);

    @Mapping(target = "programId", source = "program.id")
    @Mapping(target = "programCode", source = "program.code")
    @Mapping(target = "organizationId", source = "organization.id")
    @Mapping(target = "tags", source = "tags", qualifiedByName = "mapTagsToList")
    CourseResponse toResponse(Course course);

    @Named("mapTagsToArray")
    default String[] mapTagsToArray(List<String> tags) {
        return tags == null ? null : tags.toArray(String[]::new);
    }

    @Named("mapTagsToList")
    default List<String> mapTagsToList(String[] tags) {
        return tags == null ? List.of() : Arrays.asList(tags);
    }
}
