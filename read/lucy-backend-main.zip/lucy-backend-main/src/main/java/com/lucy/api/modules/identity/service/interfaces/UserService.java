package com.lucy.api.modules.identity.service.interfaces;

import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.identity.dtos.request.user.UserCreationRequest;
import com.lucy.api.modules.identity.dtos.response.user.UserResponse;
import com.lucy.api.modules.identity.entity.User;

public interface UserService {

    UserResponse getMe();

    void deleteMe();

    PagingResponse<UserResponse> getUsers(String keyword, PagingRequest pagingRequest);

    UserResponse getById(String id);

    UserResponse create(UserCreationRequest request);

    User getEntityById(String userId);
}

