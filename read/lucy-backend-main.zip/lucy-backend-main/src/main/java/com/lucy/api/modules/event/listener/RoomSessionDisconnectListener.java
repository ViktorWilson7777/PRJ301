package com.lucy.api.modules.event.listener;

import com.lucy.api.common.configs.WebSocketSessionStore;
import com.lucy.api.common.configs.WebSocketSessionState;
import com.lucy.api.modules.event.dto.response.ParticipantResponse;
import com.lucy.api.modules.event.dto.response.ParticipantSnapshotResponse;
import com.lucy.api.modules.event.dto.response.UserLeftResponse;
import com.lucy.api.modules.event.exception.EventApiException;
import com.lucy.api.modules.event.service.EventService;
import com.lucy.api.modules.event.service.RoomRealtimePublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.security.Principal;
import java.time.Instant;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class RoomSessionDisconnectListener {
    private final WebSocketSessionStore webSocketSessionStore;
    private final EventService eventService;
    private final RoomRealtimePublisher realtimePublisher;

    @EventListener
    public void onDisconnect(SessionDisconnectEvent event) {
        WebSocketSessionState sessionState = webSocketSessionStore.removeSession(event.getSessionId());
        Principal principal = sessionState.principal() != null ? sessionState.principal() : event.getUser();
        UUID userId = extractUserId(principal);
        if (userId == null || sessionState.roomIds().isEmpty()) {
            return;
        }

        for (UUID roomId : sessionState.roomIds()) {
            try {
                ParticipantResponse participant = eventService.findParticipantState(roomId, userId)
                        .orElse(null);
                if (participant == null) {
                    continue;
                }

                eventService.leaveEvent(roomId, userId);
                ParticipantSnapshotResponse snapshot = eventService.getParticipantSnapshot(roomId);

                UserLeftResponse response = UserLeftResponse.builder()
                        .roomId(roomId)
                        .userId(userId)
                        .displayName(participant.getDisplayName())
                        .reason("disconnect")
                        .leftAt(Instant.now())
                        .totalParticipants(snapshot.getTotalParticipants())
                        .build();

                realtimePublisher.publishParticipants(roomId, response);
                log.info("Cleaned up disconnected session for user {} in room {}", userId, roomId);
            } catch (EventApiException ex) {
                if (ex.getStatus() != HttpStatus.NOT_FOUND) {
                    log.warn("Failed to cleanup disconnected user {} in room {}: {}", userId, roomId, ex.getMessage());
                }
            } catch (Exception ex) {
                log.warn("Unexpected disconnect cleanup error for user {} in room {}: {}", userId, roomId, ex.getMessage());
            }
        }
    }

    private UUID extractUserId(Principal principal) {
        if (principal == null || !StringUtils.hasText(principal.getName())) {
            return null;
        }

        try {
            return UUID.fromString(principal.getName());
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }
}
