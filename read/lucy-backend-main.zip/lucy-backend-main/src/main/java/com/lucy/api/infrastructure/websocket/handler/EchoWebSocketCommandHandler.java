package com.lucy.api.infrastructure.websocket.handler;

import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketEchoLogConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketFrameTypeConstants;
import com.lucy.api.infrastructure.websocket.enums.WebSocketMessageType;
import com.lucy.api.infrastructure.websocket.utils.WebSocketPayloadCodec;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Handler mẫu: phản hồi {@code ECHO} để kiểm tra pipeline và mở rộng theo pattern module.
 */
@Slf4j
@Component
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class EchoWebSocketCommandHandler implements WebSocketCommandHandler {

    WebSocketPayloadCodec payloadCodec;

    @Override
    public String getType() {
        return WebSocketMessageType.ECHO.name();
    }

    @Override
    @SuppressWarnings("unchecked")
    public void handle(ChannelHandlerContext ctx, String payloadJson, String sessionId) {
        try {
            Map<String, Object> map = payloadCodec.parseMessage(payloadJson, Map.class);
            Object echo = map != null ? map.get(WebSocketConstants.FIELD_ECHO) : null;
            String body = payloadCodec.toJson(Map.of(
                    WebSocketConstants.FIELD_TYPE, WebSocketFrameTypeConstants.ECHO,
                    WebSocketConstants.FIELD_ECHO, echo != null ? echo : "",
                    WebSocketConstants.FIELD_SESSION_ID, sessionId
            ));
            if (body != null) {
                ctx.channel().writeAndFlush(new TextWebSocketFrame(body));
            }
        } catch (Exception e) {
            log.debug(WebSocketEchoLogConstants.ECHO_FAILED, e);
        }
    }
}
