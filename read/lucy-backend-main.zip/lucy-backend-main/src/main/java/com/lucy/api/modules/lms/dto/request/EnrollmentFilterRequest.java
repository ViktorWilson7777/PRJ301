package com.lucy.api.modules.lms.dto.request;

import com.lucy.api.common.constants.PaginationConstant;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.Collections;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EnrollmentFilterRequest {

    @NotBlank(message = "common.field_required")
    String courseRunId;

    @Valid
    List<EnrollmentCondition> conditions = Collections.emptyList();

    @Min(value = 1, message = "common.page_invalid")
    int page = PaginationConstant.MIN_PAGE_NUMBER;

    @Min(value = 1, message = "common.page_size_invalid")
    int pageSize = PaginationConstant.DEFAULT_PAGE_SIZE;
}
