package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.audit.annotation.AuditAction;
import com.lucy.api.modules.audit.constants.AuditActionType;
import com.lucy.api.modules.audit.constants.AuditEntityType;
import com.lucy.api.modules.lms.dto.request.LessonFileUploadRequest;
import com.lucy.api.modules.lms.dto.request.LessonUpsertRequest;
import com.lucy.api.modules.lms.dto.response.LessonFileUploadResponse;
import com.lucy.api.modules.lms.dto.response.LessonResponse;
import com.lucy.api.modules.lms.service.api.LessonService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/lessons")
@Tag(name = "LMS Lessons", description = "CRUD and file upload APIs for LMS lessons")
public class LessonController {
    private final LessonService lessonService;

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Create a new lesson")
    @AuditAction(action = AuditActionType.LESSON_CREATE, entityType = AuditEntityType.LESSON)
    public ResponseEntity<ApiResponse<LessonResponse>> create(@Valid @RequestBody LessonUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.create(request)).build());
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get all lessons, optionally filtered by chapter id")
    public ResponseEntity<ApiResponse<List<LessonResponse>>> findAll(@RequestParam(required = false) String chapterId) {
        return ResponseEntity.ok(ApiResponse.<List<LessonResponse>>builder().success(true).data(lessonService.findAll(chapterId)).build());
    }

    @GetMapping("/{lessonId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Get a lesson by id")
    public ResponseEntity<ApiResponse<LessonResponse>> findById(@PathVariable String lessonId) {
        return ResponseEntity.ok(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.findById(lessonId)).build());
    }

    @PutMapping("/{lessonId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Update a lesson")
    @AuditAction(action = AuditActionType.LESSON_UPDATE, entityType = AuditEntityType.LESSON)
    public ResponseEntity<ApiResponse<LessonResponse>> update(@PathVariable String lessonId, @Valid @RequestBody LessonUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<LessonResponse>builder().success(true).data(lessonService.update(lessonId, request)).build());
    }

    @DeleteMapping("/{lessonId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Delete a lesson")
    @AuditAction(action = AuditActionType.LESSON_DELETE, entityType = AuditEntityType.LESSON)
    public ResponseEntity<ApiResponse<String>> delete(@PathVariable String lessonId) {
        lessonService.delete(lessonId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Lesson deleted successfully").build());
    }

    @PostMapping("/{lessonId}/files")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @Operation(summary = "Upload a file and attach it to a lesson")
    public ResponseEntity<ApiResponse<LessonFileUploadResponse>> uploadFile(
            @PathVariable String lessonId,
            @Valid @ModelAttribute LessonFileUploadRequest request
    ) {
        return ResponseEntity.ok(
                ApiResponse.<LessonFileUploadResponse>builder()
                        .success(true)
                        .data(lessonService.attachFileToLesson(lessonId, request.getFile()))
                        .build()
        );
    }
}
