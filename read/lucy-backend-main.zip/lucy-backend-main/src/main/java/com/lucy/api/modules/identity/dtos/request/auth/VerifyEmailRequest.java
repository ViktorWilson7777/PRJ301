package com.lucy.api.modules.identity.dtos.request.auth;

import jakarta.validation.constraints.NotBlank;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VerifyEmailRequest {

    /** Cùng định danh đăng ký (có thể không phải định dạng email RFC). */
    @NotBlank(message = "{common.field_required}")
    String email;

    @NotBlank(message = "{common.field_required}")
    String otp;
}
