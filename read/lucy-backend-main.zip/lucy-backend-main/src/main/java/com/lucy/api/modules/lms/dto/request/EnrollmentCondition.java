package com.lucy.api.modules.lms.dto.request;

import com.lucy.api.modules.lms.dto.request.enums.FilterField;
import com.lucy.api.modules.lms.dto.request.enums.MatchMode;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EnrollmentCondition {

    @NotNull(message = "common.field_required")
    MatchMode match;

    @NotNull(message = "common.field_required")
    FilterField field;

    @NotEmpty(message = "common.field_required")
    List<String> values;
}
