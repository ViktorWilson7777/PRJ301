package com.lucy.api.modules.event.dto.realtime;

import java.time.Instant;
import java.util.UUID;

public record RealtimeMessage(
        RealtimeMessageType type,
        UUID eventId,
        UUID roomId,
        UUID actorUserId,
        Instant occurredAt,
        Object data
) {
}
