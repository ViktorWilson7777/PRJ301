package com.lucy.api.modules.livesessions.repository;

import com.lucy.api.modules.livesessions.entity.LiveSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LiveSessionRepository extends JpaRepository<LiveSession, String> {
    Optional<LiveSession> findByRoomCodeAndDeletedAtIsNull(String roomCode);
    List<LiveSession> findByOwnerIdAndDeletedAtIsNull(String ownerId);
    Optional<LiveSession> findByIdAndDeletedAtIsNull(String id);
}

