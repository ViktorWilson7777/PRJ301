package com.lucy.api.modules.event.dto.realtime;

import java.time.Instant;
import java.util.UUID;

public record CommentCreatedData(
        UUID commentId,
        String content,
        Instant createdAt,
        long commentsCount
) {
}
