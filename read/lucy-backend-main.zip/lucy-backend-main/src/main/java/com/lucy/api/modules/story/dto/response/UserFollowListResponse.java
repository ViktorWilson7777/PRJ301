package com.lucy.api.modules.story.dto.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserFollowListResponse {
    List<UserFollowItemResponse> items;
    long total;
    boolean hasMore;
    String nextCursor;
}
