package com.lucy.api.modules.lms.repository;

import com.lucy.api.modules.lms.entity.Chapter;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChapterRepository extends JpaRepository<Chapter, String> {
    List<Chapter> findAllByCourseRun_IdOrderByOrderIndexAscCreatedAtAsc(String courseRunId);
}
