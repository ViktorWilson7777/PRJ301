package com.lucy.api.modules.lms.dto.response;

import com.lucy.api.modules.lms.dto.response.CourseResponse;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ProgramResponse {
    String id;
    String code;
    String title;
    String description;
    String thumbnailUrl;
    Boolean isPublished;
    Instant publishedAt;
    LmsAccessScope accessScope;
    String organizationId;
    String ownerUserId;
    List<CourseResponse> courses;
    Instant createdAt;
    Instant updatedAt;
}
