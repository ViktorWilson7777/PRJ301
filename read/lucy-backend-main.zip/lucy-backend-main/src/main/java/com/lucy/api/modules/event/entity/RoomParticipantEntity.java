package com.lucy.api.modules.event.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "room_participants")
public class RoomParticipantEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(updatable = false, columnDefinition = "uuid")
    UUID id;

    @Column(name = "room_id", nullable = false, columnDefinition = "uuid")
    UUID roomId;

    @Column(name = "user_id", nullable = false, columnDefinition = "uuid")
    UUID userId;

    @Column(name = "is_monitor")
    boolean isMonitor;

    @Column(name = "mic_enabled")
    boolean micEnabled;

    @Column(name = "raise_hand")
    boolean raiseHand;

    @Column(name = "joined_at")
    Instant joinedAt;

    String role;

    @PrePersist
    void prePersist() {
        if (this.joinedAt == null) {
            this.joinedAt = Instant.now();
        }
    }
}
