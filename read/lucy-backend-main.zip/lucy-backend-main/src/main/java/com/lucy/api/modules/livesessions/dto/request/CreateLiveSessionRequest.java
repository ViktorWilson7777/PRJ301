package com.lucy.api.modules.livesessions.dto.request;

import com.lucy.api.modules.livesessions.entity.LiveSessionType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Getter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CreateLiveSessionRequest {

    @NotBlank(message = "Room code is required")
    String roomCode;

    @NotNull(message = "Session type is required")
    LiveSessionType type;

    /** Optional: link to an event. */
    String eventId;

    /** Optional: link to a program. */
    String programId;

    /** Optional: link to a course. */
    String courseId;

    /** Title used when creating the room in Meet service. */
    String title;
}
