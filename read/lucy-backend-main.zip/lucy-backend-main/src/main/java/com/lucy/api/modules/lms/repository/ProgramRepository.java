package com.lucy.api.modules.lms.repository;

import com.lucy.api.modules.lms.entity.Program;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProgramRepository extends JpaRepository<Program, String> {
    boolean existsByCodeIgnoreCase(String code);

    boolean existsByCodeIgnoreCaseAndIdNot(String code, String id);

    boolean existsByCodeIgnoreCaseAndAccessScopeAndOrganizationIsNull(String code, LmsAccessScope accessScope);

    boolean existsByCodeIgnoreCaseAndAccessScopeAndOrganizationIsNullAndIdNot(String code, LmsAccessScope accessScope, String id);

    boolean existsByCodeIgnoreCaseAndOrganization_Id(String code, String organizationId);

    boolean existsByCodeIgnoreCaseAndOrganization_IdAndIdNot(String code, String organizationId, String id);

    List<Program> findAllByDeletedAtIsNullOrderByCreatedAtDesc();

    Optional<Program> findByIdAndDeletedAtIsNull(String id);

    List<Program> findAllByAccessScopeAndDeletedAtIsNullOrderByCreatedAtDesc(LmsAccessScope accessScope);

    List<Program> findAllByOrganization_IdAndDeletedAtIsNullOrderByCreatedAtDesc(String organizationId);
}
