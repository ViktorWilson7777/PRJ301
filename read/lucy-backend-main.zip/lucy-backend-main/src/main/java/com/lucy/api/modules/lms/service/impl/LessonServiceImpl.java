package com.lucy.api.modules.lms.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.cloudinary.dto.StoredFileInfo;
import com.lucy.api.modules.cloudinary.service.api.FileStorageService;
import com.lucy.api.modules.lms.entity.Chapter;
import com.lucy.api.modules.lms.service.api.ChapterService;
import com.lucy.api.modules.lms.dto.request.LessonUpsertRequest;
import com.lucy.api.modules.lms.dto.response.LessonFileAttachmentResponse;
import com.lucy.api.modules.lms.dto.response.LessonFileUploadResponse;
import com.lucy.api.modules.lms.dto.response.LessonResponse;
import com.lucy.api.modules.lms.entity.Lesson;
import com.lucy.api.modules.lms.mapper.LessonMapper;
import com.lucy.api.modules.lms.repository.LessonRepository;
import com.lucy.api.modules.lms.service.api.LessonService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class LessonServiceImpl implements LessonService {
    private static final String FILE_ATTACHMENT_FIELD = "fileAttachment";

    private final LessonRepository lessonRepository;
    private final FileStorageService lessonFileStorageService;
    private final LessonMapper lessonMapper;
    private final ChapterService chapterService;

    public LessonServiceImpl(
            LessonRepository lessonRepository,
            @Qualifier("r2FileStorageServiceImpl") FileStorageService lessonFileStorageService,
            LessonMapper lessonMapper,
            ChapterService chapterService
    ) {
        this.lessonRepository = lessonRepository;
        this.lessonFileStorageService = lessonFileStorageService;
        this.lessonMapper = lessonMapper;
        this.chapterService = chapterService;
    }

    @Override
    @Transactional
    public LessonResponse create(LessonUpsertRequest request) {
        Chapter chapter = chapterService.getEntityById(request.getChapterId());
        Lesson lesson = lessonMapper.toEntity(request);
        lesson.setChapter(chapter);
        lesson.setContentData(normalizeContentData(lesson.getContentData()));
        return lessonMapper.toResponse(lessonRepository.save(lesson));
    }

    @Override
    @Transactional(readOnly = true)
    public List<LessonResponse> findAll(String chapterId) {
        if (chapterId != null) {
            chapterService.getEntityById(chapterId);
        }

        List<Lesson> lessons = chapterId == null
                ? lessonRepository.findAll(Sort.by(Sort.Order.asc("orderIndex"), Sort.Order.desc("createdAt")))
                : lessonRepository.findAllByChapter_IdOrderByOrderIndexAscCreatedAtAsc(chapterId);

        return lessons.stream().map(lessonMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public LessonResponse findById(String lessonId) {
        return lessonMapper.toResponse(getEntityById(lessonId));
    }

    @Override
    @Transactional
    public LessonResponse update(String lessonId, LessonUpsertRequest request) {
        Lesson lesson = getEntityById(lessonId);
        Chapter chapter = chapterService.getEntityById(request.getChapterId());
        lessonMapper.updateEntity(lesson, request);
        lesson.setChapter(chapter);
        lesson.setContentData(normalizeContentData(lesson.getContentData()));
        return lessonMapper.toResponse(lessonRepository.save(lesson));
    }

    @Override
    @Transactional
    public void delete(String lessonId) {
        lessonRepository.delete(getEntityById(lessonId));
    }

    @Override
    @Transactional
    public LessonFileUploadResponse attachFileToLesson(String lessonId, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new AppException("lms.lesson_file_required", HttpStatus.BAD_REQUEST);
        }

        Lesson lesson = getEntityById(lessonId);
        StoredFileInfo storedFileInfo = lessonFileStorageService.upload(file, "zenleader/lessons/" + lessonId);

        Map<String, Object> contentData = ensureContentData(lesson.getContentData());
        contentData.put(FILE_ATTACHMENT_FIELD, buildAttachmentData(storedFileInfo));
        lesson.setContentData(contentData);

        Lesson savedLesson = lessonRepository.save(lesson);
        LessonFileAttachmentResponse attachment = lessonMapper.toAttachmentResponse(storedFileInfo);
        return lessonMapper.toFileUploadResponse(savedLesson.getId(), attachment);
    }

    @Override
    @Transactional(readOnly = true)
    public Lesson getEntityById(String lessonId) {
        return lessonRepository.findById(lessonId)
                .orElseThrow(() -> new AppException("lms.lesson_not_found", HttpStatus.NOT_FOUND));
    }

    private Map<String, Object> ensureContentData(Map<String, Object> contentData) {
        return contentData == null ? new LinkedHashMap<>() : new LinkedHashMap<>(contentData);
    }

    private Map<String, Object> normalizeContentData(Map<String, Object> contentData) {
        return contentData == null ? new LinkedHashMap<>() : contentData;
    }

    private Map<String, Object> buildAttachmentData(StoredFileInfo storedFileInfo) {
        Map<String, Object> attachment = new LinkedHashMap<>();
        attachment.put("provider", storedFileInfo.getProvider());
        attachment.put("fileName", storedFileInfo.getFileName());
        attachment.put("mimeType", storedFileInfo.getMimeType());
        attachment.put("size", storedFileInfo.getSize());
        attachment.put("url", storedFileInfo.getUrl());
        attachment.put("publicId", storedFileInfo.getPublicId());
        attachment.put("resourceType", storedFileInfo.getResourceType());
        return attachment;
    }
}
