package com.lucy.api.modules.identity.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.constants.user.UserErrorCodeConstants;
import com.lucy.api.modules.identity.dtos.request.auth.ChangePasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ForgotPasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ResetPasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.VerifyOtpRequest;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.service.interfaces.OtpService;
import com.lucy.api.modules.identity.service.interfaces.PasswordService;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import com.lucy.api.modules.mail.service.interfaces.EmailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class PasswordServiceImpl implements PasswordService {
    private final UserRepository userRepository;
    private final com.lucy.api.modules.identity.repository.SessionRepository sessionRepository;
    private final OtpService otpService;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void forgotPassword(ForgotPasswordRequest request) {
        // Verify user exists
        User user = userRepository.findByEmailAndDeletedAtIsNull(request.getEmail())
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));

        // Generate OTP and store in Redis
        String otp = otpService.generateAndStoreOtp(user.getEmail());

        // Send OTP email (async)
        emailService.sendOtpEmail(user.getEmail(), otp);

        log.info("Forgot password OTP sent for email: {}", user.getEmail());
    }

    @Override
    public void verifyOtp(VerifyOtpRequest request) {
        boolean isValid = otpService.verifyOtp(request.getEmail(), request.getOtp());
        if (!isValid) {
            throw new AppException(UserErrorCodeConstants.AUTH_INVALID_OTP, HttpStatus.BAD_REQUEST);
        }
    }

    @Override
    @Transactional
    public void resetPassword(ResetPasswordRequest request) {
        boolean isValid = otpService.verifyOtp(request.getEmail(), request.getOtp());
        if (!isValid) {
            throw new AppException(UserErrorCodeConstants.AUTH_INVALID_OTP, HttpStatus.BAD_REQUEST);
        }

        User user = userRepository.findByEmailAndDeletedAtIsNull(request.getEmail())
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));

        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);

        // Revoke all sessions
        revokeAllSessions(user);

        otpService.deleteOtp(request.getEmail());

        log.info("Password reset successfully for email: {}", request.getEmail());
    }

    @Override
    @Transactional
    public void changePassword(ChangePasswordRequest request) {
        String userId = IdentityUtils.getCurrentUserId();
        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException(UserErrorCodeConstants.AUTH_USER_NOT_EXISTED, HttpStatus.NOT_FOUND));

        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPasswordHash())) {
            throw new AppException(UserErrorCodeConstants.AUTH_WRONG_PASSWORD, HttpStatus.BAD_REQUEST);
        }

        if (passwordEncoder.matches(request.getNewPassword(), user.getPasswordHash())) {
            throw new AppException(UserErrorCodeConstants.AUTH_PASSWORD_SAME, HttpStatus.BAD_REQUEST);
        }

        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);

        // Revoke all sessions
        revokeAllSessions(user);

        log.info("Password changed successfully for user: {}", userId);
    }

    private void revokeAllSessions(User user) {
        java.util.List<com.lucy.api.modules.identity.entity.Session> sessions = 
            sessionRepository.findAllByUserAndRevokedAtIsNull(user);
        
        if (!sessions.isEmpty()) {
            sessions.forEach(session -> session.setRevokedAt(java.time.Instant.now()));
            sessionRepository.saveAll(sessions);
        }
    }
}
