package com.lucy.api.modules.lms.service.api;

import com.lucy.api.modules.lms.dto.request.ChapterUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.entity.Chapter;

import java.util.List;

public interface ChapterService {
    ChapterResponse create(ChapterUpsertRequest request);
    List<ChapterResponse> findAll(String courseRunId);
    ChapterResponse findById(String chapterId);
    ChapterResponse update(String chapterId, ChapterUpsertRequest request);
    void delete(String chapterId);
    Chapter getEntityById(String chapterId);
}
