package com.lucy.api.modules.audit.service.api;

import com.lucy.api.modules.audit.dto.request.AuditLogMessage;
import com.lucy.api.modules.audit.dto.request.AuditLogSearchRequest;
import com.lucy.api.modules.audit.dto.response.AuditLogResponse;
import org.springframework.data.domain.Page;

public interface AuditLogService {
    /**
     * Persist an audit entry asynchronously.
     *
     * @param message DTO containing all necessary audit fields.
     */
    void log(AuditLogMessage message);

    /**
     * Get paginated and filtered audit logs.
     *
     * @param searchRequest Filtering and pagination parameters.
     * @return Paginated list of audit logs.
     */
    Page<AuditLogResponse> getAuditLogs(AuditLogSearchRequest searchRequest);
}
