package com.lucy.api.modules.relationship.dtos.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FriendRequestCreateRequest {

    @NotBlank(message = "common.field_required")
    String targetUserId;
}
