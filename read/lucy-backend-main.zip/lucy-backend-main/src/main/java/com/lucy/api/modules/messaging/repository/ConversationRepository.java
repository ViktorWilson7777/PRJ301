package com.lucy.api.modules.messaging.repository;

import com.lucy.api.modules.messaging.entity.Conversation;
import com.lucy.api.modules.messaging.enums.ConversationMode;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ConversationRepository extends JpaRepository<Conversation, String> {

    Optional<Conversation> findByCourseRun_IdAndMode(String courseRunId, ConversationMode mode);
    Optional<Conversation> findByRoomIdAndMode(String roomId, ConversationMode mode);

    Optional<Conversation> findByDirectKey(String directKey);
}
