package com.lucy.api.modules.relationship.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.relationship.constants.RelationshipConstants;
import com.lucy.api.modules.relationship.enums.RelationshipStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = RelationshipConstants.TABLE_RELATIONSHIPS)
public class Relationship extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "requester_id", nullable = false)
    User requester;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "addressee_id", nullable = false)
    User addressee;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    RelationshipStatus status;

    @Column(name = "requested_at", nullable = false)
    Instant requestedAt;

    @Column(name = "responded_at")
    Instant respondedAt;
}
