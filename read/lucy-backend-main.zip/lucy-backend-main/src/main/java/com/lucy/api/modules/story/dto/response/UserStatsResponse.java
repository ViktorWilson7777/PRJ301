package com.lucy.api.modules.story.dto.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserStatsResponse {
    long followers;
    long following;
    long totalEventsCreated;
    AskProfileMetricsResponse askProfile;
}
