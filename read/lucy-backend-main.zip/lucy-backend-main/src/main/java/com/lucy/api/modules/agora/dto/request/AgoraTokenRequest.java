package com.lucy.api.modules.agora.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AgoraTokenRequest {

    @NotBlank(message = "channelId invalid")
    @Pattern(regexp = "^[a-zA-Z0-9_]{1,64}$", message = "channelId invalid")
    @JsonProperty("channelId")
    String channelId;

    @Min(value = 0, message = "uid invalid")
    @NotNull(message = "uid invalid")
    @JsonProperty("uid")
    Integer uid;
}
