package com.lucy.api.modules.messaging.service.domain;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.lms.entity.enums.EnrollmentStatus;
import com.lucy.api.modules.lms.repository.EnrollmentRepository;
import com.lucy.api.modules.messaging.constant.MessagingCourseRunConstants;
import com.lucy.api.modules.messaging.constant.MessagingErrorKeys;
import com.lucy.api.modules.messaging.dto.request.AttachmentRequest;
import com.lucy.api.modules.messaging.entity.ChatAttachment;
import com.lucy.api.modules.messaging.entity.ChatMessage;
import com.lucy.api.modules.messaging.entity.Conversation;
import com.lucy.api.modules.messaging.enums.ConversationMode;
import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import com.lucy.api.modules.messaging.repository.ChatMessageRepository;
import com.lucy.api.modules.messaging.repository.ConversationParticipantRepository;
import com.lucy.api.modules.messaging.repository.ConversationRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Objects;

/**
 * Domain: quyền gửi/sửa tin (participant ACTIVE + enrollment GROUP), persist entity — không DTO, không WebSocket.
 */
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ChatMessageDomainService {

    ChatMessageRepository chatMessageRepository;
    ConversationRepository conversationRepository;
    ConversationParticipantRepository conversationParticipantRepository;
    EnrollmentRepository enrollmentRepository;
    UserRepository userRepository;

    @Transactional
    public ChatMessage createAndSaveMessage(
            String conversationId,
            String senderUserId,
            String text,
            List<AttachmentRequest> attachments,
            String replyToMessageId
    ) {
        User sender = userRepository.findByIdAndDeletedAtIsNull(senderUserId)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.NOT_FOUND));

        Conversation conversation = conversationRepository.findById(conversationId)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.CONVERSATION_NOT_FOUND, HttpStatus.NOT_FOUND));

        assertCanSend(conversation, senderUserId);

        boolean hasText = text != null && !text.trim().isEmpty();
        boolean hasAttachments = attachments != null && !attachments.isEmpty();
        if (!hasText && !hasAttachments) {
            throw new AppException(MessagingErrorKeys.EMPTY_MESSAGE, HttpStatus.BAD_REQUEST);
        }

        if (StringUtils.hasText(replyToMessageId)) {
            ChatMessage replied = chatMessageRepository.findById(replyToMessageId.trim())
                    .orElseThrow(() -> new AppException(MessagingErrorKeys.MESSAGE_NOT_FOUND, HttpStatus.NOT_FOUND));
            if (!conversationId.equals(replied.getConversation().getId())) {
                throw new AppException(MessagingErrorKeys.REPLY_WRONG_CONVERSATION, HttpStatus.BAD_REQUEST);
            }
        }

        var builder = ChatMessage.builder()
                .conversation(conversation)
                .sender(sender)
                .text(text)
                .replyToMessageId(StringUtils.hasText(replyToMessageId) ? replyToMessageId.trim() : null)
                .isEdited(Boolean.FALSE)
                .editCount(0);

        if (hasAttachments) {
            List<ChatAttachment> chatAttachments = attachments.stream()
                    .filter(Objects::nonNull)
                    .map(this::toChatAttachment)
                    .toList();
            builder.attachments(chatAttachments);
        }

        return chatMessageRepository.save(builder.build());
    }

    @Transactional
    public ChatMessage updateMessageText(String messageId, String editorUserId, String newText) {
        ChatMessage chatMessage = chatMessageRepository.findById(messageId)
                .orElseThrow(() -> new AppException(MessagingErrorKeys.MESSAGE_NOT_FOUND, HttpStatus.NOT_FOUND));

        if (chatMessage.getSender() == null || !editorUserId.equals(chatMessage.getSender().getId())) {
            throw new AppException(MessagingErrorKeys.NOT_MESSAGE_SENDER, HttpStatus.FORBIDDEN);
        }

        if (newText == null || newText.trim().isEmpty()) {
            throw new AppException(MessagingErrorKeys.EMPTY_MESSAGE, HttpStatus.BAD_REQUEST);
        }

        chatMessage.setText(newText);
        chatMessage.setIsEdited(Boolean.TRUE);
        chatMessage.setEditCount(chatMessage.getEditCount() == null ? 1 : chatMessage.getEditCount() + 1);

        return chatMessageRepository.save(chatMessage);
    }

    private void assertCanSend(Conversation conversation, String senderUserId) {
        if (!conversationParticipantRepository.existsByConversationIdAndUserIdAndStatus(
                conversation.getId(), senderUserId, ParticipantStatus.ACTIVE)) {
            throw new AppException(MessagingErrorKeys.NOT_PARTICIPANT, HttpStatus.FORBIDDEN);
        }
        if (conversation.getMode() == ConversationMode.GROUP && conversation.getCourseRun() != null) {
            String courseRunId = conversation.getCourseRun().getId();
            if (!enrollmentRepository.existsByUser_IdAndCourseRun_IdAndStatus(
                    senderUserId, courseRunId, EnrollmentStatus.ACTIVE)) {
                throw new AppException(MessagingErrorKeys.ENROLLMENT_REQUIRED, HttpStatus.FORBIDDEN);
            }
            if (conversation.getCourseRun().getDeletedAt() != null) {
                throw new AppException(MessagingErrorKeys.COURSE_RUN_CHAT_NOT_ALLOWED, HttpStatus.UNPROCESSABLE_ENTITY);
            }
            if (!MessagingCourseRunConstants.STATUS_OPEN.equalsIgnoreCase(conversation.getCourseRun().getStatus())) {
                throw new AppException(MessagingErrorKeys.COURSE_RUN_CHAT_NOT_ALLOWED, HttpStatus.UNPROCESSABLE_ENTITY);
            }
        }
    }

    private ChatAttachment toChatAttachment(AttachmentRequest request) {
        return ChatAttachment.builder()
                .type(request.getType())
                .url(request.getUrl())
                .title(request.getTitle())
                .build();
    }
}
