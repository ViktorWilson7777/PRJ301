package com.lucy.api.common.exceptions;

import com.lucy.api.common.dtos.ErrorMessage;
import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.agora.dto.response.AgoraErrorResponse;
import com.lucy.api.modules.agora.exception.AgoraConfigException;
import com.lucy.api.modules.event.exception.EventApiException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import org.springframework.validation.BindException;

import java.util.Map;

@RestControllerAdvice
@Slf4j
@RequiredArgsConstructor
public class GlobalExceptionHandler {

    private final MessageSource messageSource;

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<ApiResponse<Object>> handlingException(Exception exception) {
        log.error("Unhandled Exception: ", exception);
        return buildErrorResponse("common.uncategorized", HttpStatus.INTERNAL_SERVER_ERROR, null);
    }

    @ExceptionHandler(value = AppException.class)
    public ResponseEntity<ApiResponse<Object>> handlingAppException(AppException exception) {
        return buildErrorResponse(exception.getErrorCode(), exception.getHttpStatus(), exception.getParams());
    }

    @ExceptionHandler(value = AccessDeniedException.class)
    public ResponseEntity<ApiResponse<Object>> handlingAccessDeniedException(AccessDeniedException exception) {
        return buildErrorResponse("auth.unauthorized", HttpStatus.FORBIDDEN, null);
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public ResponseEntity<?> handlingMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        if (isAgoraTokenPath(exception)) {
            String message = extractValidationMessage(exception);
            return ResponseEntity.badRequest().body(AgoraErrorResponse.builder()
                    .code("VALIDATION_ERROR")
                    .message(message)
                    .build());
        }

        String errorCode = null;

        if (exception.getFieldError() != null && exception.getFieldError().getDefaultMessage() != null) {
            errorCode = exception.getFieldError().getDefaultMessage();
        } else if (!exception.getBindingResult().getAllErrors().isEmpty()
                && exception.getBindingResult().getAllErrors().getFirst().getDefaultMessage() != null) {
            errorCode = exception.getBindingResult().getAllErrors().getFirst().getDefaultMessage();
        }

        if (errorCode == null) {
            errorCode = "common.validation";
        }

        return buildErrorResponse(errorCode, HttpStatus.BAD_REQUEST, null);
    }

    @ExceptionHandler(value = AgoraConfigException.class)
    public ResponseEntity<AgoraErrorResponse> handlingAgoraConfigException(AgoraConfigException exception) {
        log.error("Agora token config/server error: {}", exception.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(AgoraErrorResponse.builder()
                        .code("INTERNAL_ERROR")
                        .message(exception.getMessage())
                        .build());
    }

    @ExceptionHandler(value = EventApiException.class)
    public ResponseEntity<ApiResponse<Object>> handlingEventApiException(EventApiException exception) {
        ApiResponse<Object> response = ApiResponse.builder()
                .success(false)
                .errorMessage(ErrorMessage.builder()
                        .errorCode(exception.getCode())
                        .message(exception.getMessage())
                        .build())
                .build();
        return ResponseEntity.status(exception.getStatus()).body(response);
    }

    @ExceptionHandler(value = MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ApiResponse<Object>> handlingMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException exception) {
        return buildErrorResponse("common.invalid_param", HttpStatus.BAD_REQUEST, null);
    }

    @ExceptionHandler(value = BindException.class)
    public ResponseEntity<ApiResponse<Object>> handlingBindException(BindException exception) {
        return buildErrorResponse("common.invalid_param", HttpStatus.BAD_REQUEST, null);
    }

    private ResponseEntity<ApiResponse<Object>> buildErrorResponse(String errorCode, HttpStatus status, Map<String, Object> params) {
        String localizedMessage = resolveMessage(errorCode, params);

        ApiResponse<Object> response = ApiResponse.builder()
                .success(false)
                .errorMessage(ErrorMessage.builder()
                        .errorCode(errorCode)
                        .message(localizedMessage)
                        .params(params)
                        .build())
                .build();

        return ResponseEntity.status(status).body(response);
    }

    private String resolveMessage(String key, Map<String, Object> params) {
        try {
            // Note: Map.values().toArray() order is not guaranteed for HashMap/Map.of
            // Consider using LinkedHashMap for params to ensure positional argument consistency
            Object[] args = params != null ? params.values().toArray() : null;
            return messageSource.getMessage(key, args, LocaleContextHolder.getLocale());
        } catch (Exception e) {
            return key;
        }
    }

    private boolean isAgoraTokenPath(MethodArgumentNotValidException exception) {
        return exception.getParameter().getMethod() != null
                && exception.getParameter().getMethod().getDeclaringClass().getSimpleName().equals("AgoraTokenController");
    }

    private String extractValidationMessage(MethodArgumentNotValidException exception) {
        if (exception.getFieldError() != null && exception.getFieldError().getDefaultMessage() != null) {
            return exception.getFieldError().getDefaultMessage();
        }
        return "Invalid request";
    }
}
