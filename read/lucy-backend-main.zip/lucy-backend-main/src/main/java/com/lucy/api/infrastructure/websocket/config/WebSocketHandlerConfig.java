package com.lucy.api.infrastructure.websocket.config;

import com.lucy.api.infrastructure.redis.pubsub.RedisPubSubSubscriptionService;
import com.lucy.api.infrastructure.websocket.handler.WebSocketAuthHandler;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketMessageService;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketNotificationService;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketSessionService;
import com.lucy.api.infrastructure.websocket.utils.WebSocketPayloadCodec;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.jwt.JwtDecoder;

@Configuration
public class WebSocketHandlerConfig {

    @Bean
    public WebSocketAuthHandler webSocketAuthHandler(
            JwtDecoder jwtDecoder,
            WebSocketSessionService sessionService,
            WebSocketMessageService messageService,
            WebSocketNotificationService notificationService,
            RedisPubSubSubscriptionService redisPubSubSubscriptionService,
            WebSocketPayloadCodec payloadCodec,
            MessageSource messageSource
    ) {
        return new WebSocketAuthHandler(
                jwtDecoder,
                sessionService,
                messageService,
                notificationService,
                redisPubSubSubscriptionService,
                payloadCodec,
                messageSource
        );
    }
}
