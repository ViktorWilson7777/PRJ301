package com.lucy.api.infrastructure.websocket.config;

import com.lucy.api.infrastructure.websocket.handler.WebSocketAuthHandler;
import com.lucy.api.infrastructure.websocket.handler.WebSocketCommandHandler;
import com.lucy.api.infrastructure.websocket.handler.WebSocketFrameHandler;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketMessageService;
import com.lucy.api.infrastructure.websocket.utils.WebSocketPayloadCodec;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import jakarta.annotation.PreDestroy;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.websocket.netty.enabled", havingValue = "true", matchIfMissing = true)
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WebSocketNettyConfig implements CommandLineRunner {

    final WebSocketNettyProperties webSocketNettyProperties;
    final WebSocketAuthHandler webSocketAuthHandler;
    final WebSocketMessageService webSocketMessageService;
    final WebSocketPayloadCodec webSocketPayloadCodec;
    final MessageSource messageSource;
    final List<WebSocketCommandHandler> webSocketCommandHandlers;
    final EventLoopGroup bossGroup;
    final EventLoopGroup workerGroup;

    Channel serverChannel;

    public WebSocketNettyConfig(
            WebSocketNettyProperties webSocketNettyProperties,
            WebSocketAuthHandler webSocketAuthHandler,
            WebSocketMessageService webSocketMessageService,
            WebSocketPayloadCodec webSocketPayloadCodec,
            MessageSource messageSource,
            List<WebSocketCommandHandler> webSocketCommandHandlers
    ) {
        this.webSocketNettyProperties = webSocketNettyProperties;
        this.webSocketAuthHandler = webSocketAuthHandler;
        this.webSocketMessageService = webSocketMessageService;
        this.webSocketPayloadCodec = webSocketPayloadCodec;
        this.messageSource = messageSource;
        this.webSocketCommandHandlers = webSocketCommandHandlers;
        this.bossGroup = new NioEventLoopGroup(1);
        this.workerGroup = new NioEventLoopGroup();
        this.serverChannel = null;
    }

    @Override
    public void run(String... args) throws Exception {
        if (!webSocketNettyProperties.isEnabled()) {
            log.info("Netty WebSocket server disabled by configuration");
            return;
        }
        startServer();
    }

    private void startServer() throws InterruptedException {
        ServerBootstrap bootstrap = new ServerBootstrap();
        bootstrap.group(bossGroup, workerGroup)
                .channel(NioServerSocketChannel.class)
                .option(ChannelOption.SO_BACKLOG, 128)
                .childOption(ChannelOption.SO_KEEPALIVE, true)
                .handler(new LoggingHandler(LogLevel.INFO))
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) {
                        ChannelPipeline pipeline = ch.pipeline();
                        pipeline.addLast(new HttpServerCodec());
                        pipeline.addLast(new HttpObjectAggregator(webSocketNettyProperties.getMaxFrameSize()));
                        pipeline.addLast(new WebSocketServerProtocolHandler(
                                webSocketNettyProperties.getPath(),
                                null,
                                true
                        ));
                        pipeline.addLast(new IdleStateHandler(
                                0,
                                0,
                                webSocketNettyProperties.getPingInterval(),
                                TimeUnit.MILLISECONDS
                        ));
                        pipeline.addLast(new WebSocketFrameHandler(
                                webSocketAuthHandler,
                                webSocketMessageService,
                                webSocketPayloadCodec,
                                messageSource,
                                webSocketCommandHandlers
                        ));
                    }
                });

        serverChannel = bootstrap.bind(webSocketNettyProperties.getPort()).sync().channel();
        log.info("WebSocket server started on port: {}", webSocketNettyProperties.getPort());
    }

    @PreDestroy
    public void stopServer() {
        if (serverChannel != null) {
            serverChannel.close();
        }
        bossGroup.shutdownGracefully();
        workerGroup.shutdownGracefully();
        log.info("WebSocket server stopped");
    }
}
