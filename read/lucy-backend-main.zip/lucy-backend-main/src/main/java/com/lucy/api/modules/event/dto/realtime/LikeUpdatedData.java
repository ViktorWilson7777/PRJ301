package com.lucy.api.modules.event.dto.realtime;

public record LikeUpdatedData(
        boolean liked,
        long likesCount
) {
}
