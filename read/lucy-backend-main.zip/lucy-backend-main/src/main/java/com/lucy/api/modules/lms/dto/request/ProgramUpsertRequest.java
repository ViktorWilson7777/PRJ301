package com.lucy.api.modules.lms.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Getter
@Setter
public class ProgramUpsertRequest {
    @NotBlank(message = "common.field_required")
    @Size(max = 100, message = "common.validation")
    private String code;

    @NotBlank(message = "common.field_required")
    @Size(max = 255, message = "common.validation")
    private String title;

    private String description;

    private String thumbnailUrl;

    private Boolean isPublished = Boolean.FALSE;

    private Instant publishedAt;
}
