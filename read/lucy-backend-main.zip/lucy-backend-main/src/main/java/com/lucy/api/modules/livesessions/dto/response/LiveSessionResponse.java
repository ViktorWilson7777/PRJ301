package com.lucy.api.modules.livesessions.dto.response;

import com.lucy.api.modules.livesessions.entity.LiveSession;
import com.lucy.api.modules.livesessions.entity.LiveSessionType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LiveSessionResponse {

    String id;
    String roomCode;
    LiveSessionType type;
    String status;
    String ownerId;
    String eventId;
    String programId;
    String courseId;
    Instant createdAt;
    Instant updatedAt;

    public static LiveSessionResponse fromEntity(LiveSession session) {
        return LiveSessionResponse.builder()
                .id(session.getId())
                .roomCode(session.getRoomCode())
                .type(session.getType())
                .status(session.getStatus())
                .ownerId(session.getOwnerId())
                .eventId(session.getEventId())
                .programId(session.getProgramId())
                .courseId(session.getCourseId())
                .createdAt(session.getCreatedAt())
                .updatedAt(session.getUpdatedAt())
                .build();
    }
}
