package com.lucy.api.modules.lms.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.lms.dto.request.CourseRunUpsertRequest;
import com.lucy.api.modules.lms.dto.response.CourseRunResponse;
import com.lucy.api.modules.lms.entity.Course;
import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.lms.mapper.CourseRunMapper;
import com.lucy.api.modules.lms.repository.CourseRunRepository;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import com.lucy.api.modules.lms.service.api.CourseService;
import com.lucy.api.modules.lms.service.LmsAccessService;
import com.lucy.api.modules.lms.service.PublicCreatorAccessService;
import com.lucy.api.modules.organization.service.OrganizationAccessService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseRunServiceImpl implements CourseRunService {
    private final CourseRunRepository courseRunRepository;
    private final CourseRunMapper courseRunMapper;
    private final CourseService courseService;
    private final OrganizationAccessService organizationAccessService;
    private final LmsAccessService lmsAccessService;
    private final PublicCreatorAccessService publicCreatorAccessService;

    @Override
    @Transactional
    public CourseRunResponse create(CourseRunUpsertRequest request) {
        return createPublic(request);
    }

    @Override
    @Transactional
    public CourseRunResponse createPublic(CourseRunUpsertRequest request) {
        Course course = courseService.getEntityById(request.getCourseId());
        assertPublicCourse(course);
        publicCreatorAccessService.assertCanManagePublicProgram(course.getProgram());
        CourseRun courseRun = courseRunMapper.toEntity(request);
        courseRun.setCourse(course);
        courseRun.setAccessScope(LmsAccessScope.PUBLIC);
        courseRun.setOrganization(null);
        return courseRunMapper.toResponse(courseRunRepository.save(courseRun));
    }

    @Override
    @Transactional
    public CourseRunResponse createForOrganization(String organizationId, CourseRunUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        Course course = courseService.getEntityById(request.getCourseId());
        assertOrganizationCourse(course, organizationId);
        CourseRun courseRun = courseRunMapper.toEntity(request);
        courseRun.setCourse(course);
        courseRun.setAccessScope(LmsAccessScope.ORGANIZATION);
        courseRun.setOrganization(course.getOrganization());
        return courseRunMapper.toResponse(courseRunRepository.save(courseRun));
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseRunResponse> findAll(String courseId) {
        return findAllPublic(courseId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseRunResponse> findAllPublic(String courseId) {
        List<CourseRun> courseRuns = courseId == null
                ? courseRunRepository.findAllByAccessScopeAndDeletedAtIsNull(LmsAccessScope.PUBLIC)
                : courseRunRepository.findAllByCourseId(courseId).stream()
                        .filter(it -> it.getDeletedAt() == null && it.getAccessScope() == LmsAccessScope.PUBLIC)
                        .toList();
        return courseRuns.stream().map(courseRunMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseRunResponse> findAllByOrganization(String organizationId, String courseId) {
        organizationAccessService.assertActiveMembership(organizationId);
        List<CourseRun> courseRuns = courseId == null
                ? courseRunRepository.findAllByOrganization_IdAndDeletedAtIsNull(organizationId).stream()
                        .filter(it -> it.getAccessScope() == LmsAccessScope.ORGANIZATION)
                        .toList()
                : courseRunRepository.findAllByCourseId(courseId).stream()
                        .filter(it -> it.getDeletedAt() == null
                                && it.getAccessScope() == LmsAccessScope.ORGANIZATION
                                && it.getOrganization() != null
                                && organizationId.equals(it.getOrganization().getId()))
                        .toList();
        return courseRuns.stream().map(courseRunMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public CourseRunResponse findById(String courseRunId) {
        return findPublicById(courseRunId);
    }

    @Override
    @Transactional(readOnly = true)
    public CourseRunResponse findPublicById(String courseRunId) {
        CourseRun courseRun = getEntityById(courseRunId);
        if (courseRun.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_course_run_not_found", HttpStatus.NOT_FOUND);
        }
        return courseRunMapper.toResponse(courseRun);
    }

    @Override
    @Transactional(readOnly = true)
    public CourseRunResponse findByOrganizationAndId(String organizationId, String courseRunId) {
        organizationAccessService.assertActiveMembership(organizationId);
        CourseRun courseRun = getEntityById(courseRunId);
        if (courseRun.getAccessScope() != LmsAccessScope.ORGANIZATION
                || courseRun.getOrganization() == null
                || !organizationId.equals(courseRun.getOrganization().getId())) {
            throw new AppException("lms.organization_course_run_not_found", HttpStatus.NOT_FOUND);
        }
        return courseRunMapper.toResponse(courseRun);
    }

    @Override
    @Transactional
    public CourseRunResponse update(String courseRunId, CourseRunUpsertRequest request) {
        return updatePublic(courseRunId, request);
    }

    @Override
    @Transactional
    public CourseRunResponse updatePublic(String courseRunId, CourseRunUpsertRequest request) {
        CourseRun courseRun = getEntityById(courseRunId);
        if (courseRun.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_course_run_not_found", HttpStatus.NOT_FOUND);
        }
        publicCreatorAccessService.assertCanManagePublicProgram(courseRun.getCourse().getProgram());
        Course course = courseService.getEntityById(request.getCourseId());
        assertPublicCourse(course);
        publicCreatorAccessService.assertCanManagePublicProgram(course.getProgram());
        courseRunMapper.updateEntity(courseRun, request);
        courseRun.setCourse(course);
        courseRun.setAccessScope(LmsAccessScope.PUBLIC);
        courseRun.setOrganization(null);
        return courseRunMapper.toResponse(courseRunRepository.save(courseRun));
    }

    @Override
    @Transactional
    public CourseRunResponse updateForOrganization(String organizationId, String courseRunId, CourseRunUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        CourseRun courseRun = getEntityById(courseRunId);
        lmsAccessService.assertCanManageOrganizationCourseRun(courseRun);
        Course course = courseService.getEntityById(request.getCourseId());
        assertOrganizationCourse(course, organizationId);
        courseRunMapper.updateEntity(courseRun, request);
        courseRun.setCourse(course);
        courseRun.setAccessScope(LmsAccessScope.ORGANIZATION);
        courseRun.setOrganization(course.getOrganization());
        return courseRunMapper.toResponse(courseRunRepository.save(courseRun));
    }

    @Override
    @Transactional
    public void delete(String courseRunId) {
        deletePublic(courseRunId);
    }

    @Override
    @Transactional
    public void deletePublic(String courseRunId) {
        CourseRun courseRun = getEntityById(courseRunId);
        if (courseRun.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_course_run_not_found", HttpStatus.NOT_FOUND);
        }
        publicCreatorAccessService.assertCanManagePublicProgram(courseRun.getCourse().getProgram());
        courseRun.setDeletedAt(Instant.now());
        courseRunRepository.save(courseRun);
    }

    @Override
    @Transactional
    public void deleteForOrganization(String organizationId, String courseRunId) {
        organizationAccessService.assertOrganizationRole(
                organizationId,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.OWNER,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.ADMIN,
                com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole.INSTRUCTOR
        );
        CourseRun courseRun = getEntityById(courseRunId);
        if (courseRun.getAccessScope() != LmsAccessScope.ORGANIZATION
                || courseRun.getOrganization() == null
                || !organizationId.equals(courseRun.getOrganization().getId())) {
            throw new AppException("lms.organization_course_run_not_found", HttpStatus.NOT_FOUND);
        }
        courseRun.setDeletedAt(Instant.now());
        courseRunRepository.save(courseRun);
    }

    @Override
    @Transactional(readOnly = true)
    public CourseRun getEntityById(String courseRunId) {
        return courseRunRepository.findByIdAndDeletedAtIsNull(courseRunId)
                .orElseThrow(() -> new AppException("lms.course_run_not_found", HttpStatus.NOT_FOUND));
    }

    private void assertPublicCourse(Course course) {
        if (course.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_course_not_found", HttpStatus.NOT_FOUND);
        }
    }

    private void assertOrganizationCourse(Course course, String organizationId) {
        if (course.getAccessScope() != LmsAccessScope.ORGANIZATION
                || course.getOrganization() == null
                || !organizationId.equals(course.getOrganization().getId())) {
            throw new AppException("lms.organization_course_not_found", HttpStatus.NOT_FOUND);
        }
    }
}
