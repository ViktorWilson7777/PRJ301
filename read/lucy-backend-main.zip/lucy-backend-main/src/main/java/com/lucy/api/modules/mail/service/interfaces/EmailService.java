package com.lucy.api.modules.mail.service.interfaces;

public interface EmailService {

    /**
     * Send an OTP email for password reset
     * @param toEmail recipient email address
     * @param otp the 6-digit OTP code
     */
    void sendOtpEmail(String toEmail, String otp);

    void sendRegistrationOtpEmail(String toEmail, String otp);
}
