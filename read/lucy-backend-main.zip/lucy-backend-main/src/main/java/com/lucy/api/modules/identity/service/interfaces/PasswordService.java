package com.lucy.api.modules.identity.service.interfaces;

import com.lucy.api.modules.identity.dtos.request.auth.ChangePasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ForgotPasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ResetPasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.VerifyOtpRequest;

public interface PasswordService {

    /**
     * Send OTP to user's email for password reset
     * @param request contains the email address
     */
    void forgotPassword(ForgotPasswordRequest request);

    /**
     * Verify if the OTP is valid (pre-check, does not consume the OTP)
     * @param request contains email and OTP
     */
    void verifyOtp(VerifyOtpRequest request);

    /**
     * Reset password using OTP verification
     * @param request contains email, OTP, and new password
     */
    void resetPassword(ResetPasswordRequest request);

    /**
     * Change password for authenticated user
     * @param request contains current password and new password
     */
    void changePassword(ChangePasswordRequest request);
}
