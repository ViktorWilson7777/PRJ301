package com.lucy.api.modules.commerce.service;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.commerce.dto.request.ConfirmPublicOrderPaymentRequest;
import com.lucy.api.modules.commerce.dto.request.CreatePublicOrderRequest;
import com.lucy.api.modules.commerce.dto.request.PublicCourseProductUpsertRequest;
import com.lucy.api.modules.commerce.dto.response.LearningEntitlementResponse;
import com.lucy.api.modules.commerce.dto.response.PublicCourseProductResponse;
import com.lucy.api.modules.commerce.dto.response.PublicOrderItemResponse;
import com.lucy.api.modules.commerce.dto.response.PublicOrderResponse;
import com.lucy.api.modules.commerce.dto.response.PublicPurchaseOfferResponse;
import com.lucy.api.modules.commerce.entity.LearningEntitlement;
import com.lucy.api.modules.commerce.entity.PublicCourseProduct;
import com.lucy.api.modules.commerce.entity.PublicOrder;
import com.lucy.api.modules.commerce.entity.PublicOrderItem;
import com.lucy.api.modules.commerce.entity.enums.LearningEntitlementSourceType;
import com.lucy.api.modules.commerce.entity.enums.LearningEntitlementStatus;
import com.lucy.api.modules.commerce.entity.enums.PublicOrderStatus;
import com.lucy.api.modules.commerce.repository.LearningEntitlementRepository;
import com.lucy.api.modules.commerce.repository.PublicCourseProductRepository;
import com.lucy.api.modules.commerce.repository.PublicOrderItemRepository;
import com.lucy.api.modules.commerce.repository.PublicOrderRepository;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.enums.UserRole;
import com.lucy.api.modules.identity.service.impl.CurrentUserService;
import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.lms.entity.Program;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.lms.service.PublicCreatorAccessService;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PublicCommerceService {
    PublicCourseProductRepository publicCourseProductRepository;
    PublicOrderRepository publicOrderRepository;
    PublicOrderItemRepository publicOrderItemRepository;
    LearningEntitlementRepository learningEntitlementRepository;
    CourseRunService courseRunService;
    CurrentUserService currentUserService;
    PublicCreatorAccessService publicCreatorAccessService;

    @Transactional
    public PublicCourseProductResponse upsertProduct(String courseRunId, PublicCourseProductUpsertRequest request) {
        CourseRun courseRun = courseRunService.getEntityById(courseRunId);
        assertPublicCourseRun(courseRun);
        assertCanManagePublicCourseRun(courseRun);
        PublicCourseProduct product = publicCourseProductRepository.findByCourseRun_IdAndIsActiveTrue(courseRunId)
                .orElseGet(() -> PublicCourseProduct.builder().courseRun(courseRun).build());
        product.setPriceAmount(request.getPriceAmount());
        product.setCurrency(request.getCurrency().trim().toUpperCase());
        product.setActive(request.getActive() == null || request.getActive());
        return toProductResponse(publicCourseProductRepository.save(product));
    }

    @Transactional(readOnly = true)
    public PublicPurchaseOfferResponse getPurchaseOffer(String courseRunId) {
        CourseRun courseRun = courseRunService.getEntityById(courseRunId);
        assertPublicCourseRun(courseRun);
        String currentUserId = null;
        boolean entitled = false;
        try {
            currentUserId = currentUserService.getCurrentUserId();
            entitled = learningEntitlementRepository.existsByUser_IdAndCourseRun_IdAndStatus(
                    currentUserId, courseRunId, LearningEntitlementStatus.ACTIVE
            );
        } catch (Exception ignored) {
        }
        PublicCourseProduct product = publicCourseProductRepository.findByCourseRun_IdAndIsActiveTrue(courseRunId)
                .orElse(null);
        return PublicPurchaseOfferResponse.builder()
                .courseRunId(courseRunId)
                .entitled(entitled)
                .product(product == null ? null : toProductResponse(product))
                .build();
    }

    @Transactional
    public PublicOrderResponse createOrder(CreatePublicOrderRequest request) {
        User buyer = currentUserService.getCurrentUser();
        CourseRun courseRun = courseRunService.getEntityById(request.getCourseRunId());
        assertPublicCourseRun(courseRun);
        if (learningEntitlementRepository.existsByUser_IdAndCourseRun_IdAndStatus(
                buyer.getId(), courseRun.getId(), LearningEntitlementStatus.ACTIVE)) {
            throw new AppException("commerce.entitlement_already_exists", HttpStatus.CONFLICT);
        }
        PublicCourseProduct product = publicCourseProductRepository.findByCourseRun_IdAndIsActiveTrue(courseRun.getId())
                .orElseThrow(() -> new AppException("commerce.product_not_found", HttpStatus.NOT_FOUND));

        PublicOrder order = PublicOrder.builder()
                .buyerUser(buyer)
                .status(PublicOrderStatus.PENDING)
                .totalAmount(product.getPriceAmount())
                .currency(product.getCurrency())
                .provider(request.getProvider() == null || request.getProvider().isBlank() ? "MOCK" : request.getProvider().trim().toUpperCase())
                .build();
        order = publicOrderRepository.save(order);

        PublicOrderItem item = PublicOrderItem.builder()
                .order(order)
                .courseRun(courseRun)
                .unitPrice(product.getPriceAmount())
                .build();
        publicOrderItemRepository.save(item);
        return toOrderResponse(order);
    }

    @Transactional(readOnly = true)
    public List<PublicOrderResponse> getMyOrders() {
        return publicOrderRepository.findAllByBuyerUser_IdOrderByCreatedAtDesc(currentUserService.getCurrentUserId()).stream()
                .map(this::toOrderResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public PublicOrderResponse getMyOrder(String orderId) {
        PublicOrder order = publicOrderRepository.findByIdAndBuyerUser_Id(orderId, currentUserService.getCurrentUserId())
                .orElseThrow(() -> new AppException("commerce.order_not_found", HttpStatus.NOT_FOUND));
        return toOrderResponse(order);
    }

    @Transactional
    public PublicOrderResponse confirmPayment(String orderId, ConfirmPublicOrderPaymentRequest request) {
        User actor = currentUserService.getCurrentUser();
        PublicOrder order = actor.getRoleName() == UserRole.ADMIN
                ? publicOrderRepository.findById(orderId)
                    .orElseThrow(() -> new AppException("commerce.order_not_found", HttpStatus.NOT_FOUND))
                : publicOrderRepository.findByIdAndBuyerUser_Id(orderId, actor.getId())
                    .orElseThrow(() -> new AppException("commerce.order_not_found", HttpStatus.NOT_FOUND));
        if (order.getStatus() == PublicOrderStatus.PAID) {
            return toOrderResponse(order);
        }
        if (order.getStatus() != PublicOrderStatus.PENDING) {
            throw new AppException("commerce.order_not_pending", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        order.setStatus(PublicOrderStatus.PAID);
        order.setProviderTransactionId(request.getProviderTransactionId());
        order.setPaidAt(Instant.now());
        order = publicOrderRepository.save(order);
        final PublicOrder paidOrder = order;

        for (PublicOrderItem item : publicOrderItemRepository.findAllByOrder_IdOrderByCreatedAtAsc(paidOrder.getId())) {
            learningEntitlementRepository.findByUser_IdAndCourseRun_IdAndStatus(
                    paidOrder.getBuyerUser().getId(),
                    item.getCourseRun().getId(),
                    LearningEntitlementStatus.ACTIVE
            ).orElseGet(() -> learningEntitlementRepository.save(
                    LearningEntitlement.builder()
                            .user(paidOrder.getBuyerUser())
                            .courseRun(item.getCourseRun())
                            .sourceType(LearningEntitlementSourceType.PURCHASE)
                            .sourceRefId(paidOrder.getId())
                            .status(LearningEntitlementStatus.ACTIVE)
                            .build()
            ));
        }
        return toOrderResponse(paidOrder);
    }

    @Transactional(readOnly = true)
    public List<LearningEntitlementResponse> getMyEntitlements() {
        return learningEntitlementRepository.findAllByUser_IdOrderByCreatedAtDesc(currentUserService.getCurrentUserId()).stream()
                .map(this::toEntitlementResponse)
                .toList();
    }

    private void assertPublicCourseRun(CourseRun courseRun) {
        if (courseRun.getAccessScope() != LmsAccessScope.PUBLIC) {
            throw new AppException("lms.public_course_run_not_found", HttpStatus.NOT_FOUND);
        }
    }

    private void assertCanManagePublicCourseRun(CourseRun courseRun) {
        Program program = courseRun.getCourse().getProgram();
        publicCreatorAccessService.assertCanManagePublicProgram(program);
    }

    private PublicCourseProductResponse toProductResponse(PublicCourseProduct product) {
        return PublicCourseProductResponse.builder()
                .id(product.getId())
                .courseRunId(product.getCourseRun().getId())
                .priceAmount(product.getPriceAmount())
                .currency(product.getCurrency())
                .active(product.isActive())
                .purchaseType(product.getPurchaseType())
                .build();
    }

    private PublicOrderResponse toOrderResponse(PublicOrder order) {
        List<PublicOrderItemResponse> items = publicOrderItemRepository.findAllByOrder_IdOrderByCreatedAtAsc(order.getId()).stream()
                .map(item -> PublicOrderItemResponse.builder()
                        .id(item.getId())
                        .courseRunId(item.getCourseRun().getId())
                        .courseRunCode(item.getCourseRun().getCode())
                        .unitPrice(item.getUnitPrice())
                        .build())
                .toList();
        return PublicOrderResponse.builder()
                .id(order.getId())
                .buyerUserId(order.getBuyerUser().getId())
                .status(order.getStatus())
                .totalAmount(order.getTotalAmount())
                .currency(order.getCurrency())
                .provider(order.getProvider())
                .providerTransactionId(order.getProviderTransactionId())
                .paidAt(order.getPaidAt())
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .items(items)
                .build();
    }

    private LearningEntitlementResponse toEntitlementResponse(LearningEntitlement entitlement) {
        return LearningEntitlementResponse.builder()
                .id(entitlement.getId())
                .userId(entitlement.getUser().getId())
                .courseRunId(entitlement.getCourseRun().getId())
                .courseRunCode(entitlement.getCourseRun().getCode())
                .sourceType(entitlement.getSourceType())
                .sourceRefId(entitlement.getSourceRefId())
                .status(entitlement.getStatus())
                .createdAt(entitlement.getCreatedAt())
                .updatedAt(entitlement.getUpdatedAt())
                .build();
    }
}
