package com.lucy.api.infrastructure.websocket.constants;

public final class WebSocketFrameTypeConstants {

    private WebSocketFrameTypeConstants() {
    }

    public static final String AUTH = "AUTH";
    public static final String ERROR = "ERROR";
    public static final String PONG = "PONG";
    public static final String NOTIFICATION = "NOTIFICATION";
    public static final String ECHO = "ECHO";
}
