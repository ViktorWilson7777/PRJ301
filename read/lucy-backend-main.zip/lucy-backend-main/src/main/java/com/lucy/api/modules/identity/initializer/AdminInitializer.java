package com.lucy.api.modules.identity.initializer;

import com.lucy.api.common.constants.InitializerOrder;
import com.lucy.api.modules.identity.dtos.AdminProperties;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.enums.ProfileRole;
import com.lucy.api.modules.identity.entity.enums.UserRole;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.entity.UserProfile;
import com.lucy.api.modules.identity.repository.UserProfileRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.jspecify.annotations.NonNull;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Order(InitializerOrder.ADMIN)
@Component
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class AdminInitializer implements ApplicationRunner {

    UserRepository userRepository;
    UserProfileRepository userProfileRepository;
    PasswordEncoder passwordEncoder;
    AdminProperties adminProperties;

    @Override
    @Transactional
    public void run(@NonNull ApplicationArguments args) {
        String adminUsername = adminProperties.getUsername();
        String adminPassword = adminProperties.getPassword();

        if (adminUsername == null || adminUsername.isBlank()
                || adminPassword == null || adminPassword.isBlank()) {
            return;
        }

        String adminEmail = adminUsername.trim();
        User admin = userRepository.findByEmail(adminEmail).orElse(null);

        if (admin != null) {
            log.info("Updating existing user to ADMIN role for email {}", adminEmail);
            admin.setRoleName(UserRole.ADMIN);
            admin.setVerified(true);
            if (admin.getVerifiedAt() == null) {
                admin.setVerifiedAt(Instant.now());
            }
            userRepository.save(admin);
        } else {
            log.info("Creating new admin user with email {}", adminEmail);
            admin = User.builder()
                    .email(adminEmail)
                    .passwordHash(passwordEncoder.encode(adminPassword))
                    .isVerified(true)
                    .verifiedAt(Instant.now())
                    .roleName(UserRole.ADMIN)
                    .build();
            admin = userRepository.save(admin);
        }

        final User finalAdmin = admin;
        UserProfile profile = userProfileRepository.findById(admin.getId()).orElseGet(() -> {
            log.info("Creating profile for admin user {}", adminEmail);
            return UserProfile.builder()
                    .user(finalAdmin)
                    .displayName("Admin")
                    .profileRole(ProfileRole.SUPER)
                    .build();
        });

        // Ensure profile has SUPER role even if it existed
        profile.setProfileRole(ProfileRole.SUPER);
        userProfileRepository.save(profile);

        log.info("Admin setup complete for email {}", adminEmail);
    }
}
