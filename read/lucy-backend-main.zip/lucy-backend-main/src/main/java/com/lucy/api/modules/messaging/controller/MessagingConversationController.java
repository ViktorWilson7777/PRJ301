package com.lucy.api.modules.messaging.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import com.lucy.api.modules.messaging.dto.response.ConversationListItemResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationParticipantResponse;
import com.lucy.api.modules.messaging.dto.response.ConversationResponse;
import com.lucy.api.modules.messaging.dto.request.CreateAdhocGroupConversationRequest;
import com.lucy.api.modules.messaging.dto.request.InviteMembersRequest;
import com.lucy.api.modules.messaging.dto.request.RenameGroupConversationRequest;
import com.lucy.api.modules.messaging.service.facade.MessagingFacade;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/api/v1/messaging")
@RequiredArgsConstructor
@Tag(name = "Messaging", description = "Course run group conversations")
public class MessagingConversationController {

    private final MessagingFacade messagingFacade;

    @GetMapping("/course-runs/{courseRunId}/conversation")
    public ResponseEntity<ApiResponse<ConversationResponse>> getGroupConversation(
            @PathVariable String courseRunId
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        ConversationResponse data = messagingFacade.getGroupConversationForEnrolledUser(courseRunId, userId);
        return ResponseEntity.ok(ApiResponse.<ConversationResponse>builder()
                .success(true)
                .data(data)
                .build());
    }

    @GetMapping("/rooms/{roomId}/conversation")
    public ResponseEntity<ApiResponse<ConversationResponse>> getGroupConversationByRoomIdAlias(
            @PathVariable String roomId
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        ConversationResponse data = messagingFacade.getGroupConversationForRoomParticipant(roomId, userId);
        return ResponseEntity.ok(ApiResponse.<ConversationResponse>builder()
                .success(true)
                .data(data)
                .build());
    }

    @GetMapping("/conversations/{conversationId}/participants")
    public ResponseEntity<ApiResponse<List<ConversationParticipantResponse>>> listParticipants(
            @PathVariable String conversationId
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        List<ConversationParticipantResponse> data = messagingFacade.listParticipants(conversationId, userId);
        return ResponseEntity.ok(ApiResponse.<List<ConversationParticipantResponse>>builder()
                .success(true)
                .data(data)
                .build());
    }

    @GetMapping("/conversations")
    public ResponseEntity<ApiResponse<List<ConversationListItemResponse>>> listMyConversations() {
        String userId = IdentityUtils.getCurrentUserId();
        List<ConversationListItemResponse> data = messagingFacade.listMyConversations(userId);
        return ResponseEntity.ok(ApiResponse.<List<ConversationListItemResponse>>builder()
                .success(true)
                .data(data)
                .build());
    }

    @GetMapping("/conversations/direct")
    public ResponseEntity<ApiResponse<ConversationResponse>> getOrCreateDirectConversation(
            @RequestParam("peerUserId") String peerUserId
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        ConversationResponse data = messagingFacade.getOrCreateDirectConversation(userId, peerUserId.trim());
        return ResponseEntity.ok(ApiResponse.<ConversationResponse>builder()
                .success(true)
                .data(data)
                .build());
    }

    @PostMapping("/conversations/group")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Create an ad-hoc group conversation and invite members (friends only)")
    public ResponseEntity<ApiResponse<ConversationResponse>> createAdhocGroupConversation(
            @Valid @RequestBody CreateAdhocGroupConversationRequest request
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        ConversationResponse data = messagingFacade.createAdhocGroupConversation(
                userId,
                request.getGroupName(),
                request.getMemberUserIds()
        );
        return ResponseEntity.ok(ApiResponse.<ConversationResponse>builder()
                .success(true)
                .data(data)
                .build());
    }

    @PostMapping("/conversations/{conversationId}/invites")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Invite members to a group conversation (friends only)")
    public ResponseEntity<ApiResponse<String>> inviteMembers(
            @PathVariable String conversationId,
            @Valid @RequestBody InviteMembersRequest request
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        messagingFacade.inviteMembers(conversationId, userId, request.getMemberUserIds());
        return ResponseEntity.ok(ApiResponse.<String>builder()
                .success(true)
                .data("OK")
                .build());
    }

    @GetMapping("/conversations/{conversationId}/my-status")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Get current user's participant status in a conversation")
    public ResponseEntity<ApiResponse<String>> getMyStatus(@PathVariable String conversationId) {
        String userId = IdentityUtils.getCurrentUserId();
        String status = messagingFacade.getMyParticipantStatus(conversationId, userId);
        return ResponseEntity.ok(ApiResponse.<String>builder()
                .success(true)
                .data(status)
                .build());
    }

    @PostMapping("/conversations/{conversationId}/invites/accept")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Accept a group invite")
    public ResponseEntity<ApiResponse<String>> acceptInvite(@PathVariable String conversationId) {
        String userId = IdentityUtils.getCurrentUserId();
        messagingFacade.acceptInvite(conversationId, userId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("OK").build());
    }

    @PostMapping("/conversations/{conversationId}/invites/reject")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Reject a group invite")
    public ResponseEntity<ApiResponse<String>> rejectInvite(@PathVariable String conversationId) {
        String userId = IdentityUtils.getCurrentUserId();
        messagingFacade.rejectInvite(conversationId, userId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("OK").build());
    }

    @PutMapping("/conversations/{conversationId}/group-name")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Rename ad-hoc group conversation (owner only)")
    public ResponseEntity<ApiResponse<ConversationResponse>> renameGroupConversation(
            @PathVariable String conversationId,
            @Valid @RequestBody RenameGroupConversationRequest request
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        ConversationResponse data = messagingFacade.renameGroupConversation(
                conversationId,
                userId,
                request.getGroupName()
        );
        return ResponseEntity.ok(ApiResponse.<ConversationResponse>builder()
                .success(true)
                .data(data)
                .build());
    }
}
