package com.lucy.api.modules.cloudinary.service.impl;

import com.lucy.api.modules.cloudinary.dto.StoredFileInfo;
import com.lucy.api.modules.cloudinary.service.api.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.multipart.MultipartFile;

@RequiredArgsConstructor
public class CloudinaryFileStorageServiceImpl implements FileStorageService {
    private final @Qualifier("r2FileStorageServiceImpl") FileStorageService r2FileStorageService;

    @Override
    public StoredFileInfo upload(MultipartFile file, String folder) {
        return r2FileStorageService.upload(file, folder);
    }

    @Override
    public String getPresignedUploadUrl(String key, String contentType) {
        return r2FileStorageService.getPresignedUploadUrl(key, contentType);
    }

    @Override
    public String getPresignedDownloadUrl(String key) {
        return r2FileStorageService.getPresignedDownloadUrl(key);
    }

    @Override
    public String getFileUrl(String key) {
        return r2FileStorageService.getFileUrl(key);
    }

    @Override
    public void delete(String key) {
        r2FileStorageService.delete(key);
    }
}
