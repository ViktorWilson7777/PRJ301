package com.lucy.api.modules.organization.dto.request;

import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizationMembershipUpsertRequest {
    @NotBlank(message = "common.field_required")
    String userId;

    @NotNull(message = "common.field_required")
    OrganizationMembershipRole role;

    OrganizationMembershipStatus status = OrganizationMembershipStatus.ACTIVE;
}
