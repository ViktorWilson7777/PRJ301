package com.lucy.api.modules.story.dto.request;

import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Getter
@Setter
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UpdateMyProfileRequest {
    @Size(max = 120)
    String displayName;

    @Size(max = 500)
    String avatarUrl;

    @Size(max = 120)
    String avatarKey;

    @Size(max = 500)
    String bio;

    @Size(max = 255)
    String interest;

    @Size(max = 120)
    String specialty;

    @Size(max = 20)
    List<@Size(max = 60) String> interests;
}
