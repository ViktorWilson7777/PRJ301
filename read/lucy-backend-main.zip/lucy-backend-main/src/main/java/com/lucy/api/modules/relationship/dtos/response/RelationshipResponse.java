package com.lucy.api.modules.relationship.dtos.response;

import com.lucy.api.modules.relationship.enums.RelationshipStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class RelationshipResponse {
    String id;
    RelationshipStatus status;
    Instant requestedAt;
    Instant respondedAt;
    RelationshipUserSummaryResponse requester;
    RelationshipUserSummaryResponse addressee;
}
