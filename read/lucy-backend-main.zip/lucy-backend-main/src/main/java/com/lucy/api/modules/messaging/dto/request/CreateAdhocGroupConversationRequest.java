package com.lucy.api.modules.messaging.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CreateAdhocGroupConversationRequest {
    @NotBlank
    private String groupName;

    @NotNull
    private List<String> memberUserIds;
}

