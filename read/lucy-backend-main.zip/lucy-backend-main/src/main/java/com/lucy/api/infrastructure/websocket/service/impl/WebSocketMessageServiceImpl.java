package com.lucy.api.infrastructure.websocket.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.infrastructure.redis.constants.RedisChannelPrefixes;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketMessageService;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketSessionService;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * @see WebSocketMessageService — chat: {@link #sendToTopic} chỉ {@link #publishToRedis} (plan 6.1 phương án A).
 */
@Slf4j
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WebSocketMessageServiceImpl implements WebSocketMessageService {

    StringRedisTemplate stringRedisTemplate;
    ObjectMapper objectMapper;
    WebSocketSessionService sessionService;
    ConcurrentMap<String, Channel> sessionChannels = new ConcurrentHashMap<>();

    @Override
    public void registerChannel(String sessionId, Channel channel) {
        sessionChannels.put(sessionId, channel);
    }

    @Override
    public void unregisterChannel(String sessionId) {
        sessionChannels.remove(sessionId);
    }

    @Override
    public Channel getChannel(String sessionId) {
        return sessionChannels.get(sessionId);
    }

    @Override
    public void sendToTopic(String topicId, Object payload, String type) {
        // Chi publish Redis: moi instance nhan mot lan qua WebSocketChatMessageRedisHandler -> broadcastToLocalSessions (tranh double tren cung node).
        publishToRedis(topicId, payload, type);
    }

    @Override
    public void broadcastToLocalSessions(String topicId, Object payload, String type) {
        try {
            List<String> sessionIds = sessionService.getConversationSessions(topicId);
            String messageJson = objectMapper.writeValueAsString(payload);

            for (String sessionId : sessionIds) {
                Channel channel = sessionChannels.get(sessionId);
                if (channel != null && channel.isActive()) {
                    String wrappedMessage = wrapMessageWithType(messageJson, type);
                    channel.writeAndFlush(new TextWebSocketFrame(wrappedMessage));
                }
            }

            log.info("Broadcasted message to {} sessions for topic {}", sessionIds.size(), topicId);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize message for topic {}", topicId, e);
        }
    }

    @Override
    public void publishToRedis(String topicId, Object payload, String type) {
        try {
            String channel = RedisChannelPrefixes.WS_MESSAGE + topicId;
            String messageJson = objectMapper.writeValueAsString(payload);
            stringRedisTemplate.convertAndSend(channel, messageJson);
            log.info("Published message to Redis channel: {}", channel);
        } catch (Exception e) {
            log.error("Failed to publish message to Redis for topic {}", topicId, e);
        }
    }

    @SuppressWarnings("unchecked")
    private String wrapMessageWithType(String messageJson, String type) {
        try {
            Map<String, Object> messageMap = (Map<String, Object>) objectMapper.readValue(messageJson, Map.class);
            messageMap.put(WebSocketConstants.FIELD_TYPE, type);
            return objectMapper.writeValueAsString(messageMap);
        } catch (Exception e) {
            log.error("Failed to wrap message with type", e);
            return messageJson;
        }
    }
}
