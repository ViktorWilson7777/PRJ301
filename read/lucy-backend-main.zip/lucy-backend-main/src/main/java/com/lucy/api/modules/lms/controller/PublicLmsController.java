package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.commerce.dto.request.PublicCourseProductUpsertRequest;
import com.lucy.api.modules.commerce.dto.response.PublicCourseProductResponse;
import com.lucy.api.modules.lms.dto.request.CourseRunUpsertRequest;
import com.lucy.api.modules.lms.dto.request.CourseUpsertRequest;
import com.lucy.api.modules.lms.dto.request.ProgramUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.dto.response.CourseResponse;
import com.lucy.api.modules.lms.dto.response.CourseRunResponse;
import com.lucy.api.modules.lms.dto.response.LessonResponse;
import com.lucy.api.modules.lms.dto.response.ProgramResponse;
import com.lucy.api.modules.lms.service.api.ChapterService;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import com.lucy.api.modules.lms.service.api.CourseService;
import com.lucy.api.modules.lms.service.api.LessonService;
import com.lucy.api.modules.lms.service.api.ProgramService;
import com.lucy.api.modules.commerce.service.PublicCommerceService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/public")
@Tag(name = "Public LMS", description = "Public LMS catalog APIs")
public class PublicLmsController {
    private final ProgramService programService;
    private final CourseService courseService;
    private final CourseRunService courseRunService;
    private final ChapterService chapterService;
    private final LessonService lessonService;
    private final PublicCommerceService publicCommerceService;

    @PostMapping("/programs")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ProgramResponse>> createProgram(@Valid @RequestBody ProgramUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<ProgramResponse>builder().success(true).data(programService.createPublic(request)).build());
    }

    @GetMapping("/programs")
    public ResponseEntity<ApiResponse<List<ProgramResponse>>> getPrograms() {
        return ResponseEntity.ok(ApiResponse.<List<ProgramResponse>>builder().success(true).data(programService.findAllPublic()).build());
    }

    @GetMapping("/programs/{programId}")
    public ResponseEntity<ApiResponse<ProgramResponse>> getProgram(@PathVariable String programId) {
        return ResponseEntity.ok(ApiResponse.<ProgramResponse>builder().success(true).data(programService.findPublicById(programId)).build());
    }

    @PutMapping("/programs/{programId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ProgramResponse>> updateProgram(@PathVariable String programId, @Valid @RequestBody ProgramUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<ProgramResponse>builder().success(true).data(programService.updatePublic(programId, request)).build());
    }

    @DeleteMapping("/programs/{programId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteProgram(@PathVariable String programId) {
        programService.deletePublic(programId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Public program deleted successfully").build());
    }

    @PostMapping("/courses")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseResponse>> createCourse(@Valid @RequestBody CourseUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<CourseResponse>builder().success(true).data(courseService.createPublic(request)).build());
    }

    @GetMapping("/courses")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getCourses(@RequestParam(required = false) String programId) {
        return ResponseEntity.ok(ApiResponse.<List<CourseResponse>>builder().success(true).data(courseService.findAllPublic(programId)).build());
    }

    @GetMapping("/courses/{courseId}")
    public ResponseEntity<ApiResponse<CourseResponse>> getCourse(@PathVariable String courseId) {
        return ResponseEntity.ok(ApiResponse.<CourseResponse>builder().success(true).data(courseService.findPublicById(courseId)).build());
    }

    @PutMapping("/courses/{courseId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseResponse>> updateCourse(@PathVariable String courseId, @Valid @RequestBody CourseUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<CourseResponse>builder().success(true).data(courseService.updatePublic(courseId, request)).build());
    }

    @DeleteMapping("/courses/{courseId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteCourse(@PathVariable String courseId) {
        courseService.deletePublic(courseId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Public course deleted successfully").build());
    }

    @PostMapping("/course-runs")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseRunResponse>> createCourseRun(@Valid @RequestBody CourseRunUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.createPublic(request)).build());
    }

    @GetMapping("/course-runs")
    public ResponseEntity<ApiResponse<List<CourseRunResponse>>> getCourseRuns(@RequestParam(required = false) String courseId) {
        return ResponseEntity.ok(ApiResponse.<List<CourseRunResponse>>builder().success(true).data(courseRunService.findAllPublic(courseId)).build());
    }

    @GetMapping("/course-runs/{courseRunId}")
    public ResponseEntity<ApiResponse<CourseRunResponse>> getCourseRun(@PathVariable String courseRunId) {
        return ResponseEntity.ok(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.findPublicById(courseRunId)).build());
    }

    @GetMapping("/course-runs/{courseRunId}/roadmap")
    public ResponseEntity<ApiResponse<List<ChapterResponse>>> getRoadmap(@PathVariable String courseRunId) {
        courseRunService.findPublicById(courseRunId);
        List<ChapterResponse> chapters = chapterService.findAll(courseRunId);
        for (ChapterResponse chapter : chapters) {
            chapter.setLessons(lessonService.findAll(chapter.getId()));
        }
        return ResponseEntity.ok(ApiResponse.<List<ChapterResponse>>builder().success(true).data(chapters).build());
    }

    @PutMapping("/course-runs/{courseRunId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseRunResponse>> updateCourseRun(@PathVariable String courseRunId, @Valid @RequestBody CourseRunUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.updatePublic(courseRunId, request)).build());
    }

    @DeleteMapping("/course-runs/{courseRunId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteCourseRun(@PathVariable String courseRunId) {
        courseRunService.deletePublic(courseRunId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Public course run deleted successfully").build());
    }

    @PutMapping("/course-runs/{courseRunId}/product")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<PublicCourseProductResponse>> upsertProduct(
            @PathVariable String courseRunId,
            @Valid @RequestBody PublicCourseProductUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<PublicCourseProductResponse>builder().success(true).data(publicCommerceService.upsertProduct(courseRunId, request)).build());
    }
}
