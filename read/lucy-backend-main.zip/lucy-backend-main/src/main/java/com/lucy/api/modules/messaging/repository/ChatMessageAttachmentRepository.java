package com.lucy.api.modules.messaging.repository;

import com.lucy.api.modules.messaging.entity.ChatMessageAttachmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChatMessageAttachmentRepository extends JpaRepository<ChatMessageAttachmentEntity, String> {
    List<ChatMessageAttachmentEntity> findByMessageId(String messageId);
}
