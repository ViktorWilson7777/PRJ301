package com.lucy.api.modules.lms.entity.enums;

public enum EnrollmentRole {
    STUDENT,
    TEACHER,
    ADMIN,
    NO_ROLE
}
