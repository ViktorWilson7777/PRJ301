package com.lucy.api.modules.livesessions.entity;

public enum LiveSessionType {
    TORII_MEET,
    ZOOM,
    GOOGLE_MEET,
    TEAMS,
    OTHER
}
