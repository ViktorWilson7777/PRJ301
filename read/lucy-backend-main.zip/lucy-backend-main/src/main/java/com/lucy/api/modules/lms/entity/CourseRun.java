package com.lucy.api.modules.lms.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.lms.entity.Chapter;
import com.lucy.api.modules.lms.entity.Course;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.organization.entity.Organization;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "course_runs")
public class CourseRun extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "course_id", nullable = false)
    Course course;

    @Column(nullable = false, length = 120)
    String code;

    @Column(nullable = false, length = 20)
    String status = "DRAFT";

    @Column(name = "starts_at", nullable = false)
    Instant startsAt;

    @Column(name = "ends_at", nullable = false)
    Instant endsAt;

    @Column(nullable = false, length = 64)
    String timezone = "UTC";

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "metadata", columnDefinition = "jsonb")
    Map<String, Object> metadata;

    @Column(name = "enrollment_start_date")
    Instant enrollmentStartDate;

    @Column(name = "enrollment_end_date")
    Instant enrollmentEndDate;

    @Column(name = "capacity")
    Integer capacity;

    @Column(name = "prerequisite_course_run_id")
    String prerequisiteCourseRunId;

    @Enumerated(EnumType.STRING)
    @Column(name = "access_scope", nullable = false, length = 20)
    LmsAccessScope accessScope = LmsAccessScope.PUBLIC;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id")
    Organization organization;

    @OneToMany(mappedBy = "courseRun", cascade = CascadeType.ALL)
    @OrderBy("orderIndex ASC")
    List<Chapter> chapters;

    Instant deletedAt;
}
