package com.lucy.api.modules.lms.dto.request;

import com.lucy.api.modules.lms.entity.enums.EnrollmentMethod;
import com.lucy.api.modules.lms.entity.enums.EnrollmentRole;
import com.lucy.api.modules.lms.entity.enums.EnrollmentStatus;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EnrollmentUpdateRequest {
    EnrollmentStatus status;
    EnrollmentRole role;
    EnrollmentMethod enrolmentMethod;
    Instant lastAccessedAt;
    Instant completedAt;
}
