package com.lucy.api.modules.commerce.repository;

import com.lucy.api.modules.commerce.entity.PublicOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PublicOrderRepository extends JpaRepository<PublicOrder, String> {
    List<PublicOrder> findAllByBuyerUser_IdOrderByCreatedAtDesc(String userId);

    Optional<PublicOrder> findByIdAndBuyerUser_Id(String orderId, String userId);
}
