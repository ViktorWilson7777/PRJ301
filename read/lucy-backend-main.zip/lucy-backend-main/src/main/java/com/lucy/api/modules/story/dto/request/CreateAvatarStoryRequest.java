package com.lucy.api.modules.story.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CreateAvatarStoryRequest {

    @NotBlank(message = "story.media_url_required")
    String mediaUrl;

    @Size(max = 2000, message = "common.invalid_param")
    String thumbnailUrl;

    @Size(max = 1000, message = "common.invalid_param")
    String caption;
}
