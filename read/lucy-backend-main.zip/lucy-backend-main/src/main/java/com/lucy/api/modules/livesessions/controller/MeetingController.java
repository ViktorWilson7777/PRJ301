package com.lucy.api.modules.livesessions.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.livesessions.dto.response.MeetingTokenResponse;
import com.lucy.api.modules.livesessions.service.api.LiveSessionService;
import com.lucy.api.common.constants.JwtClaimSetConstant;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/meetings")
@RequiredArgsConstructor
@Tag(name = "Meetings", description = "Endpoints for live sessions and meeting tokens")
public class MeetingController {

    private final LiveSessionService liveSessionService;

    @Operation(summary = "Get a join token for a meeting room")
    @GetMapping("/token")
    public ApiResponse<MeetingTokenResponse> getJoinToken(
            @RequestParam String roomCode,
            @AuthenticationPrincipal Jwt jwt) {

        // JWT "sub" đang set là email, còn user table lookup cần "id".
        // Backend phát hành JWT có claim "userId" => dùng claim này.
        String userId = jwt.getClaimAsString(JwtClaimSetConstant.CLAIM_USER_ID);
        if (userId == null || userId.isBlank()) {
            // Fallback để tránh NPE nếu token format bị lệch
            userId = jwt.getSubject();
        }
        MeetingTokenResponse response = liveSessionService.getJoinToken(roomCode, userId);
        
        return ApiResponse.<MeetingTokenResponse>builder()
                .data(response)
                .build();
    }
}
