package com.lucy.api.modules.identity.dtos.request.admin;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminUpdateUserStatusRequest {
    private Boolean isActive;
}

