package com.lucy.api.modules.messaging.entity;

import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "conversation_participants")
public class ConversationParticipantEntity {
    @Id
    @Column(updatable = false, length = 36)
    String id;

    @Column(name = "conversation_id", nullable = false, length = 36)
    String conversationId;

    @Column(name = "user_id", nullable = false, length = 36)
    String userId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    ParticipantStatus status;

    @Column(name = "joined_at", nullable = false)
    Instant joinedAt;

    @Column(name = "left_at")
    Instant leftAt;

    @Column(name = "created_at", nullable = false)
    Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    Instant updatedAt;

    @PrePersist
    void prePersist() {
        Instant now = Instant.now();
        if (id == null) {
            id = UUID.randomUUID().toString();
        }
        if (status == null) {
            status = ParticipantStatus.ACTIVE;
        }
        if (joinedAt == null) {
            joinedAt = now;
        }
        if (createdAt == null) {
            createdAt = now;
        }
        updatedAt = now;
    }

    @PreUpdate
    void preUpdate() {
        updatedAt = Instant.now();
    }
}
