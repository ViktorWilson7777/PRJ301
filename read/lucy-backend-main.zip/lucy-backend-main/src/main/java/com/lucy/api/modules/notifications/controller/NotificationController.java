package com.lucy.api.modules.notifications.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.common.constants.JwtClaimSetConstant;
import com.lucy.api.modules.notifications.dtos.response.NotificationResponse;
import com.lucy.api.modules.notifications.service.interfaces.NotificationService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.List;

@RestController
@RequestMapping({"/api/v1/notifications", "/api/me/notifications"})
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class NotificationController {
    NotificationService notificationService;

    @GetMapping({"", "/me"})
    public ResponseEntity<ApiResponse<List<NotificationResponse>>> getMyNotifications() {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String userId = jwt.getClaimAsString(JwtClaimSetConstant.CLAIM_USER_ID);
        
        return ResponseEntity.ok(ApiResponse.<List<NotificationResponse>>builder()
                .success(true)
                .data(notificationService.getMyNotifications(userId))
                .build());
    }

    @PatchMapping("/{id}/read")
    public ResponseEntity<ApiResponse<Void>> markAsRead(@PathVariable String id) {
        notificationService.markAsRead(id);
        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .success(true)
                .build());
    }

    @PostMapping("/{id}/read")
    public ResponseEntity<ApiResponse<Void>> markAsReadCompat(@PathVariable String id) {
        return markAsRead(id);
    }

    @PatchMapping({"/read-all", "/me/read-all"})
    public ResponseEntity<ApiResponse<Void>> markAllAsRead() {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String userId = jwt.getClaimAsString(JwtClaimSetConstant.CLAIM_USER_ID);
        
        notificationService.markAllAsRead(userId);
        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .success(true)
                .build());
    }

    @PostMapping({"/read-all", "/me/read-all"})
    public ResponseEntity<ApiResponse<Void>> markAllAsReadCompat() {
        return markAllAsRead();
    }

    @GetMapping({"/unread/count", "/me/unread/count"})
    public ResponseEntity<ApiResponse<Long>> countUnreadNotifications() {
        Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String userId = jwt.getClaimAsString(JwtClaimSetConstant.CLAIM_USER_ID);
        
        return ResponseEntity.ok(ApiResponse.<Long>builder()
                .success(true)
                .data(notificationService.countUnreadNotifications(userId))
                .build());
    }
}
