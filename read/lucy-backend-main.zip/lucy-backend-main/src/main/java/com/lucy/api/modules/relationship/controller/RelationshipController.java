package com.lucy.api.modules.relationship.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.audit.annotation.AuditAction;
import com.lucy.api.modules.audit.constants.AuditActionType;
import com.lucy.api.modules.audit.constants.AuditEntityType;
import com.lucy.api.modules.relationship.dtos.request.FriendRequestCreateRequest;
import com.lucy.api.modules.relationship.dtos.response.RelationshipResponse;
import com.lucy.api.modules.relationship.dtos.response.RelationshipStatusResponse;
import com.lucy.api.modules.relationship.service.interfaces.RelationshipService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/relationships")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Tag(name = "Relationships", description = "Friendship APIs and inbox gate checks")
public class RelationshipController {

    RelationshipService relationshipService;

    @PostMapping("/requests")
    @Operation(summary = "Send a friend request")
    @AuditAction(action = AuditActionType.RELATIONSHIP_REQUEST, entityType = AuditEntityType.RELATIONSHIP)
    public ResponseEntity<ApiResponse<RelationshipResponse>> sendFriendRequest(
            @Valid @RequestBody FriendRequestCreateRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.<RelationshipResponse>builder()
                .success(true)
                .data(relationshipService.sendFriendRequest(request))
                .build());
    }

    @PostMapping("/requests/{relationshipId}/accept")
    @Operation(summary = "Accept a received friend request")
    @AuditAction(action = AuditActionType.RELATIONSHIP_ACCEPT, entityType = AuditEntityType.RELATIONSHIP)
    public ResponseEntity<ApiResponse<RelationshipResponse>> acceptRequest(@PathVariable String relationshipId) {
        return ResponseEntity.ok(ApiResponse.<RelationshipResponse>builder()
                .success(true)
                .data(relationshipService.acceptRequest(relationshipId))
                .build());
    }

    @DeleteMapping("/requests/{relationshipId}/reject")
    @Operation(summary = "Reject a received friend request")
    @AuditAction(action = AuditActionType.RELATIONSHIP_REJECT, entityType = AuditEntityType.RELATIONSHIP)
    public ResponseEntity<ApiResponse<Void>> rejectRequest(@PathVariable String relationshipId) {
        relationshipService.rejectRequest(relationshipId);
        return ResponseEntity.ok(ApiResponse.<Void>builder().success(true).build());
    }

    @DeleteMapping("/requests/{relationshipId}/cancel")
    @Operation(summary = "Cancel a sent friend request")
    @AuditAction(action = AuditActionType.RELATIONSHIP_CANCEL, entityType = AuditEntityType.RELATIONSHIP)
    public ResponseEntity<ApiResponse<Void>> cancelSentRequest(@PathVariable String relationshipId) {
        relationshipService.cancelSentRequest(relationshipId);
        return ResponseEntity.ok(ApiResponse.<Void>builder().success(true).build());
    }

    @DeleteMapping("/friends/{relationshipId}")
    @Operation(summary = "Unfriend an accepted relationship")
    @AuditAction(action = AuditActionType.RELATIONSHIP_UNFRIEND, entityType = AuditEntityType.RELATIONSHIP)
    public ResponseEntity<ApiResponse<Void>> unfriend(@PathVariable String relationshipId) {
        relationshipService.unfriend(relationshipId);
        return ResponseEntity.ok(ApiResponse.<Void>builder().success(true).build());
    }

    @GetMapping("/friends")
    @Operation(summary = "Get my friends")
    public ResponseEntity<ApiResponse<List<RelationshipResponse>>> getMyFriends() {
        return ResponseEntity.ok(ApiResponse.<List<RelationshipResponse>>builder()
                .success(true)
                .data(relationshipService.getMyFriends())
                .build());
    }

    @GetMapping("/requests/received")
    @Operation(summary = "Get pending friend requests received by me")
    public ResponseEntity<ApiResponse<List<RelationshipResponse>>> getPendingReceivedRequests() {
        return ResponseEntity.ok(ApiResponse.<List<RelationshipResponse>>builder()
                .success(true)
                .data(relationshipService.getPendingReceivedRequests())
                .build());
    }

    @GetMapping("/requests/sent")
    @Operation(summary = "Get pending friend requests sent by me")
    public ResponseEntity<ApiResponse<List<RelationshipResponse>>> getPendingSentRequests() {
        return ResponseEntity.ok(ApiResponse.<List<RelationshipResponse>>builder()
                .success(true)
                .data(relationshipService.getPendingSentRequests())
                .build());
    }

    @GetMapping("/status/{otherUserId}")
    @Operation(summary = "Get friendship status and inbox eligibility with another user")
    public ResponseEntity<ApiResponse<RelationshipStatusResponse>> getRelationshipStatus(@PathVariable String otherUserId) {
        return ResponseEntity.ok(ApiResponse.<RelationshipStatusResponse>builder()
                .success(true)
                .data(relationshipService.getRelationshipStatus(otherUserId))
                .build());
    }
}
