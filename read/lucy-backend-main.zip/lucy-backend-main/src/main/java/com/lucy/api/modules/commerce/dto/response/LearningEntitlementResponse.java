package com.lucy.api.modules.commerce.dto.response;

import com.lucy.api.modules.commerce.entity.enums.LearningEntitlementSourceType;
import com.lucy.api.modules.commerce.entity.enums.LearningEntitlementStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class LearningEntitlementResponse {
    String id;
    String userId;
    String courseRunId;
    String courseRunCode;
    LearningEntitlementSourceType sourceType;
    String sourceRefId;
    LearningEntitlementStatus status;
    Instant createdAt;
    Instant updatedAt;
}
