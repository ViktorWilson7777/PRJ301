package com.lucy.api.modules.messaging.constant;

public final class ChatAttachmentConstants {

    public static final String TABLE_CHAT_MESSAGE_ATTACHMENTS = "chat_message_attachments";

    public static final String COL_MESSAGE_ID = "message_id";
    public static final String COL_TYPE = "type";
    public static final String COL_URL = "url";
    public static final String COL_TITLE = "title";

    private ChatAttachmentConstants() {
    }
}
