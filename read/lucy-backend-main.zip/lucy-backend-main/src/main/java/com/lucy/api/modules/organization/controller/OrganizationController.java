package com.lucy.api.modules.organization.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.organization.dto.request.OrganizationMembershipUpsertRequest;
import com.lucy.api.modules.organization.dto.request.OrganizationUpsertRequest;
import com.lucy.api.modules.organization.dto.response.OrganizationMembershipResponse;
import com.lucy.api.modules.organization.dto.response.OrganizationResponse;
import com.lucy.api.modules.organization.service.OrganizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/organizations")
@Tag(name = "Organizations", description = "Organization management APIs")
public class OrganizationController {
    private final OrganizationService organizationService;

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Create organization")
    public ResponseEntity<ApiResponse<OrganizationResponse>> create(@Valid @RequestBody OrganizationUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<OrganizationResponse>builder().success(true).data(organizationService.create(request)).build());
    }

    @GetMapping("/{organizationId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<OrganizationResponse>> getById(@PathVariable String organizationId) {
        return ResponseEntity.ok(ApiResponse.<OrganizationResponse>builder().success(true).data(organizationService.getById(organizationId)).build());
    }

    @PutMapping("/{organizationId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<OrganizationResponse>> update(@PathVariable String organizationId, @Valid @RequestBody OrganizationUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<OrganizationResponse>builder().success(true).data(organizationService.update(organizationId, request)).build());
    }

    @GetMapping("/{organizationId}/members")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<OrganizationMembershipResponse>>> getMembers(@PathVariable String organizationId) {
        return ResponseEntity.ok(ApiResponse.<List<OrganizationMembershipResponse>>builder().success(true).data(organizationService.getMembers(organizationId)).build());
    }

    @PostMapping("/{organizationId}/members")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<OrganizationMembershipResponse>> addMember(
            @PathVariable String organizationId,
            @Valid @RequestBody OrganizationMembershipUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<OrganizationMembershipResponse>builder().success(true).data(organizationService.addMember(organizationId, request)).build());
    }

    @PutMapping("/{organizationId}/members/{membershipId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<OrganizationMembershipResponse>> updateMember(
            @PathVariable String organizationId,
            @PathVariable String membershipId,
            @Valid @RequestBody OrganizationMembershipUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<OrganizationMembershipResponse>builder().success(true).data(organizationService.updateMember(organizationId, membershipId, request)).build());
    }

    @DeleteMapping("/{organizationId}/members/{membershipId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> removeMember(@PathVariable String organizationId, @PathVariable String membershipId) {
        organizationService.removeMember(organizationId, membershipId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Organization member removed successfully").build());
    }
}
