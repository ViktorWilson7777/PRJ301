package com.lucy.api.infrastructure.websocket.redis;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.infrastructure.redis.constants.RedisChannelPrefixes;
import com.lucy.api.infrastructure.redis.pubsub.RedisEventHandler;
import com.lucy.api.infrastructure.websocket.constants.WebSocketConstants;
import com.lucy.api.infrastructure.websocket.constants.WebSocketRedisInboundLogConstants;
import com.lucy.api.infrastructure.websocket.service.api.WebSocketMessageService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Order(0)
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WebSocketChatMessageRedisHandler implements RedisEventHandler {

    ObjectMapper objectMapper;
    WebSocketMessageService messageService;

    @Override
    public boolean supports(String channel) {
        return channel != null && channel.startsWith(RedisChannelPrefixes.WS_MESSAGE);
    }

    @Override
    public void handle(String channel, String payload) {
        try {
            String topicId = channel.substring(RedisChannelPrefixes.WS_MESSAGE.length());
            Object wsMessage = objectMapper.readValue(payload, Object.class);
            messageService.broadcastToLocalSessions(topicId, wsMessage, WebSocketConstants.OUTBOUND_FRAME_TYPE_MESSAGE);
            log.debug("Broadcasted message to local sessions for topic: {}", topicId);
        } catch (JsonProcessingException e) {
            log.error(WebSocketRedisInboundLogConstants.PARSE_MESSAGE_FAILED, e);
        }
    }
}
