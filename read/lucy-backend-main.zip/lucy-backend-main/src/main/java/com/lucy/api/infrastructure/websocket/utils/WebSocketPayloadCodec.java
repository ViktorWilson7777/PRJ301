package com.lucy.api.infrastructure.websocket.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lucy.api.infrastructure.websocket.enums.WebSocketMessageType;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class WebSocketPayloadCodec {

    ObjectMapper objectMapper;

    @SuppressWarnings("unchecked")
    public WebSocketMessageType getMessageType(String json) {
        try {
            Map<String, Object> map = objectMapper.readValue(json, Map.class);
            Object type = map.get("type");
            if (type instanceof String typeStr) {
                return WebSocketMessageType.valueOf(typeStr);
            }
        } catch (Exception e) {
            log.error("Failed to parse WebSocket message type", e);
        }
        return null;
    }

    public <T> T parseMessage(String json, Class<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (Exception e) {
            log.error("Failed to parse WebSocket message", e);
            return null;
        }
    }

    public String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            log.error("Failed to serialize WebSocket message", e);
            return null;
        }
    }
}
