package com.lucy.api.modules.agora.exception;

public class AgoraConfigException extends RuntimeException {
    public AgoraConfigException(String message) {
        super(message);
    }
}
