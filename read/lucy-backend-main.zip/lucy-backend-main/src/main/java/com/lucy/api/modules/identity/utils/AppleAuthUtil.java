package com.lucy.api.modules.identity.utils;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWKSecurityContext;
import com.nimbusds.jwt.SignedJWT;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@RequiredArgsConstructor
public class AppleAuthUtil {
    private static final String APPLE_ISSUER = "https://appleid.apple.com";
    private static final URL APPLE_JWKS_URL = buildAppleJwksUrl();

    private final JWKSource<JWKSecurityContext> appleJwkSource =
            new RemoteJWKSet<>(APPLE_JWKS_URL);

    @Value("${apple.client-id}")
    String clientId;

    public Map<String, Object> verifyIdentityToken(String identityToken) {
        return verifySignedToken(identityToken);
    }

    public Map<String, Object> verifySignedToken(String signedToken) {
        try {
            SignedJWT jwt = SignedJWT.parse(signedToken);

            JWSAlgorithm algorithm = jwt.getHeader().getAlgorithm();
            if (!JWSAlgorithm.RS256.equals(algorithm)) {
                throw new IllegalArgumentException("Unsupported Apple token algorithm.");
            }

            String keyId = jwt.getHeader().getKeyID();
            if (keyId == null || keyId.isBlank()) {
                throw new IllegalArgumentException("Missing key id in Apple token header.");
            }

            List<JWK> jwks = appleJwkSource.get(
                    new com.nimbusds.jose.jwk.JWKSelector(
                            new com.nimbusds.jose.jwk.JWKMatcher.Builder()
                                    .keyID(keyId)
                                    .build()
                    ),
                    null
            );

            if (jwks.isEmpty()) {
                throw new IllegalArgumentException("Unable to resolve Apple signing key.");
            }

            RSAKey rsaKey = (RSAKey) jwks.getFirst();
            RSASSAVerifier verifier = new RSASSAVerifier(rsaKey.toRSAPublicKey());
            if (!jwt.verify(verifier)) {
                throw new IllegalArgumentException("Invalid Apple identity token signature.");
            }

            var claims = jwt.getJWTClaimsSet();
            if (!APPLE_ISSUER.equals(claims.getIssuer())) {
                throw new IllegalArgumentException("Invalid Apple token issuer.");
            }

            if (!claims.getAudience().contains(clientId)) {
                throw new IllegalArgumentException("Invalid Apple token audience.");
            }

            Date expiration = claims.getExpirationTime();
            if (expiration == null || expiration.toInstant().isBefore(Instant.now())) {
                throw new IllegalArgumentException("Apple token has expired.");
            }

            return claims.getClaims();
        } catch (ParseException | JOSEException e) {
            throw new IllegalArgumentException("Invalid Apple signed token.", e);
        }
    }

    public static String extractSubject(Map<String, Object> claims) {
        Object directSub = claims.get("sub");
        if (directSub instanceof String sub && !sub.isBlank()) {
            return sub;
        }

        Object eventObj = claims.get("events");
        if (eventObj instanceof Map<?, ?> eventMap) {
            Object accountChangeObj = eventMap.get("account-change");
            if (accountChangeObj instanceof Map<?, ?> accountChangeMap) {
                Object nestedSub = accountChangeMap.get("sub");
                if (nestedSub instanceof String sub && !sub.isBlank()) {
                    return sub;
                }
            }
        }

        Object dataObj = claims.get("data");
        if (dataObj instanceof Map<?, ?> dataMap) {
            Object nestedSub = dataMap.get("sub");
            if (nestedSub instanceof String sub && !sub.isBlank()) {
                return sub;
            }
        }

        return null;
    }

    public static String extractEventType(Map<String, Object> claims) {
        Object event = claims.get("event");
        if (event instanceof String value && !value.isBlank()) {
            return value;
        }

        Object eventsObj = claims.get("events");
        if (eventsObj instanceof Map<?, ?> events) {
            Object accountChangeObj = events.get("account-change");
            if (accountChangeObj instanceof Map<?, ?> accountChangeMap) {
                Object eventNameObj = accountChangeMap.get("type");
                if (eventNameObj instanceof String type && !type.isBlank()) {
                    return type;
                }
                Object eventObj = accountChangeMap.get("event");
                if (eventObj instanceof String type && !type.isBlank()) {
                    return type;
                }
            }

            String firstKey = events.keySet().stream()
                    .filter(Objects::nonNull)
                    .map(Object::toString)
                    .findFirst()
                    .orElse(null);
            if (firstKey != null && !firstKey.isBlank()) {
                return firstKey;
            }
        }

        return "unknown";
    }

    private static URL buildAppleJwksUrl() {
        try {
            return new URL("https://appleid.apple.com/auth/keys");
        } catch (MalformedURLException e) {
            throw new IllegalStateException("Invalid Apple JWKS URL.", e);
        }
    }
}
