package com.lucy.api.modules.event.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.UUID;

/**
 * Response DTO broadcasted when a user joins a room
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserJoinedResponse {
    private UUID roomId;
    private UUID userId;
    private String displayName;
    private boolean isMonitor;
    private Instant joinedAt;
    private int totalParticipants;
    private Integer rtcUid;
}
