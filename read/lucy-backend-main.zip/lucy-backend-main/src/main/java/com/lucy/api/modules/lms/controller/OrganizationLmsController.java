package com.lucy.api.modules.lms.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.lms.dto.request.CourseRunUpsertRequest;
import com.lucy.api.modules.lms.dto.request.CourseUpsertRequest;
import com.lucy.api.modules.lms.dto.request.ProgramUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ChapterResponse;
import com.lucy.api.modules.lms.dto.response.CourseResponse;
import com.lucy.api.modules.lms.dto.response.CourseRunResponse;
import com.lucy.api.modules.lms.dto.response.ProgramResponse;
import com.lucy.api.modules.lms.service.api.ChapterService;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import com.lucy.api.modules.lms.service.api.CourseService;
import com.lucy.api.modules.lms.service.api.LessonService;
import com.lucy.api.modules.lms.service.api.ProgramService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/organizations/{organizationId}")
@Tag(name = "Organization LMS", description = "Organization LMS catalog APIs")
public class OrganizationLmsController {
    private final ProgramService programService;
    private final CourseService courseService;
    private final CourseRunService courseRunService;
    private final ChapterService chapterService;
    private final LessonService lessonService;

    @PostMapping("/programs")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ProgramResponse>> createProgram(@PathVariable String organizationId, @Valid @RequestBody ProgramUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<ProgramResponse>builder().success(true).data(programService.createForOrganization(organizationId, request)).build());
    }

    @GetMapping("/programs")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<ProgramResponse>>> getPrograms(@PathVariable String organizationId) {
        return ResponseEntity.ok(ApiResponse.<List<ProgramResponse>>builder().success(true).data(programService.findAllByOrganization(organizationId)).build());
    }

    @GetMapping("/programs/{programId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ProgramResponse>> getProgram(@PathVariable String organizationId, @PathVariable String programId) {
        return ResponseEntity.ok(ApiResponse.<ProgramResponse>builder().success(true).data(programService.findByOrganizationAndId(organizationId, programId)).build());
    }

    @PutMapping("/programs/{programId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ProgramResponse>> updateProgram(@PathVariable String organizationId, @PathVariable String programId, @Valid @RequestBody ProgramUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<ProgramResponse>builder().success(true).data(programService.updateForOrganization(organizationId, programId, request)).build());
    }

    @DeleteMapping("/programs/{programId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteProgram(@PathVariable String organizationId, @PathVariable String programId) {
        programService.deleteForOrganization(organizationId, programId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Organization program deleted successfully").build());
    }

    @PostMapping("/courses")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseResponse>> createCourse(@PathVariable String organizationId, @Valid @RequestBody CourseUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<CourseResponse>builder().success(true).data(courseService.createForOrganization(organizationId, request)).build());
    }

    @GetMapping("/courses")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getCourses(@PathVariable String organizationId, @RequestParam(required = false) String programId) {
        return ResponseEntity.ok(ApiResponse.<List<CourseResponse>>builder().success(true).data(courseService.findAllByOrganization(organizationId, programId)).build());
    }

    @GetMapping("/courses/{courseId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseResponse>> getCourse(@PathVariable String organizationId, @PathVariable String courseId) {
        return ResponseEntity.ok(ApiResponse.<CourseResponse>builder().success(true).data(courseService.findByOrganizationAndId(organizationId, courseId)).build());
    }

    @PutMapping("/courses/{courseId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseResponse>> updateCourse(@PathVariable String organizationId, @PathVariable String courseId, @Valid @RequestBody CourseUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<CourseResponse>builder().success(true).data(courseService.updateForOrganization(organizationId, courseId, request)).build());
    }

    @DeleteMapping("/courses/{courseId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteCourse(@PathVariable String organizationId, @PathVariable String courseId) {
        courseService.deleteForOrganization(organizationId, courseId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Organization course deleted successfully").build());
    }

    @PostMapping("/course-runs")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseRunResponse>> createCourseRun(@PathVariable String organizationId, @Valid @RequestBody CourseRunUpsertRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.createForOrganization(organizationId, request)).build());
    }

    @GetMapping("/course-runs")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<CourseRunResponse>>> getCourseRuns(@PathVariable String organizationId, @RequestParam(required = false) String courseId) {
        return ResponseEntity.ok(ApiResponse.<List<CourseRunResponse>>builder().success(true).data(courseRunService.findAllByOrganization(organizationId, courseId)).build());
    }

    @GetMapping("/course-runs/{courseRunId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseRunResponse>> getCourseRun(@PathVariable String organizationId, @PathVariable String courseRunId) {
        return ResponseEntity.ok(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.findByOrganizationAndId(organizationId, courseRunId)).build());
    }

    @GetMapping("/course-runs/{courseRunId}/roadmap")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<ChapterResponse>>> getRoadmap(@PathVariable String organizationId, @PathVariable String courseRunId) {
        courseRunService.findByOrganizationAndId(organizationId, courseRunId);
        List<ChapterResponse> chapters = chapterService.findAll(courseRunId);
        for (ChapterResponse chapter : chapters) {
            chapter.setLessons(lessonService.findAll(chapter.getId()));
        }
        return ResponseEntity.ok(ApiResponse.<List<ChapterResponse>>builder().success(true).data(chapters).build());
    }

    @PutMapping("/course-runs/{courseRunId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CourseRunResponse>> updateCourseRun(@PathVariable String organizationId, @PathVariable String courseRunId, @Valid @RequestBody CourseRunUpsertRequest request) {
        return ResponseEntity.ok(ApiResponse.<CourseRunResponse>builder().success(true).data(courseRunService.updateForOrganization(organizationId, courseRunId, request)).build());
    }

    @DeleteMapping("/course-runs/{courseRunId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<String>> deleteCourseRun(@PathVariable String organizationId, @PathVariable String courseRunId) {
        courseRunService.deleteForOrganization(organizationId, courseRunId);
        return ResponseEntity.ok(ApiResponse.<String>builder().success(true).data("Organization course run deleted successfully").build());
    }
}
