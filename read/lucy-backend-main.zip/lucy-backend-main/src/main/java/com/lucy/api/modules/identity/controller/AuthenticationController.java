package com.lucy.api.modules.identity.controller;

import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.modules.identity.dtos.request.auth.AuthenticationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.AppleAuthRequest;
import com.lucy.api.modules.identity.dtos.request.auth.AppleNotificationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ChangePasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ForgotPasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.GoogleAuthRequest;
import com.lucy.api.modules.identity.dtos.request.auth.IntrospectRequest;
import com.lucy.api.modules.identity.dtos.request.auth.RegisterRequest;
import com.lucy.api.modules.identity.dtos.request.auth.RefreshTokenRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ResendVerificationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.VerifyEmailRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ResetPasswordRequest;
import com.lucy.api.modules.identity.dtos.request.auth.VerifyOtpRequest;
import com.lucy.api.modules.identity.dtos.response.auth.AuthenticationResponse;
import com.lucy.api.modules.identity.dtos.response.auth.IntrospectResponse;
import com.lucy.api.modules.identity.service.interfaces.AuthenticationService;
import com.lucy.api.modules.identity.service.interfaces.PasswordService;
import com.nimbusds.jose.JOSEException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.GeneralSecurityException;
import java.text.ParseException;
import java.io.IOException;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthenticationController {
    private final AuthenticationService authenticationService;
    private final PasswordService passwordService;
    private final MessageSource messageSource;

    @PostMapping("/token")
    ResponseEntity<ApiResponse<AuthenticationResponse>> authenticate(@RequestBody AuthenticationRequest request) {
        ApiResponse<AuthenticationResponse> response = ApiResponse.<AuthenticationResponse>builder()
                .success(true)
                .message(messageSource.getMessage("auth.login_success", null, LocaleContextHolder.getLocale()))
                .data(authenticationService.authenticate(request))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/refresh")
    ResponseEntity<ApiResponse<AuthenticationResponse>> refresh(@RequestBody RefreshTokenRequest request) throws ParseException, JOSEException {
        ApiResponse<AuthenticationResponse> response = ApiResponse.<AuthenticationResponse>builder()
                .success(true)
                .message(messageSource.getMessage("auth.login_success", null, LocaleContextHolder.getLocale()))
                .data(authenticationService.refreshToken(request))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/google")
    ResponseEntity<ApiResponse<AuthenticationResponse>> authenticateWithGoogle(@Valid @RequestBody GoogleAuthRequest request) throws GeneralSecurityException, IOException {
        ApiResponse<AuthenticationResponse> response = ApiResponse.<AuthenticationResponse>builder()
                .success(true)
                .message(messageSource.getMessage("auth.login_success", null, LocaleContextHolder.getLocale()))
                .data(authenticationService.authenticateWithGoogle(request))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/apple")
    ResponseEntity<ApiResponse<AuthenticationResponse>> authenticateWithApple(@Valid @RequestBody AppleAuthRequest request) {
        ApiResponse<AuthenticationResponse> response = ApiResponse.<AuthenticationResponse>builder()
                .success(true)
                .message(messageSource.getMessage("auth.login_success", null, LocaleContextHolder.getLocale()))
                .data(authenticationService.authenticateWithApple(request))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/apple/notifications")
    ResponseEntity<ApiResponse<Void>> handleAppleServerNotification(@Valid @RequestBody AppleNotificationRequest request) {
        authenticationService.handleAppleServerNotification(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.apple_notification_received", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/introspect")
    ResponseEntity<ApiResponse<IntrospectResponse>> introspect(@RequestBody IntrospectRequest request) throws ParseException {
        ApiResponse<IntrospectResponse> response = ApiResponse.<IntrospectResponse>builder()
                .success(true)
                .message(messageSource.getMessage("auth.introspect_success", null, LocaleContextHolder.getLocale()))
                .data(authenticationService.introspect(request))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/register")
    ResponseEntity<ApiResponse<Void>> register(@Valid @RequestBody RegisterRequest request) {
        authenticationService.register(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.register_success", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/verify-email")
    ResponseEntity<ApiResponse<Void>> verifyEmail(@Valid @RequestBody VerifyEmailRequest request) {
        authenticationService.verifyEmail(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.verify_email_success", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/resend-verification")
    ResponseEntity<ApiResponse<Void>> resendVerification(@Valid @RequestBody ResendVerificationRequest request) {
        authenticationService.resendVerificationEmail(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.resend_verification_success", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/forgot-password")
    ResponseEntity<ApiResponse<Void>> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request) {
        passwordService.forgotPassword(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.forgot_password_success", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/verify-otp")
    ResponseEntity<ApiResponse<Void>> verifyOtp(@Valid @RequestBody VerifyOtpRequest request) {
        passwordService.verifyOtp(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.verify_otp_success", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/reset-password")
    ResponseEntity<ApiResponse<Void>> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        passwordService.resetPassword(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.reset_password_success", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping("/change-password")
    ResponseEntity<ApiResponse<Void>> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        passwordService.changePassword(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.change_password_success", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    ResponseEntity<ApiResponse<Void>> logout(@RequestBody RefreshTokenRequest request) throws ParseException, JOSEException {
        authenticationService.logout(request);
        ApiResponse<Void> response = ApiResponse.<Void>builder()
                .success(true)
                .message(messageSource.getMessage("auth.logout_success", null, LocaleContextHolder.getLocale()))
                .build();
        return ResponseEntity.ok(response);
    }
}
