package com.lucy.api.modules.lms.progress.service.impl;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.lms.entity.Enrollment;
import com.lucy.api.modules.lms.entity.Lesson;
import com.lucy.api.modules.lms.entity.enums.EnrollmentStatus;
import com.lucy.api.modules.lms.progress.dto.request.UpsertLessonProgressRequest;
import com.lucy.api.modules.lms.progress.dto.response.CourseRunProgressSummaryResponse;
import com.lucy.api.modules.lms.progress.dto.response.LessonProgressResponse;
import com.lucy.api.modules.lms.progress.dto.request.SubmitQuizAttemptRequest;
import com.lucy.api.modules.lms.progress.dto.response.QuizAttemptResultResponse;
import com.lucy.api.modules.lms.progress.entity.LessonProgress;
import com.lucy.api.modules.lms.progress.enums.LessonProgressStatus;
import com.lucy.api.modules.lms.progress.repository.LessonProgressRepository;
import com.lucy.api.modules.lms.progress.service.api.LearningProgressService;
import com.lucy.api.modules.lms.repository.EnrollmentRepository;
import com.lucy.api.modules.lms.repository.LessonRepository;
import com.lucy.api.modules.lms.service.LmsAccessService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class LearningProgressServiceImpl implements LearningProgressService {

    EnrollmentRepository enrollmentRepository;
    LessonRepository lessonRepository;
    LessonProgressRepository lessonProgressRepository;
    LmsAccessService lmsAccessService;

    @Override
    @Transactional(readOnly = true)
    public CourseRunProgressSummaryResponse getMyCourseRunSummary(String userId, String courseRunId) {
        Enrollment enrollment = getActiveEnrollmentOrThrow(userId, courseRunId);

        long totalLessons = lessonRepository.countByChapter_CourseRun_Id(courseRunId);
        long completedLessons = lessonProgressRepository.countCompletedByEnrollmentId(enrollment.getId());

        Integer progressPercent = null;
        if (totalLessons > 0) {
            progressPercent = (int) Math.round((completedLessons * 100.0) / totalLessons);
        }

        Instant lastUpdatedAt = lessonProgressRepository.findAllByEnrollment_Id(enrollment.getId()).stream()
                .map(LessonProgress::getUpdatedAt)
                .filter(v -> v != null)
                .max(Comparator.naturalOrder())
                .orElse(null);

        return CourseRunProgressSummaryResponse.builder()
                .courseRunId(courseRunId)
                .enrollmentId(enrollment.getId())
                .totalLessons(totalLessons)
                .completedLessons(completedLessons)
                .progressPercent(progressPercent)
                .lastUpdatedAt(lastUpdatedAt)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public List<LessonProgressResponse> getMyLessonProgresses(String userId, String courseRunId) {
        Enrollment enrollment = getActiveEnrollmentOrThrow(userId, courseRunId);
        return lessonProgressRepository.findAllByEnrollment_Id(enrollment.getId()).stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    @Transactional
    public LessonProgressResponse upsertMyLessonProgress(String userId, String courseRunId, String lessonId, UpsertLessonProgressRequest request) {
        Enrollment enrollment = getActiveEnrollmentOrThrow(userId, courseRunId);

        Lesson lesson = lessonRepository.findById(lessonId)
                .orElseThrow(() -> new AppException("lesson.not_found", HttpStatus.NOT_FOUND));

        // Ensure lesson belongs to the courseRun (chapter.courseRun.id)
        String lessonCourseRunId = Optional.ofNullable(lesson.getChapter())
                .map(c -> c.getCourseRun())
                .map(cr -> cr.getId())
                .orElse(null);
        if (lessonCourseRunId == null || !lessonCourseRunId.equals(courseRunId)) {
            throw new AppException("progress.lesson_not_in_course_run", HttpStatus.BAD_REQUEST);
        }

        LessonProgress existing = lessonProgressRepository
                .findByEnrollment_IdAndLesson_Id(enrollment.getId(), lessonId)
                .orElse(null);

        LessonProgressStatus status = normalizeStatus(request, existing);
        Integer percent = normalizePercent(request, status, existing);
        Integer lastPos = request != null ? request.getLastPositionSeconds() : null;

        LessonProgress entity = existing != null ? existing : LessonProgress.builder()
                .enrollment(enrollment)
                .lesson(lesson)
                .build();

        entity.setStatus(status);
        entity.setProgressPercent(percent);
        entity.setLastPositionSeconds(lastPos);
        if (status == LessonProgressStatus.COMPLETED && entity.getCompletedAt() == null) {
            entity.setCompletedAt(Instant.now());
        }
        if (status != LessonProgressStatus.COMPLETED) {
            entity.setCompletedAt(null);
        }

        LessonProgress saved = lessonProgressRepository.save(entity);

        // Check if course run is completed
        long totalLessons = lessonRepository.countByChapter_CourseRun_Id(courseRunId);
        long completedLessons = lessonProgressRepository.countCompletedByEnrollmentId(enrollment.getId());
        if (totalLessons > 0 && completedLessons >= totalLessons) {
            enrollment.setStatus(EnrollmentStatus.COMPLETED);
            enrollment.setCompletedAt(Instant.now());
            enrollmentRepository.save(enrollment);
        }

        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public QuizAttemptResultResponse submitMyQuizAttempt(String userId, String courseRunId, String lessonId, SubmitQuizAttemptRequest request) {
        getActiveEnrollmentOrThrow(userId, courseRunId);

        Lesson lesson = lessonRepository.findById(lessonId)
                .orElseThrow(() -> new AppException("lesson.not_found", HttpStatus.NOT_FOUND));

        String lessonCourseRunId = Optional.ofNullable(lesson.getChapter())
                .map(c -> c.getCourseRun())
                .map(cr -> cr.getId())
                .orElse(null);
        if (lessonCourseRunId == null || !lessonCourseRunId.equals(courseRunId)) {
            throw new AppException("progress.lesson_not_in_course_run", HttpStatus.BAD_REQUEST);
        }

        String type = lesson.getType() != null ? lesson.getType().toUpperCase() : "";
        if (!type.contains("QUIZ")) {
            throw new AppException("progress.lesson_not_quiz", HttpStatus.BAD_REQUEST);
        }

        Map<String, Object> contentData = lesson.getContentData() != null ? lesson.getContentData() : Map.of();
        Object questionsRaw = contentData.get("questions");
        if (!(questionsRaw instanceof List<?> questions)) {
            throw new AppException("progress.quiz_questions_missing", HttpStatus.BAD_REQUEST);
        }

        Map<Integer, Integer> selectedByQuestion = new HashMap<>();
        for (SubmitQuizAttemptRequest.QuizAnswerRequest answer : request.getAnswers()) {
            selectedByQuestion.put(answer.getQuestionIndex(), answer.getSelectedOptionIndex());
        }

        int totalQuestions = questions.size();
        int answeredQuestions = 0;
        int correctAnswers = 0;

        for (int i = 0; i < questions.size(); i++) {
            Object qRaw = questions.get(i);
            if (!(qRaw instanceof Map<?, ?> question)) {
                continue;
            }
            Integer selectedIndex = selectedByQuestion.get(i);
            if (selectedIndex == null) {
                continue;
            }
            answeredQuestions++;

            int correctIndex = resolveCorrectOptionIndex(question);
            if (correctIndex >= 0 && selectedIndex == correctIndex) {
                correctAnswers++;
            }
        }

        int scorePercent = totalQuestions == 0
                ? 0
                : (int) Math.round((correctAnswers * 100.0) / totalQuestions);
        int passPercent = resolvePassPercent(contentData);
        boolean passed = totalQuestions > 0 && scorePercent >= passPercent;

        if (passed) {
                UpsertLessonProgressRequest progressReq = new UpsertLessonProgressRequest();
                progressReq.setStatus(LessonProgressStatus.COMPLETED);
                progressReq.setProgressPercent(100);
                upsertMyLessonProgress(userId, courseRunId, lessonId, progressReq);
        }

        return QuizAttemptResultResponse.builder()
                .courseRunId(courseRunId)
                .lessonId(lessonId)
                .totalQuestions(totalQuestions)
                .answeredQuestions(answeredQuestions)
                .correctAnswers(correctAnswers)
                .scorePercent(scorePercent)
                .passPercent(passPercent)
                .passed(passed)
                .attemptedAt(Instant.now())
                .build();
    }

    private Enrollment getActiveEnrollmentOrThrow(String userId, String courseRunId) {
        Enrollment enrollment = enrollmentRepository.findByUser_IdAndCourseRun_Id(userId, courseRunId)
                .orElseThrow(() -> new AppException("enrollment.not_found", HttpStatus.NOT_FOUND));
        if (enrollment.getStatus() == EnrollmentStatus.SUSPENDED) {
            throw new AppException("enrollment.inactive", HttpStatus.FORBIDDEN);
        }
        lmsAccessService.assertCanReadCourseRun(enrollment.getCourseRun());
        return enrollment;
    }

    private LessonProgressStatus normalizeStatus(UpsertLessonProgressRequest request, LessonProgress existing) {
        if (request == null) {
            return existing != null ? existing.getStatus() : LessonProgressStatus.IN_PROGRESS;
        }
        if (request.getStatus() != null) return request.getStatus();
        Integer p = request.getProgressPercent();
        if (p != null && p >= 100) return LessonProgressStatus.COMPLETED;
        if (p != null && p <= 0 && existing == null) return LessonProgressStatus.NOT_STARTED;
        return LessonProgressStatus.IN_PROGRESS;
    }

    private int resolveCorrectOptionIndex(Map<?, ?> question) {
        Object correctIndexRaw = question.get("correctIndex");
        if (correctIndexRaw instanceof Number number) {
            return number.intValue();
        }

        Object optionsRaw = question.get("options");
        if (!(optionsRaw instanceof List<?> options)) {
            return -1;
        }

        for (int i = 0; i < options.size(); i++) {
            Object optionRaw = options.get(i);
            if (!(optionRaw instanceof Map<?, ?> optionMap)) {
                continue;
            }
            Object isCorrect = optionMap.get("isCorrect");
            if (Boolean.TRUE.equals(isCorrect)) {
                return i;
            }
        }

        return -1;
    }

    private int resolvePassPercent(Map<String, Object> contentData) {
        Object passRaw = contentData.get("passPercent");
        if (passRaw instanceof Number number) {
            int value = number.intValue();
            return Math.max(0, Math.min(100, value));
        }
        return 70;
    }

    private Integer normalizePercent(UpsertLessonProgressRequest request, LessonProgressStatus status, LessonProgress existing) {
        Integer percent = request != null ? request.getProgressPercent() : null;
        if (status == LessonProgressStatus.COMPLETED) return 100;
        if (percent == null) return existing != null ? existing.getProgressPercent() : null;
        return Math.max(0, Math.min(100, percent));
    }

    private LessonProgressResponse toResponse(LessonProgress entity) {
        return LessonProgressResponse.builder()
                .id(entity.getId())
                .enrollmentId(entity.getEnrollment() != null ? entity.getEnrollment().getId() : null)
                .lessonId(entity.getLesson() != null ? entity.getLesson().getId() : null)
                .status(entity.getStatus())
                .progressPercent(entity.getProgressPercent())
                .lastPositionSeconds(entity.getLastPositionSeconds())
                .completedAt(entity.getCompletedAt())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .build();
    }
}
