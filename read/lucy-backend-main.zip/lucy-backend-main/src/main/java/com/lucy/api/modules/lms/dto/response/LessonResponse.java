package com.lucy.api.modules.lms.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class LessonResponse {
    String id;
    String chapterId;
    String chapterTitle;
    String type;
    String title;
    String description;
    Integer orderIndex;
    Boolean isHidden;
    Boolean isOptional;
    Map<String, Object> contentData;
    Instant createdAt;
    Instant updatedAt;
}
