package com.lucy.api.modules.audit.constants;

public final class AuditEntityType {

    private AuditEntityType() {}

    // LMS Domain
    public static final String PROGRAM = "Program";
    public static final String COURSE  = "Course";
    public static final String CHAPTER = "Chapter";
    public static final String LESSON  = "Lesson";
    public static final String RELATIONSHIP = "Relationship";

}
