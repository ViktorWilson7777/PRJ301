package com.lucy.api.modules.event.service;

import org.springframework.stereotype.Component;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Component
public class EventWebSocketSessionRegistry {
    private final ConcurrentMap<String, SessionBinding> bindings = new ConcurrentHashMap<>();

    public void bind(String sessionId, UUID userId, UUID roomId) {
        if (sessionId == null || userId == null || roomId == null) {
            return;
        }
        bindings.put(sessionId, new SessionBinding(userId, roomId));
    }

    public SessionBinding unbind(String sessionId) {
        if (sessionId == null) {
            return null;
        }
        return bindings.remove(sessionId);
    }

    public record SessionBinding(UUID userId, UUID roomId) {
    }
}
