package com.lucy.api.modules.messaging.repository;

import com.lucy.api.modules.messaging.entity.ChatMessage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, String> {

    Page<ChatMessage> findByConversationIdOrderByCreatedAtDesc(String conversationId, Pageable pageable);

    Optional<ChatMessage> findFirstByConversationIdOrderByCreatedAtDesc(String conversationId);

    @Modifying
    @Transactional
    @Query(value = """
            DELETE FROM chat_message_attachments
            WHERE message_id IN (
                SELECT id FROM chat_messages WHERE sender_id IN (:userIds)
            )
            """, nativeQuery = true)
    void deleteAttachmentsBySenderIds(@Param("userIds") List<String> userIds);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM chat_messages WHERE sender_id IN (:userIds)", nativeQuery = true)
    void deleteAllBySenderIds(@Param("userIds") List<String> userIds);
}
