package com.lucy.api.common.dtos.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SortRequest {
    @NotBlank(message = "common.field_required")
    @Pattern(regexp = "^(?i)(asc|desc)$", message = "common.enum_invalid")
    String direction;

    @NotBlank(message = "common.field_required")
    String field;
}
