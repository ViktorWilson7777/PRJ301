package com.lucy.api.modules.story.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CompleteOnboardingSurveyRequest {
    @NotBlank(message = "common.invalid_param")
    @Size(max = 120, message = "common.invalid_param")
    String specialty;

    @Size(max = 20, message = "common.invalid_param")
    List<@Size(max = 60, message = "common.invalid_param") String> interests;
}
