package com.lucy.api.modules.audit.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface AuditAction {

    /**
     * The action code, e.g. "user.create", "role.update", "course.delete".
     * Maps to {@code audit_logs.action}.
     */
    String action();

    /**
     * The name of the affected entity, e.g. "User", "Role", "Course".
     * Maps to {@code audit_logs.entity_type}.
     */
    String entityType() default "";
}
