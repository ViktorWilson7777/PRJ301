package com.lucy.api.modules.lms.dto.response;

import com.lucy.api.modules.lms.entity.enums.EnrollmentMethod;
import com.lucy.api.modules.lms.entity.enums.EnrollmentRole;
import com.lucy.api.modules.lms.entity.enums.EnrollmentStatus;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EnrollmentResponse {
    String id;

    // User info
    String userId;
    String userDisplayName;
    String userEmail;
    String userAvatarUrl;

    // CourseRun info
    String courseRunId;
    String courseRunCode;
    LmsAccessScope accessScope;
    String organizationId;

    // Enrollment fields
    EnrollmentStatus status;
    EnrollmentRole role;
    EnrollmentMethod enrolmentMethod;
    Instant lastAccessedAt;
    Instant enrolledAt;
    Instant completedAt;
    Integer progressPercent;

    // Audit
    Instant createdAt;
    Instant updatedAt;
}
