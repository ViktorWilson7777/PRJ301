package com.lucy.api.modules.identity.cron;

import com.lucy.api.modules.audit.repository.AuditLogRepository;
import com.lucy.api.modules.event.repository.RoomChatMessageRepository;
import com.lucy.api.modules.event.repository.RoomCommentRepository;
import com.lucy.api.modules.event.repository.RoomEventRepository;
import com.lucy.api.modules.event.repository.RoomInterestRepository;
import com.lucy.api.modules.event.repository.RoomLikeRepository;
import com.lucy.api.modules.event.repository.RoomParticipantRepository;
import com.lucy.api.modules.event.repository.RoomParticipantSessionRepository;
import com.lucy.api.modules.event.repository.RoomRepository;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.SessionRepository;
import com.lucy.api.modules.identity.repository.UserIdentityRepository;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.lms.progress.repository.LessonProgressRepository;
import com.lucy.api.modules.lms.repository.EnrollmentRepository;
import com.lucy.api.modules.messaging.repository.ChatMessageRepository;
import com.lucy.api.modules.messaging.repository.ConversationParticipantRepository;
import com.lucy.api.modules.notifications.repository.NotificationRepository;
import com.lucy.api.modules.notifications.repository.UserDeviceRepository;
import com.lucy.api.modules.relationship.repository.RelationshipRepository;
import com.lucy.api.modules.streak.repository.StreakLogRepository;
import com.lucy.api.modules.streak.repository.StreakRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class AccountDeletionPurgeCronJob {

    private final UserRepository userRepository;
    private final SessionRepository sessionRepository;
    private final UserIdentityRepository userIdentityRepository;
        private final UserDeviceRepository userDeviceRepository;
    private final NotificationRepository notificationRepository;
    private final StreakLogRepository streakLogRepository;
    private final StreakRepository streakRepository;
    private final RelationshipRepository relationshipRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final LessonProgressRepository lessonProgressRepository;
    private final ConversationParticipantRepository conversationParticipantRepository;
    private final ChatMessageRepository chatMessageRepository;
    private final RoomRepository roomRepository;
    private final RoomCommentRepository roomCommentRepository;
    private final RoomLikeRepository roomLikeRepository;
    private final RoomInterestRepository roomInterestRepository;
    private final RoomEventRepository roomEventRepository;
    private final RoomParticipantRepository roomParticipantRepository;
    private final RoomParticipantSessionRepository roomParticipantSessionRepository;
    private final RoomChatMessageRepository roomChatMessageRepository;
    private final AuditLogRepository auditLogRepository;

    @Value("${zenleader.account-deletion.retention-days:90}")
    private long retentionDays;

    /**
     * Daily hard-delete for accounts that were soft-deleted before retention window.
     * Removes user and all directly related records for strict data-erasure policy.
     */
    @Scheduled(cron = "${zenleader.account-deletion.cron:0 30 3 * * *}")
    @Transactional
    public void purgeExpiredDeletedAccounts() {
        final Instant cutoff = Instant.now().minus(retentionDays, ChronoUnit.DAYS);

        int processed = 0;
        while (true) {
            final List<User> candidates =
                    userRepository.findTop200ByDeletedAtIsNotNullAndDeletedAtBefore(cutoff);
            if (candidates.isEmpty()) {
                break;
            }

            final List<String> userIds = candidates.stream()
                    .map(User::getId)
                    .collect(Collectors.toList());
            final List<UUID> userUuids = userIds.stream()
                    .map(this::toUuidOrNull)
                    .filter(java.util.Objects::nonNull)
                    .toList();

            // 1) Auth & identity artifacts
            sessionRepository.deleteAllByUser_IdIn(userIds);
            userIdentityRepository.deleteAllByUser_IdIn(userIds);
            userDeviceRepository.deleteAllByUserIdIn(userIds);
            notificationRepository.deleteAllByUser_IdIn(userIds);

            // 2) User-domain dependencies
            streakLogRepository.deleteAllByUser_IdIn(userIds);
            streakRepository.deleteAllByUser_IdIn(userIds);
            relationshipRepository.deleteAllByRequester_IdInOrAddressee_IdIn(userIds, userIds);

            final List<String> enrollmentIds = enrollmentRepository.findAllByUser_IdIn(userIds)
                    .stream()
                    .map(enrollment -> enrollment.getId())
                    .toList();
            if (!enrollmentIds.isEmpty()) {
                lessonProgressRepository.deleteAllByEnrollment_IdIn(enrollmentIds);
            }
            enrollmentRepository.deleteAllByUser_IdIn(userIds);

            // 3) Messaging dependencies
            chatMessageRepository.deleteAttachmentsBySenderIds(userIds);
            chatMessageRepository.deleteAllBySenderIds(userIds);
            conversationParticipantRepository.deleteAllByUser_IdIn(userIds);

            // 4) Event(room) dependencies (by actor + authored rooms)
            if (!userUuids.isEmpty()) {
                final List<UUID> authoredRoomIds = roomRepository.findIdsByMonitorIdIn(userUuids);

                roomLikeRepository.deleteAllByUserIdIn(userUuids);
                roomInterestRepository.deleteAllByUserIdIn(userUuids);
                roomCommentRepository.deleteAllByUserIdIn(userUuids);
                roomEventRepository.deleteAllByUserIdIn(userUuids);
                roomParticipantRepository.deleteAllByUserIdIn(userUuids);
                roomParticipantSessionRepository.deleteAllByUserIdIn(userUuids);
                roomChatMessageRepository.deleteAllBySenderIdIn(userUuids);

                if (!authoredRoomIds.isEmpty()) {
                    roomChatMessageRepository.deleteAllByRoomIdIn(authoredRoomIds);
                    roomParticipantSessionRepository.deleteAllByRoomIdIn(authoredRoomIds);
                    roomParticipantRepository.deleteAllByRoomIdIn(authoredRoomIds);
                    roomEventRepository.deleteAllByRoomIdIn(authoredRoomIds);
                    roomCommentRepository.deleteAllByRoomIdIn(authoredRoomIds);
                    roomLikeRepository.deleteAllByRoomIdIn(authoredRoomIds);
                    roomInterestRepository.deleteAllByRoomIdIn(authoredRoomIds);
                    roomRepository.deleteAllByIdInBatch(authoredRoomIds);
                }
            }

            // 5) Audit logs (best-effort by UUID conversion)
            final List<UUID> actorIds = new ArrayList<>();
            for (String userId : userIds) {
                try {
                    actorIds.add(UUID.fromString(userId));
                } catch (IllegalArgumentException ignored) {
                    // Skip invalid UUID format for audit actor id.
                }
            }
            if (!actorIds.isEmpty()) {
                auditLogRepository.deleteAllByActorUserIdIn(actorIds);
            }

            // 6) Remove user rows
            userRepository.deleteAllInBatch(candidates);
            processed += candidates.size();

            if (candidates.size() < 200) {
                break;
            }
        }

        if (processed > 0) {
            log.info("[AccountDeletionPurge] Hard-deleted {} account(s) and related data older than {} days", processed, retentionDays);
        }
    }

    private UUID toUuidOrNull(String raw) {
        try {
            return UUID.fromString(raw);
        } catch (Exception ignored) {
            return null;
        }
    }
}

