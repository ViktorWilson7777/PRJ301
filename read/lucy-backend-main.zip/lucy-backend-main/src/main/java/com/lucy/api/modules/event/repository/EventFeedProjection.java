package com.lucy.api.modules.event.repository;

import java.time.Instant;
import java.util.UUID;

public interface EventFeedProjection {
    UUID getId();
    String getTitle();
    String getDescription();
    String getTopic();
    String getCategory();
    String getLevel();
    String getStatus();
    Instant getEventDatetime();
    String getLocation();
    Integer getMaxParticipants();
    Integer getInterestedCount();
    Integer getLikesCount();
    Integer getCommentsCount();
    UUID getMonitorId();
}
