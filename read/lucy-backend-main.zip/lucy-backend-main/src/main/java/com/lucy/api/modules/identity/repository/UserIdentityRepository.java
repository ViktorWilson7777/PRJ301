package com.lucy.api.modules.identity.repository;

import com.lucy.api.modules.identity.entity.UserIdentity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserIdentityRepository extends JpaRepository<UserIdentity, String> {
    Optional<UserIdentity> findByProviderAndProviderUserId(String provider, String providerUserId);

    @Modifying
    @Transactional
    void deleteAllByUser_IdIn(List<String> userIds);
}
