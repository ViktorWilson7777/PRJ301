package com.lucy.api.modules.messaging.controller;

import com.lucy.api.common.constants.PaginationConstant;
import com.lucy.api.common.dtos.request.PagingRequest;
import com.lucy.api.common.dtos.request.SortRequest;
import com.lucy.api.common.dtos.response.ApiResponse;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.modules.identity.utils.IdentityUtils;
import com.lucy.api.modules.messaging.dto.request.EditMessageRequest;
import com.lucy.api.modules.messaging.dto.request.SendMessageRequest;
import com.lucy.api.modules.messaging.dto.response.ChatMessageResponse;
import com.lucy.api.modules.messaging.service.facade.MessagingFacade;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/messaging")
@RequiredArgsConstructor
@Tag(name = "Messaging Chat", description = "Gui va doc tin nhan")
public class MessagingChatController {

    private final MessagingFacade messagingFacade;

    @PostMapping("/messages")
    public ResponseEntity<ApiResponse<ChatMessageResponse>> sendMessage(
            @Valid @RequestBody SendMessageRequest request
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        ChatMessageResponse data = messagingFacade.sendMessage(
                request.getConversationId(),
                request.getPeerUserId(),
                userId,
                request.getText(),
                request.getAttachments(),
                request.getReplyToMessageId()
        );
        return ResponseEntity.ok(ApiResponse.<ChatMessageResponse>builder().success(true).data(data).build());
    }

    @GetMapping("/conversations/{conversationId}/messages")
    public ResponseEntity<ApiResponse<PagingResponse<ChatMessageResponse>>> getMessages(
            @PathVariable String conversationId,
            @RequestParam(value = "page", required = false, defaultValue = "1") int page,
            @RequestParam(value = "size", required = false, defaultValue = "100") int size,
            @RequestParam(required = false, defaultValue = PaginationConstant.DESC) String direction,
            @RequestParam(required = false, defaultValue = "createdAt") String field
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        PagingRequest request = PagingRequest.builder()
                .page(page)
                .pageSize(size)
                .sortRequest(SortRequest.builder()
                        .direction(direction)
                        .field(field)
                        .build())
                .build();
        PagingResponse<ChatMessageResponse> data =
                messagingFacade.getMessages(conversationId, userId, request);
        return ResponseEntity.ok(ApiResponse.<PagingResponse<ChatMessageResponse>>builder().success(true).data(data).build());
    }

    @PutMapping("/messages/{messageId}")
    public ResponseEntity<ApiResponse<ChatMessageResponse>> editMessage(
            @PathVariable String messageId,
            @Valid @RequestBody EditMessageRequest request
    ) {
        String userId = IdentityUtils.getCurrentUserId();
        ChatMessageResponse data = messagingFacade.editMessage(messageId, userId, request);
        return ResponseEntity.ok(ApiResponse.<ChatMessageResponse>builder().success(true).data(data).build());
    }
}
