package com.lucy.api.modules.audit.constants;

public final class AuditActionType {

    private AuditActionType() {}

    // LMS - Program
    public static final String PROGRAM_CREATE = "program.create";
    public static final String PROGRAM_UPDATE = "program.update";
    public static final String PROGRAM_DELETE = "program.delete";

    // LMS - Course
    public static final String COURSE_CREATE  = "course.create";
    public static final String COURSE_UPDATE  = "course.update";
    public static final String COURSE_DELETE  = "course.delete";

    // LMS - Chapter
    public static final String CHAPTER_CREATE = "chapter.create";
    public static final String CHAPTER_UPDATE = "chapter.update";
    public static final String CHAPTER_DELETE = "chapter.delete";

    // LMS - Lesson
    public static final String LESSON_CREATE  = "lesson.create";
    public static final String LESSON_UPDATE  = "lesson.update";
    public static final String LESSON_DELETE  = "lesson.delete";

    // Relationship
    public static final String RELATIONSHIP_REQUEST  = "relationship.request";
    public static final String RELATIONSHIP_ACCEPT   = "relationship.accept";
    public static final String RELATIONSHIP_REJECT   = "relationship.reject";
    public static final String RELATIONSHIP_CANCEL   = "relationship.cancel";
    public static final String RELATIONSHIP_UNFRIEND = "relationship.unfriend";

}
