package com.lucy.api.modules.lms.mapper;

import org.mapstruct.Named;
import org.springframework.stereotype.Component;

@Component
public class MapperUtils {
    @Named("trimValue")
    public String trimValue(String value) {
        return value == null ? null : value.trim();
    }
}
