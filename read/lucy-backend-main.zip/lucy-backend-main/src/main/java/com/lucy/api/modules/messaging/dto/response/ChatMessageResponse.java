package com.lucy.api.modules.messaging.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ChatMessageResponse {
    String id;
    String conversationId;
    String senderId;
    String senderUsername;
    ChatSenderInfoResponse senderInfo;
    String text;
    String replyToMessageId;
    Boolean isEdited;
    Integer editCount;
    Instant createdAt;
    Instant updatedAt;
    List<ChatAttachmentResponse> attachments;
    Boolean isEcho;
}
