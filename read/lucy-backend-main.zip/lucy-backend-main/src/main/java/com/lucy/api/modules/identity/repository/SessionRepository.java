package com.lucy.api.modules.identity.repository;

import com.lucy.api.modules.identity.entity.Session;
import com.lucy.api.modules.identity.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.List;

@Repository
public interface SessionRepository extends JpaRepository<Session, String> {
    Optional<Session> findByTokenHashAndRevokedAtIsNull(String tokenHash);
    List<Session> findAllByUserAndRevokedAtIsNull(User user);

    @Modifying
    @Transactional
    void deleteAllByUser_IdIn(List<String> userIds);

    @Modifying
    @Transactional
    void deleteAllByUser_Id(String userId);
}
