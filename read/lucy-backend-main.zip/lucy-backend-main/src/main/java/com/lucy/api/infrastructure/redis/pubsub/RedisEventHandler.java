package com.lucy.api.infrastructure.redis.pubsub;

/**
 * Xử lý một loại kênh pub/sub Redis; {@link RedisPubSubDispatcher} gọi tối đa một handler mỗi message.
 */
public interface RedisEventHandler {

    boolean supports(String channel);

    void handle(String channel, String payload);
}
