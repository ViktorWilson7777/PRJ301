package com.lucy.api.infrastructure.websocket.constants;

public final class WebSocketRedisInboundLogConstants {

    private WebSocketRedisInboundLogConstants() {
    }

    public static final String PARSE_MESSAGE_FAILED = "Failed to parse message from Redis";
    public static final String PARSE_NOTIFICATION_FAILED = "Failed to parse notification from Redis";
}
