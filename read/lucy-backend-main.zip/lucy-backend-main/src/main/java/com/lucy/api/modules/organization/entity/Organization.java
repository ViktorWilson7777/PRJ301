package com.lucy.api.modules.organization.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.organization.entity.enums.OrganizationStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "organizations", uniqueConstraints = @UniqueConstraint(name = "organizations_code_key", columnNames = "code"))
public class Organization extends BaseEntity {
    @Column(nullable = false, length = 100)
    String code;

    @Column(nullable = false, length = 255)
    String name;

    @Column(columnDefinition = "TEXT")
    String description;

    @Column(columnDefinition = "TEXT")
    String logoUrl;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    OrganizationStatus status = OrganizationStatus.ACTIVE;

    Instant deletedAt;
}
