package com.lucy.api.infrastructure.redis.pubsub;

import com.lucy.api.infrastructure.redis.constants.RedisBootstrapLogConstants;
import com.lucy.api.infrastructure.redis.constants.RedisWsKeyConstants;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.Set;

@Slf4j
@Component
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class RedisPubSubBootstrap {

    StringRedisTemplate stringRedisTemplate;
    RedisPubSubSubscriptionService redisPubSubSubscriptionService;

    @PostConstruct
    public void init() {
        try {
            subscribeExistingMessageChannels();
            subscribeExistingNotificationChannels();
            log.info(RedisBootstrapLogConstants.INIT_OK);
        } catch (Exception e) {
            log.warn(RedisBootstrapLogConstants.INIT_WARN, e.getMessage());
        }
    }

    private void subscribeExistingMessageChannels() {
        Set<String> conversationKeys =
                stringRedisTemplate.keys(RedisWsKeyConstants.PREFIX_CONVERSATION_SESSIONS + "*");
        if (conversationKeys != null && !conversationKeys.isEmpty()) {
            for (String key : conversationKeys) {
                String conversationId = extractConversationIdFromKey(key);
                if (conversationId != null) {
                    redisPubSubSubscriptionService.subscribeToConversation(conversationId);
                }
            }
        }
    }

    private void subscribeExistingNotificationChannels() {
        Set<String> userKeys = stringRedisTemplate.keys(RedisWsKeyConstants.PREFIX_USER_SESSIONS + "*");
        if (userKeys != null && !userKeys.isEmpty()) {
            for (String key : userKeys) {
                String userId = extractUserIdFromKey(key);
                if (userId != null) {
                    redisPubSubSubscriptionService.subscribeToUserNotifications(userId);
                }
            }
        }
    }

    private static String extractConversationIdFromKey(String key) {
        if (key == null) {
            return null;
        }
        String prefix = RedisWsKeyConstants.PREFIX_CONVERSATION_SESSIONS;
        String suffix = RedisWsKeyConstants.SUFFIX_CONVERSATION_SESSIONS;
        if (key.startsWith(prefix) && key.endsWith(suffix)) {
            return key.substring(prefix.length(), key.length() - suffix.length());
        }
        return null;
    }

    private static String extractUserIdFromKey(String key) {
        if (key == null) {
            return null;
        }
        String prefix = RedisWsKeyConstants.PREFIX_USER_SESSIONS;
        String suffix = RedisWsKeyConstants.SUFFIX_USER_SESSIONS;
        if (key.startsWith(prefix) && key.endsWith(suffix)) {
            return key.substring(prefix.length(), key.length() - suffix.length());
        }
        return null;
    }
}
