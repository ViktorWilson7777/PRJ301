package com.lucy.api.modules.lms.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CourseUpsertRequest {
    @NotBlank(message = "common.field_required")
    @Size(max = 100, message = "common.validation")
    private String code;

    @NotBlank(message = "common.field_required")
    @Size(max = 255, message = "common.validation")
    private String title;

    private String description;

    @Size(max = 50, message = "common.validation")
    private String level;

    private String thumbnailUrl;

    @Size(max = 100, message = "common.validation")
    private String category;

    @NotNull(message = "common.field_required")
    private String programId;

    @NotNull(message = "common.field_required")
    @PositiveOrZero(message = "common.validation")
    private Integer orderIndex;

    private List<String> tags;
}
