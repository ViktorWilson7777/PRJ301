package com.lucy.api.common.constants;

public class GlobalVariableConstant {
    public static final int PAGE_SIZE_INDEX = 1;
}
