package com.lucy.api.modules.organization.dto.response;

import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OrganizationMembershipResponse {
    String id;
    String organizationId;
    String userId;
    String userEmail;
    String userDisplayName;
    OrganizationMembershipRole role;
    OrganizationMembershipStatus status;
    Instant joinedAt;
    Instant createdAt;
    Instant updatedAt;
}
