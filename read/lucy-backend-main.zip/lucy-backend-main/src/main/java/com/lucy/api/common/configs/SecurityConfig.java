package com.lucy.api.common.configs;

import com.lucy.api.common.constants.JwtClaimSetConstant;
import lombok.experimental.NonFinal;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.context.MessageSource;

import javax.crypto.spec.SecretKeySpec;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import org.springframework.util.StringUtils;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    private static final String[] WHITELIST_ENDPOINTS = {
            "/swagger-ui",
            "/swagger-ui/**",
            "/api/v1/api-docs",
            "/api/v1/api-docs/**",
            "/actuator/health",
            "/actuator/info",
            // Auth endpoints – public
            "/api/v1/auth/register",
            "/api/v1/auth/token",
            "/api/v1/auth/refresh",
            "/api/v1/auth/login",
            "/api/v1/auth/google",
            "/api/v1/auth/apple",
            "/api/v1/auth/forgot-password",
            "/api/v1/auth/verify-otp",
            "/api/v1/auth/reset-password",
            "/api/v1/auth/verify-email",
            "/api/v1/auth/resend-verification",
            "/ws-room",
            "/ws-room/**",
            "/ws-messaging",
            "/ws-messaging/**"
    };

    @NonFinal
    @Value(value = "${security.jwt.signer-key}")
    private String SIGNER_KEY;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity,
                                                   CorsConfigurationSource corsConfigurationSource,
                                                   AuthenticationEntryPoint authenticationEntryPoint) throws Exception {
        return httpSecurity
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .cors(cors -> cors.configurationSource(corsConfigurationSource))
                .csrf(AbstractHttpConfigurer::disable)
                .exceptionHandling(exception -> exception.authenticationEntryPoint(authenticationEntryPoint))
                .authorizeHttpRequests(request -> request
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .requestMatchers(WHITELIST_ENDPOINTS).permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/v1/public/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/syllabus", "/api/syllabus/**").permitAll()
                        .requestMatchers("/api/admin/**").hasAnyAuthority("ROLE_ADMIN")
                        .requestMatchers("/api/mod/**").hasAnyAuthority("ROLE_ADMIN", "ROLE_MOD")
                        .requestMatchers("/api/**").authenticated()
                        .anyRequest().permitAll()
                )
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(jwtConfigurer -> jwtConfigurer.decoder(jwtDecoder())
                                .jwtAuthenticationConverter(jwtAuthenticationConverter()))
                )
                .build();
    }

    @Bean
    JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
        jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(jwt -> {
            HashSet<GrantedAuthority> authorities = new HashSet<>();

            // CLAIM_SCOPE in our tokens may be either:
            // - "role1 role2" (single string), or
            // - ["role1", "role2"] (string list)
            Object rawScope = jwt.getClaims().get(JwtClaimSetConstant.CLAIM_SCOPE);
            if (rawScope instanceof String scopeString) {
                if (StringUtils.hasText(scopeString)) {
                    for (String role : scopeString.trim().split("\\s+")) {
                        if (StringUtils.hasText(role)) {
                            authorities.add(new SimpleGrantedAuthority(role));
                        }
                    }
                }
            } else if (rawScope instanceof Collection<?> scopeCollection) {
                scopeCollection.forEach(role -> {
                    if (role instanceof String roleText && StringUtils.hasText(roleText)) {
                        authorities.add(new SimpleGrantedAuthority(roleText));
                    }
                });
            }

            List<String> permissions = jwt.getClaimAsStringList(JwtClaimSetConstant.CLAIM_PERMISSION);
            if (permissions != null) {
                permissions.forEach(permission -> {
                    if (StringUtils.hasText(permission)) {
                        authorities.add(new SimpleGrantedAuthority(permission));
                    }
                });
            }

            return authorities;
        });
        return jwtAuthenticationConverter;
    }

    @Bean
    JwtDecoder jwtDecoder() {
        SecretKeySpec secretKey = new SecretKeySpec(SIGNER_KEY.getBytes(), "HS512");
        return NimbusJwtDecoder.withSecretKey(secretKey)
                .macAlgorithm(MacAlgorithm.HS512)
                .build();
    }

    @Bean
    AuthenticationEntryPoint authenticationEntryPoint(MessageSource messageSource) {
        return new JwtAuthenticationEntryPoint(messageSource);
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
