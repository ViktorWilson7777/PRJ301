package com.lucy.api.modules.messaging.entity;

import com.lucy.api.modules.messaging.constant.ChatAttachmentConstants;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Embeddable
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ChatAttachment {

    @Column(name = ChatAttachmentConstants.COL_TYPE, length = 50)
    String type;

    @Column(name = ChatAttachmentConstants.COL_URL, length = 1000)
    String url;

    @Column(name = ChatAttachmentConstants.COL_TITLE, length = 255)
    String title;
}
