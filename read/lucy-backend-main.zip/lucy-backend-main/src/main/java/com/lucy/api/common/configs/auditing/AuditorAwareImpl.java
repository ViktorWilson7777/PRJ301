package com.lucy.api.common.configs.auditing;

//import org.springframework.data.domain.AuditorAware;
//
//import java.util.Optional;
//
//public class AuditorAwareImpl implements AuditorAware<String> {
//
//    @Override
//    public Optional<String> getCurrentAuditor() {
//        String userId = AuthUtils.getCurrentUserId();
//        return Optional.of(userId);
//    }
//}
