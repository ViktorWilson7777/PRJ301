package com.lucy.api.modules.messaging.service.domain;

import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.lms.repository.CourseRunRepository;
import com.lucy.api.modules.messaging.entity.Conversation;
import com.lucy.api.modules.messaging.enums.ConversationMode;
import com.lucy.api.modules.messaging.enums.ConversationStatus;
import com.lucy.api.modules.messaging.repository.ConversationRepository;
import com.lucy.api.modules.messaging.util.DirectKeyNormalizer;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Domain: tạo/tìm conversation (GROUP/DIRECT), không event, không Redis.
 */
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ConversationDomainService {

    ConversationRepository conversationRepository;
    CourseRunRepository courseRunRepository;

    @Transactional
    public Conversation ensureGroupConversation(String courseRunId) {
        Optional<Conversation> existing =
                conversationRepository.findByCourseRun_IdAndMode(courseRunId, ConversationMode.GROUP);
        if (existing.isPresent()) {
            return existing.get();
        }
        try {
            CourseRun courseRun = courseRunRepository.getReferenceById(courseRunId);
            Conversation created = Conversation.builder()
                    .mode(ConversationMode.GROUP)
                    .courseRun(courseRun)
                    .status(ConversationStatus.OPEN)
                    .build();
            return conversationRepository.save(created);
        } catch (DataIntegrityViolationException e) {
            return conversationRepository
                    .findByCourseRun_IdAndMode(courseRunId, ConversationMode.GROUP)
                    .orElseThrow(() -> e);
        }
    }

    @Transactional
    public Conversation ensureDirectConversation(String userIdA, String userIdB) {
        String directKey = DirectKeyNormalizer.buildDirectKey(userIdA, userIdB);
        Optional<Conversation> existing = conversationRepository.findByDirectKey(directKey);
        if (existing.isPresent()) {
            return existing.get();
        }
        try {
            Conversation created = Conversation.builder()
                    .mode(ConversationMode.DIRECT)
                    .directKey(directKey)
                    .status(ConversationStatus.OPEN)
                    .build();
            return conversationRepository.save(created);
        } catch (DataIntegrityViolationException e) {
            return conversationRepository.findByDirectKey(directKey).orElseThrow(() -> e);
        }
    }

    @Transactional
    public Conversation createAdhocGroupConversation(String groupName, String createdBy) {
        Conversation created = Conversation.builder()
                .mode(ConversationMode.GROUP)
                .groupName(groupName != null ? groupName.trim() : null)
                .createdBy(createdBy)
                .status(ConversationStatus.OPEN)
                .build();
        return conversationRepository.save(created);
    }
}
