package com.lucy.api.modules.lms.repository;

import com.lucy.api.modules.lms.entity.Lesson;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LessonRepository extends JpaRepository<Lesson, String> {
    List<Lesson> findAllByChapter_IdOrderByOrderIndexAscCreatedAtAsc(String chapterId);

    long countByChapter_CourseRun_Id(String courseRunId);

    interface CourseRunLessonCount {
        String getCourseRunId();
        long getTotalLessons();
    }

    @Query("""
            select c.courseRun.id as courseRunId, count(l) as totalLessons
            from Lesson l
            join l.chapter c
            where c.courseRun.id in :courseRunIds
            group by c.courseRun.id
            """)
    List<CourseRunLessonCount> countLessonsByCourseRunIds(@Param("courseRunIds") List<String> courseRunIds);
}
