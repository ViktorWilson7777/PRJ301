package com.lucy.api.modules.event.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Request DTO for leaving a room via WebSocket
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LeaveRoomRequest {
    private UUID roomId;
    private String reason; // optional: "timeout", "manual", "kicked"
}
