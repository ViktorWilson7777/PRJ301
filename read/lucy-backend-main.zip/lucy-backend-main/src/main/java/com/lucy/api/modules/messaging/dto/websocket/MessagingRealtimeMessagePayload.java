package com.lucy.api.modules.messaging.dto.websocket;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.Instant;
import java.util.List;

/**
 * Payload realtime chat (Redis + WebSocket), tuong thich JSON broadcast.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MessagingRealtimeMessagePayload {
    String conversationId;
    String messageId;
    String text;
    String senderId;
    String senderUsername;
    Instant timestamp;
    List<MessagingAttachmentPayload> attachments;
    Boolean isEdited;
    Integer editCount;
    String senderFullName;
    String senderAvatarUrl;
}
