package com.lucy.api.modules.organization.entity.enums;

public enum OrganizationMembershipStatus {
    ACTIVE,
    INVITED,
    SUSPENDED
}
