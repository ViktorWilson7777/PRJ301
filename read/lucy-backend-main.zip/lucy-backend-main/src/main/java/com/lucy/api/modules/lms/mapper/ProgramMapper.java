package com.lucy.api.modules.lms.mapper;

import com.lucy.api.modules.lms.mapper.CourseMapper;
import com.lucy.api.modules.lms.dto.request.ProgramUpsertRequest;
import com.lucy.api.modules.lms.dto.response.ProgramResponse;
import com.lucy.api.modules.lms.entity.Program;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", uses = { CourseMapper.class, MapperUtils.class })
public interface ProgramMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "courses", ignore = true)
    @Mapping(target = "deletedAt", ignore = true)
    @Mapping(target = "organization", ignore = true)
    @Mapping(target = "ownerUserId", ignore = true)
    @Mapping(target = "accessScope", ignore = true)
    @Mapping(target = "code", source = "code", qualifiedByName = "trimValue")
    @Mapping(target = "title", source = "title", qualifiedByName = "trimValue")
    @Mapping(target = "published", source = "isPublished")
    Program toEntity(ProgramUpsertRequest request);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "courses", ignore = true)
    @Mapping(target = "deletedAt", ignore = true)
    @Mapping(target = "organization", ignore = true)
    @Mapping(target = "ownerUserId", ignore = true)
    @Mapping(target = "accessScope", ignore = true)
    @Mapping(target = "code", source = "code", qualifiedByName = "trimValue")
    @Mapping(target = "title", source = "title", qualifiedByName = "trimValue")
    @Mapping(target = "published", source = "isPublished")
    void updateEntity(@MappingTarget Program program, ProgramUpsertRequest request);

    @Mapping(target = "isPublished", source = "published")
    @Mapping(target = "organizationId", source = "organization.id")
    ProgramResponse toResponse(Program program);
}
