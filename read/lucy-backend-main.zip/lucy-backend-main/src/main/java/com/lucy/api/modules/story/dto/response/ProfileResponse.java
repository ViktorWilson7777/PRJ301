package com.lucy.api.modules.story.dto.response;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

import java.util.Map;

@Getter
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ProfileResponse {
    String id;
    String email;
    String role;
    String profileRole;
    String displayName;
    String avatarUrl;
    String avatarKey;
    String interest;
    String specialty;
    java.util.List<String> interests;
    String backgroundUrl;
    Map<String, Object> backgroundMetadata;
    Map<String, Object> publicProfileSettings;
    AskProfileMetricsResponse askProfile;
    long followers;
    long following;
    long totalEventsCreated;
    boolean isProfileCompleted;
}
