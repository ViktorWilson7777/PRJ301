package com.lucy.api.modules.event.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Redis Cache Service for Room Status and Settings
 * Caches room state for fast real-time access
 * 
 * Redis Key Patterns:
 * - room:{roomId}:status - Room status (open, live, ended, etc.)
 * - room:{roomId}:settings - Room settings (mute all, max participants, etc.)
 * - room:{roomId}:metadata - Additional metadata
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class RoomStatusCacheService {

    private final RedisTemplate<String, Object> redisTemplate;
    private final ObjectMapper objectMapper;

    private static final String ROOM_KEY_PREFIX = "room:";
    private static final String STATUS_KEY_SUFFIX = ":status";
    private static final String SETTINGS_KEY_SUFFIX = ":settings";
    private static final String METADATA_KEY_SUFFIX = ":metadata";
    
    // TTL: 24 hours
    private static final long ROOM_TTL_HOURS = 24;

    /**
     * Cache room status
     */
    public void cacheRoomStatus(String roomId, String status) {
        try {
            String key = getRoomStatusKey(roomId);
            redisTemplate.opsForValue().set(key, status, ROOM_TTL_HOURS, TimeUnit.HOURS);
            log.debug("Cached room {} status: {}", roomId, status);
        } catch (Exception e) {
            log.error("Failed to cache room status", e);
        }
    }

    /**
     * Get cached room status
     */
    public String getRoomStatus(String roomId) {
        try {
            String key = getRoomStatusKey(roomId);
            Object status = redisTemplate.opsForValue().get(key);
            return status != null ? status.toString() : null;
        } catch (Exception e) {
            log.error("Failed to get room status from cache", e);
            return null;
        }
    }

    /**
     * Cache room settings
     */
    public void cacheRoomSettings(String roomId, Map<String, Object> settings) {
        try {
            String key = getRoomSettingsKey(roomId);
            String settingsJson = objectMapper.writeValueAsString(settings);
            redisTemplate.opsForValue().set(key, settingsJson, ROOM_TTL_HOURS, TimeUnit.HOURS);
            log.debug("Cached room {} settings", roomId);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize room settings", e);
        }
    }

    /**
     * Get cached room settings
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getRoomSettings(String roomId) {
        try {
            String key = getRoomSettingsKey(roomId);
            Object settingsJson = redisTemplate.opsForValue().get(key);
            
            if (settingsJson == null) {
                return new HashMap<>();
            }
            
            return objectMapper.readValue(settingsJson.toString(), Map.class);
        } catch (Exception e) {
            log.error("Failed to get room settings from cache", e);
            return new HashMap<>();
        }
    }

    /**
     * Update specific setting in room
     */
    public void updateRoomSetting(String roomId, String key, Object value) {
        try {
            Map<String, Object> settings = getRoomSettings(roomId);
            settings.put(key, value);
            cacheRoomSettings(roomId, settings);
            log.debug("Updated room {} setting: {} = {}", roomId, key, value);
        } catch (Exception e) {
            log.error("Failed to update room setting", e);
        }
    }

    /**
     * Get specific setting from room
     */
    public Object getRoomSetting(String roomId, String key) {
        Map<String, Object> settings = getRoomSettings(roomId);
        return settings.get(key);
    }

    /**
     * Cache room metadata
     */
    public void cacheRoomMetadata(String roomId, Map<String, Object> metadata) {
        try {
            String key = getRoomMetadataKey(roomId);
            String metadataJson = objectMapper.writeValueAsString(metadata);
            redisTemplate.opsForValue().set(key, metadataJson, ROOM_TTL_HOURS, TimeUnit.HOURS);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize room metadata", e);
        }
    }

    /**
     * Get cached room metadata
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> getRoomMetadata(String roomId) {
        try {
            String key = getRoomMetadataKey(roomId);
            Object metadataJson = redisTemplate.opsForValue().get(key);
            
            if (metadataJson == null) {
                return new HashMap<>();
            }
            
            return objectMapper.readValue(metadataJson.toString(), Map.class);
        } catch (Exception e) {
            log.error("Failed to get room metadata from cache", e);
            return new HashMap<>();
        }
    }

    /**
     * Clear all cache for a room
     */
    public void clearRoomCache(String roomId) {
        try {
            String statusKey = getRoomStatusKey(roomId);
            String settingsKey = getRoomSettingsKey(roomId);
            String metadataKey = getRoomMetadataKey(roomId);
            
            redisTemplate.delete(statusKey);
            redisTemplate.delete(settingsKey);
            redisTemplate.delete(metadataKey);
            
            log.info("Cleared all cache for room {}", roomId);
        } catch (Exception e) {
            log.error("Failed to clear room cache", e);
        }
    }

    /**
     * Refresh TTL for room cache
     */
    public void refreshRoomTTL(String roomId) {
        try {
            String statusKey = getRoomStatusKey(roomId);
            String settingsKey = getRoomSettingsKey(roomId);
            String metadataKey = getRoomMetadataKey(roomId);
            
            redisTemplate.expire(statusKey, ROOM_TTL_HOURS, TimeUnit.HOURS);
            redisTemplate.expire(settingsKey, ROOM_TTL_HOURS, TimeUnit.HOURS);
            redisTemplate.expire(metadataKey, ROOM_TTL_HOURS, TimeUnit.HOURS);
        } catch (Exception e) {
            log.error("Failed to refresh room TTL", e);
        }
    }

    /**
     * Check if room exists in cache
     */
    public boolean isRoomCached(String roomId) {
        try {
            String key = getRoomStatusKey(roomId);
            return redisTemplate.hasKey(key);
        } catch (Exception e) {
            log.error("Failed to check if room is cached", e);
            return false;
        }
    }

    // Helper methods
    private String getRoomStatusKey(String roomId) {
        return ROOM_KEY_PREFIX + roomId + STATUS_KEY_SUFFIX;
    }

    private String getRoomSettingsKey(String roomId) {
        return ROOM_KEY_PREFIX + roomId + SETTINGS_KEY_SUFFIX;
    }

    private String getRoomMetadataKey(String roomId) {
        return ROOM_KEY_PREFIX + roomId + METADATA_KEY_SUFFIX;
    }
}
