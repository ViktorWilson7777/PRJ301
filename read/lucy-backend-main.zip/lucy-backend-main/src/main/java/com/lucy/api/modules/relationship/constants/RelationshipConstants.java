package com.lucy.api.modules.relationship.constants;

public final class RelationshipConstants {

    private RelationshipConstants() {}

    public static final String TABLE_RELATIONSHIPS = "relationships";
    public static final String NOTIFICATION_TYPE = "FRIENDSHIP";
}
