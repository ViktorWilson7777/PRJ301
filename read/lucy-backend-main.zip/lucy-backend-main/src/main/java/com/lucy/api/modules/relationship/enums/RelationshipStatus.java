package com.lucy.api.modules.relationship.enums;

public enum RelationshipStatus {
    PENDING,
    ACCEPTED
}
