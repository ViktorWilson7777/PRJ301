package com.lucy.api.modules.lms.service.impl;

import com.lucy.api.common.constants.GlobalVariableConstant;
import com.lucy.api.common.dtos.response.PagingResponse;
import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.entity.enums.UserRole;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.service.impl.CurrentUserService;
import com.lucy.api.modules.lms.dto.request.EnrollMeRequest;
import com.lucy.api.modules.lms.dto.request.EnrollmentCondition;
import com.lucy.api.modules.lms.dto.request.EnrollmentFilterRequest;
import com.lucy.api.modules.lms.dto.request.EnrollmentUpdateRequest;
import com.lucy.api.modules.lms.dto.request.ManualEnrollmentRequest;
import com.lucy.api.modules.lms.dto.request.enums.FilterField;
import com.lucy.api.modules.lms.dto.request.enums.MatchMode;
import com.lucy.api.modules.lms.dto.response.EnrollmentImportResponse;
import com.lucy.api.modules.lms.dto.response.EnrollmentResponse;
import com.lucy.api.modules.lms.entity.CourseRun;
import com.lucy.api.modules.lms.entity.Enrollment;
import com.lucy.api.modules.lms.entity.enums.EnrollmentMethod;
import com.lucy.api.modules.lms.entity.enums.EnrollmentRole;
import com.lucy.api.modules.lms.entity.enums.EnrollmentStatus;
import com.lucy.api.modules.lms.entity.enums.LmsAccessScope;
import com.lucy.api.modules.lms.mapper.EnrollmentMapper;
import com.lucy.api.modules.lms.repository.EnrollmentRepository;
import com.lucy.api.modules.lms.repository.LessonRepository;
import com.lucy.api.modules.lms.progress.repository.LessonProgressRepository;
import com.lucy.api.modules.lms.service.LmsAccessService;
import com.lucy.api.modules.lms.service.api.CourseRunService;
import com.lucy.api.modules.lms.service.api.EnrollmentService;
import com.lucy.api.modules.messaging.event.EnrollmentActivatedEvent;
import com.lucy.api.modules.messaging.event.EnrollmentRemovedEvent;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole;
import com.lucy.api.modules.organization.service.OrganizationAccessService;
import com.lucy.api.modules.streak.service.api.StreakService;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final EnrollmentMapper enrollmentMapper;
    private final CourseRunService courseRunService;
    private final UserRepository userRepository;
    private final ApplicationEventPublisher applicationEventPublisher;
    private final StreakService streakService;
    private final LessonRepository lessonRepository;
    private final LessonProgressRepository lessonProgressRepository;
    private final CurrentUserService currentUserService;
    private final LmsAccessService lmsAccessService;
    private final OrganizationAccessService organizationAccessService;

    @Override
    @Transactional
    public EnrollmentResponse enroll(String userId, String courseRunId) {
        if (enrollmentRepository.existsByUserIdAndCourseRunId(userId, courseRunId)) {
            throw new AppException("lms.enrollment_already_exists", HttpStatus.CONFLICT);
        }

        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new AppException("auth.user_not_existed", HttpStatus.NOT_FOUND));

        CourseRun courseRun = courseRunService.getEntityById(courseRunId);

        Enrollment enrollment = Enrollment.builder()
                .user(user)
                .courseRun(courseRun)
                .organization(courseRun.getOrganization())
                .accessScope(courseRun.getAccessScope())
                .status(EnrollmentStatus.ACTIVE)
                .role(EnrollmentRole.STUDENT)
                .enrolmentMethod(resolveEnrollmentMethod(courseRun))
                .enrolledAt(Instant.now())
                .build();

        Enrollment saved = enrollmentRepository.save(enrollment);
        if (saved.getStatus() == EnrollmentStatus.ACTIVE) {
            applicationEventPublisher.publishEvent(
                    new EnrollmentActivatedEvent(saved.getUser().getId(), saved.getCourseRun().getId()));
        }
        return toResponsesWithProgress(List.of(saved)).getFirst();
    }

    @Override
    @Transactional
    public EnrollmentResponse enrollMe(EnrollMeRequest request) {
        CourseRun courseRun = courseRunService.getEntityById(request.getCourseRunId());

        if (!"OPEN".equalsIgnoreCase(courseRun.getStatus())) {
            throw new AppException("lms.course_run_not_enrollable", HttpStatus.UNPROCESSABLE_ENTITY);
        }

        Instant now = Instant.now();
        if (courseRun.getEnrollmentStartDate() != null && now.isBefore(courseRun.getEnrollmentStartDate())) {
            throw new AppException("lms.enrollment_not_started", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        if (courseRun.getEnrollmentEndDate() != null && now.isAfter(courseRun.getEnrollmentEndDate())) {
            throw new AppException("lms.enrollment_period_closed", HttpStatus.UNPROCESSABLE_ENTITY);
        }

        if (courseRun.getCapacity() != null) {
            long currentCount = enrollmentRepository.countByCourseRunId(request.getCourseRunId());
            if (currentCount >= courseRun.getCapacity()) {
                throw new AppException("lms.course_run_full", HttpStatus.CONFLICT);
            }
        }

        if (courseRun.getPrerequisiteCourseRunId() != null) {
            boolean completedPrerequisite = enrollmentRepository.existsByUserIdAndCourseRunIdAndCompletedAtIsNotNull(
                    request.getUserId(),
                    courseRun.getPrerequisiteCourseRunId()
            );
            if (!completedPrerequisite) {
                throw new AppException("lms.prerequisite_not_completed", HttpStatus.UNPROCESSABLE_ENTITY);
            }
        }

        lmsAccessService.assertCanSelfEnroll(courseRun, request.getUserId());

        EnrollmentResponse response = enroll(request.getUserId(), request.getCourseRunId());
        streakService.trackActivity(request.getUserId(), "LMS_ENROLL", Instant.now());
        return response;
    }

    @Override
    @Transactional
    public EnrollmentResponse manualEnroll(ManualEnrollmentRequest request) {
        CourseRun courseRun = courseRunService.getEntityById(request.getCourseRunId());
        lmsAccessService.assertCanManualEnroll(courseRun);
        return enroll(request.getUserId(), request.getCourseRunId());
    }

    @Override
    @Transactional
    public EnrollmentImportResponse importFromExcel(MultipartFile file, String courseRunId, boolean dryRun) {
        if (file == null || file.isEmpty()) {
            throw new AppException("lms.import_file_required", HttpStatus.BAD_REQUEST);
        }
        CourseRun courseRun = courseRunService.getEntityById(courseRunId);
        if (courseRun.getAccessScope() != LmsAccessScope.ORGANIZATION || courseRun.getOrganization() == null) {
            throw new AppException("lms.import_only_for_organization", HttpStatus.BAD_REQUEST);
        }
        organizationAccessService.assertOrganizationRole(
                courseRun.getOrganization().getId(),
                OrganizationMembershipRole.OWNER,
                OrganizationMembershipRole.ADMIN,
                OrganizationMembershipRole.INSTRUCTOR
        );

        List<EnrollmentImportResponse.FailureItem> failures = new ArrayList<>();
        Set<String> emailsInFile = new HashSet<>();
        int totalRows = 0;
        int successCount = 0;
        int skippedCount = 0;

        DataFormatter formatter = new DataFormatter();
        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            if (sheet == null) {
                throw new AppException("lms.import_invalid_excel", HttpStatus.BAD_REQUEST);
            }

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new AppException("lms.import_invalid_header", HttpStatus.BAD_REQUEST);
            }
            Map<String, Integer> headerMap = extractHeaderMap(headerRow, formatter);
            Integer emailCol = headerMap.get("email");
            if (emailCol == null) {
                throw new AppException("lms.import_missing_email_column", HttpStatus.BAD_REQUEST);
            }
            Integer orderNoCol = headerMap.get("order_no");
            Integer amountCol = headerMap.get("amount");

            int lastRowNum = sheet.getLastRowNum();
            for (int rowIdx = 1; rowIdx <= lastRowNum; rowIdx++) {
                Row row = sheet.getRow(rowIdx);
                if (row == null) {
                    continue;
                }
                String email = readCell(row, emailCol, formatter).trim().toLowerCase();
                String orderNo = orderNoCol == null ? null : readCell(row, orderNoCol, formatter).trim();
                String amountRaw = amountCol == null ? null : readCell(row, amountCol, formatter).trim();
                BigDecimal amount = parseAmount(amountRaw);

                if (email.isBlank()) {
                    continue;
                }
                totalRows++;

                if (!emailsInFile.add(email)) {
                    skippedCount++;
                    failures.add(buildFailure(rowIdx, email, orderNo, amount, "Duplicate email in file"));
                    continue;
                }

                User user = userRepository.findByEmailAndDeletedAtIsNull(email).orElse(null);
                if (user == null) {
                    failures.add(buildFailure(rowIdx, email, orderNo, amount, "User email not found"));
                    continue;
                }

                if (enrollmentRepository.existsByUserIdAndCourseRunId(user.getId(), courseRunId)) {
                    skippedCount++;
                    failures.add(buildFailure(rowIdx, email, orderNo, amount, "User already enrolled"));
                    continue;
                }

                try {
                    if (!dryRun) {
                        enroll(user.getId(), courseRunId);
                    }
                    successCount++;
                } catch (AppException ex) {
                    failures.add(buildFailure(rowIdx, email, orderNo, amount, ex.getMessage()));
                }
            }
        } catch (AppException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new AppException("lms.import_invalid_excel", HttpStatus.BAD_REQUEST);
        }

        return EnrollmentImportResponse.builder()
                .totalRows(totalRows)
                .successCount(successCount)
                .skippedCount(skippedCount)
                .failedCount(Math.max(0, totalRows - successCount - skippedCount))
                .failures(failures)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public byte[] generateImportTemplate() {
        try (Workbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("enrollments");
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("email");
            header.createCell(1).setCellValue("order_no");
            header.createCell(2).setCellValue("amount");

            Row sample = sheet.createRow(1);
            sample.createCell(0).setCellValue("student@example.com");
            sample.createCell(1).setCellValue("ORD-1001");
            sample.createCell(2).setCellValue("199.99");

            sheet.autoSizeColumn(0);
            sheet.autoSizeColumn(1);
            sheet.autoSizeColumn(2);

            workbook.write(outputStream);
            return outputStream.toByteArray();
        } catch (Exception ex) {
            throw new AppException("lms.import_template_generation_failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public boolean hasActiveEnrollment(String userId, String courseRunId) {
        return enrollmentRepository.existsByUser_IdAndCourseRun_IdAndStatus(userId, courseRunId, EnrollmentStatus.ACTIVE);
    }

    @Override
    @Transactional(readOnly = true)
    public PagingResponse<EnrollmentResponse> getList(EnrollmentFilterRequest request) {
        CourseRun courseRun = courseRunService.getEntityById(request.getCourseRunId());
        assertCanInspectCourseRun(courseRun);

        Specification<Enrollment> spec = buildSpecification(request);

        int pageIndex = request.getPage() - GlobalVariableConstant.PAGE_SIZE_INDEX;
        Pageable pageable = PageRequest.of(pageIndex, request.getPageSize());

        Page<Enrollment> page = enrollmentRepository.findAll(spec, pageable);
        List<EnrollmentResponse> data = toResponsesWithProgress(page.getContent());

        return PagingResponse.<EnrollmentResponse>builder()
                .currentPage(request.getPage())
                .pageSize(page.getSize())
                .totalPages(page.getTotalPages())
                .totalElement(page.getTotalElements())
                .data(data)
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public EnrollmentResponse getById(String enrollmentId) {
        Enrollment enrollment = getEntityById(enrollmentId);
        assertCanInspectEnrollment(enrollment);
        return toResponsesWithProgress(List.of(enrollment)).getFirst();
    }

    @Override
    @Transactional
    public EnrollmentResponse update(String enrollmentId, EnrollmentUpdateRequest request) {
        Enrollment enrollment = getEntityById(enrollmentId);
        assertCanManageEnrollment(enrollment);
        EnrollmentStatus previousStatus = enrollment.getStatus();
        enrollmentMapper.updateEntity(enrollment, request);
        Enrollment saved = enrollmentRepository.save(enrollment);
        if (request.getCompletedAt() != null) {
            streakService.trackActivity(saved.getUser().getId(), "LMS_COMPLETED", request.getCompletedAt());
        } else if (request.getLastAccessedAt() != null) {
            streakService.trackActivity(saved.getUser().getId(), "LMS_ACCESS", request.getLastAccessedAt());
        }
        publishEnrollmentMessagingEvents(
                saved.getUser().getId(),
                saved.getCourseRun().getId(),
                previousStatus,
                saved.getStatus());
        return toResponsesWithProgress(List.of(saved)).getFirst();
    }

    @Override
    @Transactional(readOnly = true)
    public Enrollment getEntityById(String enrollmentId) {
        return enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new AppException("lms.enrollment_not_found", HttpStatus.NOT_FOUND));
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getByCourseRunId(String courseRunId) {
        CourseRun courseRun = courseRunService.getEntityById(courseRunId);
        assertCanInspectCourseRun(courseRun);
        return toResponsesWithProgress(enrollmentRepository.findAllByCourseRunId(courseRunId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getByUserId(String userId) {
        String currentUserId = currentUserService.getCurrentUserId();
        if (!currentUserId.equals(userId) && currentUserService.getCurrentUser().getRoleName() != UserRole.ADMIN) {
            throw new AppException("lms.enrollment_forbidden", HttpStatus.FORBIDDEN);
        }
        return toResponsesWithProgress(enrollmentRepository.findAllByUserId(userId));
    }

    private List<EnrollmentResponse> toResponsesWithProgress(List<Enrollment> enrollments) {
        if (enrollments == null || enrollments.isEmpty()) return List.of();

        List<String> enrollmentIds = enrollments.stream().map(Enrollment::getId).toList();
        List<String> courseRunIds = enrollments.stream().map(e -> e.getCourseRun().getId()).distinct().toList();

        Map<String, Long> totalLessonsByCourseRunId = new HashMap<>();
        for (LessonRepository.CourseRunLessonCount row : lessonRepository.countLessonsByCourseRunIds(courseRunIds)) {
            totalLessonsByCourseRunId.put(row.getCourseRunId(), row.getTotalLessons());
        }

        Map<String, Long> completedByEnrollmentId = new HashMap<>();
        for (LessonProgressRepository.EnrollmentCompletedCount row : lessonProgressRepository.countCompletedByEnrollmentIds(enrollmentIds)) {
            completedByEnrollmentId.put(row.getEnrollmentId(), row.getCompletedLessons());
        }

        return enrollments.stream().map(enrollment -> {
            EnrollmentResponse response = enrollmentMapper.toResponse(enrollment);
            long total = totalLessonsByCourseRunId.getOrDefault(enrollment.getCourseRun().getId(), 0L);
            long completed = completedByEnrollmentId.getOrDefault(enrollment.getId(), 0L);
            int percent = total <= 0 ? 0 : (int) Math.round((completed * 100.0) / total);
            response.setProgressPercent(Math.max(0, Math.min(100, percent)));
            response.setAccessScope(enrollment.getAccessScope());
            return response;
        }).toList();
    }

    @Override
    @Transactional
    public void delete(String enrollmentId) {
        Enrollment enrollment = getEntityById(enrollmentId);
        assertCanManageEnrollment(enrollment);
        String userId = enrollment.getUser().getId();
        String courseRunId = enrollment.getCourseRun().getId();
        enrollmentRepository.delete(enrollment);
        applicationEventPublisher.publishEvent(new EnrollmentRemovedEvent(userId, courseRunId));
    }

    private void publishEnrollmentMessagingEvents(
            String userId,
            String courseRunId,
            EnrollmentStatus previousStatus,
            EnrollmentStatus newStatus
    ) {
        boolean wasActive = previousStatus == EnrollmentStatus.ACTIVE;
        boolean isActive = newStatus == EnrollmentStatus.ACTIVE;
        if (!wasActive && isActive) {
            applicationEventPublisher.publishEvent(new EnrollmentActivatedEvent(userId, courseRunId));
        } else if (wasActive && !isActive) {
            applicationEventPublisher.publishEvent(new EnrollmentRemovedEvent(userId, courseRunId));
        }
    }

    private Map<String, Integer> extractHeaderMap(Row headerRow, DataFormatter formatter) {
        Map<String, Integer> headerMap = new HashMap<>();
        short lastCellNum = headerRow.getLastCellNum();
        for (int i = 0; i < lastCellNum; i++) {
            String rawHeader = formatter.formatCellValue(headerRow.getCell(i)).trim().toLowerCase();
            if (rawHeader.isBlank()) {
                continue;
            }
            String normalized = rawHeader.replace(" ", "_").replace("-", "_");
            if ("e_mail".equals(normalized)) {
                normalized = "email";
            }
            if ("order".equals(normalized)) {
                normalized = "order_no";
            }
            headerMap.put(normalized, i);
        }
        return headerMap;
    }

    private String readCell(Row row, Integer colIndex, DataFormatter formatter) {
        if (colIndex == null || colIndex < 0) {
            return "";
        }
        Cell cell = row.getCell(colIndex);
        if (cell == null) {
            return "";
        }
        return formatter.formatCellValue(cell);
    }

    private BigDecimal parseAmount(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return new BigDecimal(value.replace(",", "").trim());
        } catch (Exception ex) {
            return null;
        }
    }

    private EnrollmentImportResponse.FailureItem buildFailure(
            int rowIdx,
            String email,
            String orderNo,
            BigDecimal amount,
            String reason
    ) {
        return EnrollmentImportResponse.FailureItem.builder()
                .rowNumber(rowIdx + 1)
                .email(email)
                .orderNo(orderNo == null || orderNo.isBlank() ? null : orderNo)
                .amount(amount)
                .reason(reason)
                .build();
    }

    private Specification<Enrollment> buildSpecification(EnrollmentFilterRequest request) {
        Specification<Enrollment> spec = byCourseRunId(request.getCourseRunId());
        if (request.getConditions() == null || request.getConditions().isEmpty()) {
            return spec;
        }
        for (EnrollmentCondition condition : request.getConditions()) {
            Specification<Enrollment> conditionSpec = buildConditionSpec(condition);
            if (conditionSpec != null) {
                spec = spec.and(conditionSpec);
            }
        }
        return spec;
    }

    private Specification<Enrollment> byCourseRunId(String courseRunId) {
        return (root, query, cb) -> cb.equal(root.get("courseRun").get("id"), courseRunId);
    }

    private Specification<Enrollment> buildConditionSpec(EnrollmentCondition condition) {
        if (condition.getValues() == null || condition.getValues().isEmpty()) {
            return null;
        }

        FilterField field = condition.getField();
        MatchMode match = condition.getMatch();
        List<String> values = condition.getValues();

        return switch (field) {
            case KEYWORD -> keywordSpec(match, values);
            case ROLE -> roleSpec(match, values);
            case INACTIVE_FOR_MORE_THAN -> inactiveSpec(match, values);
        };
    }

    private Specification<Enrollment> keywordSpec(MatchMode match, List<String> values) {
        return (root, query, cb) -> {
            Join<Enrollment, User> userJoin = root.join("user", JoinType.INNER);
            Join<User, ?> profileJoin = userJoin.join("profile", JoinType.LEFT);
            List<Predicate> predicates = values.stream()
                    .map(v -> cb.like(cb.lower(profileJoin.get("displayName")), "%" + v.toLowerCase() + "%"))
                    .toList();
            return match == MatchMode.ANY ? cb.or(predicates.toArray(Predicate[]::new)) : cb.and(predicates.toArray(Predicate[]::new));
        };
    }

    private Specification<Enrollment> roleSpec(MatchMode match, List<String> values) {
        return (root, query, cb) -> {
            List<Predicate> predicates = values.stream()
                    .map(v -> cb.equal(root.get("role"), EnrollmentRole.valueOf(v.toUpperCase())))
                    .toList();
            return match == MatchMode.ANY ? cb.or(predicates.toArray(Predicate[]::new)) : cb.and(predicates.toArray(Predicate[]::new));
        };
    }

    private Specification<Enrollment> inactiveSpec(MatchMode match, List<String> values) {
        return (root, query, cb) -> {
            int days = Integer.parseInt(values.getFirst());
            Instant cutoff = Instant.now().minusSeconds(days * 86400L);
            Predicate predicate = cb.or(cb.isNull(root.get("lastAccessedAt")), cb.lessThan(root.get("lastAccessedAt"), cutoff));
            return predicate;
        };
    }

    private EnrollmentMethod resolveEnrollmentMethod(CourseRun courseRun) {
        return courseRun.getAccessScope() == LmsAccessScope.PUBLIC
                ? EnrollmentMethod.MANUAL_ENROLMENTS
                : EnrollmentMethod.MANUAL_ENROLMENTS;
    }

    private void assertCanInspectCourseRun(CourseRun courseRun) {
        if (currentUserService.getCurrentUser().getRoleName() == UserRole.ADMIN) {
            return;
        }
        if (courseRun.getAccessScope() == LmsAccessScope.ORGANIZATION && courseRun.getOrganization() != null) {
            organizationAccessService.assertOrganizationRole(
                    courseRun.getOrganization().getId(),
                    OrganizationMembershipRole.OWNER,
                    OrganizationMembershipRole.ADMIN,
                    OrganizationMembershipRole.INSTRUCTOR
            );
            return;
        }
        throw new AppException("lms.enrollment_forbidden", HttpStatus.FORBIDDEN);
    }

    private void assertCanInspectEnrollment(Enrollment enrollment) {
        if (currentUserService.getCurrentUser().getRoleName() == UserRole.ADMIN) {
            return;
        }
        if (enrollment.getUser().getId().equals(currentUserService.getCurrentUserId())) {
            return;
        }
        if (enrollment.getAccessScope() == LmsAccessScope.ORGANIZATION && enrollment.getOrganization() != null) {
            organizationAccessService.assertOrganizationRole(
                    enrollment.getOrganization().getId(),
                    OrganizationMembershipRole.OWNER,
                    OrganizationMembershipRole.ADMIN,
                    OrganizationMembershipRole.INSTRUCTOR
            );
            return;
        }
        throw new AppException("lms.enrollment_forbidden", HttpStatus.FORBIDDEN);
    }

    private void assertCanManageEnrollment(Enrollment enrollment) {
        if (currentUserService.getCurrentUser().getRoleName() == UserRole.ADMIN) {
            return;
        }
        if (enrollment.getAccessScope() == LmsAccessScope.ORGANIZATION && enrollment.getOrganization() != null) {
            organizationAccessService.assertOrganizationRole(
                    enrollment.getOrganization().getId(),
                    OrganizationMembershipRole.OWNER,
                    OrganizationMembershipRole.ADMIN,
                    OrganizationMembershipRole.INSTRUCTOR
            );
            return;
        }
        throw new AppException("lms.enrollment_forbidden", HttpStatus.FORBIDDEN);
    }
}
