package com.lucy.api.modules.identity.dtos.request.user;

import com.lucy.api.modules.identity.constants.user.UserConstants;
import jakarta.persistence.Column;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserCreationRequest {
    @Column(name = UserConstants.COL_EMAIL, nullable = false, unique = true)
    String email;

    @Column(name = UserConstants.COL_DISPLAY_NAME, nullable = false)
    String displayName;

    @Column(name = UserConstants.COL_PASSWORD_HASH)
    String passwordHash;
}
