package com.lucy.api.modules.identity.repository;

import com.lucy.api.modules.identity.entity.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile, String> {
    /**
     * UserProfile uses {@code id} as the userId via {@code @MapsId}.
     * Avoid derived queries like findByUserId() because {@code userId} is not a persistent attribute.
     */
    default Optional<UserProfile> findByUserId(String userId) {
        return findById(userId);
    }

    default boolean existsByUserId(String userId) {
        return existsById(userId);
    }
}
