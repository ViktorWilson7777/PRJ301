package com.lucy.api.modules.commerce.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConfirmPublicOrderPaymentRequest {
    @NotBlank(message = "common.field_required")
    String providerTransactionId;
}
