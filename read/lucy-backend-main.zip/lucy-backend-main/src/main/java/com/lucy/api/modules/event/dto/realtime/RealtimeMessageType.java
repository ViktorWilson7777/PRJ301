package com.lucy.api.modules.event.dto.realtime;

public enum RealtimeMessageType {
    LIKE_UPDATED,
    INTEREST_UPDATED,
    COMMENT_CREATED,
    PARTICIPANT_JOINED,
    PARTICIPANT_LEFT,
    MIC_TOGGLED,
    HAND_STATUS_CHANGED
}
