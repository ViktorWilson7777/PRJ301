package com.lucy.api.infrastructure.websocket.utils;

import java.util.UUID;

public final class SessionIdGenerator {

    private SessionIdGenerator() {
    }

    public static String generate() {
        return UUID.randomUUID().toString();
    }
}
