package com.lucy.api.modules.identity.service.interfaces;

import com.nimbusds.jose.JOSEException;
import com.lucy.api.modules.identity.dtos.request.auth.AppleAuthRequest;
import com.lucy.api.modules.identity.dtos.request.auth.AppleNotificationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.AuthenticationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.GoogleAuthRequest;
import com.lucy.api.modules.identity.dtos.request.auth.IntrospectRequest;
import com.lucy.api.modules.identity.dtos.request.auth.RefreshTokenRequest;
import com.lucy.api.modules.identity.dtos.request.auth.RegisterRequest;
import com.lucy.api.modules.identity.dtos.request.auth.ResendVerificationRequest;
import com.lucy.api.modules.identity.dtos.request.auth.VerifyEmailRequest;
import com.lucy.api.modules.identity.dtos.response.auth.AuthenticationResponse;
import com.lucy.api.modules.identity.dtos.response.auth.IntrospectResponse;

import java.text.ParseException;
import java.io.IOException;
import java.security.GeneralSecurityException;

public interface AuthenticationService {
    /**
     * authenticate
     * @author catsocute
     * @param request {AuthenticationRequest}
     * @return AuthenticationResponse
     */
    AuthenticationResponse authenticate(AuthenticationRequest request);

    /**
     * refresh token
     * @param request {RefreshTokenRequest}
     * @return AuthenticationResponse
     */
    AuthenticationResponse refreshToken(RefreshTokenRequest request) throws ParseException, JOSEException;

    /**
     * introspect token
     * @author catsocute
     * @param request {IntrospectRequest}
     * @return IntrospectResponse
     */
    IntrospectResponse introspect(IntrospectRequest request) throws ParseException;

    /**
     * authenticate with google id token
     * @param request {GoogleAuthRequest}
     * @return AuthenticationResponse
     */
    AuthenticationResponse authenticateWithGoogle(GoogleAuthRequest request) throws GeneralSecurityException, IOException;

    AuthenticationResponse authenticateWithApple(AppleAuthRequest request);

    void handleAppleServerNotification(AppleNotificationRequest request);

    /**
     * register new user
     * @param request {RegisterRequest}
     */
    void register(RegisterRequest request);

    void verifyEmail(VerifyEmailRequest request);

    void resendVerificationEmail(ResendVerificationRequest request);

    void logout(RefreshTokenRequest request) throws ParseException, JOSEException;
}
