package com.lucy.api.modules.lms.service.api;

import com.lucy.api.modules.lms.dto.request.CourseUpsertRequest;
import com.lucy.api.modules.lms.dto.response.CourseResponse;
import com.lucy.api.modules.lms.entity.Course;

import java.util.List;

public interface CourseService {
    CourseResponse create(CourseUpsertRequest request);

    CourseResponse createPublic(CourseUpsertRequest request);

    CourseResponse createForOrganization(String organizationId, CourseUpsertRequest request);

    List<CourseResponse> findAll(String programId);

    List<CourseResponse> findAllPublic(String programId);

    List<CourseResponse> findAllByOrganization(String organizationId, String programId);

    CourseResponse findById(String courseId);

    CourseResponse findPublicById(String courseId);

    CourseResponse findByOrganizationAndId(String organizationId, String courseId);

    CourseResponse update(String courseId, CourseUpsertRequest request);

    CourseResponse updatePublic(String courseId, CourseUpsertRequest request);

    CourseResponse updateForOrganization(String organizationId, String courseId, CourseUpsertRequest request);

    void delete(String courseId);

    void deletePublic(String courseId);

    void deleteForOrganization(String organizationId, String courseId);

    Course getEntityById(String courseId);
}
