package com.lucy.api.modules.organization.service;

import com.lucy.api.common.exceptions.AppException;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.identity.repository.UserRepository;
import com.lucy.api.modules.identity.service.impl.CurrentUserService;
import com.lucy.api.modules.organization.dto.request.OrganizationMembershipUpsertRequest;
import com.lucy.api.modules.organization.dto.request.OrganizationUpsertRequest;
import com.lucy.api.modules.organization.dto.response.OrganizationMembershipResponse;
import com.lucy.api.modules.organization.dto.response.OrganizationResponse;
import com.lucy.api.modules.organization.entity.Organization;
import com.lucy.api.modules.organization.entity.OrganizationMembership;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipRole;
import com.lucy.api.modules.organization.entity.enums.OrganizationMembershipStatus;
import com.lucy.api.modules.organization.entity.enums.OrganizationStatus;
import com.lucy.api.modules.organization.repository.OrganizationMembershipRepository;
import com.lucy.api.modules.organization.repository.OrganizationRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class OrganizationService {
    OrganizationRepository organizationRepository;
    OrganizationMembershipRepository organizationMembershipRepository;
    CurrentUserService currentUserService;
    UserRepository userRepository;
    OrganizationAccessService organizationAccessService;

    @Transactional
    public OrganizationResponse create(OrganizationUpsertRequest request) {
        validateCode(request.getCode(), null);
        Organization organization = new Organization();
        organization.setCode(request.getCode().trim());
        organization.setName(request.getName().trim());
        organization.setDescription(request.getDescription());
        organization.setLogoUrl(request.getLogoUrl());
        organization.setStatus(OrganizationStatus.ACTIVE);
        organization = organizationRepository.save(organization);

        User currentUser = currentUserService.getCurrentUser();
        OrganizationMembership membership = OrganizationMembership.builder()
                .organization(organization)
                .user(currentUser)
                .role(OrganizationMembershipRole.OWNER)
                .status(OrganizationMembershipStatus.ACTIVE)
                .joinedAt(Instant.now())
                .build();
        organizationMembershipRepository.save(membership);
        return toResponse(organization);
    }

    @Transactional(readOnly = true)
    public OrganizationResponse getById(String organizationId) {
        organizationAccessService.assertActiveMembership(organizationId);
        return toResponse(getEntityById(organizationId));
    }

    @Transactional
    public OrganizationResponse update(String organizationId, OrganizationUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN);
        Organization organization = getEntityById(organizationId);
        validateCode(request.getCode(), organizationId);
        organization.setCode(request.getCode().trim());
        organization.setName(request.getName().trim());
        organization.setDescription(request.getDescription());
        organization.setLogoUrl(request.getLogoUrl());
        return toResponse(organizationRepository.save(organization));
    }

    @Transactional(readOnly = true)
    public List<OrganizationMembershipResponse> getMembers(String organizationId) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN);
        return organizationMembershipRepository.findAllByOrganization_IdOrderByCreatedAtAsc(organizationId).stream()
                .map(this::toMembershipResponse)
                .toList();
    }

    @Transactional
    public OrganizationMembershipResponse addMember(String organizationId, OrganizationMembershipUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN);
        Organization organization = getEntityById(organizationId);
        User user = userRepository.findByIdAndDeletedAtIsNull(request.getUserId())
                .orElseThrow(() -> new AppException("auth.user_not_existed", HttpStatus.NOT_FOUND));
        OrganizationMembership membership = organizationMembershipRepository.findByOrganization_IdAndUser_Id(organizationId, request.getUserId())
                .orElseGet(() -> OrganizationMembership.builder()
                        .organization(organization)
                        .user(user)
                        .joinedAt(Instant.now())
                        .build());
        membership.setRole(request.getRole());
        membership.setStatus(request.getStatus() == null ? OrganizationMembershipStatus.ACTIVE : request.getStatus());
        return toMembershipResponse(organizationMembershipRepository.save(membership));
    }

    @Transactional
    public OrganizationMembershipResponse updateMember(String organizationId, String membershipId, OrganizationMembershipUpsertRequest request) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN);
        OrganizationMembership membership = organizationMembershipRepository.findByIdAndOrganization_Id(membershipId, organizationId)
                .orElseThrow(() -> new AppException("organization.membership_not_found", HttpStatus.NOT_FOUND));
        membership.setRole(request.getRole());
        if (request.getStatus() != null) {
            membership.setStatus(request.getStatus());
        }
        return toMembershipResponse(organizationMembershipRepository.save(membership));
    }

    @Transactional
    public void removeMember(String organizationId, String membershipId) {
        organizationAccessService.assertOrganizationRole(organizationId, OrganizationMembershipRole.OWNER, OrganizationMembershipRole.ADMIN);
        OrganizationMembership membership = organizationMembershipRepository.findByIdAndOrganization_Id(membershipId, organizationId)
                .orElseThrow(() -> new AppException("organization.membership_not_found", HttpStatus.NOT_FOUND));
        organizationMembershipRepository.delete(membership);
    }

    @Transactional(readOnly = true)
    public Organization getEntityById(String organizationId) {
        return organizationRepository.findByIdAndDeletedAtIsNull(organizationId)
                .orElseThrow(() -> new AppException("organization.not_found", HttpStatus.NOT_FOUND));
    }

    private void validateCode(String code, String currentId) {
        String normalizedCode = code.trim();
        boolean exists = currentId == null
                ? organizationRepository.existsByCodeIgnoreCase(normalizedCode)
                : organizationRepository.existsByCodeIgnoreCaseAndIdNot(normalizedCode, currentId);
        if (exists) {
            throw new AppException("organization.code_exists", HttpStatus.CONFLICT);
        }
    }

    private OrganizationResponse toResponse(Organization organization) {
        return OrganizationResponse.builder()
                .id(organization.getId())
                .code(organization.getCode())
                .name(organization.getName())
                .description(organization.getDescription())
                .logoUrl(organization.getLogoUrl())
                .status(organization.getStatus())
                .createdAt(organization.getCreatedAt())
                .updatedAt(organization.getUpdatedAt())
                .build();
    }

    private OrganizationMembershipResponse toMembershipResponse(OrganizationMembership membership) {
        return OrganizationMembershipResponse.builder()
                .id(membership.getId())
                .organizationId(membership.getOrganization().getId())
                .userId(membership.getUser().getId())
                .userEmail(membership.getUser().getEmail())
                .userDisplayName(membership.getUser().getProfile() != null ? membership.getUser().getProfile().getDisplayName() : null)
                .role(membership.getRole())
                .status(membership.getStatus())
                .joinedAt(membership.getJoinedAt())
                .createdAt(membership.getCreatedAt())
                .updatedAt(membership.getUpdatedAt())
                .build();
    }
}
