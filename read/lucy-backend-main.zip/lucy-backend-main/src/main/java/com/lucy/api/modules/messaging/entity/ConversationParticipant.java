package com.lucy.api.modules.messaging.entity;

import com.lucy.api.common.entity.BaseEntity;
import com.lucy.api.modules.identity.entity.User;
import com.lucy.api.modules.messaging.constant.ConversationParticipantConstants;
import com.lucy.api.modules.messaging.enums.ParticipantStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import lombok.experimental.SuperBuilder;

import java.time.Instant;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = ConversationParticipantConstants.TABLE)
public class ConversationParticipant extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = ConversationParticipantConstants.COL_CONVERSATION_ID, nullable = false)
    Conversation conversation;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = ConversationParticipantConstants.COL_USER_ID, nullable = false)
    User user;

    @Enumerated(EnumType.STRING)
    @Column(name = ConversationParticipantConstants.COL_STATUS, nullable = false, length = 20)
    ParticipantStatus status = ParticipantStatus.ACTIVE;

    @Column(name = ConversationParticipantConstants.COL_JOINED_AT, nullable = false)
    Instant joinedAt;

    @Column(name = ConversationParticipantConstants.COL_LEFT_AT)
    Instant leftAt;
}
